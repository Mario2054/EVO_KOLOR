#pragma once
/*
  ================================================================
  EVO4 MULTI - konfiguracja dla Arduino IDE
  Wersja: APMS NATIVE480 HQ FULL ARDUINO C6 EQ16
  ================================================================

  W Arduino IDE nie ma środowisk kompilacji jak w PlatformIO, dlatego
  panel wybierasz tutaj jedną liczbą.

  EVO4_PANEL_SELECT:
    1 = TFT ILI9488 480x320  - panel zastosowany w EVO4
    2 = TFT ILI9341 320x240  - nowe panele kolorowe EVO4 Multi
    3 = OLED SSD1322 256x64  - stare panele EVO3 1:1
    4 = OLED SH1122 256x64   - stare panele EVO3 1:1
    5 = TFT ST7796 480x320   - panel EVO4

  Po zmianie panelu zapisz plik i kompiluj ponownie.
*/

#ifndef EVO_BUILD_ARDUINO_IDE
  #define EVO_BUILD_ARDUINO_IDE 1
#endif


// ------------------------------------------------------------------
// EVO4 MULTI - WYBOR WERSJI PRZED KOMPILACJA
// ------------------------------------------------------------------
// 1 = FULL: wszystkie funkcje aktywne, bez kodow licencji
// 0 = LICENSED: licencje RADIO, C6EQ, DSP, NV3007 i BTTX
//     sa przechowywane centralnie w NVS glownego ESP32-S3.
#ifndef EVO4_BUILD_FULL
  #define EVO4_BUILD_FULL 1
#endif


// Stabilny tryb odtwarzania plikow SD/USB. Biblioteka Audio nie jest wywolywana
// jednoczesnie z osobnego tasku podczas PLAY/STOP/zmiany utworu.
#ifndef EVO_RTOS_AUDIO_TASK
  #define EVO_RTOS_AUDIO_TASK 0
#endif

// LED obslugiwane przez istniejacy fallback w loop() co 25 ms.
// Oszczedza 3 KB stosu wewnetrznego RAM potrzebnego dla DLNA/Audio4.
#ifndef EVO_RTOS_CONTROL_TASK
  // Zadanie WS2812 jest odseparowane od sterowania PLAY/STOP i TFT.
  // Gdy brak pamieci, automatyczny fallback w loop() pozostaje aktywny.
  #define EVO_RTOS_CONTROL_TASK 1
#endif

#ifndef EVO_RTOS_GPIO16_TASK
  // Sekwencja GPIO16 dziala rowniez przy blokujacej inicjalizacji Wi-Fi.
  #define EVO_RTOS_GPIO16_TASK 1
#endif
#ifndef EVO_RTOS_CONTROL_CORE
  #define EVO_RTOS_CONTROL_CORE 1
#endif
#ifndef EVO_RTOS_CONTROL_PRIORITY
  #define EVO_RTOS_CONTROL_PRIORITY 1
#endif
#ifndef EVO_RTOS_CONTROL_STACK
  #define EVO_RTOS_CONTROL_STACK 3072
#endif

// ESP32-S3 / Arduino-ESP32 3.3.x: wejscie w light sleep przy aktywnych
// zadaniach audio/TFT potrafi zakleszczyc mechanizm IPC miedzy rdzeniami
// (reset TG1WDT_SYS_RST). Domyslnie standby pracuje jako bezpieczna petla
// RTOS z delay(), nadal wygaszajac ekran i wyjscie GPIO16.
#ifndef EVO_STANDBY_USE_LIGHT_SLEEP
  #define EVO_STANDBY_USE_LIGHT_SLEEP 0
#endif

// ------------------------------------------------------------------
// WYBÓR PANELU
// ------------------------------------------------------------------
#ifndef EVO4_PANEL_SELECT
  #define EVO4_PANEL_SELECT 5
#endif


// ------------------------------------------------------------------
// NATIVE 480x320 HQ - cala grafika i tekst
// ------------------------------------------------------------------
// 1 = geometria wszystkich paneli jest rysowana od razu w 480x320.
// Brak koncowego skalowania gotowej klatki 320x240.
#ifndef EVO_TFT_NATIVE_HQ_GEOMETRY
  #define EVO_TFT_NATIVE_HQ_GEOMETRY 1
#endif
// 1 = osobne, czytelniejsze fonty U8g2 dla natywnego TFT.
#ifndef EVO_TFT_NATIVE_HQ_TEXT
  #define EVO_TFT_NATIVE_HQ_TEXT 1
#endif

// ------------------------------------------------------------------
// HQ LOGO / OKLADKI NA TFT
// ------------------------------------------------------------------
// 1 = po narysowaniu UI obraz 160x160 jest skalowany biliniowo bezposrednio
//     na fizyczny TFT. Daje wyraznie lepsza jakosc na ST7796/ILI9488 480x320.
#ifndef EVO_TFT_HQ_ARTWORK_OVERLAY
  #define EVO_TFT_HQ_ARTWORK_OVERLAY 1
#endif
// iTunes zwraca domyslnie artworkUrl100. Program podnosi go do 300x300.
#ifndef EVO_ARTWORK_ITUNES_SIDE
  #define EVO_ARTWORK_ITUNES_SIDE 300
#endif
// Limit pojedynczego pliku JPEG/PNG. Bufor jest w PSRAM.
#ifndef EVO_ARTWORK_DOWNLOAD_MAX
  #define EVO_ARTWORK_DOWNLOAD_MAX (512 * 1024)
#endif

#if EVO4_PANEL_SELECT == 1
  #define EVO_PANEL_ILI9488
  #define EVO_TFT_NATIVE_UI 1
  #define EVO_TFT_NATIVE_ALL_SCREENS 1
  #define EVO_TFT_NATIVE_DOUBLE_BUFFER 1
  #define EVO_TFT_NATIVE_DELTA_RENDER 1
  #define EVO_TFT_SPI_FREQ 27000000
  #define EVO_TFT_INVERT false
  #define EVO_AUDIO_SAFE_FRAME_MS 110
  #define EVO_AUDIO_SAFE_MENU_FRAME_MS 180
#elif EVO4_PANEL_SELECT == 2
  #define EVO_PANEL_ILI9341
  #define EVO_TFT_NATIVE_UI 1
  #define EVO_TFT_NATIVE_ALL_SCREENS 1
  #define EVO_TFT_NATIVE_DOUBLE_BUFFER 1
  #define EVO_TFT_NATIVE_DELTA_RENDER 1
  #define EVO_TFT_SPI_FREQ 27000000
  #define EVO_AUDIO_SAFE_FRAME_MS 95
  #define EVO_AUDIO_SAFE_MENU_FRAME_MS 160
#elif EVO4_PANEL_SELECT == 3
  #define EVO_PANEL_SSD1322
  #define EVO_TFT_NATIVE_UI 0
  #define EVO_LGFX_SCALE_TO_PANEL 0
  #define EVO_SSD1322_USE_U8G2_FALLBACK 1
  #define EVO_STANDBY_CLOCK_ALWAYS_AFTER_POWER_OFF 0
  #define EVO_TFT_SPI_FREQ 18000000
#elif EVO4_PANEL_SELECT == 4
  #define EVO_PANEL_SH1122
  #define EVO_TFT_NATIVE_UI 0
  #define EVO_LGFX_SCALE_TO_PANEL 0
  #define EVO_SSD1322_USE_U8G2_FALLBACK 1
  #define EVO_STANDBY_CLOCK_ALWAYS_AFTER_POWER_OFF 0
  #define EVO_TFT_SPI_FREQ 18000000
#elif EVO4_PANEL_SELECT == 5
  // ST7796 korzysta z tego samego layoutu 480x320 co ILI9488.
  // EVO_PANEL_ST7796 wybiera sterownik, a znacznik ILI9488 zachowuje UI EVO4.
  #define EVO_PANEL_ILI9488
  #define EVO_PANEL_ST7796
  // Tryb ST7796 jest opcjonalny; jego kolejnosc kanalow dobierz osobno.
  #define EVO_TFT_NATIVE_UI 1
  #define EVO_TFT_NATIVE_ALL_SCREENS 1
  #define EVO_TFT_NATIVE_DOUBLE_BUFFER 1
  #define EVO_TFT_NATIVE_DELTA_RENDER 1
  #define EVO_TFT_SPI_FREQ 27000000
  #define EVO_TFT_INVERT false
  #define EVO_AUDIO_SAFE_FRAME_MS 110
  #define EVO_AUDIO_SAFE_MENU_FRAME_MS 180
#else
  #error "Nieprawidłowy EVO4_PANEL_SELECT. Ustaw 1, 2, 3, 4 albo 5."
#endif


// ------------------------------------------------------------------
// USB HOST / VBUS
// ------------------------------------------------------------------
// ESP32-S3 host USB korzysta ze stalych pinow: D- GPIO19, D+ GPIO20.
// Generic ESP32S3 Dev Module NIE wlacza 5 V VBUS programowo.
// Jesli Twoja plytka ma tranzystor/przelacznik 5 V sterowany GPIO, wpisz pin.
// -1 = VBUS jest zasilany sprzetowo i program niczym nim nie steruje.
#ifndef EVO_USB_VBUS_EN_PIN
  #define EVO_USB_VBUS_EN_PIN -1
#endif
#ifndef EVO_USB_VBUS_EN_ACTIVE
  #define EVO_USB_VBUS_EN_ACTIVE HIGH
#endif

// ------------------------------------------------------------------
// AKTYWNE FUNKCJE NA TEN ETAP PROJEKTU
// ------------------------------------------------------------------
#define EVO_FEATURE_WIFI_WEB              1
#define EVO_FEATURE_SD_PLAYER_WEB         1
#define EVO_FEATURE_SD_RECORDER_WEB       1
#define EVO_FEATURE_EXTERNAL_ANALYZER_WEB 1
#define EVO_FEATURE_C6_EQ16_WEB           1

// Odłożone na później. Strony techniczne mogą zostać jako ukryte,
// ale aktywne sterowanie nie pracuje w aktualnym etapie.
#define EVO_FEATURE_DLNA_WEB              1


// ------------------------------------------------------------------
// Opcjonalne podświetlenie TFT
// ------------------------------------------------------------------
// Jeżeli LED/BL ekranu masz podłączony do GPIO ESP32-S3, wpisz tu pin.
// Przykład:
//   #define EVO_TFT_BL 45
//   #define EVO_TFT_BL_INVERT false
