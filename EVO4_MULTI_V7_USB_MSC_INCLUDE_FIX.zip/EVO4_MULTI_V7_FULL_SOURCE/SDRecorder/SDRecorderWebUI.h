#pragma once
#include <Arduino.h>

static const char SDRECORDER_HTML[] PROGMEM = R"HTML(
<!doctype html><html lang="pl"><head><style id="evo4-unified-theme">:root{--evo-bg:#06111f;--evo-card:#081827;--evo-border:#1a344b;--evo-blue:#008cff;--evo-cyan:#29c7ff}html,body{color-scheme:dark}body{background:#06111f!important;color:#e9f2ff!important;font-family:'Segoe UI',Arial,sans-serif!important}button,input,select{font-family:inherit}button{cursor:pointer}button:hover{filter:brightness(1.16)}.evo4-return{position:fixed;right:18px;top:16px;z-index:99999;display:flex;align-items:center;gap:9px;padding:9px 15px 9px 10px;border-radius:30px;background:linear-gradient(135deg,#004a9b,#008cff 55%,#003a7a);border:1px solid #29c7ff;box-shadow:0 0 12px #008cff77;color:white!important;text-decoration:none!important;font:bold 13px 'Segoe UI',Arial,sans-serif;letter-spacing:.2px}.evo4-return .evo4-arrow{display:grid;place-items:center;width:32px;height:32px;border-radius:50%;background:#061b38;border:1px solid #7edbff;font-size:25px;line-height:1}.evo4-return:hover{box-shadow:0 0 20px #008cffb0;transform:translateY(-1px)}@media(max-width:600px){.evo4-return{right:8px;top:8px;padding:6px 10px}.evo4-return .evo4-arrow{width:26px;height:26px;font-size:21px}}</style><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1">
<title>EVO4 MULTI SD / USB RECORDER</title>
<style>
:root{--c:#00bfff;--b:#086acb;--y:#ffd900;--g:#20ef37;--r:#ff3131;--bg:#020508;--line:#087faf;--mut:#9eb0bf}*{box-sizing:border-box}html,body{margin:0;min-height:100%;background:#020305;color:#eef7ff;font-family:Consolas,"Courier New",monospace}body{padding:8px}.deck{width:min(930px,100%);margin:auto;background:#010305;border:2px solid #00bff0;border-radius:19px;padding:6px;box-shadow:0 0 18px #008ed766,inset 0 0 16px #001521}.inner{border:1px solid #17455f;border-radius:13px;padding:5px}.top{height:58px;border:1px solid #00bff0;border-radius:15px;display:grid;grid-template-columns:210px 1fr 180px;align-items:center;padding:3px 14px;background:linear-gradient(#0c1821,#020507)}.brand{font:900 35px/1 Arial;letter-spacing:-2px;text-shadow:0 2px #59656c}.brand small{font:700 12px Consolas;color:var(--c);letter-spacing:0}.head{text-align:center}.head b{display:block;color:var(--c);font-size:18px}.head span{font-size:12px}.dsp{font-size:12px;color:var(--g);position:relative}.vu{position:absolute;right:0;bottom:0;display:flex;align-items:flex-end;gap:2px;height:24px}.vu i{width:6px;background:linear-gradient(to top,#f00,#ff0 45%,#00e43a 75%,#5d4dff)}.titlebar{height:31px;margin-top:5px;padding:7px 10px;background:linear-gradient(#0e80dc,#004184);border:1px solid #2a9be6;border-radius:4px;font-size:12px;box-shadow:inset 0 0 8px #4fc3ff55;position:relative}.close{position:absolute;right:5px;top:4px;border:1px solid #76cfff;background:#064e91;color:#fff;border-radius:4px;width:21px;height:21px;line-height:18px;text-align:center}.controls{display:grid;grid-template-columns:52px 76px 52px 52px 52px 63px 1fr;gap:4px;margin:5px 0}.btn,.vol{height:52px;border:1px solid #8293a1;border-radius:7px;background:linear-gradient(#47525d,#161d24 51%,#05080b);color:#fff;box-shadow:inset 0 0 7px #000;cursor:pointer}.btn{padding:3px}.btn .ico{font:bold 20px/23px Arial}.btn .txt{font-size:8px}.btn.play{border:2px solid var(--y)}.btn.play .ico,.btn.eq .ico{color:var(--y)}.btn:hover,.btn.remote-active{background:linear-gradient(#1ba9f4,#07538c 58%,#031c2f);border-color:#fff;box-shadow:0 0 10px #00bfff}.vol{padding:7px 10px;font-size:9px}.volrow{display:flex;align-items:center;gap:5px;margin-top:7px}.vol input{width:100%;accent-color:var(--y)}.content{display:grid;grid-template-columns:32% 30% 38%;border:1px solid var(--line);height:260px}.pane{padding:6px;border-right:1px solid var(--line);min-width:0;overflow:hidden}.pane:last-child{border-right:0}.cassette{height:137px;border:1px solid #607283;border-radius:5px;background:linear-gradient(155deg,#26333d,#080b0e 55%,#121920);position:relative;overflow:hidden;box-shadow:inset 0 0 13px #000}.cassette:before{content:"A";position:absolute;left:7px;top:5px;color:#00bfff;font-size:15px}.reels{display:flex;justify-content:space-around;padding:28px 26px 0}.reel{width:57px;height:57px;border:6px double #008de0;border-radius:50%;background:repeating-conic-gradient(#196993 0 12deg,#06131d 12deg 25deg);box-shadow:0 0 8px #008de0,inset 0 0 5px #001626;position:relative}.reel:after{content:"";position:absolute;inset:15px;border:4px solid #15191d;border-radius:50%;background:#262b30}.playing .reel{animation:spin 4.8s linear infinite}@keyframes spin{to{transform:rotate(-360deg)}}.cassette .basf{position:absolute;left:13px;bottom:17px;font:bold 12px Arial;color:#e7ebef}.cassette .c90{position:absolute;right:10px;bottom:17px;font:bold 13px Arial;color:#00a9ff}.cassette .type{position:absolute;right:9px;bottom:6px;font:6px Arial;color:#ffd800}.cassette:after{content:"";position:absolute;left:19%;right:19%;bottom:6px;height:25px;border:1px solid #657686;background:#0c1217;clip-path:polygon(12% 0,88% 0,100% 100%,0 100%)}.time{font-size:13px;color:var(--c);margin:7px 0 4px}.progress{height:7px;border:1px solid #708494;border-radius:5px;background:#05080a;overflow:hidden}.progress i{display:block;height:100%;width:0;background:#0d8ee8}.tags{display:grid;grid-template-columns:repeat(4,1fr);gap:3px;margin-top:5px}.tag{font-size:7px;border:1px solid #435766;border-radius:3px;padding:3px;text-align:center}.meta label{display:block;color:var(--c);font-size:8px}.meta .v{font-size:10px;padding:3px 0 6px;border-bottom:1px dotted #556571;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.eq{height:38px;display:flex;align-items:flex-end;gap:2px;margin-top:4px}.eq i{width:4px;min-height:2px;background:linear-gradient(to top,#12d118 0 56%,#ffe000 57% 83%,#ff3c00 84%)}.listhead{display:flex;justify-content:space-between;align-items:center;color:var(--c);font-size:9px}.delbtn{border:1px solid #ff5757;border-radius:4px;background:linear-gradient(#8b1818,#300606);color:#fff;font:700 8px Consolas;padding:4px 7px;cursor:pointer}.delbtn:disabled{opacity:.35;cursor:not-allowed}.delbtn:not(:disabled):hover{background:linear-gradient(#e72d2d,#710b0b);box-shadow:0 0 7px #ff3030}.path{height:25px;padding:5px 3px;border-top:1px solid #334a5a;border-bottom:1px solid #334a5a;color:var(--c);font-size:9px;white-space:nowrap;overflow:hidden}.files{height:211px;overflow-y:auto;padding:2px}.file{font-size:9px;padding:4px;border-radius:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;cursor:pointer}.file.sel,.file:hover{background:linear-gradient(90deg,#0c78d3,#034f9a)}.status{height:29px;border:1px solid var(--line);border-top:0;display:grid;grid-template-columns:1fr 1fr 1fr 1fr;align-items:center;padding:0 10px;font-size:9px}.status span:nth-child(1),.status span:nth-child(2){color:var(--g)}.status span:nth-child(3){color:var(--y);text-align:center}.status span:last-child{color:var(--y);text-align:right}.keys{height:28px;border:1px solid var(--line);border-top:0;display:grid;grid-template-columns:repeat(9,1fr);align-items:center}.keys span{text-align:center;font-size:7px;border-right:1px solid #17384d}.keys b{color:var(--c)}.keys .back b{color:var(--g)}.menu{display:block;margin-top:5px;padding:8px;border:1px solid var(--g);border-radius:5px;text-align:center;color:#fff;text-decoration:none;font:bold 11px Arial;background:linear-gradient(#16431f,#06160a)}
@media(max-width:700px){body{padding:2px}.deck{border-radius:8px;padding:3px}.top{grid-template-columns:120px 1fr 90px}.brand{font-size:24px}.controls{grid-template-columns:repeat(6,1fr)}.vol{grid-column:1/-1}.content{grid-template-columns:1fr;height:auto}.pane{border-right:0;border-bottom:1px solid var(--line)}.files{height:220px}.keys{height:auto;grid-template-columns:repeat(3,1fr)}.keys span{padding:5px}.status{grid-template-columns:repeat(2,1fr);height:auto;padding:5px}}
</style></head><body><a class="evo4-return" href="/" aria-label="Powrót do głównej strony EVO4 MULTI"><span class="evo4-arrow">↶</span><span>POWRÓT DO MENU</span></a><div class="deck" id="app"><div class="inner"><div class="top"><div class="brand">EVO4 <small>MULTI</small></div><div class="head"><b>SD / USB RECORDER</b><span id="topTitle">Radio Italo 4 You</span></div><div class="dsp">DSP&nbsp;&nbsp;&nbsp;OK<br>C6<div class="vu"><i style="height:5px"></i><i style="height:7px"></i><i style="height:9px"></i><i style="height:11px"></i><i style="height:13px"></i><i style="height:15px"></i><i style="height:17px"></i><i style="height:19px"></i><i style="height:21px"></i><i style="height:23px"></i></div></div></div><div class="titlebar">EVO4 MULTI RECORDER SD / USB <span class="close">×</span></div><div class="controls"><button id="btnPlayer" class="btn" onclick="location.href='/sdplayer'"><div class="ico">◀◀</div><div class="txt">PLAYER</div></button><button id="btnRec" class="btn play" onclick="toggleRec()"><div class="ico" style="color:#ff3333">●</div><div class="txt">RECORD</div></button><button id="btnStop" class="btn" onclick="cmd('stop')"><div class="ico">■</div><div class="txt">STOP</div></button><button id="btnFiles" class="btn" onclick="location.href='/files'"><div class="ico">▶▶</div><div class="txt">FILES</div></button><button id="btnList" class="btn" onclick="document.getElementById('files').scrollIntoView({behavior:'smooth'})"><div class="ico">☷</div><div class="txt">LIST</div></button><button id="btnEq" class="btn eq" onclick="location.href='/eq16'"><div class="ico">EQ</div><div class="txt">EQUALIZER</div></button><div class="vol">RECORD LEVEL<div class="volrow"><span>−</span><input type="range" min="0" max="100" value="75"><span>+</span></div></div></div><div class="content"><section class="pane"><div class="cassette"><div class="reels"><div class="reel"></div><div class="reel"></div></div><span class="basf">BASF</span><span class="c90">90</span><span class="type">CHROME SUPER II</span></div><div class="time"><span style="color:#ff3030">●</span> <span id="ct">00:00:00</span></div><div class="progress"><i id="prog" style="background:#ed2828"></i></div><div class="tags"><span class="tag">MP3</span><span class="tag" id="size">0 B</span><span class="tag">STREAM</span><span class="tag">STEREO</span></div></section><section class="pane meta"><label>ŹRÓDŁO / STACJA</label><div class="v" id="station">-</div><label>TYTUŁ UTWORU</label><div class="v" id="song">-</div><label>WYKONAWCA</label><div class="v" id="artist">-</div><label>PLIK</label><div class="v" id="fname">-</div><div class="eq" id="eq"></div></section><section class="pane"><div class="listhead"><span>NAGRANIA</span><span id="cnt">SD / USB</span><button id="btnDelete" class="delbtn" type="button" disabled>USUŃ PLIK</button></div><div class="path">♫ /RECORDINGS/</div><div class="files" id="files"><div class="file sel" id="currentFile">Brak aktywnego nagrania</div><div class="file">Nagrania zapisywane na karcie SD</div><div class="file">USB po uruchomieniu hosta USB</div></div></section></div><div class="status"><span>SD CARD</span><span id="state">READY</span><span id="bytes">0 B</span><span>RECORDER</span></div><div class="keys"><span><b>5 / OK</b> REC</span><span><b>0</b> STOP</span><span><b>7</b> LISTA</span><span><b>8</b> EQ</span><span><b>VOL±</b> LEVEL</span><span><b>SD</b> ZAPIS</span><span><b>USB</b> GOTOWE</span><span class="back"><b>BACK</b> POWRÓT</span><span><b>MENU</b></span></div><a class="menu" href="/menu">⌂ POWRÓT DO MENU GŁÓWNEGO EVO4 MULTI</a></div></div><script>
const $=id=>document.getElementById(id);
const nasBar=document.createElement('div');
nasBar.style.cssText='padding:9px 12px;border-top:1px solid #087faf;font:12px Consolas;color:#9eb0bf';
nasBar.innerHTML='<a href="/sdrecorder/nas" style="color:#00bfff">NAS / WebDAV - ustawienia</a> &nbsp; <button type="button" onclick="location.href=\'/dlna?recordings=1\'" style="background:#075d7e;color:#fff;border:1px solid #20c7e9;border-radius:5px;padding:6px 9px">OTWORZ RECORDINGS NA SERWERZE</button> &nbsp; <button id="nasRetry" type="button">Wyslij zaznaczony ponownie</button> &nbsp; <span id="nasState">NAS: ...</span>';
document.querySelector('.deck').appendChild(nasBar);
async function refreshNas(){try{let r=await fetch('/sdrecorder/nas/status',{cache:'no-store'}),s=await r.json();$('nasState').textContent='NAS: '+s.detail+(s.http?' (HTTP '+s.http+')':'');$('nasRetry').disabled=!selectedPath||s.busy||!s.enabled}catch(e){$('nasState').textContent='NAS: brak statusu'}}
$('nasRetry').addEventListener('click',async()=>{if(!selectedPath)return;try{let r=await fetch('/sdrecorder/nas/retry',{method:'POST',body:new URLSearchParams({path:selectedPath})});if(!r.ok)alert(await r.text());else refreshNas()}catch(e){alert('Blad sieci NAS')} });
refreshNas();setInterval(refreshNas,3000);
for(let i=0;i<28;i++){
  let b=document.createElement('i');
  b.style.height=(4+(i*7)%33)+'px';
  $('eq').appendChild(b);
}
let active=false;
let selectedPath='';
let selectedName='';

function setSelected(path,name){
  selectedPath=path||'';
  selectedName=name||'';
  const del=$('btnDelete');
  if(del) del.disabled=!selectedPath;
}

function renderRecordings(items){
  const box=$('files');
  if(!box||!Array.isArray(items))return;
  box.innerHTML='';
  if(!items.length){
    setSelected('','');
    let e=document.createElement('div');
    e.className='file';
    e.textContent='Brak nagrań w /RECORDINGS';
    box.appendChild(e);
    $('cnt').textContent='0 plików';
    return;
  }

  let stillExists=items.some(x=>(x.path||'')===selectedPath);
  if(!stillExists) setSelected(items[0].path||'',items[0].name||'');

  items.forEach((x,i)=>{
    let e=document.createElement('div');
    const path=x.path||'';
    const name=x.name||'';
    e.className='file'+(path===selectedPath?' sel':'');
    e.textContent='♫ '+name+'  ('+formatBytes(x.size||0)+')';
    e.title=path||name;
    e.addEventListener('click',()=>{
      setSelected(path,name);
      document.querySelectorAll('#files .file').forEach(n=>n.classList.remove('sel'));
      e.classList.add('sel');
    });
    box.appendChild(e);
  });
  $('cnt').textContent=items.length+' plików';
}

function formatBytes(v){
  v=Number(v)||0;
  if(v<1024)return v+' B';
  if(v<1048576)return (v/1024).toFixed(1)+' KB';
  return (v/1048576).toFixed(1)+' MB';
}

async function loadRecordings(){
  try{
    let r=await fetch('/sdrecorder/api/list?t='+Date.now(),{cache:'no-store'});
    if(!r.ok)throw new Error('HTTP '+r.status);
    let d=await r.json();
    renderRecordings(d.items||[]);
  }catch(e){
    const box=$('files');
    if(box)box.innerHTML='<div class="file">Błąd odczytu listy SD</div>';
  }
}

async function deleteSelected(){
  if(!selectedPath)return;
  if(active && selectedPath===($('fname').textContent||'')){
    alert('Nie można usunąć pliku podczas nagrywania. Najpierw naciśnij STOP.');
    return;
  }
  if(!confirm('Usunąć plik?\n'+selectedName))return;

  const del=$('btnDelete');
  del.disabled=true;
  try{
    let r=await fetch('/sdrecorder/api/delete?path='+encodeURIComponent(selectedPath),{cache:'no-store'});
    let d=await r.json();
    if(!r.ok||!d.ok)throw new Error(d.msg||('HTTP '+r.status));
    setSelected('','');
    await loadRecordings();
  }catch(e){
    alert('Nie udało się usunąć pliku: '+e.message);
  }finally{
    del.disabled=!selectedPath;
  }
}

function fmt(s){
  s=Math.max(0,Number(s)||0);
  return String(Math.floor(s/3600)).padStart(2,'0')+':'+String(Math.floor(s/60)%60).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0');
}
async function cmd(c){
  try{
    const r=await fetch('/sdrecorder/api/'+c+'?t='+Date.now(),{cache:'no-store'});
    const d=await r.json();
    if(!r.ok||d.ok===false)throw new Error(d.msg||('HTTP '+r.status));
  }catch(e){alert('Błąd Recordera: '+e.message);}
  setTimeout(load,100);
  setTimeout(loadRecordings,350);
}
async function toggleRec(){await cmd(active?'stop':'start')}
async function load(){
  try{
    let r=await fetch('/sdrecorder/api/status?t='+Date.now(),{cache:'no-store'}),d=await r.json();
    active=!!d.active;
    document.body.classList.toggle('playing',active);
    let bm={3:'btnStop',5:'btnList',6:'btnEq',7:'btnRec',8:'btnPlayer'};
    document.querySelectorAll('.remote-active').forEach(x=>x.classList.remove('remote-active'));
    if(bm[d.button]&&$(bm[d.button]))$(bm[d.button]).classList.add('remote-active');
    $('state').textContent=active?'RECORDING':(d.msg||'READY');
    $('ct').textContent=fmt(d.seconds);
    $('size').textContent=d.size||'0 B';
    $('bytes').textContent=d.size||'0 B';
    $('station').textContent=d.station||'-';
    $('song').textContent=d.title||'-';
    $('artist').textContent=d.artist||'-';
    $('fname').textContent=d.file||'-';
    const currentFileEl=$('currentFile');
    if(currentFileEl) currentFileEl.textContent=d.file||'Brak aktywnego nagrania';
    $('topTitle').textContent=d.title||d.station||'EVO4 MULTI';
    $('prog').style.width=(Number(d.seconds||0)%100)+'%';
    [...$('eq').children].forEach((b,i)=>b.style.height=(active?(4+((i*11+Date.now()/90)%34)):4)+'px');
  }catch(e){
    $('state').textContent='BRAK POŁĄCZENIA';
  }
}
$('btnDelete').addEventListener('click',deleteSelected);
load();
loadRecordings();
setInterval(load,700);
setInterval(loadRecordings,3000);
</script></body></html>
)HTML";
