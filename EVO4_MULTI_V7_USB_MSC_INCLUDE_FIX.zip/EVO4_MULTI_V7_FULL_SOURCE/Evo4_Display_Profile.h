#pragma once
/*
  ============================================================================
  EVO4 MULTI - universal display profile
  APMS FULL 2026-05-22

  Zasada projektu:
    OLED SSD1322 / SH1122  -> stare panele EVO3, 256x64, bez przebudowy wygladu
    TFT ILI9341 / ILI9488  -> nowe kolorowe panele EVO4 Multi

  Ten plik nie rysuje paneli. On pilnuje konfiguracji kompilacji, zeby
  przypadkiem nie wlaczyc dwoch ekranow naraz albo natywnego TFT UI dla OLED.
  ============================================================================
*/

#ifndef EVO4_DISPLAY_BASE
  #define EVO4_DISPLAY_BASE 1
#endif

#ifndef EVO4_DISPLAY_BASE_REV
  #define EVO4_DISPLAY_BASE_REV "2026-05-22-FULL"
#endif

// Gdy projekt zostanie skompilowany bez wyboru panelu, zachowujemy zgodnosc
// ze starym EVO3 i startujemy jako OLED SSD1322.
#if !defined(EVO_PANEL_SSD1322) && !defined(EVO_PANEL_SH1122) && !defined(EVO_PANEL_ILI9341) && !defined(EVO_PANEL_ILI9488)
  #define EVO_PANEL_SSD1322
#endif

#if (defined(EVO_PANEL_SSD1322) + defined(EVO_PANEL_SH1122) + defined(EVO_PANEL_ILI9341) + defined(EVO_PANEL_ILI9488)) != 1
  #error "Wybierz dokladnie jeden panel: EVO_PANEL_SSD1322, EVO_PANEL_SH1122, EVO_PANEL_ILI9341 albo EVO_PANEL_ILI9488"
#endif

#if defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)
  #ifndef EVO_DISPLAY_TFT
    #define EVO_DISPLAY_TFT 1
  #endif
  #ifndef EVO_DISPLAY_OLED
    #define EVO_DISPLAY_OLED 0
  #endif
  #ifndef EVO_TFT_NATIVE_UI
    #define EVO_TFT_NATIVE_UI 1
  #endif
  #ifndef EVO_TFT_NATIVE_ALL_SCREENS
    #define EVO_TFT_NATIVE_ALL_SCREENS 1
  #endif
  #ifndef EVO4_TFT_EVO4_PANELS
    #define EVO4_TFT_EVO4_PANELS 1
  #endif
  #ifndef EVO4_OLED_LEGACY_PANELS
    #define EVO4_OLED_LEGACY_PANELS 0
  #endif
#else
  #ifndef EVO_DISPLAY_TFT
    #define EVO_DISPLAY_TFT 0
  #endif
  #ifndef EVO_DISPLAY_OLED
    #define EVO_DISPLAY_OLED 1
  #endif
  #ifndef EVO_TFT_NATIVE_UI
    #define EVO_TFT_NATIVE_UI 0
  #endif
  #ifndef EVO_TFT_NATIVE_ALL_SCREENS
    #define EVO_TFT_NATIVE_ALL_SCREENS 0
  #endif
  #ifndef EVO_LGFX_SCALE_TO_PANEL
    #define EVO_LGFX_SCALE_TO_PANEL 0
  #endif
  #ifndef EVO4_TFT_EVO4_PANELS
    #define EVO4_TFT_EVO4_PANELS 0
  #endif
  #ifndef EVO4_OLED_LEGACY_PANELS
    #define EVO4_OLED_LEGACY_PANELS 1
  #endif
#endif

#if EVO_DISPLAY_OLED && EVO_TFT_NATIVE_UI
  #error "OLED ma uzywac starych paneli EVO3. Ustaw EVO_TFT_NATIVE_UI=0 dla SSD1322/SH1122."
#endif

#if EVO_DISPLAY_TFT && !EVO_TFT_NATIVE_UI
  // To jest dopuszczalne jako tryb zgodnosci, ale glowny wariant TFT EVO4
  // powinien miec EVO_TFT_NATIVE_UI=1.
#endif

#if defined(EVO_PANEL_ST7796)
  #define EVO4_DISPLAY_NAME "TFT ST7796 480x320 - EVO4 Multi"
#elif defined(EVO_PANEL_ILI9488)
  #define EVO4_DISPLAY_NAME "TFT ILI9488 480x320 - EVO4 Multi"
#elif defined(EVO_PANEL_ILI9341)
  #define EVO4_DISPLAY_NAME "TFT ILI9341 320x240 - EVO4 Multi"
#elif defined(EVO_PANEL_SH1122)
  #define EVO4_DISPLAY_NAME "OLED SH1122 256x64 - EVO3 legacy"
#else
  #define EVO4_DISPLAY_NAME "OLED SSD1322 256x64 - EVO3 legacy"
#endif
