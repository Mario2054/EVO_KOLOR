#pragma once
#include <Arduino.h>

// ================================================================
// EVO4 MULTI / APMS - most EQ16 -> ESP32-C6 DSP po UART
// ---------------------------------------------------------------
// Ten plik jest dolaczany PO funkcjach widmoSend()/widmoEnsureUart()
// i PO tablicy evo43Eq16[]. Wykorzystuje ten sam UART1 RX18/TX17,
// ale NIE uruchamia procedury widmoSetUart(true), bo ona wysyla
// komendy analizatora (PING, STYLE, WIDSENS...), ktorych ESP32-C6 EQ
// nie rozumie.
//
// Komendy zgodne z APMS_C6_EQ16_EVO4_UART:
//   HELP / STATUS / FREQ / SAVE / LOAD / RESET
//   EQ ON / EQ OFF
//   BYPASS ON / BYPASS OFF
//   RAW ON / RAW OFF
//   LIMITER ON / LIMITER OFF
//   BAND 1..16 -16..+16
//   PREAMP -24..+16
//   LEVEL -24..+16
//   PRESET FLAT/ROCK/POP/JAZZ/LOUD/DANCE/VOCAL/BASS
// ================================================================

static bool evoDspEq16AutoSync = true;
static bool evoDspC6UartEnabled = true;
static bool evoDspEqOn = true;
static int8_t evoDspPreampDb = 0;
static int8_t evoDspLevelDb = -20;     // Domyslny poziom DSP C6: LEVEL -20 dB
static bool evoDspLimiterOn = true;

// Dodatkowe funkcje najnowszego C6 EQ.
// Nie zmieniaja dzialajacego mechanizmu presetow i 16 pasm.
static bool evoDspBypassOn = false;
static bool evoDspRawOn = false;
static bool evoDspToneOn = false;
static int8_t evoDspBandsStaging[16] = {};
static uint8_t evoDspBandsHalfMask = 0;
static uint32_t evoDspBandsSnapshotMs = 0;

static void evoDspBeginBandSnapshot()
{
  for (uint8_t i = 0; i < 16; ++i) evoDspBandsStaging[i] = evo43Eq16[i];
  evoDspBandsHalfMask = 0;
  evoDspBandsSnapshotMs = millis();
}

static void evoDspCommitBandSnapshot()
{
  for (uint8_t i = 0; i < 16; ++i) evo43Eq16[i] = evoDspBandsStaging[i];
  evoDspBandsHalfMask = 0;
  evoDspBandsSnapshotMs = 0;
  evo43Eq16Enabled = true;
  if (evo43Eq16PendingUserLoad >= 1 && evo43Eq16PendingUserLoad <= 3) {
    evo43Eq16FinishPendingUserLoad();
  } else {
    evo43ApplyEq16ToTone();
    ActionNeedUpdateTime = true;
  }
}

static String evoDspDbText(int db)
{
  return String(db >= 0 ? "+" : "") + String(db);
}

static void evoDspEnsureC6Uart()
{
  if (!evoDspC6UartEnabled) return;
  widmoSetUartForDspC6();             // tylko start UART, bez komend analizatora
}

static void evoDspSendCommand(const String &cmd)
{
  if (!evoDspC6UartEnabled)
  {
    widmoAppendLog(String("DSP UART OFF - pomijam: ") + cmd + "\n");
    return;
  }
  evoDspEnsureC6Uart();
  widmoSend(cmd);
}

static void evoDspSetUartEnabled(bool on)
{
  evoDspC6UartEnabled = on;
  if (on)
  {
    widmoSetUartForDspC6();
    evoDspSendCommand("STATUS");
  }
  else
  {
    widmoUartEnabled = false;
    widmoStopUart();                  // bez wysylania OFF, bo C6 EQ nie ma takiej komendy zasilania
    widmoAppendLog("DSP C6 UART OFF\n");
  }
}

static void evoDspSendRuntimeState(bool saveAfter = false)
{
  evoDspSendCommand(String("EQ ") + (evoDspEqOn ? "ON" : "OFF"));
  evoDspSendCommand(String("PREAMP ") + evoDspDbText((int)evoDspPreampDb));
  evoDspSendCommand(String("LEVEL ") + evoDspDbText((int)evoDspLevelDb));
  evoDspSendCommand(String("LIMITER ") + (evoDspLimiterOn ? "ON" : "OFF"));
  if (saveAfter) evoDspSendCommand("SAVE");
}

static void evoDspSendEq16All(bool saveAfter = false, bool force = false)
{
  if (!force && !evoDspEq16AutoSync) return;

  evoDspEnsureC6Uart();
  evoDspSendCommand(String("EQ ") + (evoDspEqOn ? "ON" : "OFF"));

  for (uint8_t i = 0; i < 16; i++)
  {
    int v = constrain((int)evo43Eq16[i], -16, 16);
    evoDspSendCommand(String("BAND ") + String(i + 1) + " " + evoDspDbText(v));
  }

  evoDspSendRuntimeState(false);
  if (saveAfter) evoDspSendCommand("SAVE");
}

static void evoDspSendEq16Band(uint8_t band, int8_t value, bool saveAfter = false, bool force = false)
{
  if (!force && !evoDspEq16AutoSync) return;
  if (band > 15) band = 15;
  int v = constrain((int)value, -16, 16);

  evoDspEnsureC6Uart();
  evoDspSendCommand(String("EQ ") + (evoDspEqOn ? "ON" : "OFF"));
  evoDspSendCommand(String("BAND ") + String(band + 1) + " " + evoDspDbText(v));
  if (saveAfter) evoDspSendCommand("SAVE");
}

static void evoDspSetEqEnabled(bool on)
{
  evoDspEqOn = on;
  evoDspSendCommand(String("EQ ") + (on ? "ON" : "OFF"));
}

static void evoDspSetPreamp(int db)
{
  evoDspPreampDb = (int8_t)constrain(db, -24, 16);
  evoDspSendCommand(String("PREAMP ") + evoDspDbText((int)evoDspPreampDb));
}

static void evoDspSetLevel(int db)
{
  evoDspLevelDb = (int8_t)constrain(db, -24, 16);
  evoDspSendCommand(String("LEVEL ") + evoDspDbText((int)evoDspLevelDb));
}

static void evoDspSetLimiter(bool on)
{
  evoDspLimiterOn = on;
  evoDspSendCommand(String("LIMITER ") + (on ? "ON" : "OFF"));
}


static void evoDspSetBypass(bool on)
{
  evoDspBypassOn = on;
  evoDspSendCommand(String("BYPASS ") + (on ? "ON" : "OFF"));
}

static void evoDspSetRaw(bool on)
{
  evoDspRawOn = on;
  evoDspSendCommand(String("RAW ") + (on ? "ON" : "OFF"));
}

static void evoDspSetTone(bool on)
{
  evoDspToneOn = on;
  evoDspSendCommand(String("TONE ") + (on ? "ON" : "OFF"));
}

static void evoDspUserSave(uint8_t slot)
{
  if (slot < 1 || slot > 3) return;
  evoDspSendCommand(String("USER SAVE ") + String(slot));
}

static void evoDspUserLoad(uint8_t slot)
{
  if (slot < 1 || slot > 3) return;
  evoDspBeginBandSnapshot();
  evoDspSendCommand(String("USER LOAD ") + String(slot));
  // C6 zwraca atomowe EQSTATE, a STATUS pozostaje kontrola zgodnosci.
  evoDspSendCommand("STATUS");
}

// Parser odpowiedzi najnowszego C6.
// Uzywany glownie po USER LOAD 1/2/3, aby lokalne suwaki/wykres/TFT
// zostaly ustawione na wartosci zapisane w C6.
// Presety fabryczne nadal dzialaja po staremu i sa aktualizowane lokalnie natychmiast.
static int evoDspReadIntField(const String &line, const String &key, int fallback)
{
  String k = key + "=";
  int p = line.indexOf(k);
  if (p < 0) return fallback;
  p += k.length();
  int e = line.indexOf(' ', p);
  if (e < 0) e = line.length();
  return line.substring(p, e).toInt();
}

static float evoDspReadDbField(const String &line, const String &key, float fallback)
{
  String k = key + "=";
  int p = line.indexOf(k);
  if (p < 0) return fallback;
  p += k.length();
  int e = line.indexOf("dB", p);
  if (e < 0) {
    e = line.indexOf(' ', p);
    if (e < 0) e = line.length();
  }
  return line.substring(p, e).toFloat();
}

static void evoDspHandleC6Line(const String &line)
{
  if (line.startsWith("EQSTATE "))
  {
    evoDspEqOn      = evoDspReadIntField(line, "EQ",      evoDspEqOn ? 1 : 0) != 0;
    evoDspBypassOn  = evoDspReadIntField(line, "BYPASS",  evoDspBypassOn ? 1 : 0) != 0;
    evoDspRawOn     = evoDspReadIntField(line, "RAW",     evoDspRawOn ? 1 : 0) != 0;
    evoDspLimiterOn = evoDspReadIntField(line, "LIMITER", evoDspLimiterOn ? 1 : 0) != 0;
    evoDspPreampDb  = (int8_t)constrain((int)lroundf(evoDspReadIntField(line, "PREAMP", evoDspPreampDb * 10) / 10.0f), -24, 16);
    evoDspLevelDb   = (int8_t)constrain((int)lroundf(evoDspReadIntField(line, "LEVEL",  evoDspLevelDb * 10) / 10.0f), -24, 16);

    int p = line.indexOf("BANDS=");
    if (p >= 0) {
      p += 6;
      evoDspBeginBandSnapshot();
      uint8_t count = 0;
      while (count < 16 && p < (int)line.length()) {
        int comma = line.indexOf(',', p);
        int end = (comma < 0) ? line.length() : comma;
        String value = line.substring(p, end);
        value.trim();
        if (!value.length()) break;
        evoDspBandsStaging[count++] = constrain((int)lroundf(value.toInt() / 10.0f), -16, 16);
        if (comma < 0) break;
        p = comma + 1;
      }
      if (count == 16) evoDspCommitBandSnapshot();
    }
    return;
  }

  if (line.startsWith("STATUS:"))
  {
    evoDspEqOn      = evoDspReadIntField(line, "EQ",      evoDspEqOn ? 1 : 0) != 0;
    evoDspBypassOn  = evoDspReadIntField(line, "BYPASS",  evoDspBypassOn ? 1 : 0) != 0;
    evoDspRawOn     = evoDspReadIntField(line, "RAW",     evoDspRawOn ? 1 : 0) != 0;
    evoDspLimiterOn = evoDspReadIntField(line, "LIMITER", evoDspLimiterOn ? 1 : 0) != 0;
    evoDspToneOn    = evoDspReadIntField(line, "TONE",    evoDspToneOn ? 1 : 0) != 0;

    evoDspPreampDb = (int8_t)constrain((int)lroundf(evoDspReadDbField(line, "PREAMP", evoDspPreampDb)), -24, 16);
    evoDspLevelDb  = (int8_t)constrain((int)lroundf(evoDspReadDbField(line, "LEVEL",  evoDspLevelDb)),  -24, 16);
    return;
  }

  int first = -1;
  if (line.startsWith("BANDS 01-08:")) first = 0;
  else if (line.startsWith("BANDS 09-16:")) first = 8;
  if (first < 0) return;

  if (evoDspBandsSnapshotMs == 0 || (uint32_t)(millis() - evoDspBandsSnapshotMs) > 1000U || first == 0) {
    evoDspBeginBandSnapshot();
  }

  uint8_t parsed = 0;
  for (int j = 0; j < 8; ++j)
  {
    int bandIndex = first + j;
    String key = String(bandIndex + 1) + "=";
    int p = line.indexOf(key);
    if (p < 0) continue;
    p += key.length();
    int e = line.indexOf("dB", p);
    if (e < 0) {
      e = line.indexOf(' ', p);
      if (e < 0) e = line.length();
    }
    float db = line.substring(p, e).toFloat();
    // Panel EVO4 ma krok 1 dB, C6 moze zwracac np. 4.5 dB.
    evoDspBandsStaging[bandIndex] = constrain((int)lroundf(db), -16, 16);
    ++parsed;
  }

  if (parsed == 8) evoDspBandsHalfMask |= (first == 0) ? 0x01 : 0x02;
  if (evoDspBandsHalfMask == 0x03) evoDspCommitBandSnapshot();
}

static String evoDspBuildHtml()
{
  String html = F("<!doctype html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>ESP32-C6 DSP EQ16</title><style>body{font-family:Arial;background:#101010;color:#eee;max-width:980px;margin:auto;padding:18px;text-align:center}.card{background:#1d1d1d;border:1px solid #099;border-radius:12px;padding:14px;margin:10px 0}.b{padding:10px 14px;margin:4px;border:0;border-radius:8px;background:#047;color:#fff;font-weight:bold}.g{background:#286}.r{background:#a22}.o{background:#d87800}.c{background:#087}input{padding:8px;border-radius:6px;border:1px solid #777;background:#111;color:#fff}a{color:#0ff}pre{background:#020202;color:#0f0;text-align:left;padding:12px;border-radius:8px;white-space:pre-wrap;max-height:280px;overflow:auto}.warn{color:#ffb000}.mini{font-size:.9rem;color:#bbb}</style></head><body><h2>EVO4 MULTI - ESP32-C6 DSP EQ16 UART</h2>");

  html += F("<div class='card'><h3>Status połączenia</h3><p>UART C6: <b>");
  html += evoDspC6UartEnabled ? (evoDspC6IsUartActive() ? "ON" : "GOTOWY") : "OFF";
  html += F("</b> | Auto sync: <b>"); html += (evoDspEq16AutoSync ? "ON" : "OFF");
  html += F("</b> | EQ: <b>"); html += (evoDspEqOn ? "ON" : "OFF");
  html += F("</b> | Limiter: <b>"); html += (evoDspLimiterOn ? "ON" : "OFF");
  html += F("</b></p><p class='mini'>Połączenie: EVO TX17 → C6 RX16, EVO RX18 ← C6 TX17, GND wspólne, 115200 8N1.</p>");
  html += F("<button class='b g' onclick=location.href='/dsp/api/uart?en=1'>UART ON</button><button class='b r' onclick=location.href='/dsp/api/uart?en=0'>UART OFF</button><button class='b c' onclick=location.href='/dsp/api/cmd?c=STATUS'>STATUS</button><button class='b c' onclick=location.href='/dsp/api/cmd?c=FREQ'>FREQ</button><button class='b c' onclick=location.href='/dsp/api/cmd?c=HELP'>HELP</button></div>");

  html += F("<div class='card'><h3>Synchronizacja EQ16</h3><button class='b g' onclick=location.href='/dsp/api/sync'>WYŚLIJ 16 PASM DO C6 + SAVE</button><button class='b' onclick=location.href='/dsp/api/autosync?en=1'>AUTO ON</button><button class='b r' onclick=location.href='/dsp/api/autosync?en=0'>AUTO OFF</button><button class='b g' onclick=location.href='/dsp/api/eq?en=1'>EQ ON</button><button class='b r' onclick=location.href='/dsp/api/eq?en=0'>EQ OFF</button></div>");

  html += F("<div class='card'><h3>Aktywny preset: <span style='color:#ffd54a'>"); html += evo43Eq16ActiveLabel(); html += F("</span></h3>");
  html += F("<button class='b g' onclick=location.href='/eq16/api/user?op=load&slot=1&return=dsp'>USER 1</button><button class='b g' onclick=location.href='/eq16/api/user?op=load&slot=2&return=dsp'>USER 2</button><button class='b g' onclick=location.href='/eq16/api/user?op=load&slot=3&return=dsp'>USER 3</button><a class='b c' href='/eq16'>SUWAKI / KRZYWA EQ16</a></div>");

  html += F("<div class='card'><h3>Preamp / Level / Limiter</h3><form action='/dsp/api/preamp'>PREAMP -24..+16 dB: <input name='v' type='number' min='-24' max='16' value='"); html += String((int)evoDspPreampDb); html += F("'><button class='b'>SET</button></form>");
  html += F("<form action='/dsp/api/level'>LEVEL -24..+16 dB: <input name='v' type='number' min='-24' max='16' value='"); html += String((int)evoDspLevelDb); html += F("'><button class='b'>SET</button></form>");
  html += F("<button class='b g' onclick=location.href='/dsp/api/limiter?en=1'>LIMITER ON</button><button class='b r' onclick=location.href='/dsp/api/limiter?en=0'>LIMITER OFF</button></div>");

  html += F("<div class='card'><h3>Komendy serwisowe C6</h3><button class='b o' onclick=location.href='/dsp/api/cmd?c=SAVE'>SAVE</button><button class='b o' onclick=location.href='/dsp/api/cmd?c=LOAD'>LOAD</button><button class='b r' onclick=location.href='/dsp/api/cmd?c=RESET'>RESET</button><button class='b' onclick=location.href='/dsp/api/cmd?c=PRESET%20FLAT'>FLAT</button><button class='b' onclick=location.href='/dsp/api/cmd?c=PRESET%20ROCK'>ROCK</button><button class='b' onclick=location.href='/dsp/api/cmd?c=PRESET%20BASS'>BASS</button></div>");


  html += F("<div class='card'><form action='/dsp/api/cmd'><h3>Terminal UART ESP32-C6</h3><input name='c' style='width:75%' placeholder='np. EQ ON / BAND 1 +6 / BAND 8 +16 / PREAMP -6 / LEVEL +6 / PRESET ROCK'><button class='b'>SEND</button></form><p class='mini'>Komendy analizatora WIDMO-VU są osobno w /widmo. Ta strona nie wysyła już PING/STYLE/WIDSENS do C6.</p><pre>");
  html += widmoLog;
  html += F("</pre></div><p><a href='/eq16'>EQ16</a> | <a href='/mode?m=23'>Panel EVO4 MULTI</a> | <a href='/widmo'>Analizator /widmo</a> | <a href='/menu'>Menu</a></p></body></html>");
  return html;
}
