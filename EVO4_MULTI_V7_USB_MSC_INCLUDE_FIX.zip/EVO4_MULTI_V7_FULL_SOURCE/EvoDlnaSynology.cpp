/*
  EVO4 MULTI - LINKER SPLIT FIX
  Implementacja DLNA w osobnym module kompilacji.

  To nie zmienia funkcji DLNA. Zmiana dotyczy organizacji kodu, aby funkcje
  discoveryTask()/browseTask() nie trafialy do ogromnego obiektu .ino.
*/

#include "EvoDlnaSynology.h"

#include <WiFi.h>
#include <WiFiUdp.h>
#include <HTTPClient.h>
#include <esp_heap_caps.h>
#include <new>
#include <cstring>

namespace EvoDlna {

Server servers[MAX_SERVERS];
Item items[MAX_ITEMS];
uint8_t serverCount = 0;
uint8_t itemCount = 0;
uint8_t selectedServer = 0;
uint8_t selectedItem = 0;
String currentObjectId = "0";
String currentTitle = "MEDIA";
String historyId[MAX_DEPTH];
String historyTitle[MAX_DEPTH];
uint8_t historyDepth = 0;
uint32_t pageStart = 0;
uint32_t totalMatches = 0;
String lastStatus = "DLNA: WYBIERZ SZUKAJ LUB PODAJ IP NAS";
String lastError;
String nowPlaying;
std::atomic<bool> busy{false};
SemaphoreHandle_t mutex = nullptr;
TaskHandle_t worker = nullptr;
uint32_t discoverStackSpare = 0;
uint32_t browseStackSpare = 0;

// Stan zadania wewnetrzny - nie musi byc widoczny w glownym .ino.
static String requestControlUrl;
static String requestObjectId;
static String requestTitle;
static int8_t requestHistoryAction = 0;
static uint32_t requestPageStart = 0;
static String manualDescriptionUrl;

static String xmlDecode(String s) {
  s.replace("&amp;", "&"); s.replace("&lt;", "<"); s.replace("&gt;", ">");
  s.replace("&quot;", "\""); s.replace("&apos;", "'");
  s.replace("&#39;", "'"); s.replace("&#34;", "\"");
  return s;
}

static String xmlEncode(String s) {
  s.replace("&", "&amp;"); s.replace("<", "&lt;"); s.replace(">", "&gt;");
  s.replace("\"", "&quot;"); s.replace("'", "&apos;");
  return s;
}

static String between(const String &s, const String &a, const String &b, int from = 0) {
  int p = s.indexOf(a, from); if (p < 0) return String();
  p += a.length(); int e = s.indexOf(b, p); if (e < 0) return String();
  return xmlDecode(s.substring(p, e));
}

static String attr(const String &tag, const char *name) {
  String key = String(name) + "=\"";
  int p = tag.indexOf(key); if (p < 0) return String();
  p += key.length(); int e = tag.indexOf('"', p); if (e < 0) return String();
  return xmlDecode(tag.substring(p, e));
}

static String originOf(const String &url) {
  int scheme = url.indexOf("://"); if (scheme < 0) return String();
  int slash = url.indexOf('/', scheme + 3);
  return slash < 0 ? url : url.substring(0, slash);
}

static String absoluteUrl(const String &base, String value) {
  value.trim();
  if (value.startsWith("http://") || value.startsWith("https://")) return value;
  String origin = originOf(base);
  if (!value.startsWith("/")) value = "/" + value;
  return origin + value;
}

static String headerValue(const String &packet, const char *header) {
  String lower = packet; lower.toLowerCase();
  String key = String(header); key.toLowerCase(); key += ":";
  int p = lower.indexOf(key); if (p < 0) return String();
  p += key.length(); int e = packet.indexOf('\n', p); if (e < 0) e = packet.length();
  String v = packet.substring(p, e); v.trim(); return v;
}

// HTTPClient::getString() kopiuje cala odpowiedz SOAP do malego RAM
// wewnetrznego. Synology dodaje dlugie metadane DIDL, dlatego odbieramy
// odpowiedz do ograniczonego bufora w PSRAM i parsujemy ja na miejscu.
class PsramResponse : public Stream {
public:
  static constexpr size_t CAPACITY = 65536;
  char *data = nullptr;
  size_t length = 0;
  bool overflow = false;
  PsramResponse() {
    data = static_cast<char *>(heap_caps_malloc(CAPACITY, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
    if (data) data[0] = '\0';
  }
  ~PsramResponse() override { if (data) heap_caps_free(data); }
  size_t write(uint8_t value) override { return write(&value, 1); }
  size_t write(const uint8_t *bytes, size_t size) override {
    if (!data || !bytes || length + size >= CAPACITY) { overflow = true; return 0; }
    memcpy(data + length, bytes, size);
    length += size;
    data[length] = '\0';
    return size;
  }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}
};

static void decodeXmlInPlace(char *text) {
  if (!text) return;
  char *read = text, *write = text;
  while (*read) {
    struct Entity { const char *name; char value; };
    static const Entity entities[] = {
      {"&lt;", '<'}, {"&gt;", '>'}, {"&amp;", '&'},
      {"&quot;", '"'}, {"&apos;", '\''}, {"&#39;", '\''}, {"&#34;", '"'}
    };
    bool converted = false;
    if (*read == '&') for (const Entity &entity : entities) {
      size_t n = strlen(entity.name);
      if (strncmp(read, entity.name, n) == 0) {
        *write++ = entity.value;
        read += n;
        converted = true;
        break;
      }
    }
    if (!converted) *write++ = *read++;
  }
  *write = '\0';
}

static const char *findBefore(const char *start, const char *end, const char *needle) {
  if (!start || !end || start >= end) return nullptr;
  const char *found = strstr(start, needle);
  return found && found < end ? found : nullptr;
}

static String copyRange(const char *start, const char *end, size_t maxLength = 2048) {
  if (!start || !end || end <= start || static_cast<size_t>(end - start) > maxLength) return String();
  String result;
  size_t length = static_cast<size_t>(end - start);
  if (result.reserve(length + 1)) result.concat(start, length);
  return result;
}

static String tagValue(const char *start, const char *end, const char *open, const char *close) {
  const char *begin = findBefore(start, end, open);
  if (!begin) return String();
  begin += strlen(open);
  const char *finish = findBefore(begin, end, close);
  return xmlDecode(copyRange(begin, finish));
}

static String attrValue(const char *start, const char *end, const char *name) {
  String key = String(name) + "=\"";
  const char *begin = findBefore(start, end, key.c_str());
  if (!begin) return String();
  begin += key.length();
  const char *finish = findBefore(begin, end, "\"");
  return xmlDecode(copyRange(begin, finish));
}

static bool __attribute__((noinline)) httpGet(const String &url, String &body) {
  HTTPClient http;
  http.setConnectTimeout(2500);
  http.setTimeout(4500);
  http.useHTTP10(true);
  if (!http.begin(url)) return false;
  http.addHeader("Connection", "close");
  int code = http.GET();
  if (code == HTTP_CODE_OK) body = http.getString();
  http.end();
  return code == HTTP_CODE_OK && body.length() > 0;
}

static bool __attribute__((noinline)) describe(const String &location, Server &out) {
  String xml;
  if (!httpGet(location, xml)) return false;
  out.location = location;
  out.name = between(xml, "<friendlyName>", "</friendlyName>");
  out.udn = between(xml, "<UDN>", "</UDN>");
  if (!out.name.length()) out.name = "DLNA SERVER";

  int pos = 0;
  while ((pos = xml.indexOf("<service>", pos)) >= 0) {
    int end = xml.indexOf("</service>", pos); if (end < 0) break;
    String block = xml.substring(pos, end + 10);
    if (block.indexOf("ContentDirectory") >= 0) {
      String control = between(block, "<controlURL>", "</controlURL>");
      if (control.length()) {
        out.controlUrl = absoluteUrl(location, control);
        return true;
      }
    }
    pos = end + 10;
  }
  return false;
}

static bool isAudioResource(const String &attrs, const String &url) {
  String x = attrs + " " + url; x.toLowerCase();
  return x.indexOf("audio/") >= 0 || x.indexOf("audioitem") >= 0 ||
         x.endsWith(".mp3") || x.endsWith(".flac") || x.endsWith(".wav") ||
         x.endsWith(".aac") || x.endsWith(".m4a") || x.endsWith(".ogg");
}

static bool browseSoap(const String &controlUrl, const String &objectId,
                       uint32_t startIndex, Item *out, uint8_t &count,
                       uint32_t &matches, String &error) {
  String body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" "
                "s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                "<s:Body><u:Browse xmlns:u=\"urn:schemas-upnp-org:service:ContentDirectory:1\">"
                "<ObjectID>" + xmlEncode(objectId) + "</ObjectID>"
                "<BrowseFlag>BrowseDirectChildren</BrowseFlag><Filter>*</Filter>"
                "<StartingIndex>" + String(startIndex) + "</StartingIndex><RequestedCount>8</RequestedCount>"
                "<SortCriteria></SortCriteria></u:Browse></s:Body></s:Envelope>";
  HTTPClient http;
  http.setConnectTimeout(3000); http.setTimeout(7000); http.useHTTP10(true);
  if (!http.begin(controlUrl)) { error = "BLEDNY URL CONTROL"; return false; }
  http.addHeader("Content-Type", "text/xml; charset=\"utf-8\"");
  http.addHeader("SOAPAction", "\"urn:schemas-upnp-org:service:ContentDirectory:1#Browse\"");
  http.addHeader("Connection", "close");
  PsramResponse response;
  if (!response.data) { http.end(); error = "BRAK PSRAM NA SOAP"; return false; }
  int code = http.POST((uint8_t*)body.c_str(), body.length());
  int received = code == HTTP_CODE_OK ? http.writeToStream(&response) : 0;
  http.end();
  if (code != HTTP_CODE_OK) {
    error = String("SOAP HTTP ") + code;
    return false;
  }
  if (received <= 0 || response.overflow || !response.length) {
    error = response.overflow ? "SOAP ZA DUZY (64 KB)" : "PUSTA ODPOWIEDZ SOAP";
    return false;
  }
  const char *responseEnd = response.data + response.length;
  matches = tagValue(response.data, responseEnd, "<TotalMatches>", "</TotalMatches>").toInt();
  char *didl = response.data;
  char *resultStart = strstr(response.data, "<Result>");
  if (resultStart) {
    resultStart += strlen("<Result>");
    char *resultEnd = strstr(resultStart, "</Result>");
    if (!resultEnd) { error = "BRAK KONCA RESULT"; return false; }
    *resultEnd = '\0';
    decodeXmlInPlace(resultStart);
    didl = resultStart;
  }
  const char *didlEnd = didl + strlen(didl);
  count = 0;
  const char *pos = didl;
  while (count < MAX_ITEMS) {
    const char *pc = findBefore(pos, didlEnd, "<container");
    const char *pi = findBefore(pos, didlEnd, "<item");
    bool container = pc && (!pi || pc < pi);
    const char *start = container ? pc : pi;
    if (!start) break;
    const char *closeTag = container ? "</container>" : "</item>";
    const char *tagEnd = static_cast<const char *>(memchr(start, '>', didlEnd - start));
    const char *end = tagEnd ? findBefore(tagEnd, didlEnd, closeTag) : nullptr;
    if (!tagEnd || !end) break;
    Item it;
    it.container = container;
    it.id = attrValue(start, tagEnd, "id");
    it.parentId = attrValue(start, tagEnd, "parentID");
    it.title = tagValue(tagEnd + 1, end, "<dc:title>", "</dc:title>");
    if (!it.title.length()) {
      const char *tp = findBefore(tagEnd + 1, end, ":title>");
      if (tp) { tp += 7; it.title = xmlDecode(copyRange(tp, findBefore(tp, end, "</"))); }
    }
    if (!it.title.length()) it.title = container ? "KATALOG" : "UTWOR";
    if (!container) {
      const char *rp = tagEnd + 1;
      while ((rp = findBefore(rp, end, "<res"))) {
        const char *re = static_cast<const char *>(memchr(rp, '>', end - rp));
        const char *rc = re ? findBefore(re + 1, end, "</res>") : nullptr;
        if (!re || !rc) break;
        String ra = copyRange(rp, re + 1, 1024);
        String ru = xmlDecode(copyRange(re + 1, rc)); ru.trim();
        if (isAudioResource(ra, ru)) {
          it.url = ru;
          it.mime = attrValue(rp, re, "protocolInfo");
          break;
        }
        rp = rc + strlen("</res>");
      }
      if (!it.url.length()) { pos = end + strlen(closeTag); continue; }
    }
    out[count++] = it;
    pos = end + strlen(closeTag);
  }
  return true;
}

static void publishStatus(const String &status, const String &error = String()) {
  if (mutex && xSemaphoreTake(mutex, pdMS_TO_TICKS(250)) == pdTRUE) {
    lastStatus = status; lastError = error;
    xSemaphoreGive(mutex);
  }
}

static void __attribute__((noinline)) discoveryTask(void *) {
  publishStatus("SZUKANIE SERWEROW");
  Server found[MAX_SERVERS]; uint8_t foundCount = 0;
  String locations[MAX_SERVERS]; uint8_t locationCount = 0;
  if (manualDescriptionUrl.startsWith("http://")) {
    locations[locationCount++] = manualDescriptionUrl;
  } else if (manualDescriptionUrl.length()) {
    // Sam adres IP: sprawdz znane opisy Synology i miniDLNA/ReadyMedia.
    locations[locationCount++] = String("http://") + manualDescriptionUrl + ":50001/desc/device.xml";
    locations[locationCount++] = String("http://") + manualDescriptionUrl + ":8200/rootDesc.xml";
  }

  WiFiUDP udp;
  if (!manualDescriptionUrl.length() && WiFi.status() == WL_CONNECTED && udp.begin(0)) {
    const char *targets[] = {
      "urn:schemas-upnp-org:device:MediaServer:1",
      "urn:schemas-upnp-org:service:ContentDirectory:1"
    };
    for (const char *st : targets) {
      String q = String("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n") +
                 "MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: " + st + "\r\n\r\n";
      udp.beginPacket(IPAddress(239,255,255,250), 1900);
      udp.write((const uint8_t*)q.c_str(), q.length()); udp.endPacket();
    }
    uint32_t until = millis() + 2200;
    while ((int32_t)(until - millis()) > 0) {
      int n = udp.parsePacket();
      if (n > 0) {
        String packet; packet.reserve(n + 1);
        while (n-- > 0) packet += (char)udp.read();
        String loc = headerValue(packet, "location");
        bool duplicate = false;
        for (uint8_t i=0;i<locationCount;i++) if (locations[i] == loc) duplicate = true;
        if (loc.length() && !duplicate && locationCount < MAX_SERVERS) locations[locationCount++] = loc;
      }
      vTaskDelay(pdMS_TO_TICKS(15));
    }
    udp.stop();
  }
  for (uint8_t i=0;i<locationCount && foundCount<MAX_SERVERS;i++) {
    Server s;
    if (describe(locations[i], s)) {
      found[foundCount++] = s;
      if (manualDescriptionUrl.length()) break;
    }
    vTaskDelay(1);
  }
  const uint32_t stackSpare = uxTaskGetStackHighWaterMark(nullptr);
  if (mutex && xSemaphoreTake(mutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    discoverStackSpare = stackSpare;
    for (uint8_t i=0;i<foundCount;i++) servers[i] = found[i];
    selectedServer = 0;
    serverCount = foundCount;
    lastStatus = foundCount ? String("SERWERY ") + foundCount : "BRAK SERWERA DLNA";
    lastError = foundCount ? "" : "NAS nie odpowiedzial jako DLNA; sprawdz Media Server i porty";
    xSemaphoreGive(mutex);
  }
  busy.store(false); worker = nullptr; vTaskDelete(nullptr);
}

static void browseTask(void *) {
  publishStatus("WCZYTYWANIE KATALOGU");
  // Lista tymczasowa w PSRAM: stos zadania musi miescic sie w wolnym RAM wewnetrznym.
  Item *found = static_cast<Item *>(heap_caps_malloc(sizeof(Item) * MAX_ITEMS,
                                                      MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT));
  if (!found) {
    publishStatus("DLNA: BRAK PSRAM NA LISTE");
    busy.store(false); worker = nullptr; vTaskDelete(nullptr);
    return;
  }
  for (uint8_t i=0; i<MAX_ITEMS; i++) new (&found[i]) Item();
  uint8_t foundCount = 0; uint32_t matches = 0; String error;
  bool ok = browseSoap(requestControlUrl, requestObjectId, requestPageStart,
                       found, foundCount, matches, error);
  const uint32_t stackSpare = uxTaskGetStackHighWaterMark(nullptr);
  if (mutex && xSemaphoreTake(mutex, pdMS_TO_TICKS(500)) == pdTRUE) {
    browseStackSpare = stackSpare;
    if (ok) {
      if (requestHistoryAction > 0 && historyDepth < MAX_DEPTH) {
        historyId[historyDepth] = currentObjectId;
        historyTitle[historyDepth] = currentTitle;
        historyDepth++;
      } else if (requestHistoryAction < 0 && historyDepth > 0) historyDepth--;
      currentObjectId = requestObjectId;
      currentTitle = requestTitle.length() ? requestTitle : "MEDIA";
      pageStart = requestPageStart;
      totalMatches = matches ? matches : (requestPageStart + foundCount);
      itemCount = 0; selectedItem = 0;
      for (uint8_t i=0;i<foundCount;i++) items[i] = found[i];
      itemCount = foundCount;
      lastStatus = String("ELEMENTY ") + foundCount; lastError = "";
    } else {
      lastStatus = "BLAD DLNA BROWSE"; lastError = error;
    }
    xSemaphoreGive(mutex);
  }
  for (uint8_t i=0; i<MAX_ITEMS; i++) found[i].~Item();
  heap_caps_free(found);
  busy.store(false); worker = nullptr; vTaskDelete(nullptr);
}

void begin() {
  if (!mutex) mutex = xSemaphoreCreateMutex();
}

bool discoverAsync(const String &manualUrl) {
  bool expected = false; if (!busy.compare_exchange_strong(expected, true)) return false;
  manualDescriptionUrl = manualUrl; begin();
  publishStatus("SZUKANIE SERWEROW");
  if (xTaskCreatePinnedToCore(discoveryTask, "dlna_discover", 5120, nullptr, 1, &worker, 0) != pdPASS) {
    busy.store(false); worker = nullptr;
    publishStatus("DLNA: BRAK PAMIECI NA SKAN",
                  String("heap=") + ESP.getFreeHeap() + " max=" + ESP.getMaxAllocHeap());
    return false;
  }
  return true;
}

bool browseAsync(const String &control, const String &id, const String &title,
                        int8_t historyAction, uint32_t startIndex) {
  bool expected = false; if (!busy.compare_exchange_strong(expected, true)) return false;
  requestControlUrl = control; requestObjectId = id; requestTitle = title;
  requestHistoryAction = historyAction; begin();
  requestPageStart = startIndex;
  if (xTaskCreatePinnedToCore(browseTask, "dlna_browse", 5120, nullptr, 1, &worker, 0) != pdPASS) {
    busy.store(false); worker = nullptr;
    publishStatus("DLNA: BRAK PAMIECI NA LISTE",
                  String("heap=") + ESP.getFreeHeap() + " max=" + ESP.getMaxAllocHeap());
    return false;
  }
  return true;
}

bool selectServerAndBrowse(uint8_t index) {
  if (busy.load() || index >= serverCount) return false;
  selectedServer = index; historyDepth = 0; currentObjectId = "0"; currentTitle = servers[index].name;
  return browseAsync(servers[index].controlUrl, "0", servers[index].name, 0);
}

bool openSelected(String &playUrl, String &title) {
  playUrl = ""; title = "";
  if (busy.load() || selectedItem >= itemCount || selectedServer >= serverCount) return false;
  Item it = items[selectedItem];
  if (it.container) return browseAsync(servers[selectedServer].controlUrl, it.id, it.title, +1);
  playUrl = it.url; title = it.title; nowPlaying = it.title; return playUrl.length() > 0;
}

bool goBack() {
  if (busy.load() || selectedServer >= serverCount || historyDepth == 0) return false;
  return browseAsync(servers[selectedServer].controlUrl,
                     historyId[historyDepth-1], historyTitle[historyDepth-1], -1);
}

bool nextPage() {
  if (busy.load() || selectedServer >= serverCount ||
      pageStart + MAX_ITEMS >= totalMatches) return false;
  return browseAsync(servers[selectedServer].controlUrl, currentObjectId,
                     currentTitle, 0, pageStart + MAX_ITEMS);
}

bool previousPage() {
  if (busy.load() || selectedServer >= serverCount || pageStart == 0) return false;
  uint32_t previous = pageStart >= MAX_ITEMS ? pageStart - MAX_ITEMS : 0;
  return browseAsync(servers[selectedServer].controlUrl, currentObjectId,
                     currentTitle, 0, previous);
}

void selectDelta(int delta) {
  if (!itemCount || busy.load()) return;
  int n = (int)selectedItem + delta;
  if (n < 0) n = itemCount - 1;
  if (n >= itemCount) n = 0;
  selectedItem = (uint8_t)n;
}


} // namespace EvoDlna
