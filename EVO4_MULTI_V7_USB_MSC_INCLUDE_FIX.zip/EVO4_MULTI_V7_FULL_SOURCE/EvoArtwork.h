#pragma once

#include <Arduino.h>
#include <memory>
#include <atomic>

namespace EvoArtwork {

// Logiczny kafelek UI i bufor HQ dla obrazu.
constexpr int side = 80;
constexpr int sourceSide = 160;

#ifndef EVO_ARTWORK_ITUNES_SIDE
  #define EVO_ARTWORK_ITUNES_SIDE 300
#endif

#ifndef EVO_ARTWORK_DOWNLOAD_MAX
  #define EVO_ARTWORK_DOWNLOAD_MAX (512 * 1024)
#endif

struct Picture {
  uint16_t pixels[sourceSide * sourceSide] = {};
  uint16_t preview[side * side] = {};
  bool decoded = false;
};

struct Result {
  String logoUrl, coverUrl;
  String logoStatus = "waiting", coverStatus = "waiting";
  std::shared_ptr<Picture> logo, cover;
};

// Uzywane przez petle glownego programu do wykrycia nowej grafiki.
extern std::atomic<bool> changed;

// Publiczny interfejs modulu. Implementacja jest w EvoArtwork.cpp,
// dzieki czemu ogromny kod HTTP/JSON/JPEG/PNG nie jest juz kompilowany
// wewnatrz jednego, bardzo duzego pliku .ino.
void initMemoryPolicy();
void submit(const String &station,
            const String &artist,
            const String &title,
            const String &logo,
            bool active);
void setActive(bool active); // Pause fetches when neither panel nor WWW needs artwork
String diagnostics();
Result snapshot();

} // namespace EvoArtwork
