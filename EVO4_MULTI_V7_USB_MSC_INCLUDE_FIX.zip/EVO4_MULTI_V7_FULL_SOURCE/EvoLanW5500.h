#pragma once
#include <Arduino.h>
#include <SPI.h>
#include "Evo4_User_Config.h"

// EVO4 MULTI v. 7 - W5500 SPI, wspolna magistrala z karta SD.
// Fizyczne polaczenia: SCK=45, MISO=21, MOSI=48, CS_SD=47, CS_W5500=9.
// NIE podlaczac W5500 do TFT GPIO 38..41 (konflikt z ekranem).
// Arduino-ESP32 3.x: ETH.begin(ETH_PHY_W5500, addr, cs, irq, rst, spi).
#ifndef EVO_LAN_W5500_ENABLE
#define EVO_LAN_W5500_ENABLE 1
#endif
#ifndef EVO_LAN_CS
#define EVO_LAN_CS 9
#endif
#ifndef EVO_LAN_SD_CS
#define EVO_LAN_SD_CS 47
#endif
#ifndef EVO_LAN_SCK
#define EVO_LAN_SCK 45
#endif
#ifndef EVO_LAN_MISO
#define EVO_LAN_MISO 21
#endif
#ifndef EVO_LAN_MOSI
#define EVO_LAN_MOSI 48
#endif

#if EVO_LAN_W5500_ENABLE && __has_include(<ETH.h>) && defined(ESP_ARDUINO_VERSION_MAJOR) && (ESP_ARDUINO_VERSION_MAJOR >= 3)
#include <ETH.h>
#define EVO_LAN_SUPPORTED 1
#else
#define EVO_LAN_SUPPORTED 0
#endif

inline void evoLanPreparePins() {
  pinMode(EVO_LAN_CS, OUTPUT);
  digitalWrite(EVO_LAN_CS, HIGH);
  pinMode(EVO_LAN_SD_CS, OUTPUT);
  digitalWrite(EVO_LAN_SD_CS, HIGH);
}

inline bool &evoLanStarted() { static bool started = false; return started; }

inline bool evoLanBegin(SPIClass &bus) {
  evoLanPreparePins();
#if EVO_LAN_SUPPORTED
  // SD korzysta juz z tej samej instancji SPIClass.
  // IRQ i RST sa niepodlaczone; PHY address dla W5500 = 1.
  bool ok = ETH.begin(ETH_PHY_W5500, 1, EVO_LAN_CS, -1, -1, bus);
  evoLanStarted() = ok;
  Serial.printf("[EVO LAN] W5500 init=%s; CS=%d, SCK=%d, MISO=%d, MOSI=%d\n",
                ok ? "OK" : "FAIL", EVO_LAN_CS, EVO_LAN_SCK, EVO_LAN_MISO, EVO_LAN_MOSI);
  return ok;
#else
  (void)bus;
  evoLanStarted() = false;
  Serial.println("[EVO LAN] W5500: wymagany Arduino-ESP32 3.x z ETH.h albo wlacz EVO_LAN_W5500_ENABLE");
  return false;
#endif
}

inline void evoLanLoop() {
#if EVO_LAN_SUPPORTED
  static uint32_t last = 0;
  if (millis() - last >= 30000) {
    last = millis();
    Serial.printf("[EVO LAN] init=%d link=%d ip=%s\n", (int)evoLanStarted(),
                  (int)ETH.linkUp(), ETH.localIP().toString().c_str());
  }
#endif
}

inline String evoLanStatusJson() {
#if EVO_LAN_SUPPORTED
  return String("{\"supported\":true,\"initialized\":") + (evoLanStarted() ? "true" : "false") +
         ",\"link\":" + (ETH.linkUp() ? "true" : "false") +
         ",\"ip\":\"" + ETH.localIP().toString() +
         "\",\"spi\":\"SD shared\",\"cs\":" + String(EVO_LAN_CS) + "}";
#else
  return String("{\"supported\":false,\"initialized\":false,\"link\":false,\"ip\":\"0.0.0.0\",\"cs\":") + String(EVO_LAN_CS) + "}";
#endif
}

inline String evoLanPage() {
  return R"HTML(<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EVO4 MULTI | W5500</title><style>body{font:16px system-ui;background:#101a2a;color:#f2f6ff;max-width:800px;margin:30px auto;padding:16px}section{background:#1b2b43;padding:20px;border-radius:14px}a{color:#8dd6ff}pre{white-space:pre-wrap}</style><section><h1>EVO4 MULTI — Ethernet W5500</h1><p>SPI wspolne z SD: SCK 45, MISO 21, MOSI 48; CS LAN 9, CS SD 47. W5500 nie moze uzywac pinow TFT 38–41.</p><p>Stan Ethernet. Funkcje aplikacji, ktore jawnie uzywaja WiFiClient, wymagaja dalszej migracji do klienta sieciowego.</p><pre id="status">Odczyt...</pre><p><a href="/menu">Powrot do menu</a></p></section><script>async function tick(){try{let r=await fetch('/network/lan/status');document.getElementById('status').textContent=JSON.stringify(await r.json(),null,2)}catch(e){document.getElementById('status').textContent=String(e)}}tick();setInterval(tick,4000)</script></html>)HTML";
}
