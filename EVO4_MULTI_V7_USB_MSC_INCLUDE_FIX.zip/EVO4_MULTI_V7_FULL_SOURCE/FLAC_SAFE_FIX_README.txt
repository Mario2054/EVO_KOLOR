EVO4 MULTI v. 7 - FLAC SAFE, etap diagnostyczny
1. audio.loop() przeniesione na poczatek loop() przed USB/LAN i innymi zadaniami.
2. Pozostawiono tylko jedno wywolanie audio.loop() na iteracje, bez dodatkowego tasku.
3. Dla aktywnego dekodera FLAC pobieranie nowych grafik odroczone o 8 s od wykrycia kodeka; po tym czasie logo i okladki nadal dzialaja.
4. Log [V7 AUDIO LOOP] wyraznie wskazuje pomiar petli glownej, nie tasku dekodera biblioteki.
NIE ZMIENIANO: wyszukiwania logo, SD/USB, WWW, FLAC dekodera, konfiguracji pinow.
WERYFIKACJA: nie kompilowano na Arduino ESP32 3.3.12 ani nie testowano na plytce.
TEST: 1) Dance Wave FLAC 2-3 min; 2) logo po 8 s; 3) log [V7 AUDIO LOOP]; 4) radio MP3, SD/USB -> radio.
