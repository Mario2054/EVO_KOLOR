#pragma once

#include <Arduino.h>
#include <FS.h>

void evoNasUploadInit();
bool evoNasUploadEnabled();
bool evoNasUploadBusy();
bool evoNasUploadIsPath(const String &path);
bool evoNasUploadConfigure(bool enabled, const String &host, uint16_t port,
                           const String &directory, const String &user,
                           const String &newPassword, String &error);
bool evoNasUploadQueue(fs::FS &storage, const String &path, bool onUsb,
                       String &error);
String evoNasUploadConfigPage();
String evoNasUploadStatusJson();
