#pragma once

#include <Arduino.h>
#include <FS.h>

// EVO4 PCB USB-A HOST:
// D- = GPIO19, D+ = GPIO20, VBUS = 5 V z ukladu zasilania USB HOST.
// Arduino-ESP32 3.3.12: oficjalny TinyUSB USBHost + USBHostMSC + USBMSCFS.
// Arduino IDE: USB Mode = USB-OTG (TinyUSB), USB CDC On Boot = Disabled.
bool evoUsbHostSupported();
bool evoUsbHostBegin();
void evoUsbHostLoop();
bool evoUsbHostMounted();
bool evoUsbHostReady();
fs::FS &evoUsbHostFs();
const char *evoUsbHostStatus();
uint64_t evoUsbHostCapacityBytes();
void evoUsbHostSetActivity(const char *activity);
const char *evoUsbHostActivity();
uint32_t evoUsbHostReadCount();
uint32_t evoUsbHostErrorCount();
uint32_t evoUsbHostLastSector();
uint32_t evoUsbHostLastSectorCount();
int32_t evoUsbHostLastError();
uint32_t evoUsbHostLastTransferMs();

// Diagnostyka backendu wybranego podczas kompilacji.
const char *evoUsbHostBackend();
