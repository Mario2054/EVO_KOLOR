#pragma once
#include <atomic>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
// Single producer (Audio compressed-stream callback), single consumer (main loop).
// Storage is owned by caller and MUST outlive capture. Capacity power of two.
class EvoMp3Ring {
public:
  void attach(uint8_t *memory,uint32_t capacity) {
    memory_=memory; capacity_=capacity;
    reset();
  }
  void reset() {
    read_.store(0,std::memory_order_relaxed);
    write_.store(0,std::memory_order_relaxed);
    dropped_.store(0,std::memory_order_relaxed);
    peak_.store(0,std::memory_order_relaxed);
  }
  bool push(const uint8_t *source,size_t n) {
    if(!memory_ || !capacity_ || (capacity_&(capacity_-1)) || !source || !n || n>capacity_) {
      dropped_.fetch_add(static_cast<uint32_t>(n),std::memory_order_relaxed);
      return false;
    }
    const uint32_t w=write_.load(std::memory_order_relaxed);
    const uint32_t r=read_.load(std::memory_order_acquire);
    const uint32_t occupied=w-r;
    if(occupied>capacity_ || n>capacity_-occupied){
      dropped_.fetch_add(static_cast<uint32_t>(n),std::memory_order_relaxed);
      return false; // Never write part of an Audio4 callback chunk
    }
    const uint32_t offset=w&(capacity_-1);
    const size_t first=n<capacity_-offset?n:capacity_-offset;
    memcpy(memory_+offset,source,first);
    if(first<n)memcpy(memory_,source+first,n-first);
    write_.store(w+static_cast<uint32_t>(n),std::memory_order_release);
    const uint32_t used=occupied+static_cast<uint32_t>(n);
    uint32_t prev=peak_.load(std::memory_order_relaxed);
    while(used>prev&&!peak_.compare_exchange_weak(prev,used,std::memory_order_relaxed)){}
    return true;
  }
  size_t copy(void* dst,size_t limit) const {
    if(!dst || !limit || !memory_)return 0;
    const uint32_t r=read_.load(std::memory_order_relaxed);
    const uint32_t w=write_.load(std::memory_order_acquire);
    const uint32_t n=w-r;
    const size_t size=(size_t)n<limit?(size_t)n:limit;
    const uint32_t offset=r&(capacity_-1);
    const size_t first=size<capacity_-offset?size:capacity_-offset;
    memcpy(dst,memory_+offset,first);
    if(first<size)memcpy(static_cast<uint8_t*>(dst)+first,memory_,size-first);
    return size;
  }
  void consume(size_t count) {
    if(!count)return;
    // Only the single consumer calls consume; count <= preceding copy count.
    read_.store(read_.load(std::memory_order_relaxed)+static_cast<uint32_t>(count),std::memory_order_release);
  }
  uint32_t available()const{return write_.load(std::memory_order_acquire)-read_.load(std::memory_order_acquire);}
  uint32_t dropped()const{return dropped_.load(std::memory_order_relaxed);}
  uint32_t peak()const{return peak_.load(std::memory_order_relaxed);}
  uint32_t capacity()const{return capacity_;}
private:
  uint8_t *memory_=nullptr;
  uint32_t capacity_=0;
  std::atomic<uint32_t> read_{0},write_{0},dropped_{0},peak_{0};
};
