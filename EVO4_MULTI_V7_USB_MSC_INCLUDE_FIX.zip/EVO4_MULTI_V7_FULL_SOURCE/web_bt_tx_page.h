#pragma once
#include <Arduino.h>

/*
  APMS EVO4 MULTI / EVO4 MULTI
  Panel WWW sterowania modułem EVO-BT-TX v5.5
  Przygotowano dla EJCON

  Wymagane endpointy po stronie EVO4 MULTI:
    GET  /api/bt/status
      JSON:
      {
        "bt":true, "connected":true, "audio":true,
        "device":"BTS650K", "mac":"1C:2C:E0:02:60:80",
        "sourceHz":44100, "mode":"TX", "gain":300, "volume":100,
        "ringBuffer":4095, "ringBufferMax":4096,
        "autoConnect":true, "autoSave":true, "reconnect":true,
        "fw":"v5.5 STABLE", "uart":"RX17/TX16",
        "i2s":"BCLK26 / WS25 / DIN22",
        "uptime":"00:12:45",
        "i2sOk":24507, "i2sErr":0, "i2sZero":0,
        "i2sBytes":50190336, "cbCalls":9834, "cbSilent":0,
        "cbUnderrun":0, "rbOverflow":0, "clip":0,
        "connectMs":14136, "audioDelayMs":6527,
        "retries":0, "retryMax":1, "lastConnection":"AUTO"
      }

    POST /api/bt/command
      Content-Type: application/json
      Body: {"cmd":"GET"}
      Odpowiedź: {"ok":true,"response":"OK ..."} albo zwykły tekst.

    GET /api/bt/devices
      JSON:
      {"scanning":false,"devices":[
        {"idx":0,"name":"BTS650K","mac":"1C:2C:E0:02:60:80","rssi":-72}
      ]}

  Możesz zmienić endpointy w stałej API_CONFIG w kodzie JavaScript.
*/

static const char EVO_BT_WEB_PAGE[] PROGMEM = R"BTWEB(
<!DOCTYPE html>
<html lang="pl">
<head><style id="evo4-unified-theme">:root{--evo-bg:#06111f;--evo-card:#081827;--evo-border:#1a344b;--evo-blue:#008cff;--evo-cyan:#29c7ff}html,body{color-scheme:dark}body{background:#06111f!important;color:#e9f2ff!important;font-family:'Segoe UI',Arial,sans-serif!important}button,input,select{font-family:inherit}button{cursor:pointer}button:hover{filter:brightness(1.16)}.evo4-return{position:fixed;right:18px;top:16px;z-index:99999;display:flex;align-items:center;gap:9px;padding:9px 15px 9px 10px;border-radius:30px;background:linear-gradient(135deg,#004a9b,#008cff 55%,#003a7a);border:1px solid #29c7ff;box-shadow:0 0 12px #008cff77;color:white!important;text-decoration:none!important;font:bold 13px 'Segoe UI',Arial,sans-serif;letter-spacing:.2px}.evo4-return .evo4-arrow{display:grid;place-items:center;width:32px;height:32px;border-radius:50%;background:#061b38;border:1px solid #7edbff;font-size:25px;line-height:1}.evo4-return:hover{box-shadow:0 0 20px #008cffb0;transform:translateY(-1px)}@media(max-width:600px){.evo4-return{right:8px;top:8px;padding:6px 10px}.evo4-return .evo4-arrow{width:26px;height:26px;font-size:21px}}</style>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>APMS EVO-BT-TX v5.5</title>
<style>
:root{
  --bg:#f3f5f8;--card:#fff;--line:#dfe5ec;--text:#131820;--muted:#657080;
  --blue:#1475dc;--blue2:#0f62bd;--green:#239a3b;--red:#e53535;--amber:#f08c18;
  --shadow:0 4px 16px rgba(20,36,58,.10);--radius:14px
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);font-family:Arial,Helvetica,sans-serif;color:var(--text)}
.wrap{max-width:1180px;margin:0 auto;padding:18px}
header{text-align:center;margin:2px 0 14px}
header h1{font-size:28px;margin:0;font-weight:800;letter-spacing:.3px}
header p{margin:4px 0 0;color:#4d5663;font-weight:600}
.card{background:var(--card);border:1px solid #e4e8ee;border-radius:var(--radius);box-shadow:var(--shadow);padding:18px;margin-bottom:12px}
.card h2{font-size:19px;margin:0 0 14px;display:flex;gap:8px;align-items:center}
.statebar{display:flex;justify-content:center;gap:24px;flex-wrap:wrap;border:1px solid #addfb7;background:#f2fff4;color:#147c2a;border-radius:6px;padding:8px;font-weight:700}
.dot{display:inline-block;width:11px;height:11px;border-radius:50%;background:#a8adb5;margin-right:6px}
.dot.on{background:var(--green)}
.grid{display:grid;grid-template-columns:repeat(4,1fr);border:1px solid var(--line);border-radius:8px;overflow:hidden;margin-top:8px}
.cell{text-align:center;padding:11px;border-right:1px solid var(--line);border-bottom:1px solid var(--line);min-height:66px}
.cell:nth-child(4n){border-right:0}
.cell:nth-last-child(-n+4){border-bottom:0}
.label{font-size:13px;color:#4c5562;margin-bottom:5px}.value{font-weight:800;font-size:15px;word-break:break-word}
.badge{display:inline-block;padding:3px 9px;color:#fff;background:var(--blue);border-radius:5px;font-weight:800}
.badge.green{background:var(--green)}.badge.red{background:var(--red)}
.meta{display:flex;gap:18px;justify-content:center;flex-wrap:wrap;color:#596272;font-size:13px;margin-top:12px}
.row{display:flex;gap:16px;align-items:center;flex-wrap:wrap}.grow{flex:1}
.btn{border:0;border-radius:6px;padding:10px 16px;font-weight:800;color:white;background:var(--blue);cursor:pointer;box-shadow:0 2px 5px rgba(0,0,0,.09)}
.btn:hover{background:var(--blue2)}.btn.green{background:var(--green)}.btn.red{background:var(--red)}.btn.gray{background:#727b87}
.btn.active{outline:3px solid rgba(20,117,220,.25)}
.controls{display:grid;grid-template-columns:1fr 1fr;gap:24px}
.control{text-align:center}.control+.control{border-left:1px solid var(--line)}
input[type=range]{width:86%;accent-color:var(--blue)}
input[type=number],input[type=text]{border:1px solid #cfd5dc;border-radius:5px;padding:9px;font-size:14px}
.quick{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin-top:12px}
.actions{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.diag{display:grid;grid-template-columns:repeat(6,1fr);border:1px solid var(--line);border-radius:8px;overflow:hidden}
.diag .cell{min-height:62px}.good{color:var(--green)}.warn{color:var(--amber)}.bad{color:var(--red)}.violet{color:#6c22d7}
.devices{width:100%;border-collapse:collapse;margin-top:12px}.devices th,.devices td{border-bottom:1px solid var(--line);padding:9px;text-align:left;font-size:14px}.devices th{background:#f7f9fb}
.terminal{height:210px;background:#090b0d;color:#46e33c;border-radius:7px;padding:10px;overflow:auto;font:13px/1.45 Consolas,monospace;white-space:pre-wrap}
.termrow{display:flex;gap:8px;margin-bottom:8px}.termrow input{flex:1}
.small{font-size:12px;color:var(--muted)}.right{margin-left:auto}
.progress{height:7px;background:#e5e9ee;border-radius:8px;overflow:hidden;margin-top:6px}.progress>span{display:block;height:100%;background:var(--green);width:0}
footer{display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap;color:#66707c;font-size:13px;padding:8px 2px 18px}
.toast{position:fixed;right:20px;bottom:20px;background:#17202b;color:#fff;padding:12px 16px;border-radius:7px;display:none;z-index:99;max-width:360px}
@media(max-width:900px){.grid{grid-template-columns:repeat(2,1fr)}.cell:nth-child(4n){border-right:1px solid var(--line)}.cell:nth-child(2n){border-right:0}.cell:nth-last-child(-n+4){border-bottom:1px solid var(--line)}.cell:nth-last-child(-n+2){border-bottom:0}.diag{grid-template-columns:repeat(3,1fr)}}
@media(max-width:650px){.wrap{padding:10px}.controls{grid-template-columns:1fr}.control+.control{border-left:0;border-top:1px solid var(--line);padding-top:18px}.grid,.diag{grid-template-columns:1fr}.cell{border-right:0!important;border-bottom:1px solid var(--line)!important}.cell:last-child{border-bottom:0!important}header h1{font-size:22px}}
</style>
</head>
<body><a class="evo4-return" href="/" aria-label="Powrót do głównej strony EVO4 MULTI"><span class="evo4-arrow">↶</span><span>POWRÓT DO MENU</span></a>
<div class="wrap">
<header>
  <h1>🔷 APMS EVO-BT-TX v5.5</h1>
  <p>Przygotowano dla EJCON</p>
</header>

<section class="card">
  <h2>📶 Status</h2>
  <div class="statebar">
    <span><i id="btDot" class="dot"></i>Bluetooth: <b id="btState">---</b></span>
    <span><i id="connDot" class="dot"></i><b id="connState">Disconnected</b></span>
    <span><i id="audioDot" class="dot"></i><b id="audioState">Audio stopped</b></span>
  </div>
  <div class="grid">
    <div class="cell"><div class="label">Device</div><div class="value" id="device">---</div></div>
    <div class="cell"><div class="label">MAC</div><div class="value" id="mac">---</div></div>
    <div class="cell"><div class="label">Source</div><div class="value" id="source">---</div></div>
    <div class="cell"><div class="label">Mode</div><div class="value"><span class="badge" id="mode">---</span></div></div>
    <div class="cell"><div class="label">GAIN</div><div class="value" id="gain">--- %</div></div>
    <div class="cell"><div class="label">Volume</div><div class="value" id="volume">--- %</div></div>
    <div class="cell"><div class="label">Ring Buffer</div><div class="value" id="rb">--- / ---</div><div class="progress"><span id="rbBar"></span></div></div>
    <div class="cell"><div class="label">Uptime</div><div class="value" id="uptime">---</div></div>
    <div class="cell"><div class="label">Auto Connect</div><span class="badge green" id="autoConnect">---</span></div>
    <div class="cell"><div class="label">Auto Save</div><span class="badge green" id="autoSave">---</span></div>
    <div class="cell"><div class="label">Reconnect</div><span class="badge green" id="reconnect">---</span></div>
    <div class="cell"><div class="label">Last Connect</div><div class="value" id="lastConnection">---</div></div>
  </div>
  <div class="meta">
    <span>FW: <b id="fw">---</b></span><span>|</span>
    <span>Device Name: <b>EVO-BT-TX</b></span><span>|</span>
    <span>UART: <b id="uartPins">---</b></span><span>|</span>
    <span>I2S: <b id="i2sPins">---</b></span>
  </div>
</section>

<section class="card">
  <h2>⚡ Komunikacja UART</h2>
  <div class="row">
    <label><input type="checkbox" id="uartEnabled" checked onchange="setUart(this.checked)"> Włącz komunikację UART z modułem BT (RX19/TX20)</label>
    <span class="right">Status: <b class="good" id="uartStatus">Connected</b></span>
    <button class="btn" onclick="sendCommand('PING')">Test UART</button>
  </div>
  <div class="small">Po wyłączeniu sterowanie modułem BT przez UART zostaje zatrzymane po stronie EVO4 MULTI.</div>
</section>

<section class="card">
  <h2>🔄 Mode Selection</h2>
  <div class="actions">
    <button class="btn green" onclick="setMode('OFF')">OFF</button>
    <button class="btn" onclick="setMode('RX')">RX (Receiver)</button>
    <button class="btn active" onclick="setMode('TX')">TX (Transmitter)</button>
    <button class="btn" onclick="setMode('AUTO')">AUTO</button>
  </div>
  <p class="small" style="text-align:center">RX – telefon wysyła audio do radia &nbsp; | &nbsp; TX – radio wysyła audio do słuchawek BT &nbsp; | &nbsp; AUTO – automatyczny wybór</p>
</section>

<section class="card">
  <div class="controls">
    <div class="control">
      <h2 style="justify-content:center">🔊 Volume (TX Mode)</h2>
      <div><input id="volNum" type="number" min="0" max="100" value="100"> % <button class="btn" onclick="setVolume()">Set</button></div>
      <input id="volRange" type="range" min="0" max="100" value="100" oninput="volNum.value=this.value">
      <div class="quick"><button class="btn" onclick="quickVol(25)">25%</button><button class="btn" onclick="quickVol(50)">50%</button><button class="btn" onclick="quickVol(75)">75%</button><button class="btn" onclick="quickVol(100)">100%</button></div>
    </div>
    <div class="control">
      <h2 style="justify-content:center">🎚 GAIN (Audio Boost)</h2>
      <div><input id="gainNum" type="number" min="100" max="400" value="300"> % <button class="btn" onclick="setGain()">Set</button></div>
      <input id="gainRange" type="range" min="100" max="400" step="1" value="300" oninput="gainNum.value=this.value">
      <div class="quick"><button class="btn green" onclick="quickGain(100)">100%</button><button class="btn green" onclick="quickGain(200)">200%</button><button class="btn green" onclick="quickGain(300)">300%</button><button class="btn green" onclick="quickGain(400)">400%</button></div>
    </div>
  </div>
  <div class="small" style="text-align:center;background:#edf5ff;padding:7px;margin-top:12px;border-radius:5px">GAIN 100% = 0 dB &nbsp; | &nbsp; 200% ≈ +6 dB &nbsp; | &nbsp; 300% ≈ +9.5 dB &nbsp; | &nbsp; 400% ≈ +12 dB &nbsp; (Soft Limiter ON)</div>
</section>

<section class="card">
  <h2>🔧 Actions</h2>
  <div class="actions">
    <button class="btn" onclick="sendCommand('GET')">🔄 Odczytaj status</button>
    <button class="btn" onclick="sendCommand('PING')">📡 Test PING</button>
    <button class="btn" onclick="scanDevices()">🔍 Scan Devices</button>
    <button class="btn gray" onclick="sendCommand('STOPSCAN')">⏹ Stop Scan</button>
    <button class="btn green" onclick="sendCommand('CONNECT LAST')">♻ Connect Last Device</button>
    <button class="btn" onclick="sendCommand('DISCONNECT')">↪ Disconnect</button>
    <button class="btn red" onclick="deletePaired()">🗑 Delete All Paired</button>
    <button class="btn green" onclick="sendCommand('SAVE')">💾 Zapisz ustawienia</button>
  </div>
  <div id="devicePanel" style="display:none">
    <table class="devices">
      <thead><tr><th>#</th><th>Nazwa</th><th>MAC</th><th>RSSI</th><th>Akcja</th></tr></thead>
      <tbody id="devicesBody"></tbody>
    </table>
  </div>
  <p class="small" style="text-align:center">Połączenie zostanie automatycznie ponowione po utracie połączenia (1 próba).</p>
</section>

<section class="card">
  <div class="row"><h2>📊 Diagnostyka (na żywo)</h2><label class="right small">Auto-refresh co 1 s <input type="checkbox" id="autoRefresh" checked></label></div>
  <div class="diag">
    <div class="cell"><div class="label">I2S OK</div><div class="value good" id="i2sOk">0</div></div>
    <div class="cell"><div class="label">I2S ERR</div><div class="value good" id="i2sErr">0</div></div>
    <div class="cell"><div class="label">I2S ZERO</div><div class="value good" id="i2sZero">0</div></div>
    <div class="cell"><div class="label">I2S BYTES</div><div class="value" id="i2sBytes">0</div></div>
    <div class="cell"><div class="label">CB CALLS</div><div class="value" id="cbCalls">0</div></div>
    <div class="cell"><div class="label">CB SILENT</div><div class="value good" id="cbSilent">0</div></div>
    <div class="cell"><div class="label">CB UNDERRUN</div><div class="value good" id="cbUnderrun">0</div></div>
    <div class="cell"><div class="label">RB OVERFLOW</div><div class="value good" id="rbOverflow">0</div></div>
    <div class="cell"><div class="label">CLIP</div><div class="value good" id="clip">0</div></div>
    <div class="cell"><div class="label">CONNECT MS</div><div class="value violet" id="connectMs">0</div></div>
    <div class="cell"><div class="label">AUDIO DELAY MS</div><div class="value violet" id="audioDelayMs">0</div></div>
    <div class="cell"><div class="label">RETRIES</div><div class="value warn" id="retries">0 / 1</div></div>
  </div>
</section>

<section class="card">
  <h2>🖥 Terminal diagnostyczny BT UART</h2>
  <div class="termrow">
    <input type="text" id="cmd" placeholder="AT / komenda UART" onkeydown="if(event.key==='Enter')manualSend()">
    <button class="btn" onclick="manualSend()">Send</button>
    <button class="btn red" onclick="clearTerminal()">Clear</button>
  </div>
  <div class="terminal" id="terminal"></div>
</section>

<section class="card">
  <h2>🎛 Sterowanie pilotem IR — panel MODE 12</h2>
  <div class="grid">
    <div class="cell"><div class="label">VOL + / VOL −</div><div class="value">Głośność BT ±5%</div></div>
    <div class="cell"><div class="label">Góra / Dół</div><div class="value">GAIN ±25%</div></div>
    <div class="cell"><div class="label">Prawo / Lewo</div><div class="value">MODE TX / OFF</div></div>
    <div class="cell"><div class="label">OK</div><div class="value">CONNECT LAST</div></div>
    <div class="cell"><div class="label">MUTE</div><div class="value">DISCONNECT</div></div>
    <div class="cell"><div class="label">0 / 1</div><div class="value">OFF / TX</div></div>
    <div class="cell"><div class="label">2 / 3 / 4</div><div class="value">SCAN / CONNECT / DISCONNECT</div></div>
    <div class="cell"><div class="label">5 / 6</div><div class="value">SAVE / GET</div></div>
  </div>
  <p class="small" style="text-align:center">Odbiornik IR: GPIO8. Poza panelem Bluetooth pilot zachowuje dotychczasowe funkcje radia.</p>
</section>

<footer><span>APMS EVO4 MULTI &nbsp; | &nbsp; Bluetooth Audio Transmitter &nbsp; | &nbsp; v5.5 STABLE</span><span>Przygotowano dla EJCON</span></footer>
</div>
<div class="toast" id="toast"></div>

<script>
const API_CONFIG={
  status:'/bt/api/state',
  diag:'/bt/api/diagfull',
  command:'/bt/api/cmd',
  devices:'/bt/api/devices'
};

const $=id=>document.getElementById(id);
function esc(s){return String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function term(line,dir='<'){
  const t=$('terminal');
  const time=new Date().toLocaleTimeString('pl-PL');
  t.textContent+=`[${time}] ${dir} ${line}\n`;
  t.scrollTop=t.scrollHeight;
}
function toast(msg){
  const el=$('toast');el.textContent=msg;el.style.display='block';
  setTimeout(()=>el.style.display='none',2600);
}
async function apiJson(url,opt={}){
  const r=await fetch(url,{cache:'no-store',...opt});
  const ct=r.headers.get('content-type')||'';
  if(!r.ok)throw new Error(`HTTP ${r.status}`);
  return ct.includes('application/json')?r.json():{response:await r.text()};
}
async function sendCommand(cmd){
  if(!$('uartEnabled').checked){toast('Komunikacja UART jest wyłączona');return}
  term(cmd,'>');
  try{
    const d=await apiJson(API_CONFIG.command+'?cmd='+encodeURIComponent(cmd),{method:'POST'});
    term(d.response||d.message||(d.ok?'OK':'Brak odpowiedzi'),'<');
    toast(d.ok===false?'Polecenie odrzucone':'Polecenie wysłane');
    setTimeout(refreshStatus,250);
    return d;
  }catch(e){term('ERR '+e.message,'!');toast('Błąd komunikacji: '+e.message)}
}
function boolBadge(id,v){const e=$(id);e.textContent=v?'ON':'OFF';e.className='badge '+(v?'green':'red')}
function setDot(id,on){$(id).classList.toggle('on',!!on)}
function setText(id,v,fallback='---'){$(id).textContent=(v===undefined||v===null||v==='')?fallback:v}
function fmtBytes(n){n=Number(n)||0;if(n>=1048576)return(n/1048576).toFixed(1)+' MB';if(n>=1024)return(n/1024).toFixed(1)+' kB';return n+' B'}
function diagClass(id,n){const e=$(id);e.className='value '+((Number(n)||0)===0?'good':'bad')}
async function refreshStatus(){
  try{
    const s=await apiJson(API_CONFIG.status);
    const bt=s.bt??s.btOn, connected=s.connected??s.conn;
    setDot('btDot',bt);setDot('connDot',connected);setDot('audioDot',s.audio);
    setText('btState',bt?'ON':'OFF');setText('connState',connected?'Connected':'Disconnected');
    setText('audioState',s.audio?'Audio Streaming':'Audio stopped');
    setText('device',s.device??s.name);setText('mac',s.mac);setText('source',s.sourceHz?`${(s.sourceHz/1000).toFixed(1)} kHz (${s.sourceHz} Hz)`:'---');
    setText('mode',s.mode);setText('gain',(s.gain??s.boost??0)+' %');setText('volume',(s.volume??s.vol??0)+' %');
    setText('rb',`${s.ringBuffer??0} / ${s.ringBufferMax??4096}`);
    $('rbBar').style.width=Math.min(100,100*(s.ringBuffer||0)/(s.ringBufferMax||4096))+'%';
    setText('uptime',s.uptime);boolBadge('autoConnect',s.autoConnect);boolBadge('autoSave',s.autoSave);boolBadge('reconnect',s.reconnect);
    setText('lastConnection',s.lastConnection);setText('fw',s.fw);setText('uartPins',s.uart);setText('i2sPins',s.i2s);
    setText('i2sOk',s.i2sOk??0);setText('i2sErr',s.i2sErr??0);setText('i2sZero',s.i2sZero??0);setText('i2sBytes',fmtBytes(s.i2sBytes));
    setText('cbCalls',s.cbCalls??0);setText('cbSilent',s.cbSilent??0);setText('cbUnderrun',s.cbUnderrun??0);
    setText('rbOverflow',s.rbOverflow??0);setText('clip',s.clip??0);setText('connectMs',s.connectMs??0);setText('audioDelayMs',s.audioDelayMs??0);
    setText('retries',`${s.retries??0} / ${s.retryMax??1}`);
    diagClass('i2sErr',s.i2sErr);diagClass('i2sZero',s.i2sZero);diagClass('cbSilent',s.cbSilent);
    diagClass('cbUnderrun',s.cbUnderrun);diagClass('rbOverflow',s.rbOverflow);diagClass('clip',s.clip);
    $('volNum').value=s.volume??s.vol??100;$('volRange').value=s.volume??s.vol??100;
    $('gainNum').value=s.gain??s.boost??300;$('gainRange').value=s.gain??s.boost??300;
    $('uartStatus').textContent='Connected';$('uartStatus').className='good';
  }catch(e){$('uartStatus').textContent='No response';$('uartStatus').className='bad'}
}
function setMode(m){sendCommand('MODE '+m)}
function setVolume(){let v=Math.max(0,Math.min(100,Number($('volNum').value)||0));$('volRange').value=v;sendCommand('VOL '+v)}
function quickVol(v){$('volNum').value=v;$('volRange').value=v;sendCommand('VOL '+v)}
function setGain(){let v=Math.max(100,Math.min(400,Number($('gainNum').value)||100));$('gainRange').value=v;sendCommand('GAIN '+v)}
function quickGain(v){$('gainNum').value=v;$('gainRange').value=v;sendCommand('GAIN '+v)}
function manualSend(){const c=$('cmd').value.trim();if(!c)return;$('cmd').value='';sendCommand(c)}
function clearTerminal(){$('terminal').textContent=''}
async function scanDevices(){await sendCommand('SCAN');$('devicePanel').style.display='block';setTimeout(loadDevices,1800);setTimeout(loadDevices,4500)}
async function loadDevices(){
  try{
    const d=await apiJson(API_CONFIG.devices),tb=$('devicesBody');tb.innerHTML='';
    (d.devices||[]).forEach(x=>{
      const tr=document.createElement('tr');
      const id=x.idx??x.id;
      tr.innerHTML=`<td>${id}</td><td>${esc(x.name||'')}</td><td>${esc(x.mac||'')}</td><td>${x.rssi??''}</td><td><button class="btn" onclick="connectDevice(${id})">Połącz</button></td>`;
      tb.appendChild(tr);
    });
  }catch(e){term('ERR DEVICES '+e.message,'!')}
}
function deletePaired(){if(confirm('Usunąć wszystkie sparowane urządzenia Bluetooth?'))sendCommand('DELPAIRED ALL')}
async function connectDevice(id){await apiJson('/bt/api/connect?id='+encodeURIComponent(id),{method:'POST'});toast('Łączenie z urządzeniem '+id)}
async function setUart(on){await apiJson('/bt/api/uart?enable='+(on?'1':'0'),{method:'POST'});$('uartStatus').textContent=on?'Connected':'Disabled'}
setInterval(()=>{if($('autoRefresh').checked)refreshStatus()},1000);
setUart(true);apiJson('/bt/api/terminal?enable=1',{method:'POST'});refreshStatus();loadDevices();term('Panel BT gotowy.');
</script>
</body>
</html>
)BTWEB";
