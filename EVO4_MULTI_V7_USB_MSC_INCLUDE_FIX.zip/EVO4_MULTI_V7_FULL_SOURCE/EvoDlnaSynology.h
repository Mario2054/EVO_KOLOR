#pragma once

#include <Arduino.h>
#include <atomic>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/semphr.h"

// Lekki klient UPnP AV / DLNA dla EVO4.
// Ciezka implementacja HTTP/SOAP/SSDP jest w EvoDlnaSynology.cpp.
// Rozdzielenie jest celowe: zapobiega bledowi linkera Xtensa L32R
// przy bardzo duzym szkicu Arduino.
namespace EvoDlna {

static constexpr uint8_t MAX_SERVERS = 8;
static constexpr uint8_t MAX_ITEMS = 8;
static constexpr uint8_t MAX_DEPTH = 10;

struct Server {
  String name;
  String location;
  String controlUrl;
  String udn;
};

struct Item {
  String id;
  String parentId;
  String title;
  String url;
  String mime;
  bool container = false;
};

extern Server servers[MAX_SERVERS];
extern Item items[MAX_ITEMS];
extern uint8_t serverCount;
extern uint8_t itemCount;
extern uint8_t selectedServer;
extern uint8_t selectedItem;
extern String currentObjectId;
extern String currentTitle;
extern String historyId[MAX_DEPTH];
extern String historyTitle[MAX_DEPTH];
extern uint8_t historyDepth;
extern uint32_t pageStart;
extern uint32_t totalMatches;
extern String lastStatus;
extern String lastError;
extern String nowPlaying;
extern std::atomic<bool> busy;
extern SemaphoreHandle_t mutex;
extern TaskHandle_t worker;
extern uint32_t discoverStackSpare;
extern uint32_t browseStackSpare;

void begin();
bool discoverAsync(const String &manualUrl = String());
bool browseAsync(const String &control,
                 const String &id,
                 const String &title,
                 int8_t historyAction,
                 uint32_t startIndex = 0);
bool selectServerAndBrowse(uint8_t index);
bool openSelected(String &playUrl, String &title);
bool goBack();
bool nextPage();
bool previousPage();
void selectDelta(int delta);

} // namespace EvoDlna
