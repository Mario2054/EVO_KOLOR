#pragma once
#include <Arduino.h>

// ================================================================
// APMS / EVO4 - obsluga presetow z pilota dla zewnetrznego EQ16 DSP ESP32-C6
//
// Ten plik jest dolaczany po EvoDspEq16Bridge.h.
// Korzysta z istniejacej funkcji evo43Eq16Preset(p), a po zmianie
// presetu wysyla komplet 16 pasm do zewnetrznego ESP32-C6 DSP po UART.
//
// Pilot w menu GRAPHIC EQ16:
//   KEY 0 = FLAT
//   KEY 1 = ROCK
//   KEY 2 = POP
//   KEY 3 = JAZZ
//   KEY 4 = LOUDNESS
//   KEY 5 = DANCE
//   KEY 6 = VOCAL
//   KEY 7 = BASS
//   BANK+/- = dostep do wszystkich 16 presetow
//   BANK+ = nastepny preset
//   BANK- = poprzedni preset
//   DIRECT = reset / FLAT
// ================================================================

#ifndef EVO_EQ16_PRESET_REMOTE_COUNT
#define EVO_EQ16_PRESET_REMOTE_COUNT 16
#endif

static uint8_t evoEq16RemotePreset = 0;

static const char* evoEq16PresetName(uint8_t preset)
{
  static const char* names[EVO_EQ16_PRESET_REMOTE_COUNT] = {
    "FLAT", "ROCK", "POP", "JAZZ", "LOUD", "DANCE", "VOCAL", "BASS",
    "TREBLE", "CLASSICAL", "ELECTRONIC", "ACOUSTIC", "MOVIE", "NIGHT", "RADIO", "RETRO"
  };
  if (preset >= EVO_EQ16_PRESET_REMOTE_COUNT) preset = 0;
  return names[preset];
}

static void evoEq16ApplyPresetRemote(uint8_t preset, bool openPanel = true)
{
  if (preset >= EVO_EQ16_PRESET_REMOTE_COUNT) preset = 0;
  evoEq16RemotePreset = preset;

  // Ustawienie tablicy EQ16 w glownym EVO3.
  evo43Eq16Preset(preset);

  // Wyslanie calego EQ16 do zewnetrznego procesora DSP/korektora.
  evoDspSendEq16All(true, true);

  evo43Eq16EditGain = false;
  evo43LastAction = String("EQ PRESET ") + String(preset) + " " + evoEq16PresetName(preset);

  if (openPanel) evo43Eq16OpenPanel();
}

static void evoEq16PresetNext()
{
  uint8_t next = evoEq16RemotePreset + 1;
  if (next >= EVO_EQ16_PRESET_REMOTE_COUNT) next = 0;
  evoEq16ApplyPresetRemote(next, true);
}

static void evoEq16PresetPrev()
{
  uint8_t prev = (evoEq16RemotePreset == 0) ? (EVO_EQ16_PRESET_REMOTE_COUNT - 1) : (evoEq16RemotePreset - 1);
  evoEq16ApplyPresetRemote(prev, true);
}

static bool evoEq16HandlePresetKey(uint8_t key)
{
  if (key >= EVO_EQ16_PRESET_REMOTE_COUNT) return false;
  evoEq16ApplyPresetRemote(key, true);
  return true;
}
