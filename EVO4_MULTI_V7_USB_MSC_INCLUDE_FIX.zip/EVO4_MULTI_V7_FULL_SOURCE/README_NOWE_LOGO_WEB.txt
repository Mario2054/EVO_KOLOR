EVO4 MULTI V6 - nowe logo i okladka zastepcza
Zmiany tylko w Evo4_Evo3_Pixel_Web.h.
Logo w naglowku i przy braku logo stacji: grafika EVO4 MULTI.
Brak okladki: grafika winyl/ALBUM COVER.
Prawdziwe logo stacji i prawdziwa okladka maja pierwszenstwo.
Grafiki osadzone w HTML, bez dodatkowych zapytan do ESP32.
Nie testowano kompilacji ani urzadzenia.
