#pragma once
#include <Arduino.h>
#include <atomic>
#include <stdint.h>
// HQ60: RGB565 panel palette runtime variables only. No artwork/global byte swap.
namespace Evo4Retro {
constexpr uint16_t RGB(uint32_t v) {
  return uint16_t(((((v>>16)&255u)>>3)<<11) | (((((v>>8)&255u)>>2)<<5)) | ((v&255u)>>3));
}
namespace Cassette {
  extern std::atomic<uint32_t> BG; // RGB default 0x060609
  extern std::atomic<uint32_t> SHELL; // RGB default 0xAC2428
  extern std::atomic<uint32_t> SHELL_EDGE; // RGB default 0xEA6961
  extern std::atomic<uint32_t> BODY; // RGB default 0x202124
  extern std::atomic<uint32_t> WINDOW_TRIM; // RGB default 0x781E25
  extern std::atomic<uint32_t> WHITE; // RGB default 0xFCF7ED
  extern std::atomic<uint32_t> LABEL_RULE; // RGB default 0xA93434
  extern std::atomic<uint32_t> WINDOW_BG; // RGB default 0x11191C
  extern std::atomic<uint32_t> WINDOW_BORDER; // RGB default 0xABB1B3
  extern std::atomic<uint32_t> TAPE_DARK; // RGB default 0x513429
  extern std::atomic<uint32_t> TAPE_BROWN; // RGB default 0x855339
  extern std::atomic<uint32_t> HUB_SHADOW; // RGB default 0x31353B
  extern std::atomic<uint32_t> CENTER_BORDER; // RGB default 0x8F9293
  extern std::atomic<uint32_t> TAPE_HIGHLIGHT; // RGB default 0xCFB17B
  extern std::atomic<uint32_t> STRIP; // RGB default 0xC91B24
  extern std::atomic<uint32_t> PLAY_CYAN; // RGB default 0x00DCD7
  extern std::atomic<uint32_t> RED; // RGB default 0xF13738
  extern std::atomic<uint32_t> YELLOW; // RGB default 0xF8D450
  extern std::atomic<uint32_t> GREEN; // RGB default 0x34CF65
  extern std::atomic<uint32_t> HUB_METAL; // RGB default 0xCACED0
  extern std::atomic<uint32_t> HUB_HIGHLIGHT; // RGB default 0xF4F2E9
  extern std::atomic<uint32_t> HUB_TOOTH; // RGB default 0x54595B
  extern std::atomic<uint32_t> METER_OFF; // RGB default 0x343638
}
namespace Reel {
  extern std::atomic<uint32_t> BACKDROP; // RGB default 0x1B1E20
  extern std::atomic<uint32_t> WOOD; // RGB default 0x513022
  extern std::atomic<uint32_t> PANEL_FACE; // RGB default 0xC8CFD0
  extern std::atomic<uint32_t> SILVER_TRIM; // RGB default 0xF3F3EF
  extern std::atomic<uint32_t> PANEL_STRIP; // RGB default 0xB5A485
  extern std::atomic<uint32_t> PANEL_DARK; // RGB default 0x25292D
  extern std::atomic<uint32_t> ALUMINUM; // RGB default 0xD6DAD9
  extern std::atomic<uint32_t> ALUMINUM_EDGE; // RGB default 0xA5AEAF
  extern std::atomic<uint32_t> ALUMINUM_LIGHT; // RGB default 0xF2F2EA
  extern std::atomic<uint32_t> ALUMINUM_MID; // RGB default 0xDEE2DF
  extern std::atomic<uint32_t> METAL_GROOVE; // RGB default 0xA5A9A8
  extern std::atomic<uint32_t> TAPE; // RGB default 0x302A25
  extern std::atomic<uint32_t> WHITE; // RGB default 0xF8F5EA
  extern std::atomic<uint32_t> BUTTON; // RGB default 0x777C7E
  extern std::atomic<uint32_t> AMBER; // RGB default 0xFFD069
  extern std::atomic<uint32_t> GREEN; // RGB default 0x42D267
  extern std::atomic<uint32_t> RED; // RGB default 0xDC3033
  extern std::atomic<uint32_t> COUNTER_BG; // RGB default 0x0D1215
  extern std::atomic<uint32_t> VU_FACE; // RGB default 0xF4E9CA
  extern std::atomic<uint32_t> VU_EDGE; // RGB default 0xA08E70
  extern std::atomic<uint32_t> VU_INK; // RGB default 0x34302B
  extern std::atomic<uint32_t> VU_PIN; // RGB default 0xC79B57
}
namespace Turntable {
  extern std::atomic<uint32_t> BG; // RGB default 0x190F0D
  extern std::atomic<uint32_t> WOOD; // RGB default 0x713D25
  extern std::atomic<uint32_t> WOOD_BORDER; // RGB default 0xBD8756
  extern std::atomic<uint32_t> WOOD_GROOVE; // RGB default 0x4C2919
  extern std::atomic<uint32_t> WOOD_GROOVE2; // RGB default 0x8B5937
  extern std::atomic<uint32_t> WOOD_STRIPE; // RGB default 0xA06B44
  extern std::atomic<uint32_t> PLATTER_RIM; // RGB default 0xBABDBA
  extern std::atomic<uint32_t> PLATTER_SHADE; // RGB default 0x565B5A
  extern std::atomic<uint32_t> VINYL; // RGB default 0x101315
  extern std::atomic<uint32_t> GROOVE; // RGB default 0x2F3337
  extern std::atomic<uint32_t> GROOVE_DARK; // RGB default 0x1A1D20
  extern std::atomic<uint32_t> LABEL_GOLD; // RGB default 0xD2AF65
  extern std::atomic<uint32_t> WHITE; // RGB default 0xF7F1E4
  extern std::atomic<uint32_t> GOLD_HIGHLIGHT; // RGB default 0xFFD782
  extern std::atomic<uint32_t> VINYL_REFLEX; // RGB default 0x494D4D
  extern std::atomic<uint32_t> HORN_BRASS; // RGB default 0xCDA352
  extern std::atomic<uint32_t> HORN_LIGHT; // RGB default 0xF6D58C
  extern std::atomic<uint32_t> HORN_INSIDE; // RGB default 0x805B2F
  extern std::atomic<uint32_t> HORN_RIB; // RGB default 0xA0743B
  extern std::atomic<uint32_t> ARM_GOLD; // RGB default 0xECCB88
  extern std::atomic<uint32_t> ARM_SHADOW; // RGB default 0x967D56
  extern std::atomic<uint32_t> ARM_BASE; // RGB default 0x686C6C
  extern std::atomic<uint32_t> ARM_METAL; // RGB default 0xE7E6DD
  extern std::atomic<uint32_t> GREEN; // RGB default 0x46D266
  extern std::atomic<uint32_t> RED; // RGB default 0xE24A3A
}
namespace Nixie {
  extern std::atomic<uint32_t> BG; // RGB default 0x080608
  extern std::atomic<uint32_t> GLASS; // RGB default 0x181517
  extern std::atomic<uint32_t> FRAME; // RGB default 0x725035
  extern std::atomic<uint32_t> TUBE_GLOW; // RGB default 0x7A290C
  extern std::atomic<uint32_t> TUBE_ON; // RGB default 0xFFB343
  extern std::atomic<uint32_t> TUBE_DIM; // RGB default 0x28170E
  extern std::atomic<uint32_t> GLASS_REFLEX; // RGB default 0xB49C82
  extern std::atomic<uint32_t> GLASS_INNER; // RGB default 0x251209
  extern std::atomic<uint32_t> DOT_DIM; // RGB default 0x2B1308
  extern std::atomic<uint32_t> DOT_GLOW; // RGB default 0x843009
  extern std::atomic<uint32_t> DOT_ON; // RGB default 0xFFCC65
  extern std::atomic<uint32_t> TEXT_DIM; // RGB default 0xA68B69
  extern std::atomic<uint32_t> DATE; // RGB default 0xFFCA67
  extern std::atomic<uint32_t> TEXT; // RGB default 0xEFDDC1
  extern std::atomic<uint32_t> NOW_PLAYING; // RGB default 0xF0AF57
  extern std::atomic<uint32_t> PANEL_BORDER; // RGB default 0x6C4E34
  extern std::atomic<uint32_t> PANEL_INNER; // RGB default 0x2F2018
  extern std::atomic<uint32_t> FILM_LINE; // RGB default 0x584D42
  extern std::atomic<uint32_t> FILM_LINE_LITE; // RGB default 0xB6A795
}
namespace Common {
  extern std::atomic<uint32_t> FRAME_OUTER;
  extern std::atomic<uint32_t> FRAME_INNER;
  extern std::atomic<uint32_t> TOP_ACCENT;
  extern std::atomic<uint32_t> BOTTOM_ACCENT;
}
namespace Native {
  constexpr uint8_t MODES = 31;
  constexpr uint8_t SLOTS = 10;
  void select(uint8_t mode);
  uint16_t color(uint8_t slot);
  bool set(uint8_t mode, uint8_t slot, uint32_t rgb888);
  void reset();
  void begin();
  void save();
  uint32_t rgb(uint8_t mode, uint8_t slot);
  const char* name(uint8_t slot);
}
namespace Pixels {
  struct ProtectedRect { int16_t x, y, w, h; };
  // Mapowanie RGB565 na koncowej klatce TFT, niezalezne od stalych w rysowniku.
  bool set(uint8_t mode, uint16_t source, uint16_t target);
  bool remove(uint8_t mode, uint16_t source);
  void reset();
  void begin();
  void service();
  void apply(uint8_t mode, uint16_t *buffer, int32_t width, int32_t height,
             uint16_t rawSample, uint16_t samplePixel,
             const ProtectedRect *protectedRects = nullptr, uint8_t protectedCount = 0);
  String json(uint8_t mode);
}
namespace Theme {
  struct Entry { const char *group; const char *key; std::atomic<uint32_t> *value; uint32_t rgbDefault; };
  size_t count();
  const Entry* entry(size_t id);
  bool set(size_t id, uint32_t rgb888);
  void reset();
  void begin();
  void service(); // only on Arduino loop task; NVS commit is deferred
  String json();
  const char* html();
  uint32_t generation();
  bool dirty();
}
}
