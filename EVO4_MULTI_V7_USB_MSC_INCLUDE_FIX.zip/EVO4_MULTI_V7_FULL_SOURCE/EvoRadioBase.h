#pragma once
#include <Arduino.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include <esp_heap_caps.h>
#include <esp_heap_caps_init.h>
#include <WiFiClientSecure.h>  // ESP32 Arduino Core 3.3.12: klient HTTPS/TLS

// ETAP 5: ESP-IDF heap allocator policy. With PSRAM enabled in Arduino board
// settings, allocations >= 4096 B may use external RAM. This is NOT a forced
// mbedTLS allocator replacement; verify actual TLS results in diagnostics.
// Must be called once early in setup(), before WiFi/audio/USB initialization.
inline void evoRadioBaseMemoryPolicy() {
  if (!psramFound()) {
    Serial.println("[RADIOBASE] PSRAM not detected; TLS memory policy unchanged");
    return;
  }
  heap_caps_malloc_extmem_enable(4096);
  Serial.printf("[RADIOBASE] ETAP5 PSRAM malloc threshold=4096; internal=%u, psram=%u\n",
      (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
      (unsigned)heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
}

// RadioBase REST v1. Pierwszy etap: katalog i odtwarzanie przez istniejący silnik EVO.
// Wymaga działającego połączenia internetowego. Nie zmienia kodu SD/USB/REC.
namespace EvoRadioBase {
static const char* BASE = "https://radiobase.pl/api/v1";
inline String errorJson(const String& msg) {
  String escaped;
  for (size_t i=0; i<msg.length(); ++i) {
    char c=msg[i];
    if(c=='\\' || c=='"') { escaped+='\\'; escaped+=c; }
    else if(c=='\n' || c=='\r') escaped+=' ';
    else escaped+=c;
  }
  return String("{\"error\":\"")+escaped+"\"}";
}
// Uruchamiaj tylko na zadanie: nie zajmuje RAM podczas normalnego odtwarzania.
inline String connectionDiagnostic() {
  Serial.println("[RADIOBASE] ===== DNS/TCP/TLS TEST =====");
  Serial.printf("[RADIOBASE] heap=%u, largest_internal=%u, psram=%u, largest_psram=%u\n",
      (unsigned)ESP.getFreeHeap(),
      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
      (unsigned)ESP.getFreePsram(),
      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_SPIRAM));
  if (WiFi.status() != WL_CONNECTED) return errorJson("Wi-Fi rozlaczone");
  IPAddress ip;
  if (!WiFi.hostByName("radiobase.pl", ip)) {
    Serial.println("[RADIOBASE] DNS FAILED");
    return errorJson("DNS FAILED");
  }
  Serial.printf("[RADIOBASE] DNS OK: %s\n", ip.toString().c_str());
  {
    WiFiClient tcp;
    bool ok = tcp.connect(ip, 443, 5000);
    Serial.printf("[RADIOBASE] TCP 443: %s\n", ok ? "OK" : "FAILED");
    tcp.stop();
    if (!ok) return errorJson("TCP 443 FAILED");
  }
  // TLS test with mbedTLS error details; no secrets are logged.
  auto testTls = [](const char* host) -> bool {
    Serial.printf("[RADIOBASE] TLS connecting to %s\n", host);
    WiFiClientSecure tls;
    tls.setInsecure(); // Diagnostics only; certificate validation disabled.
    tls.setTimeout(12000);
    bool ok = tls.connect(host, 443);
    char err[192] = {0};
    int tlsCode = ok ? 0 : tls.lastError(err, sizeof(err));
    Serial.printf("[RADIOBASE] TLS %s: %s, error=%d, detail=%s, heap=%u, largest_internal=%u\n",
        host, ok ? "OK" : "FAILED", tlsCode, err,
        (unsigned)ESP.getFreeHeap(),
        (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT));
    tls.stop();
    return ok;
  };
  bool radioTls = testTls("radiobase.pl");
  if (!radioTls) {
    // Control: distinguish server-specific TLS failure from general TLS failure.
    bool controlTls = testTls("example.com");
    return errorJson(controlTls ? "RadioBase TLS FAILED; control TLS OK" :
                                  "TLS FAILED for RadioBase and control host; see Serial log");
  }
  Serial.println("[RADIOBASE] ===== TEST OK =====");
  return String("{\"ok\":true,\"message\":\"DNS TCP TLS OK\"}");
}
inline String apiGet(const String& resource, int &status) {
  status = 503;
  Serial.printf("[RADIOBASE] WiFi.status=%d, IP=%s, heap=%u\n",
                (int)WiFi.status(), WiFi.localIP().toString().c_str(), (unsigned)ESP.getFreeHeap());
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[RADIOBASE] Brak polaczenia Wi-Fi");
    return errorJson("Brak polaczenia Wi-Fi");
  }
  WiFiClientSecure client;
  client.setInsecure(); // Tylko diagnostyka: brak weryfikacji certyfikatu TLS.
  client.setTimeout(7000);
  HTTPClient http;
  http.setConnectTimeout(7000);
  http.setTimeout(10000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  String url = String(BASE) + resource;
  Serial.printf("[RADIOBASE] GET %s; largest_internal=%u; psram=%u\n", url.c_str(),
      (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
      (unsigned)ESP.getFreePsram());
  if (!http.begin(client, url)) {
    status = 502;
    Serial.println("[RADIOBASE] http.begin() FAILED");
    return errorJson("Nie mozna zainicjalizowac HTTPS");
  }
  http.addHeader("Accept", "application/json");
  http.addHeader("User-Agent", "EVO4-MULTI-RadioBase/1.0");
  int code = http.GET();
  Serial.printf("[RADIOBASE] HTTP code=%d\n", code);
  if (code < 0) {
    char tlsErr[192] = {0};
    int tlsCode=client.lastError(tlsErr, sizeof(tlsErr));
    Serial.printf("[RADIOBASE] TLS code=%d detail=%s\n", tlsCode, tlsErr);
    String detail=http.errorToString(code);
    Serial.printf("[RADIOBASE] HTTP transport error: %s\n", detail.c_str());
    http.end();
    status = 502;
    return errorJson(String("HTTPS: ")+detail+" ("+String(code)+")");
  }
  String result=http.getString();
  Serial.printf("[RADIOBASE] Content-Type=%s, response bytes=%u\n",
                http.header("Content-Type").c_str(), (unsigned)result.length());
  Serial.printf("[RADIOBASE] Response first 350 chars: %.350s\n", result.c_str());
  http.end();
  status=code;
  if (code<200 || code>=300) {
    if (result.length()==0 || !(result.startsWith("{") || result.startsWith("[")))
      return errorJson(String("RadioBase HTTP ")+String(code)+": "+result.substring(0,120));
  }
  if (code>=200 && code<300 && result.isEmpty()) {
    status=502;
    return errorJson("RadioBase zwrocilo pusta odpowiedz");
  }
  return result;
}
inline String page() { return R"RB(<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EVO4 MULTI — RadioBase</title><style>body{background:#0b1525;color:#eaf4ff;font:16px system-ui;max-width:960px;margin:auto;padding:18px}input,select,button{padding:10px;margin:4px;border-radius:8px;border:1px solid #375b80;background:#182c45;color:#fff}button{cursor:pointer;background:#1766a6}article{padding:12px;margin:9px 0;background:#162a43;border-radius:10px}small{color:#9db6d3}a{color:#8acfff}#msg{padding:8px;color:#ffd58c}</style></head><body><h1>📻 EVO4 MULTI / RadioBase</h1><p><a href="/menu">← Menu EVO4</a></p><input id="q" placeholder="Szukaj stacji"><select id="country"><option value="">Wszystkie kraje</option><option value="Poland">Polska</option></select><button onclick="load()">Szukaj</button><div id="msg">Pobieranie katalogu…</div><div id="items"></div><button onclick="pageNum=Math.max(1,pageNum-1);load()">Poprzednia</button><span id="pg">1</span><button onclick="pageNum++;load()">Następna</button><script>let pageNum=1;const E=x=>document.getElementById(x);function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}function stream(s){let x=s.stream_url||s.streamUrl||s.url||s.listen_url||s.listenUrl||s.stream||'';if(typeof x==='object')x=x.url||'';if(!x&&Array.isArray(s.streams)&&s.streams.length){let y=s.streams[0];x=typeof y==='string'?y:(y.url||y.stream_url||'');}return x;}async function load(){E('msg').textContent='Pobieranie…';E('pg').textContent=pageNum;let p=new URLSearchParams({page:pageNum,per_page:25});if(E('q').value)p.set('q',E('q').value);if(E('country').value)p.set('country',E('country').value);try{let r=await fetch('/radiobase/api/stations?'+p);let j=await r.json();if(!r.ok)throw Error(j.error||'HTTP '+r.status);let a=Array.isArray(j)?j:(j.data||j.stations||j.results||j.items||[]);if(!Array.isArray(a))a=[];E('items').innerHTML=a.map(s=>{let u=stream(s),n=s.name||s.title||s.slug||'Stacja';return '<article><b>'+esc(n)+'</b><br><small>'+esc(s.country||'')+' '+esc(s.codec||'')+'</small><br>'+(u?'<button class="play" data-url="'+esc(u)+'" data-name="'+esc(n)+'">▶ PLAY</button>':'<small>Brak adresu strumienia w danych katalogu</small>')+'</article>'}).join('')||'<p>Brak wyników.</p>';E('msg').textContent='Wyników na stronie: '+a.length;}catch(e){E('msg').textContent='Błąd: '+e.message;}}E('items').addEventListener('click',async e=>{let b=e.target.closest('button.play');if(!b)return;E('msg').textContent='Uruchamianie '+b.dataset.name+'…';let p=new URLSearchParams({url:b.dataset.url,title:b.dataset.name});try{let r=await fetch('/radiobase/api/play?'+p);let j=await r.json();E('msg').textContent=j.ok?'Uruchomiono: '+b.dataset.name:'Nie udało się uruchomić: '+(j.error||'błąd');}catch(e){E('msg').textContent=e.message}});E('q').addEventListener('keydown',e=>{if(e.key==='Enter'){pageNum=1;load()}});load();</script></body></html>)RB"; }
}
