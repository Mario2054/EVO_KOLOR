/*
  EVO4 MULTI - LINKER SPLIT FIX
  Implementacja modulu artwork poza glownym .ino.

  Powod:
  Arduino laczy caly szkic .ino w jeden bardzo duzy obiekt. Przy ESP32-S3
  i toolchainie z Arduino-ESP32 3.3.11 sekcje literalow w funkcjach
  EvoArtwork::worker() przekroczyly zasieg instrukcji Xtensa L32R.
  Oddzielny plik .cpp tworzy osobny, maly obiekt i usuwa blad linkera
  "dangerous relocation: l32r: literal target out of range".
*/

#include "EvoArtwork.h"
#include "Evo4_User_Config.h"
#include "Evo4_Display_Profile.h"

#include <WiFi.h>
#include <HTTPClient.h>
#include <NetworkClientSecure.h>
#include <ArduinoJson.h>
#include <esp_heap_caps.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <freertos/semphr.h>
#include <mbedtls/platform.h>
#include <cstring>
#include <new>

#if EVO_DISPLAY_TFT
  #ifndef LGFX_USE_V1
    #define LGFX_USE_V1
  #endif
  #include <LovyanGFX.hpp>
#endif

namespace EvoArtwork {

struct Request {
  String station, artist, title, logo;
};

// Keep the existing TLS allocator for audio and all other tasks.
// Only artwork connections use external RAM; install before networking starts.
void *tlsAllocate(size_t n, size_t size) {
  if (strcmp(pcTaskGetName(nullptr), "artwork") == 0)
    return heap_caps_calloc(n, size, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  return heap_caps_calloc(n, size, MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
}
void initMemoryPolicy() {
  mbedtls_platform_set_calloc_free(tlsAllocate, heap_caps_free);
}
struct PsramJsonAllocator : ArduinoJson::Allocator {
  void *allocate(size_t n) override { return heap_caps_malloc(n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT); }
  void deallocate(void *p) override { heap_caps_free(p); }
  void *reallocate(void *p, size_t n) override { return heap_caps_realloc(p, n, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT); }
};
PsramJsonAllocator jsonAllocator;
Request wanted;
Result ready;
uint32_t generation = 0, lastWanted = 0;
bool enabled = false;
std::atomic<bool> changed{false};

// Stan wewnetrzny modulu artwork.
// W poprzedniej wersji LINKER_SPLIT_FIX te zmienne zostaly przypadkowo
// usuniete podczas przenoszenia implementacji z EvoArtwork.h do .cpp,
// przez co kompilator zglaszal m.in. "mutex was not declared".
static SemaphoreHandle_t mutex = nullptr;
static TaskHandle_t task = nullptr;
// Task TLS/HTTP wykonuje dostep do WiFi: stos musi byc w RAM wewnetrznym.
// Nie przenosimy stosu do PSRAM (przy wylaczonym cache mogloby to byc ryzykowne).
static String stage = "idle";
static int httpCode = 0;
static uint32_t cycles = 0;
void progress(const char *message, int code = 0) {
  xSemaphoreTake(mutex, portMAX_DELAY); stage = message; if (code) httpCode = code; xSemaphoreGive(mutex);
}
String key(String s) {
  s.toLowerCase();
  String out;
  for (size_t i = 0; i < s.length(); ++i) {
    uint8_t c = s[i];
    if ((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c >= 128) out += char(c);
  }
  return out;
}
String baseTitle(String s) {
  int pos = s.indexOf('('); if (pos > 0) s = s.substring(0, pos);
  pos = s.indexOf('['); if (pos > 0) s = s.substring(0, pos);
  s.trim(); return s;
}
String searchArtist(String s) {
  s.trim();
  // Station rotation banners are not part of the artist's name.
  // Example: "= POWER PLAY = BALTIMORA" -> "BALTIMORA".
  if (s.startsWith("=")) {
    int end = s.indexOf('=', 1);
    if (end > 1 && end + 1 < int(s.length())) s = s.substring(end + 1);
  }
  s.trim(); return s;
}
bool same(const Request &a, const Request &b) {
  return a.station == b.station && a.artist == b.artist && a.title == b.title && a.logo == b.logo;
}
String encode(const String &s) {
  const char hex[] = "0123456789ABCDEF";
  String out;
  for (size_t i = 0; i < s.length(); ++i) {
    uint8_t c = s[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.') out += char(c);
    else { out += '%'; out += hex[c >> 4]; out += hex[c & 15]; }
  }
  return out;
}
String url(String s) {
  s.trim();
  if (s.startsWith("//")) s = "https:" + s;
  if (!s.startsWith("http://") && !s.startsWith("https://")) return String();
  return s;
}
class Buffer : public Stream {
public:
  uint8_t *data;
  size_t used = 0, capacity;
  explicit Buffer(size_t cap) : capacity(cap) {
    data = (uint8_t*)heap_caps_malloc(cap + 1, MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
    if (!data && cap <= 65536) data = (uint8_t*)malloc(cap + 1);
  }
  ~Buffer() { free(data); }
  size_t write(uint8_t c) override { return write(&c, 1); }
  size_t write(const uint8_t *p, size_t n) override {
    if (!data || n > capacity - used) return 0;
    memcpy(data + used, p, n); used += n; data[used] = 0; return n;
  }
  int available() override { return 0; }
  int read() override { return -1; }
  int peek() override { return -1; }
  void flush() override {}
};
bool get(const String &address, Buffer &body) {
  if (!body.data || !url(address).length() || WiFi.status() != WL_CONNECTED) return false;
  NetworkClient plain;
  NetworkClientSecure tls;
  // Same TLS policy as the existing bank downloader; public artwork only.
  tls.setInsecure();
  tls.setHandshakeTimeout(6);
  HTTPClient http;
  http.setConnectTimeout(4000); http.setTimeout(5000);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.setRedirectLimit(4);
  http.setUserAgent("EVO4-Artwork/1.0");
  if (!http.begin(address.startsWith("https:") ? static_cast<NetworkClient&>(tls) : plain, address)) return false;
  const size_t internalBefore = heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  const size_t largestBefore = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  Serial.printf("[ART MEM] before GET free=%u largest=%u psram=%u\n", (unsigned)internalBefore, (unsigned)largestBefore, (unsigned)ESP.getFreePsram());
  int code = http.GET();
  bool ok = code == HTTP_CODE_OK && http.getSize() <= int(body.capacity);
  if (ok) ok = http.writeToStream(&body) > 0;
  http.end();
  progress(ok ? "http_ok" : "http_error", code);
  Serial.printf("[ART MEM] after GET code=%d bytes=%u free=%u largest=%u psram=%u\n", code, (unsigned)body.used,
                (unsigned)heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT),
                (unsigned)ESP.getFreePsram());
  if (ok) {
    const bool jpg = body.used >= 3 && body.data[0] == 0xFF && body.data[1] == 0xD8 && body.data[2] == 0xFF;
    const bool png = body.used >= 8 && memcmp(body.data, "\x89PNG\r\n\x1a\n", 8) == 0;
    Serial.printf("[ART TRACE] HTTP 200 bytes=%u format=%s url=%s\n", (unsigned)body.used, jpg ? "JPEG" : (png ? "PNG" : "JSON/OTHER"), address.c_str());
  } else Serial.printf("[ART] HTTP/download failed: %d url=%s\n", code, address.c_str());
  return ok;
}
// Radio Browser names often differ from the bank label (e.g. "Radio 7 Mlawa"
// vs "Radio 7"). Search the full name first, then a short distinctive name.
// Never accept an unrelated station merely because it contains "radio".
String lookupLogo(const String &station) {
  if (!station.length()) return String();
  const String wanted = key(station);
  String noRadio = station;
  if (noRadio.startsWith("Radio ") || noRadio.startsWith("RADIO "))
    noRadio = noRadio.substring(6);
  noRadio.trim();
  String shortName = noRadio;
  const int cut = shortName.indexOf(' ');
  if (cut > 0) shortName = shortName.substring(0, cut);
  String terms[3] = {station, noRadio, shortName};
  int bestScore = -1;
  String bestLogo;
  for (int pass = 0; pass < 3; ++pass) {
    if (terms[pass].length() < 2) continue;
    bool duplicate = false;
    for (int prev = 0; prev < pass; ++prev)
      if (key(terms[prev]) == key(terms[pass])) duplicate = true;
    if (duplicate) continue;
    Buffer body(96 * 1024);
    String query = "/json/stations/byname/" + encode(terms[pass]) + "?order=votes&reverse=true&limit=50";
    if (!get("https://de1.api.radio-browser.info" + query, body)) {
      body.used = 0;
      if (!get("https://nl1.api.radio-browser.info" + query, body)) continue;
    }
    JsonDocument doc(&jsonAllocator);
    if (deserializeJson(doc, body.data, body.used)) continue;
    for (JsonObject row : doc.as<JsonArray>()) {
      String name = key(row["name"] | "");
      if (!name.length()) continue;
      String compact = name, expected = wanted;
      if (compact.startsWith("radio")) compact.remove(0, 5);
      if (expected.startsWith("radio")) expected.remove(0, 5);
      int score = -1;
      if (name == wanted) score = 100;
      else if (compact == expected) score = 95;
      else if (expected.startsWith(compact) && compact.length() >= 2) score = 75;
      else if (compact.startsWith(expected) && expected.length() >= 3) score = 70;
      else if (compact.startsWith(key(noRadio)) && key(noRadio).length() >= 3) score = 65;
      // Reject ambiguous short names unless the candidate itself is an exact match.
      String shortKey = key(shortName);
      if (score < 0 && shortKey.length() >= 4 && compact == shortKey) score = 55;
      String found = url(row["favicon"] | "");
      if (score > bestScore && found.length()) { bestScore = score; bestLogo = found; }
    }
    if (bestScore >= 95) break;
  }
  Serial.printf("[ART LOOKUP] station=%s score=%d logo=%s\n", station.c_str(), bestScore, bestLogo.c_str());
  return bestLogo;
}
String lookupCover(const String &artist, const String &title) {
  if (!artist.length() || !title.length()) return String();
  Buffer body(64 * 1024);
  String cleanTitle = baseTitle(title);
  String cleanArtist = searchArtist(artist);
  if (!cleanArtist.length() || !cleanTitle.length()) return String();
  if (!get("https://itunes.apple.com/search?term=" + encode(cleanArtist + " " + cleanTitle) + "&entity=song&limit=10", body)) return String();
  JsonDocument doc(&jsonAllocator);
  if (deserializeJson(doc, body.data, body.used)) return String();
  String a = key(cleanArtist), t = key(cleanTitle);
  for (JsonObject row : doc["results"].as<JsonArray>()) {
    String ra = row["artistName"] | "", rt = row["trackName"] | "";
    ra = key(ra); rt = key(baseTitle(rt));
    if (!ra.length() || !rt.length()) continue;
    if ((ra.indexOf(a) >= 0 || a.indexOf(ra) >= 0) && (rt.indexOf(t) >= 0 || t.indexOf(rt) >= 0)) {
      String found = url(row["artworkUrl100"] | "");
      // iTunes zwraca pole artworkUrl100, ale ten sam CDN udostepnia wieksze
      // warianty. 300x300 daje wyraznie lepszy detal na TFT 480x320, a nadal
      // jest lekkie dla ESP32-S3 i PSRAM.
      found.replace("100x100bb", String(EVO_ARTWORK_ITUNES_SIDE) + "x" + String(EVO_ARTWORK_ITUNES_SIDE) + "bb");
      return found;
    }
  }
  return String();
}
// Read dimensions before decoding so even large logos fit the small TFT tile.
bool dimensions(const uint8_t *p, size_t n, int &w, int &h, bool &png) {
  png = n >= 24 && memcmp(p, "\x89PNG\r\n\x1a\n", 8) == 0;
  if (png) {
    uint32_t pw = (uint32_t(p[16]) << 24) | (uint32_t(p[17]) << 16) | (p[18] << 8) | p[19];
    uint32_t ph = (uint32_t(p[20]) << 24) | (uint32_t(p[21]) << 16) | (p[22] << 8) | p[23];
    if (!pw || !ph || pw > 2048 || ph > 2048) return false;
    w = pw; h = ph; return true;
  }
  if (n < 4 || p[0] != 0xff || p[1] != 0xd8) return false;
  size_t i = 2;
  while (i + 3 < n) {
    if (p[i++] != 0xff) return false;
    while (i < n && p[i] == 0xff) ++i;
    if (i >= n) return false;
    uint8_t marker = p[i++];
    if (marker == 0xda || marker == 0xd9) return false;
    if (marker == 0x01 || (marker >= 0xd0 && marker <= 0xd7)) continue;
    if (i + 2 > n) return false;
    size_t len = (p[i] << 8) | p[i + 1];
    if (len < 2 || len > n - i) return false;
    if (marker == 0xc0 || marker == 0xc1 || marker == 0xc2) {
      if (len < 8) return false;
      h = (p[i + 3] << 8) | p[i + 4]; w = (p[i + 5] << 8) | p[i + 6];
      return w > 0 && h > 0 && w <= 2048 && h <= 2048;
    }
    i += len;
  }
  return false;
}
uint16_t average565(uint16_t a, uint16_t b, uint16_t c, uint16_t d) {
  uint32_t r = ((a >> 11) & 31) + ((b >> 11) & 31) + ((c >> 11) & 31) + ((d >> 11) & 31);
  uint32_t g = ((a >> 5) & 63) + ((b >> 5) & 63) + ((c >> 5) & 63) + ((d >> 5) & 63);
  uint32_t bl = (a & 31) + (b & 31) + (c & 31) + (d & 31);
  return uint16_t(((r >> 2) << 11) | ((g >> 2) << 5) | (bl >> 2));
}
std::shared_ptr<Picture> download(const String &address) {
#if EVO_DISPLAY_TFT
  if (!address.length()) return {};
  Buffer body(EVO_ARTWORK_DOWNLOAD_MAX);
  if (!get(address, body)) return {};
  int w = 0, h = 0; bool png = false;
  if (!dimensions(body.data, body.used, w, h, png)) { Serial.printf("[ART TRACE] image header INVALID bytes=%u url=%s\n", (unsigned)body.used, address.c_str()); return {}; }
  Serial.printf("[ART TRACE] image header OK type=%s dimensions=%dx%d bytes=%u\n", png ? "PNG" : "JPEG", w, h, (unsigned)body.used);

  // Dekodowanie 2x wieksze od kafelka UI. Sprite i Picture sa w PSRAM.
  LGFX_Sprite tile;
  tile.setPsram(true);
  tile.setColorDepth(16);
  if (!tile.createSprite(sourceSide, sourceSide)) { Serial.println("[ART TRACE] sprite allocation FAILED"); return {}; }
  tile.fillScreen(0);
  float scale = float(sourceSide) / (w > h ? w : h);
  int drawW = max(1, int(w * scale + 0.5f));
  int drawH = max(1, int(h * scale + 0.5f));
  int x = (sourceSide - drawW) / 2;
  int y = (sourceSide - drawH) / 2;
  bool ok = png ? tile.drawPng(body.data, body.used, x, y, drawW, drawH, 0, 0, scale)
                : tile.drawJpg(body.data, body.used, x, y, drawW, drawH, 0, 0, scale);
  if (!ok) { Serial.printf("[ART TRACE] decode FAILED url=%s\n", address.c_str()); return {}; }

  void *memory = heap_caps_malloc(sizeof(Picture), MALLOC_CAP_SPIRAM | MALLOC_CAP_8BIT);
  if (!memory) { Serial.println("[ART TRACE] picture PSRAM allocation FAILED"); return {}; }
  auto picture = std::shared_ptr<Picture>(new(memory) Picture(), [](Picture *p) { p->~Picture(); free(p); });
  for (int yy = 0; yy < sourceSide; ++yy)
    for (int xx = 0; xx < sourceSide; ++xx)
      picture->pixels[yy * sourceSide + xx] = tile.readPixel(xx, yy);

  // Podglad 80x80 trafia do logicznego bufora UI. Uzywamy filtra 2x2 zamiast
  // zwyklego odrzucania pikseli, wiec nawet fallback wyglada czytelniej.
  for (int yy = 0; yy < side; ++yy) {
    const int sy = yy * 2;
    for (int xx = 0; xx < side; ++xx) {
      const int sx = xx * 2;
      const uint16_t *p0 = picture->pixels + sy * sourceSide + sx;
      picture->preview[yy * side + xx] = average565(p0[0], p0[1], p0[sourceSide], p0[sourceSide + 1]);
    }
  }
  picture->decoded = true;
  Serial.printf("[ART TRACE] image READY %dx%d PSRAM=%u\n", w, h, (unsigned)ESP.getFreePsram());
  return picture;
#else
  return {};
#endif
}
void worker(void *) {
  uint32_t seen = UINT32_MAX, retryAt = 0;
  Request previous;
  Result result;
  for (;;) {
    Request request; uint32_t gen; bool active;
    xSemaphoreTake(mutex, portMAX_DELAY);
    request = wanted; gen = generation;
    active = enabled && uint32_t(millis() - lastWanted) < 15000;
    xSemaphoreGive(mutex);
    if (active && WiFi.status() == WL_CONNECTED && (gen != seen || int32_t(millis() - retryAt) >= 0)) {
      if (request.station != previous.station || request.logo != previous.logo) { result.logo.reset(); result.logoUrl = ""; }
      if (request.station != previous.station || request.artist != previous.artist || request.title != previous.title) { result.cover.reset(); result.coverUrl = ""; }
      seen = gen; previous = request;
      xSemaphoreTake(mutex, portMAX_DELAY); ++cycles; xSemaphoreGive(mutex);
      progress("lookup_logo");
      if (!result.logoUrl.length()) {
        result.logoUrl = url(request.logo);
        if (!result.logoUrl.length()) result.logoUrl = lookupLogo(request.station);
      }
      progress("lookup_cover");
      if (!result.coverUrl.length()) result.coverUrl = lookupCover(request.artist, request.title);
      progress("download_logo");
      if (!result.logo) result.logo = download(result.logoUrl);
      progress("download_cover");
      if (!result.cover) result.cover = download(result.coverUrl);
      result.logoStatus = result.logo ? "ready" : (result.logoUrl.length() ? "download_failed" : "not_found");
      result.coverStatus = result.cover ? "ready" : (result.coverUrl.length() ? "download_failed" : (request.artist.length() && request.title.length() ? "not_found" : "no_metadata"));
      Serial.printf("[ART TRACE] result station=%s logo=%s cover=%s logoURL=%s coverURL=%s\n", request.station.c_str(), result.logoStatus.c_str(), result.coverStatus.c_str(), result.logoUrl.c_str(), result.coverUrl.c_str());
      progress("idle");
      xSemaphoreTake(mutex, portMAX_DELAY);
      if (generation == gen) { ready = result; changed.store(true); }
      xSemaphoreGive(mutex);
      retryAt = millis() + 60000;
    }
    vTaskDelay(pdMS_TO_TICKS(250));
  }
}
void submit(const String &station, const String &artist, const String &title, const String &logo, bool active) {
  if (!mutex) mutex = xSemaphoreCreateMutex();
  if (!mutex) return;
  Request next{station, artist, title, logo};
  xSemaphoreTake(mutex, portMAX_DELAY);
  if (!same(next, wanted)) {
    if (next.station != wanted.station || next.logo != wanted.logo) { ready.logo.reset(); ready.logoUrl = ""; }
    if (next.station != wanted.station || next.artist != wanted.artist || next.title != wanted.title) { ready.cover.reset(); ready.coverUrl = ""; }
    wanted = next; ++generation; changed.store(true);
  }
  if (active) { enabled = true; lastWanted = millis(); }
  xSemaphoreGive(mutex);
  if (active && !task) {
    // Dynamiczne zadanie FreeRTOS na core 0 alokuje stos z pamieci wewnetrznej.
    // HTTPS buffers, JPEG/PNG, JSON i obrazy nadal pozostaja w PSRAM.
    TaskHandle_t created = nullptr;
    if (xTaskCreatePinnedToCore(worker, "artwork", 12288, nullptr,
                                 1, &created, 0) == pdPASS) {
      task = created;
    } else {
      progress("task_no_internal_ram");
    }
  }
}
void setActive(bool active) {
  if (!mutex) return;
  if (xSemaphoreTake(mutex, pdMS_TO_TICKS(25)) == pdTRUE) {
    enabled = active;
    if (active) lastWanted = millis();
    xSemaphoreGive(mutex);
  }
}
String diagnostics() {
  if (!mutex) return F("{\"task\":false,\"stage\":\"not_started\"}");
  JsonDocument doc(&jsonAllocator);
  xSemaphoreTake(mutex, portMAX_DELAY);
  doc["task"] = task != nullptr; doc["stage"] = stage; doc["http"] = httpCode; doc["cycles"] = cycles;
  doc["logoStatus"] = ready.logoStatus; doc["coverStatus"] = ready.coverStatus;
  xSemaphoreGive(mutex);
  doc["heap"] = ESP.getFreeHeap(); doc["largestHeap"] = heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT);
  doc["psram"] = ESP.getFreePsram(); doc["stackFree"] = task ? uxTaskGetStackHighWaterMark(task) : 0;
  String out; serializeJson(doc, out); return out;
}
Result snapshot() {
  if (!mutex) return {};
  xSemaphoreTake(mutex, portMAX_DELAY); Result result = ready; xSemaphoreGive(mutex); return result;
}

} // namespace EvoArtwork
