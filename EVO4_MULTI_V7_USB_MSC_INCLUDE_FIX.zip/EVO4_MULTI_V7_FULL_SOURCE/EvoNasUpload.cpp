#include "EvoNasUpload.h"
#include "EvoUsbHost.h"

#include <HTTPClient.h>
#include <Preferences.h>
#include <WiFi.h>
#include <esp_heap_caps.h>
#include <atomic>
#include <ctype.h>
#include <limits.h>
#include <new>

namespace {

struct UploadJob {
  fs::FS *storage;
  String path;
  String host;
  String directory;
  String user;
  String password;
  uint16_t port;
  bool onUsb;
};

bool initialized = false;
bool enabled = false;
String host;
String directory = "/music/RECORDINGS";
String user;
String password;
uint16_t port = 5005;
String activePath;
std::atomic<bool> busy{false};
std::atomic<uint8_t> state{0}; // 0 idle, 1 queued, 2 sending, 3 done, 4 error
std::atomic<int> httpCode{0};
portMUX_TYPE statusMux = portMUX_INITIALIZER_UNLOCKED;
char detail[96] = "Nieskonfigurowano";

void setDetail(const char *message) {
  portENTER_CRITICAL(&statusMux);
  snprintf(detail, sizeof(detail), "%s", message ? message : "");
  portEXIT_CRITICAL(&statusMux);
}

String detailCopy() {
  char copy[sizeof(detail)];
  portENTER_CRITICAL(&statusMux);
  memcpy(copy, detail, sizeof(copy));
  portEXIT_CRITICAL(&statusMux);
  copy[sizeof(copy) - 1] = 0;
  return String(copy);
}

bool privateIp(const String &value) {
  IPAddress ip;
  if (!ip.fromString(value)) return false;
  return ip[0] == 10 || (ip[0] == 172 && ip[1] >= 16 && ip[1] <= 31) ||
         (ip[0] == 192 && ip[1] == 168);
}

bool safeDirectory(const String &value) {
  if (value.length() < 2 || value.length() > 120 || value[0] != '/' ||
      value.endsWith("/") || value.indexOf("..") >= 0 ||
      value.indexOf("//") >= 0) return false;
  for (size_t i = 1; i < value.length(); ++i) {
    const char c = value[i];
    if (!isalnum((unsigned char)c) && c != '/' && c != '_' && c != '-') return false;
  }
  return true;
}

String htmlEscape(const String &value) {
  String result;
  result.reserve(value.length() + 8);
  for (size_t i = 0; i < value.length(); ++i) {
    switch (value[i]) {
      case '&': result += F("&amp;"); break;
      case '<': result += F("&lt;"); break;
      case '>': result += F("&gt;"); break;
      case '"': result += F("&quot;"); break;
      case '\'': result += F("&#39;"); break;
      default: result += value[i]; break;
    }
  }
  return result;
}

String jsonEscape(const String &value) {
  String result;
  result.reserve(value.length() + 8);
  for (size_t i = 0; i < value.length(); ++i) {
    const char c = value[i];
    if (c == '"' || c == '\\') result += '\\';
    if ((uint8_t)c >= 32) result += c;
  }
  return result;
}

String urlFileName(const String &path) {
  const int slash = path.lastIndexOf('/');
  const String file = path.substring(slash + 1);
  static const char hex[] = "0123456789ABCDEF";
  String encoded;
  encoded.reserve(file.length() * 2);
  for (size_t i = 0; i < file.length(); ++i) {
    const uint8_t c = (uint8_t)file[i];
    if (isalnum(c) || c == '-' || c == '_' || c == '.') encoded += (char)c;
    else { encoded += '%'; encoded += hex[c >> 4]; encoded += hex[c & 15]; }
  }
  return encoded;
}

void uploadTask(void *arg) {
  UploadJob *job = static_cast<UploadJob *>(arg);
  state.store(2, std::memory_order_release);
  setDetail("Laczenie z Synology");
  int result = 0;
  if (WiFi.status() == WL_CONNECTED && (!job->onUsb || evoUsbHostMounted())) {
    File file = job->storage->open(job->path, FILE_READ);
    if (file && !file.isDirectory() && file.size() >= 4096 &&
        file.size() <= INT_MAX) {
      WiFiClient client;
      HTTPClient http;
      const String url = "http://" + job->host + ":" + String(job->port) +
                         job->directory + "/" + urlFileName(job->path);
      http.setConnectTimeout(5000);
      http.setTimeout(15000);
      if (http.begin(client, url)) {
        http.setAuthorization(job->user.c_str(), job->password.c_str());
        http.addHeader("Content-Type", "audio/mpeg");
        setDetail("Wysylanie nagrania");
        result = http.sendRequest("PUT", &file, file.size());
        http.end();
      }
      file.close();
    }
  }
  httpCode.store(result, std::memory_order_release);
  if (result == 200 || result == 201 || result == 204) {
    state.store(3, std::memory_order_release);
    setDetail("Wyslano na NAS; lokalny plik zachowany");
    Serial.printf("[NAS REC] PUT OK (%d): %s\n", result, job->path.c_str());
  } else {
    state.store(4, std::memory_order_release);
    if (result == 401 || result == 403) setDetail("NAS: brak uprawnien WebDAV");
    else if (result == 404 || result == 409) setDetail("NAS: brak folderu docelowego");
    else if (result < 0) setDetail("NAS: blad polaczenia lub zapisu");
    else setDetail("NAS: wysylka nieudana; plik jest lokalnie");
    Serial.printf("[NAS REC] PUT ERROR (%d): %s\n", result, job->path.c_str());
  }
  delete job;
  busy.store(false, std::memory_order_release);
  vTaskDelete(nullptr);
}

} // namespace

void evoNasUploadInit() {
  if (initialized) return;
  initialized = true;
  Preferences prefs;
  if (prefs.begin("nasrec", true)) {
    enabled = prefs.getBool("enabled", false);
    host = prefs.getString("host", "");
    port = prefs.getUShort("port", 5005);
    directory = prefs.getString("dir", "/music/RECORDINGS");
    user = prefs.getString("user", "");
    password = prefs.getString("pass", "");
    prefs.end();
  }
  if (!privateIp(host) || !safeDirectory(directory) || !port ||
      user.isEmpty() || password.isEmpty()) enabled = false;
  setDetail(enabled ? "NAS gotowy" : "NAS wylaczony");
}

bool evoNasUploadEnabled() { evoNasUploadInit(); return enabled; }
bool evoNasUploadBusy() { return busy.load(std::memory_order_acquire); }
bool evoNasUploadIsPath(const String &path) {
  return evoNasUploadBusy() && path == activePath;
}

bool evoNasUploadConfigure(bool newEnabled, const String &newHost,
                           uint16_t newPort, const String &newDirectory,
                           const String &newUser, const String &newPassword,
                           String &error) {
  evoNasUploadInit();
  if (evoNasUploadBusy()) { error = "Trwa wysylanie nagrania"; return false; }
  if (!privateIp(newHost)) { error = "Podaj lokalny adres IPv4 NAS"; return false; }
  if (!newPort) { error = "Nieprawidlowy port WebDAV"; return false; }
  if (!safeDirectory(newDirectory)) { error = "Nieprawidlowa sciezka WebDAV"; return false; }
  if (newUser.isEmpty() || newUser.length() > 64 ||
      newUser.indexOf(':') >= 0 || newUser.indexOf('\r') >= 0 ||
      newUser.indexOf('\n') >= 0) {
    error = "Nieprawidlowy uzytkownik"; return false;
  }
  const String actualPassword = newPassword.isEmpty() ? password : newPassword;
  if (actualPassword.isEmpty() || actualPassword.length() > 96) {
    error = "Podaj haslo konta WebDAV"; return false;
  }
  Preferences prefs;
  if (!prefs.begin("nasrec", false)) { error = "Blad pamieci ustawien"; return false; }
  bool ok = prefs.putBool("enabled", newEnabled) == 1;
  ok = prefs.putString("host", newHost) > 0 && ok;
  ok = prefs.putUShort("port", newPort) == 2 && ok;
  ok = prefs.putString("dir", newDirectory) > 0 && ok;
  ok = prefs.putString("user", newUser) > 0 && ok;
  if (!newPassword.isEmpty()) ok = prefs.putString("pass", newPassword) > 0 && ok;
  prefs.end();
  if (!ok) { error = "Nie zapisano ustawien NAS"; return false; }
  enabled = newEnabled;
  host = newHost;
  port = newPort;
  directory = newDirectory;
  user = newUser;
  password = actualPassword;
  state.store(0, std::memory_order_release);
  setDetail(enabled ? "NAS gotowy" : "NAS wylaczony");
  return true;
}

bool evoNasUploadQueue(fs::FS &storage, const String &path, bool onUsb,
                       String &error) {
  evoNasUploadInit();
  if (!enabled) { error = "Wysylka NAS jest wylaczona"; return false; }
  if (busy.exchange(true, std::memory_order_acq_rel)) {
    error = "Trwa poprzednia wysylka NAS"; return false;
  }
  if (!path.startsWith("/RECORDINGS/") || path.indexOf("..") >= 0 ||
      (onUsb && !evoUsbHostMounted())) {
    busy.store(false, std::memory_order_release);
    error = "Brak pliku lokalnego"; return false;
  }
  // DLNA/USB zuzywaja sporo RAM wewnetrznego. Nie startuj uploadu kosztem
  // stabilnosci audio i serwera WWW; plik pozostanie do recznego ponowienia.
  if (heap_caps_get_free_size(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) < 11000 ||
      heap_caps_get_largest_free_block(MALLOC_CAP_INTERNAL | MALLOC_CAP_8BIT) < 6000) {
    busy.store(false, std::memory_order_release);
    state.store(4, std::memory_order_release);
    setDetail("NAS: brak RAM; plik jest lokalnie");
    error = "Za malo RAM na wysylke NAS";
    return false;
  }
  UploadJob *job = new (std::nothrow) UploadJob{&storage, path, host, directory,
                                                user, password, port, onUsb};
  if (!job) { busy.store(false, std::memory_order_release); error = "Brak pamieci"; return false; }
  activePath = path;
  httpCode.store(0, std::memory_order_release);
  state.store(1, std::memory_order_release);
  setDetail("Oczekuje na wysylke");
  if (xTaskCreatePinnedToCore(uploadTask, "nas_rec_put", 5120, job, 1,
                              nullptr, 0) != pdPASS) {
    delete job;
    busy.store(false, std::memory_order_release);
    state.store(4, std::memory_order_release);
    setDetail("Nie utworzono zadania NAS");
    error = "Brak pamieci na zadanie NAS";
    return false;
  }
  return true;
}

String evoNasUploadStatusJson() {
  evoNasUploadInit();
  String result = "{\"enabled\":";
  result += enabled ? "true" : "false";
  result += ",\"busy\":";
  result += evoNasUploadBusy() ? "true" : "false";
  result += ",\"state\":" + String(state.load(std::memory_order_acquire));
  result += ",\"http\":" + String(httpCode.load(std::memory_order_acquire));
  result += ",\"detail\":\"" + jsonEscape(detailCopy()) + "\"}";
  return result;
}

String evoNasUploadConfigPage() {
  evoNasUploadInit();
  String html;
  html.reserve(3600);
  html += F("<!doctype html><html lang='pl'><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>EVO4 NAS Recorder</title><style>body{font:16px Arial;background:#07111a;color:#e8f7ff;max-width:760px;margin:auto;padding:18px}fieldset{border:1px solid #26b8ef;border-radius:12px;padding:18px}label{display:block;margin:12px 0}input{box-sizing:border-box;width:100%;padding:10px;background:#101e2a;border:1px solid #4b829d;color:white;border-radius:6px}input[type=checkbox]{width:auto}button,a{display:inline-block;margin:12px 7px 0 0;padding:10px 14px;background:#076a9b;color:white;border:0;border-radius:6px;text-decoration:none}.note{color:#b6c7d3;line-height:1.45}</style></head><body><h2>EVO4 - kopia nagran na Synology</h2><p class='note'>Recorder nagrywa najpierw na USB/SD. Po STOP wysyla zamkniety plik przez WebDAV. Plik lokalny pozostaje nawet po bledzie sieci.</p><form method='post' action='/sdrecorder/nas/save'><fieldset><legend>WebDAV w sieci lokalnej</legend><label><input type='checkbox' name='enabled' value='1'");
  if (enabled) html += F(" checked");
  html += F("> Wysylaj automatycznie po nagraniu</label><label>Adres IPv4 Synology<input name='host' required value='");
  html += htmlEscape(host);
  html += F("' placeholder='192.168.1.130'></label><label>Port HTTP WebDAV<input name='port' type='number' min='1' max='65535' value='");
  html += String(port);
  html += F("'></label><label>Istniejacy folder docelowy<input name='dir' required value='");
  html += htmlEscape(directory);
  html += F("'></label><label>Konto NAS z zapisem do folderu<input name='user' required value='");
  html += htmlEscape(user);
  html += F("'></label><label>Haslo (puste = bez zmiany)<input name='password' type='password' autocomplete='new-password' value=''></label><button type='submit'>Zapisz</button></fieldset></form><p class='note'>Utworz folder w DSM przed pierwsza wysylka. Uzyj osobnego konta tylko do zapisu nagran. HTTP WebDAV przesyla haslo w sieci lokalnej - nie wystawiaj portu 5005 do Internetu.</p><p>Stan: <span id='status'>...</span></p><a href='/sdrecorder'>Powrot do Recordera</a><script>async function refresh(){try{let r=await fetch('/sdrecorder/nas/status',{cache:'no-store'}),s=await r.json();document.getElementById('status').textContent=s.detail+(s.http?' (HTTP '+s.http+')':'')}catch(e){}}refresh();setInterval(refresh,3000)</script></body></html>");
  return html;
}
