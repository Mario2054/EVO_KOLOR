#pragma once

static const char EVO_DLNA_WEB_PAGE[] PROGMEM = R"DLNAHTML(
<!doctype html><html lang="pl"><head><style id="evo4-unified-theme">:root{--evo-bg:#06111f;--evo-card:#081827;--evo-border:#1a344b;--evo-blue:#008cff;--evo-cyan:#29c7ff}html,body{color-scheme:dark}body{background:#06111f!important;color:#e9f2ff!important;font-family:'Segoe UI',Arial,sans-serif!important}button,input,select{font-family:inherit}button{cursor:pointer}button:hover{filter:brightness(1.16)}.evo4-return{position:fixed;right:18px;top:16px;z-index:99999;display:flex;align-items:center;gap:9px;padding:9px 15px 9px 10px;border-radius:30px;background:linear-gradient(135deg,#004a9b,#008cff 55%,#003a7a);border:1px solid #29c7ff;box-shadow:0 0 12px #008cff77;color:white!important;text-decoration:none!important;font:bold 13px 'Segoe UI',Arial,sans-serif;letter-spacing:.2px}.evo4-return .evo4-arrow{display:grid;place-items:center;width:32px;height:32px;border-radius:50%;background:#061b38;border:1px solid #7edbff;font-size:25px;line-height:1}.evo4-return:hover{box-shadow:0 0 20px #008cffb0;transform:translateY(-1px)}@media(max-width:600px){.evo4-return{right:8px;top:8px;padding:6px 10px}.evo4-return .evo4-arrow{width:26px;height:26px;font-size:21px}}</style><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EVO4 DLNA</title><style>
body{font:16px Arial;background:#08131e;color:#e9f6ff;max-width:780px;margin:auto;padding:18px}
a{color:#54dfff}.card{background:#102536;border:1px solid #1783a0;border-radius:12px;padding:14px;margin:12px 0}
button{background:#075d7e;color:white;border:1px solid #20c7e9;border-radius:7px;padding:9px 12px;margin:3px;cursor:pointer}
.row{display:flex;justify-content:space-between;align-items:center;gap:8px;border-bottom:1px solid #25465a;padding:5px 0}
.row button{flex:1;text-align:left}.muted{color:#9bb5c4}input{background:#071019;color:white;border:1px solid #26768c;padding:8px;width:75%}
</style></head><body><a class="evo4-return" href="/" aria-label="Powrót do głównej strony EVO4 MULTI"><span class="evo4-arrow">↶</span><span>POWRÓT DO MENU</span></a><h2>EVO4 DLNA / NAS</h2>
<p>miniDLNA / ReadyMedia, Synology Media Server, QNAP DLNA</p>
<div class="card">
<button onclick="go('discover')">Szukaj serwerów</button>
<button onclick="go('back')">Katalog wyżej</button>
<button onclick="go('servers')">Serwery</button>
<button onclick="go('stop')">STOP</button>
<p>Adres IP NAS (lub pelny adres opisu DLNA, gdy wyszukiwanie jest blokowane):</p>
<input id="url" placeholder="IP NAS, np. 192.168.1.130">
<button onclick="go('discover&url='+encodeURIComponent(document.getElementById('url').value))">Dodaj / szukaj</button>
</div><div class="card"><div id="status">Ładowanie...</div><h3 id="title"></h3><div id="rows"></div></div>
<div id="pages" class="muted"></div>
<p class="muted">Spotify Connect nie jest DLNA i wymaga osobnej integracji.</p>
<p><a href="/menu">Menu EVO4</a></p>
<script>
const pageSize=8;
let lastRowsKey='';
const autoRecordings=new URLSearchParams(location.search).get('recordings')==='1';
async function dlnaState(){return await(await fetch('/dlna/api/state?t='+Date.now(),{cache:'no-store'})).json()}
async function autoAction(c){let r=await fetch('/dlna/api/action?cmd='+c,{cache:'no-store'});if(!r.ok)throw new Error('Polecenie DLNA: HTTP '+r.status)}
async function waitDlna(){
  for(let i=0;i<48;i++){let d=await dlnaState();if(!d.busy)return d;await new Promise(r=>setTimeout(r,250))}
  throw new Error('Serwer DLNA nie odpowiedzial w wymaganym czasie');
}
function findFolder(d,name){name=name.toLocaleLowerCase('pl');return (d.items||[]).findIndex(x=>x.dir&&(x.name||'').trim().toLocaleLowerCase('pl')===name)}
async function openFolder(d,name){let i=findFolder(d,name);if(i<0)throw new Error('Brak katalogu: '+name);await autoAction('open&i='+i);return await waitDlna()}
async function openRecordings(){
  try{
    document.getElementById('status').textContent='Otwieranie RECORDINGS na serwerze...';
    let d=await dlnaState();
    if(!(d.servers||[]).length){await autoAction('discover');d=await waitDlna()}
    if(!(d.servers||[]).length)throw new Error('Nie znaleziono serwera DLNA');
    await autoAction('servers');await autoAction('server&i=0');d=await waitDlna();
    d=await openFolder(d,'Muzyka');d=await openFolder(d,'Wg folderu');d=await openFolder(d,'RECORDINGS');
    await refresh();
  }catch(e){document.getElementById('status').textContent='RECORDINGS: '+e.message}
}
async function go(c){
  try{
    let r=await fetch('/dlna/api/action?cmd='+c+'&t='+Date.now(),{cache:'no-store'});
    if(!r.ok){
      let result={}; try{result=await r.json()}catch(_){}
      document.getElementById('status').textContent=result.error||('Blad polecenia: '+r.status);
      return;
    }
    // Browse DLNA dziala w osobnym zadaniu ESP32. Dla zmiany katalogu/strony
    // czekamy az worker skonczy, zamiast odswiezac stara strone po 100 ms.
    if(c==='nextpage'||c==='prevpage'||c==='back'||c.startsWith('server')||c.startsWith('open')){
      document.getElementById('status').textContent='DLNA: wczytywanie...';
      await waitDlna();
    }
    await refresh();
  }catch(e){document.getElementById('status').textContent='Brak połączenia: '+e}
}
async function refresh(){
  try{
    let d=await(await fetch('/dlna/api/state?t='+Date.now(),{cache:'no-store'})).json();
    document.getElementById('status').textContent=d.status+(d.error?' — '+d.error:'')+
      (d.busy?' (praca w tle)':'')+(d.playing?' | GRA: '+d.now:'');
    document.getElementById('title').textContent=d.view==='servers'?'SERWERY':d.path;
    let data=d.view==='servers'?d.servers:d.items;
    let key=d.view+'|'+d.pageStart+'|'+d.busy+'|'+JSON.stringify(data);
    if(key!==lastRowsKey){
      lastRowsKey=key;
      let rows=document.getElementById('rows'); rows.replaceChildren();
      if(!data.length && !d.busy) rows.textContent=d.view==='servers'?'Nie znaleziono serwera DLNA.':'Brak utworow w tym katalogu.';
      data.forEach((x,i)=>{
        let line=document.createElement('div');line.className='row';
        let b=document.createElement('button');b.disabled=d.busy;
        b.textContent=(x.dir?'[KATALOG] ':'')+(x.name||'-');
        b.onclick=()=>go((d.view==='servers'?'server':'open')+'&i='+i);
        line.appendChild(b);rows.appendChild(line);
      });
    }
    let pages=document.getElementById('pages');pages.replaceChildren();
    if(d.view!=='servers' && d.totalMatches>pageSize){
      let p=document.createElement('button');p.textContent='Poprzednia';p.disabled=d.pageStart===0||d.busy;p.onclick=()=>go('prevpage');pages.appendChild(p);
      pages.append(' '+(Math.floor(d.pageStart/pageSize)+1)+' / '+Math.ceil(d.totalMatches/pageSize)+' ');
      let n=document.createElement('button');n.textContent='Nastepna';n.disabled=d.pageStart+pageSize>=d.totalMatches||d.busy;n.onclick=()=>go('nextpage');pages.appendChild(n);
    }
  }catch(e){document.getElementById('status').textContent='Błąd WWW: '+e}
}
refresh();if(autoRecordings)setTimeout(openRecordings,250);setInterval(refresh,1200);
</script></body></html>
)DLNAHTML";
