#include "EvoUsbHost.h"
#include <EVO_USB_HOST_MSC.h> // Jawne dolaczenie biblioteki z Arduino/libraries; brak lokalnego naglowka o tej nazwie
#include "Evo4_User_Config.h"
// Wybierz dostepny backend USB; brak MSC zglaszamy jawnie w runtime.
#include <memory>
#include <atomic>
#include <vfs_api.h>

#if defined(__has_include)
# if __has_include("usb/usb_host.h") && __has_include("usb/msc_host.h") && __has_include("usb/msc_host_vfs.h")
#  define EVO_USB_USE_ORIGINAL_IDF 1
# else
#  define EVO_USB_USE_ORIGINAL_IDF 0
# endif
#else
# define EVO_USB_USE_ORIGINAL_IDF 0
#endif

#if EVO_USB_USE_ORIGINAL_IDF
const char *evoUsbHostBackend() { return "ESP-IDF USB HOST MSC"; }
extern "C" {
# include "sdkconfig.h"
# include "esp_err.h"
# include "esp_intr_alloc.h"
# include "esp_vfs_fat.h"
# include "freertos/FreeRTOS.h"
# include "freertos/queue.h"
# include "freertos/task.h"
# include "usb/usb_host.h"
# include "usb/msc_host.h"
# include "usb/msc_host_vfs.h"
}

namespace {

constexpr const char *kMountPoint = "/usb";

// Arduino ESP32 >= 3.3.11: without this callback the IDF USB host can silently
// refuse to enumerate every connected device.
#if defined(CONFIG_USB_HOST_ENABLE_ENUM_FILTER_CALLBACK) && CONFIG_USB_HOST_ENABLE_ENUM_FILTER_CALLBACK
static bool evoUsbAllowAll(const usb_device_desc_t *desc, uint8_t *configuration) {
  (void)desc;
  if (configuration) *configuration = 1;
  return true;
}
#endif

enum class UsbMessageId : uint8_t { Connected, Disconnected };
struct UsbMessage {
  UsbMessageId id;
  union {
    uint8_t address;
    msc_host_device_handle_t handle;
  } device;
};

QueueHandle_t usbQueue = nullptr;
TaskHandle_t usbDaemonTaskHandle = nullptr;
TaskHandle_t usbManagerTaskHandle = nullptr;
msc_host_device_handle_t usbDevice = nullptr;
msc_host_vfs_handle_t usbVfsHandle = nullptr;
std::shared_ptr<VFSImpl> usbFsImpl(new VFSImpl());
fs::FS usbFs(usbFsImpl);
std::atomic<bool> usbReady{false};
std::atomic<bool> usbMounted{false};
std::atomic<uint64_t> usbCapacity{0};
std::atomic<const char *> usbStatus{"USB START"};
std::atomic<const char *> usbActivity{"IDLE"};
std::atomic<uint32_t> usbReadCount{0};
std::atomic<uint32_t> usbErrorCount{0};
std::atomic<uint32_t> usbLastSector{0};
std::atomic<uint32_t> usbLastSectorCount{0};
std::atomic<int32_t> usbLastError{0};
std::atomic<uint32_t> usbLastTransferMs{0};

void mscEventCallback(const msc_host_event_t *event, void *) {
  if (!event || !usbQueue) return;
  UsbMessage message{};
  if (event->event == msc_host_event_t::MSC_DEVICE_CONNECTED) {
    message.id = UsbMessageId::Connected;
    message.device.address = event->device.address;
  } else if (event->event == msc_host_event_t::MSC_DEVICE_DISCONNECTED) {
    message.id = UsbMessageId::Disconnected;
    message.device.handle = event->device.handle;
  } else {
    return;
  }
  xQueueSend(usbQueue, &message, 0);
}

void unmountDevice() {
  usbMounted.store(false, std::memory_order_release);
  usbFsImpl->mountpoint(nullptr);
  usbCapacity.store(0, std::memory_order_relaxed);
  if (usbVfsHandle) {
    msc_host_vfs_unregister(usbVfsHandle);
    usbVfsHandle = nullptr;
  }
  if (usbDevice) {
    msc_host_uninstall_device(usbDevice);
    usbDevice = nullptr;
  }
}

void managerTask(void *) {
  UsbMessage message{};
  uint8_t pendingAddress = 0;
  uint32_t nextRetryMs = 0;
  for (;;) {
    if (xQueueReceive(usbQueue, &message, pdMS_TO_TICKS(500)) != pdTRUE) {
      if (!pendingAddress || (int32_t)(millis() - nextRetryMs) < 0) continue;
      message = UsbMessage{};
      message.id = UsbMessageId::Connected;
      message.device.address = pendingAddress;
    }
    if (message.id == UsbMessageId::Connected) {
      if (usbDevice) continue;
      pendingAddress = message.device.address;
      usbStatus.store("USB WYKRYTO", std::memory_order_relaxed);
      esp_err_t err = ESP_FAIL;
      // Niektore pendrive'y sa widoczne natychmiast po starcie, ale przez
      // pierwsze sekundy nie przyjmuja jeszcze komend MSC/FAT. Poprzednio
      // jeden taki blad konczyl montowanie az do fizycznego wyjecia USB.
      // Teraz montowanie jest automatycznie ponawiane bez restartu radia.
      Serial.printf("[USB] IDF MSC CONNECTED address=%u\n", (unsigned)message.device.address);
      for (uint8_t attempt = 0; attempt < 8 && !usbDevice; ++attempt) {
        if (attempt) {
          usbStatus.store("USB MOUNT RETRY", std::memory_order_relaxed);
          vTaskDelay(pdMS_TO_TICKS(750));
        }
        err = msc_host_install_device(message.device.address, &usbDevice);
        Serial.printf("[USB] IDF open attempt=%u result=%s\n", (unsigned)(attempt+1), esp_err_to_name(err));
        if (err != ESP_OK) {
          usbDevice = nullptr;
          continue;
        }

        esp_vfs_fat_mount_config_t mountConfig{};
        mountConfig.format_if_mount_failed = false;
        mountConfig.max_files = 8;
        mountConfig.allocation_unit_size = 8192;
        err = msc_host_vfs_register(usbDevice, kMountPoint, &mountConfig, &usbVfsHandle);
        Serial.printf("[USB] IDF FAT mount attempt=%u result=%s\n", (unsigned)(attempt+1), esp_err_to_name(err));
        if (err == ESP_OK) break;

        usbVfsHandle = nullptr;
        msc_host_uninstall_device(usbDevice);
        usbDevice = nullptr;
      }
      if (!usbDevice || err != ESP_OK) {
        usbStatus.store("USB MOUNT ERROR", std::memory_order_relaxed);
        Serial.printf("[USB] IDF MOUNT FAILED %s\n", esp_err_to_name(err));
        // Retry even if the stick stays plugged in; the IDF callback may only
        // report the initial connection and never send another event.
        nextRetryMs = millis() + 5000UL;
        continue;
      }

      pendingAddress = 0;
      msc_host_device_info_t info{};
      if (msc_host_get_device_info(usbDevice, &info) == ESP_OK) {
        usbCapacity.store((uint64_t)info.sector_count * info.sector_size, std::memory_order_relaxed);
      }
      usbFsImpl->mountpoint(kMountPoint);
      usbReadCount.store(0, std::memory_order_relaxed);
      usbErrorCount.store(0, std::memory_order_relaxed);
      usbLastError.store(0, std::memory_order_relaxed);
      usbActivity.store("MOUNT OK", std::memory_order_relaxed);
      usbMounted.store(true, std::memory_order_release);
      usbStatus.store("USB GOTOWE", std::memory_order_relaxed);
      Serial.printf("[USB] IDF MOUNT OK path=%s capacity=%llu\n", kMountPoint, (unsigned long long)usbCapacity.load());
    } else if (message.id == UsbMessageId::Disconnected &&
               (!usbDevice || message.device.handle == usbDevice)) {
      pendingAddress = 0;
      // Najpierw powiadom petle EVO, aby Audio zamknelo plik. Dopiero potem
      // usun montowanie VFS i uchwyt urzadzenia (bezpieczne hot-unplug).
      usbMounted.store(false, std::memory_order_release);
      usbStatus.store("USB ODLACZANIE", std::memory_order_relaxed);
      // Daj glownej petli czas na zatrzymanie Playera/Recordera i zamkniecie
      // File zanim VFS oraz uchwyt MSC zostana zwolnione.
      vTaskDelay(pdMS_TO_TICKS(1500));
      unmountDevice();
      usbStatus.store("USB ODLACZONE", std::memory_order_relaxed);
      Serial.println("[USB] IDF DISCONNECTED");
    }
  }
}

void daemonTask(void *) {
  usb_host_config_t hostConfig{};
  hostConfig.intr_flags = ESP_INTR_FLAG_LEVEL1;
#if defined(CONFIG_USB_HOST_ENABLE_ENUM_FILTER_CALLBACK) && CONFIG_USB_HOST_ENABLE_ENUM_FILTER_CALLBACK
  hostConfig.enum_filter_cb = evoUsbAllowAll;
#endif
  Serial.println("[USB] BACKEND=IDF (kolejnosc uruchomienia jak w dzialajacym PlatformIO)");
  esp_err_t err = usb_host_install(&hostConfig);
  Serial.printf("[USB] usb_host_install=%s\n", esp_err_to_name(err));
  if (err != ESP_OK) {
    usbStatus.store("USB HOST ERROR", std::memory_order_relaxed);
    usbReady.store(false, std::memory_order_release);
    usbDaemonTaskHandle = nullptr;
    vTaskDelete(nullptr);
    return;
  }

  msc_host_driver_config_t mscConfig{};
  mscConfig.create_backround_task = true;
  // Odbior callbacku transferu musi miec pierwszenstwo przed renderowaniem
  // TFT i obsluga WWW; inaczej poprawny transfer konczyl sie timeoutem.
  mscConfig.task_priority = 10;
  mscConfig.stack_size = 4096;
  mscConfig.core_id = 1;
  mscConfig.callback = mscEventCallback;
  mscConfig.callback_arg = nullptr;
  err = msc_host_install(&mscConfig);
  Serial.printf("[USB] msc_host_install=%s\n", esp_err_to_name(err));
  if (err != ESP_OK) {
    usbStatus.store("USB MSC ERROR", std::memory_order_relaxed);
    usb_host_uninstall();
    usbReady.store(false, std::memory_order_release);
    usbDaemonTaskHandle = nullptr;
    vTaskDelete(nullptr);
    return;
  }

  usbReady.store(true, std::memory_order_release);
  usbStatus.store("USB CZEKA", std::memory_order_relaxed);
  for (;;) {
    uint32_t eventFlags = 0;
    usb_host_lib_handle_events(portMAX_DELAY, &eventFlags);
  }
}

}  // namespace

extern "C" void evo_usb_msc_read_begin(uint32_t sector, uint32_t count) {
  usbLastSector.store(sector, std::memory_order_relaxed);
  usbLastSectorCount.store(count, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ", std::memory_order_relaxed);
}

extern "C" void evo_usb_msc_read_ok(uint32_t sector, uint32_t count) {
  (void)sector;
  (void)count;
  usbReadCount.fetch_add(1, std::memory_order_relaxed);
  usbLastError.store(0, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ OK", std::memory_order_relaxed);
}

extern "C" void evo_usb_msc_read_error(uint32_t sector, uint32_t count, int32_t error) {
  usbLastSector.store(sector, std::memory_order_relaxed);
  usbLastSectorCount.store(count, std::memory_order_relaxed);
  usbLastError.store(error, std::memory_order_relaxed);
  usbErrorCount.fetch_add(1, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ ERROR", std::memory_order_relaxed);
}

bool evoUsbHostSupported() { return true; }

bool evoUsbHostBegin() {
  if (usbDaemonTaskHandle && usbManagerTaskHandle) return true;
#if defined(ARDUINO_USB_MODE) && (ARDUINO_USB_MODE != 0)
  static bool usbModeWarned = false;
  if (!usbModeWarned) {
    usbModeWarned = true;
    Serial.printf("[USB DIAG] HOST BLOCKED: ARDUINO_USB_MODE=%d; required=0\n", (int)ARDUINO_USB_MODE);
  }
  usbStatus.store("ZLY USB MODE", std::memory_order_relaxed);
  return false;
#endif
#if defined(ARDUINO_USB_CDC_ON_BOOT) && (ARDUINO_USB_CDC_ON_BOOT != 0)
  Serial.println("[USB] IDF HOST ERROR: set USB CDC On Boot = Disabled");
  usbStatus.store("CDC BLOKUJE HOST", std::memory_order_relaxed);
  return false;
#endif
#if defined(ARDUINO_USB_MODE)
  Serial.printf("[USB] BACKEND=IDF USB_MODE=%d CDC=%d\n", (int)ARDUINO_USB_MODE,
#if defined(ARDUINO_USB_CDC_ON_BOOT)
                (int)ARDUINO_USB_CDC_ON_BOOT
#else
                -1
#endif
                );
#endif
#if (EVO_USB_VBUS_EN_PIN >= 0)
  pinMode(EVO_USB_VBUS_EN_PIN, OUTPUT);
  digitalWrite(EVO_USB_VBUS_EN_PIN, EVO_USB_VBUS_EN_ACTIVE);
  Serial.printf("[USB] VBUS enable GPIO%d\n", (int)EVO_USB_VBUS_EN_PIN);
#else
  Serial.println("[USB] VBUS: oczekuje 5 V na gniezdzie USB-A");
#endif
  if (!usbQueue) {
    usbQueue = xQueueCreate(6, sizeof(UsbMessage));
    if (!usbQueue) {
      usbStatus.store("USB QUEUE ERROR", std::memory_order_relaxed);
      return false;
    }
  }
  // Po nieudanym starcie zachowujemy juz utworzone zadanie i kolejke.
  // Ponowienie nie moze tworzyc drugiego managera na tej samej magistrali.
  if (!usbManagerTaskHandle &&
      xTaskCreatePinnedToCore(managerTask, "evo_usb_msc", 6144, nullptr, 3,
                              &usbManagerTaskHandle, 0) != pdPASS) {
    usbStatus.store("USB TASK ERROR MSC", std::memory_order_relaxed);
    return false;
  }
  if (!usbDaemonTaskHandle &&
      xTaskCreatePinnedToCore(daemonTask, "evo_usb_host", 4096, nullptr, 10,
                              &usbDaemonTaskHandle, 0) != pdPASS) {
    usbStatus.store("USB TASK ERROR HOST", std::memory_order_relaxed);
    return false;
  }
  return true;
}

void evoUsbHostLoop() {
  if (usbReady.load(std::memory_order_acquire) || usbDaemonTaskHandle) return;
  static uint32_t lastRetryMs = 0;
  const uint32_t now = millis();
  if (now - lastRetryMs < 5000UL) return;
  lastRetryMs = now;
  evoUsbHostBegin();
}
bool evoUsbHostMounted() { return usbMounted.load(std::memory_order_acquire); }
bool evoUsbHostReady() { return usbReady.load(std::memory_order_acquire); }
fs::FS &evoUsbHostFs() { return usbFs; }
const char *evoUsbHostStatus() { return usbStatus.load(std::memory_order_relaxed); }
uint64_t evoUsbHostCapacityBytes() { return usbCapacity.load(std::memory_order_relaxed); }
void evoUsbHostSetActivity(const char *activity) { usbActivity.store(activity ? activity : "", std::memory_order_relaxed); }
const char *evoUsbHostActivity() { return usbActivity.load(std::memory_order_relaxed); }
uint32_t evoUsbHostReadCount() { return usbReadCount.load(std::memory_order_relaxed); }
uint32_t evoUsbHostErrorCount() { return usbErrorCount.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastSector() { return usbLastSector.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastSectorCount() { return usbLastSectorCount.load(std::memory_order_relaxed); }
int32_t evoUsbHostLastError() { return usbLastError.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastTransferMs() { return usbLastTransferMs.load(std::memory_order_relaxed); }


#else // Arduino USB Host when ESP-IDF MSC component is absent.

// EVO4 HQ57W - USB HOST DIAG/FIX
// Arduino-ESP32 3.3.12: oficjalny TinyUSB Host MSC.
// Cel tej wersji: trzymac sie mozliwie blisko oficjalnego przykladu Espressif.
// Bez recznego pinowania tasku USB do core 0, bez starego usb/msc_host.h.

#include <atomic>

#if defined(__has_include)
  #if __has_include(<USBHost.h>) && __has_include(<USBHostMSC.h>) && __has_include(<USBMSCFS.h>)
    #define EVO_USB_HOST_ARDUINO_API 1
  #else
    #define EVO_USB_HOST_ARDUINO_API 0
  #endif
#else
  #define EVO_USB_HOST_ARDUINO_API 0
#endif

#if EVO_USB_HOST_ARDUINO_API

const char *evoUsbHostBackend() { return "Arduino TinyUSB USBHostMSC"; }
#include <USBHost.h>
#include <USBHostMSC.h>
#include <USBMSCFS.h>

namespace {
USBMSCFSClass usbFs;
std::atomic<bool> usbReady{false};
std::atomic<bool> usbMounted{false};
std::atomic<uint64_t> usbCapacity{0};
std::atomic<const char *> usbStatus{"USB START"};
std::atomic<const char *> usbActivity{"IDLE"};
std::atomic<uint32_t> usbReadCount{0};
std::atomic<uint32_t> usbErrorCount{0};
std::atomic<uint32_t> usbLastSector{0};
std::atomic<uint32_t> usbLastSectorCount{0};
std::atomic<int32_t> usbLastError{0};
std::atomic<uint32_t> usbLastTransferMs{0};

uint32_t lastHostRetryMs = 0;
uint32_t lastMountRetryMs = 0;
uint32_t mscSeenAtMs = 0;
uint32_t lastDiagMs = 0;
bool lastDevicePresent = false;
bool fsBeginWasAttempted = false;

static void usbPrintBuildConfig() {
#if defined(ARDUINO_USB_MODE)
  Serial.printf("[USB] ARDUINO_USB_MODE=%d (dla USB-OTG/TinyUSB oczekiwane 0)\n", (int)ARDUINO_USB_MODE);
#else
  Serial.println("[USB] ARDUINO_USB_MODE=niezdefiniowane");
#endif
#if defined(ARDUINO_USB_CDC_ON_BOOT)
  Serial.printf("[USB] ARDUINO_USB_CDC_ON_BOOT=%d (oczekiwane 0)\n", (int)ARDUINO_USB_CDC_ON_BOOT);
#endif
  Serial.println("[USB] D-=GPIO19 D+=GPIO20; VBUS USB-A MUSI miec 5 V");
}

static void vbusOn() {
#if (EVO_USB_VBUS_EN_PIN >= 0)
  pinMode(EVO_USB_VBUS_EN_PIN, OUTPUT);
  digitalWrite(EVO_USB_VBUS_EN_PIN, EVO_USB_VBUS_EN_ACTIVE);
  delay(120);
  Serial.printf("[USB] VBUS EN przez GPIO%d\n", (int)EVO_USB_VBUS_EN_PIN);
#else
  Serial.println("[USB] VBUS EN pin=-1: oczekuje stalego 5 V z hardware");
#endif
}

void markUnmounted(const char *status) {
  if (usbMounted.exchange(false, std::memory_order_acq_rel)) {
    usbFs.end();
  }
  fsBeginWasAttempted = false;
  mscSeenAtMs = 0;
  usbCapacity.store(0, std::memory_order_relaxed);
  usbStatus.store(status, std::memory_order_relaxed);
}

bool tryMountFilesystem() {
  if (!USBHostMSC.mounted()) return false;

  // Pierwsza proba dopiero po chwili od enumeracji. Czesc pendrive'ow potrzebuje
  // kilkuset ms po MSC mount zanim READ CAPACITY/FatFs jest stabilne.
  if (mscSeenAtMs && (uint32_t)(millis() - mscSeenAtMs) < 350UL) return false;

  fsBeginWasAttempted = true;
  if (!usbFs.begin("/usb", 5, false)) {
    usbErrorCount.fetch_add(1, std::memory_order_relaxed);
    usbLastError.store(-1, std::memory_order_relaxed);
    usbActivity.store("MOUNT ERROR", std::memory_order_relaxed);
    usbStatus.store("USB MOUNT ERROR", std::memory_order_relaxed);
    Serial.printf("[USB] FAT mount ERROR; blocks=%lu size=%lu. Wymagany FAT16/FAT32.\n",
                  (unsigned long)USBHostMSC.blockCount(),
                  (unsigned long)USBHostMSC.blockSize());
    return false;
  }

  uint64_t capacity = usbFs.cardSize();
  if (!capacity) capacity = (uint64_t)USBHostMSC.blockCount() * (uint64_t)USBHostMSC.blockSize();
  usbCapacity.store(capacity, std::memory_order_relaxed);
  usbMounted.store(true, std::memory_order_release);
  usbStatus.store("USB GOTOWE", std::memory_order_relaxed);
  usbActivity.store("MOUNT OK", std::memory_order_relaxed);
  usbLastError.store(0, std::memory_order_relaxed);
  Serial.printf("[USB] MOUNT OK /usb, capacity=%llu bytes, block=%lu x %lu\n",
                (unsigned long long)capacity,
                (unsigned long)USBHostMSC.blockCount(),
                (unsigned long)USBHostMSC.blockSize());
  return true;
}
}  // namespace

extern "C" void evo_usb_msc_read_begin(uint32_t sector, uint32_t count) {
  usbLastSector.store(sector, std::memory_order_relaxed);
  usbLastSectorCount.store(count, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ", std::memory_order_relaxed);
}
extern "C" void evo_usb_msc_read_ok(uint32_t sector, uint32_t count) {
  usbLastSector.store(sector, std::memory_order_relaxed);
  usbLastSectorCount.store(count, std::memory_order_relaxed);
  usbReadCount.fetch_add(1, std::memory_order_relaxed);
  usbLastError.store(0, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ OK", std::memory_order_relaxed);
}
extern "C" void evo_usb_msc_read_error(uint32_t sector, uint32_t count, int32_t error) {
  usbLastSector.store(sector, std::memory_order_relaxed);
  usbLastSectorCount.store(count, std::memory_order_relaxed);
  usbLastError.store(error, std::memory_order_relaxed);
  usbErrorCount.fetch_add(1, std::memory_order_relaxed);
  usbLastTransferMs.store(millis(), std::memory_order_relaxed);
  usbActivity.store("READ ERROR", std::memory_order_relaxed);
}

bool evoUsbHostSupported() { return true; }

bool evoUsbHostBegin() {
  if (usbReady.load(std::memory_order_acquire) && USBHost.started()) return true;

  usbPrintBuildConfig();
#if defined(ARDUINO_USB_MODE) && (ARDUINO_USB_MODE != 0)
  usbStatus.store("ZLY USB MODE", std::memory_order_relaxed);
  usbActivity.store("USTAW USB-OTG", std::memory_order_relaxed);
  Serial.println("[USB] ERROR: Narzedzia -> USB Mode musi byc USB-OTG (TinyUSB)");
  return false;
#endif
#if defined(ARDUINO_USB_CDC_ON_BOOT) && (ARDUINO_USB_CDC_ON_BOOT != 0)
  usbStatus.store("CDC BLOKUJE HOST", std::memory_order_relaxed);
  usbActivity.store("CDC ON BOOT=OFF", std::memory_order_relaxed);
  Serial.println("[USB] ERROR: USB CDC On Boot musi byc Disabled");
  return false;
#endif

  vbusOn();
  Serial.println("[USB] USBHost.begin() - oficjalny TinyUSB Host...");
  // NIE ustawiamy USBHost.setCore(). Oficjalny przyklad Espressif pozwala
  // bibliotece utworzyc worker na domyslnym rdzeniu.
  const bool ok = USBHost.begin();
  usbReady.store(ok, std::memory_order_release);
  if (ok) {
    usbStatus.store("USB CZEKA", std::memory_order_relaxed);
    usbActivity.store("HOST OK", std::memory_order_relaxed);
    Serial.println("[USB] HOST OK - czekam na pendrive");
  } else {
    usbStatus.store("USB HOST ERROR", std::memory_order_relaxed);
    usbActivity.store("HOST ERROR", std::memory_order_relaxed);
    usbErrorCount.fetch_add(1, std::memory_order_relaxed);
    Serial.println("[USB] USBHost.begin() ERROR");
  }
  return ok;
}

void evoUsbHostLoop() {
  const uint32_t now = millis();

  if (!usbReady.load(std::memory_order_acquire) || !USBHost.started()) {
    if ((uint32_t)(now - lastHostRetryMs) >= 5000UL) {
      lastHostRetryMs = now;
      evoUsbHostBegin();
    }
    return;
  }

  USBHost.task();

  const bool devicePresent = USBHostMSC.mounted();
  if (devicePresent != lastDevicePresent) {
    lastDevicePresent = devicePresent;
    if (devicePresent) {
      mscSeenAtMs = now;
      fsBeginWasAttempted = false;
      usbStatus.store("USB WYKRYTO", std::memory_order_relaxed);
      usbActivity.store("MSC CONNECTED", std::memory_order_relaxed);
      Serial.printf("[USB] MSC CONNECTED addr=%u lun=%u blocks=%lu blockSize=%lu\n",
                    (unsigned)USBHostMSC.devAddr(), (unsigned)USBHostMSC.lun(),
                    (unsigned long)USBHostMSC.blockCount(), (unsigned long)USBHostMSC.blockSize());
      lastMountRetryMs = 0;
    } else {
      Serial.println("[USB] MSC DISCONNECTED");
      markUnmounted("USB ODLACZONE");
      usbActivity.store("DISCONNECTED", std::memory_order_relaxed);
    }
  }

  if (devicePresent && !usbMounted.load(std::memory_order_acquire)) {
    if (lastMountRetryMs == 0 || (uint32_t)(now - lastMountRetryMs) >= 1500UL) {
      lastMountRetryMs = now;
      tryMountFilesystem();
    }
  }

  // Co 2 s status diagnostyczny. Pozwala od razu rozroznic: host / enumeracja / FAT.
  if ((uint32_t)(now - lastDiagMs) >= 2000UL) {
    lastDiagMs = now;
    Serial.printf("[USB DIAG] host=%d started=%d msc=%d fs=%d addr=%u blocks=%lu bsz=%lu err=%lu\n",
                  usbReady.load() ? 1 : 0, USBHost.started() ? 1 : 0,
                  devicePresent ? 1 : 0, usbMounted.load() ? 1 : 0,
                  devicePresent ? (unsigned)USBHostMSC.devAddr() : 0U,
                  devicePresent ? (unsigned long)USBHostMSC.blockCount() : 0UL,
                  devicePresent ? (unsigned long)USBHostMSC.blockSize() : 0UL,
                  (unsigned long)usbErrorCount.load());
  }
}

bool evoUsbHostMounted() { return usbMounted.load(std::memory_order_acquire); }
bool evoUsbHostReady() { return usbReady.load(std::memory_order_acquire); }
fs::FS &evoUsbHostFs() { return usbFs; }
const char *evoUsbHostStatus() { return usbStatus.load(std::memory_order_relaxed); }
uint64_t evoUsbHostCapacityBytes() { return usbCapacity.load(std::memory_order_relaxed); }
void evoUsbHostSetActivity(const char *activity) { usbActivity.store(activity ? activity : "", std::memory_order_relaxed); }
const char *evoUsbHostActivity() { return usbActivity.load(std::memory_order_relaxed); }
uint32_t evoUsbHostReadCount() { return usbReadCount.load(std::memory_order_relaxed); }
uint32_t evoUsbHostErrorCount() { return usbErrorCount.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastSector() { return usbLastSector.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastSectorCount() { return usbLastSectorCount.load(std::memory_order_relaxed); }
int32_t evoUsbHostLastError() { return usbLastError.load(std::memory_order_relaxed); }
uint32_t evoUsbHostLastTransferMs() { return usbLastTransferMs.load(std::memory_order_relaxed); }

#else

const char *evoUsbHostBackend() { return "BRAK STEROWNIKA USB HOST MSC"; }
#include <memory>
#include <vfs_api.h>
namespace {
std::shared_ptr<VFSImpl> usbFsImpl(new VFSImpl());
fs::FS usbFs(usbFsImpl);
std::atomic<const char *> usbStatus{"USB HOST API BRAK"};
std::atomic<const char *> usbActivity{"DISABLED"};
}
extern "C" void evo_usb_msc_read_begin(uint32_t, uint32_t) {}
extern "C" void evo_usb_msc_read_ok(uint32_t, uint32_t) {}
extern "C" void evo_usb_msc_read_error(uint32_t, uint32_t, int32_t) {}
bool evoUsbHostSupported() { return false; }
bool evoUsbHostBegin() {
  Serial.println("[USB] ERROR: missing BOTH IDF MSC (msc_host.h + msc_host_vfs.h) and Arduino USBHostMSC/USBMSCFS");
  return false;
}
void evoUsbHostLoop() {}
bool evoUsbHostMounted() { return false; }
bool evoUsbHostReady() { return false; }
fs::FS &evoUsbHostFs() { return usbFs; }
const char *evoUsbHostStatus() { return usbStatus.load(std::memory_order_relaxed); }
uint64_t evoUsbHostCapacityBytes() { return 0; }
void evoUsbHostSetActivity(const char *activity) { usbActivity.store(activity ? activity : "", std::memory_order_relaxed); }
const char *evoUsbHostActivity() { return usbActivity.load(std::memory_order_relaxed); }
uint32_t evoUsbHostReadCount() { return 0; }
uint32_t evoUsbHostErrorCount() { return 0; }
uint32_t evoUsbHostLastSector() { return 0; }
uint32_t evoUsbHostLastSectorCount() { return 0; }
int32_t evoUsbHostLastError() { return 0; }
uint32_t evoUsbHostLastTransferMs() { return 0; }

#endif

#endif // EVO_USB_USE_ORIGINAL_IDF
