#include "Evo4_Retro_Palette.h"
#include <Preferences.h>
#include <string.h>
#include <esp_heap_caps.h>
// All values below are direct draw colors. Images, JPEG/PNG and RGB565 transfer unchanged.
namespace Evo4Retro {
namespace Cassette {
  std::atomic<uint32_t> BG{RGB(0x060609)};
  std::atomic<uint32_t> SHELL{RGB(0xAC2428)};
  std::atomic<uint32_t> SHELL_EDGE{RGB(0xEA6961)};
  std::atomic<uint32_t> BODY{RGB(0x202124)};
  std::atomic<uint32_t> WINDOW_TRIM{RGB(0x781E25)};
  std::atomic<uint32_t> WHITE{RGB(0xFCF7ED)};
  std::atomic<uint32_t> LABEL_RULE{RGB(0xA93434)};
  std::atomic<uint32_t> WINDOW_BG{RGB(0x11191C)};
  std::atomic<uint32_t> WINDOW_BORDER{RGB(0xABB1B3)};
  std::atomic<uint32_t> TAPE_DARK{RGB(0x513429)};
  std::atomic<uint32_t> TAPE_BROWN{RGB(0x855339)};
  std::atomic<uint32_t> HUB_SHADOW{RGB(0x31353B)};
  std::atomic<uint32_t> CENTER_BORDER{RGB(0x8F9293)};
  std::atomic<uint32_t> TAPE_HIGHLIGHT{RGB(0xCFB17B)};
  std::atomic<uint32_t> STRIP{RGB(0xC91B24)};
  std::atomic<uint32_t> PLAY_CYAN{RGB(0x00DCD7)};
  std::atomic<uint32_t> RED{RGB(0xF13738)};
  std::atomic<uint32_t> YELLOW{RGB(0xF8D450)};
  std::atomic<uint32_t> GREEN{RGB(0x34CF65)};
  std::atomic<uint32_t> HUB_METAL{RGB(0xCACED0)};
  std::atomic<uint32_t> HUB_HIGHLIGHT{RGB(0xF4F2E9)};
  std::atomic<uint32_t> HUB_TOOTH{RGB(0x54595B)};
  std::atomic<uint32_t> METER_OFF{RGB(0x343638)};
}
namespace Reel {
  std::atomic<uint32_t> BACKDROP{RGB(0x1B1E20)};
  std::atomic<uint32_t> WOOD{RGB(0x513022)};
  std::atomic<uint32_t> PANEL_FACE{RGB(0xC8CFD0)};
  std::atomic<uint32_t> SILVER_TRIM{RGB(0xF3F3EF)};
  std::atomic<uint32_t> PANEL_STRIP{RGB(0xB5A485)};
  std::atomic<uint32_t> PANEL_DARK{RGB(0x25292D)};
  std::atomic<uint32_t> ALUMINUM{RGB(0xD6DAD9)};
  std::atomic<uint32_t> ALUMINUM_EDGE{RGB(0xA5AEAF)};
  std::atomic<uint32_t> ALUMINUM_LIGHT{RGB(0xF2F2EA)};
  std::atomic<uint32_t> ALUMINUM_MID{RGB(0xDEE2DF)};
  std::atomic<uint32_t> METAL_GROOVE{RGB(0xA5A9A8)};
  std::atomic<uint32_t> TAPE{RGB(0x302A25)};
  std::atomic<uint32_t> WHITE{RGB(0xF8F5EA)};
  std::atomic<uint32_t> BUTTON{RGB(0x777C7E)};
  std::atomic<uint32_t> AMBER{RGB(0xFFD069)};
  std::atomic<uint32_t> GREEN{RGB(0x42D267)};
  std::atomic<uint32_t> RED{RGB(0xDC3033)};
  std::atomic<uint32_t> COUNTER_BG{RGB(0x0D1215)};
  std::atomic<uint32_t> VU_FACE{RGB(0xF4E9CA)};
  std::atomic<uint32_t> VU_EDGE{RGB(0xA08E70)};
  std::atomic<uint32_t> VU_INK{RGB(0x34302B)};
  std::atomic<uint32_t> VU_PIN{RGB(0xC79B57)};
}
namespace Turntable {
  std::atomic<uint32_t> BG{RGB(0x190F0D)};
  std::atomic<uint32_t> WOOD{RGB(0x713D25)};
  std::atomic<uint32_t> WOOD_BORDER{RGB(0xBD8756)};
  std::atomic<uint32_t> WOOD_GROOVE{RGB(0x4C2919)};
  std::atomic<uint32_t> WOOD_GROOVE2{RGB(0x8B5937)};
  std::atomic<uint32_t> WOOD_STRIPE{RGB(0xA06B44)};
  std::atomic<uint32_t> PLATTER_RIM{RGB(0xBABDBA)};
  std::atomic<uint32_t> PLATTER_SHADE{RGB(0x565B5A)};
  std::atomic<uint32_t> VINYL{RGB(0x101315)};
  std::atomic<uint32_t> GROOVE{RGB(0x2F3337)};
  std::atomic<uint32_t> GROOVE_DARK{RGB(0x1A1D20)};
  std::atomic<uint32_t> LABEL_GOLD{RGB(0xD2AF65)};
  std::atomic<uint32_t> WHITE{RGB(0xF7F1E4)};
  std::atomic<uint32_t> GOLD_HIGHLIGHT{RGB(0xFFD782)};
  std::atomic<uint32_t> VINYL_REFLEX{RGB(0x494D4D)};
  std::atomic<uint32_t> HORN_BRASS{RGB(0xCDA352)};
  std::atomic<uint32_t> HORN_LIGHT{RGB(0xF6D58C)};
  std::atomic<uint32_t> HORN_INSIDE{RGB(0x805B2F)};
  std::atomic<uint32_t> HORN_RIB{RGB(0xA0743B)};
  std::atomic<uint32_t> ARM_GOLD{RGB(0xECCB88)};
  std::atomic<uint32_t> ARM_SHADOW{RGB(0x967D56)};
  std::atomic<uint32_t> ARM_BASE{RGB(0x686C6C)};
  std::atomic<uint32_t> ARM_METAL{RGB(0xE7E6DD)};
  std::atomic<uint32_t> GREEN{RGB(0x46D266)};
  std::atomic<uint32_t> RED{RGB(0xE24A3A)};
}
namespace Nixie {
  std::atomic<uint32_t> BG{RGB(0x080608)};
  std::atomic<uint32_t> GLASS{RGB(0x181517)};
  std::atomic<uint32_t> FRAME{RGB(0x725035)};
  std::atomic<uint32_t> TUBE_GLOW{RGB(0x7A290C)};
  std::atomic<uint32_t> TUBE_ON{RGB(0xFFB343)};
  std::atomic<uint32_t> TUBE_DIM{RGB(0x28170E)};
  std::atomic<uint32_t> GLASS_REFLEX{RGB(0xB49C82)};
  std::atomic<uint32_t> GLASS_INNER{RGB(0x251209)};
  std::atomic<uint32_t> DOT_DIM{RGB(0x2B1308)};
  std::atomic<uint32_t> DOT_GLOW{RGB(0x843009)};
  std::atomic<uint32_t> DOT_ON{RGB(0xFFCC65)};
  std::atomic<uint32_t> TEXT_DIM{RGB(0xA68B69)};
  std::atomic<uint32_t> DATE{RGB(0xFFCA67)};
  std::atomic<uint32_t> TEXT{RGB(0xEFDDC1)};
  std::atomic<uint32_t> NOW_PLAYING{RGB(0xF0AF57)};
  std::atomic<uint32_t> PANEL_BORDER{RGB(0x6C4E34)};
  std::atomic<uint32_t> PANEL_INNER{RGB(0x2F2018)};
  std::atomic<uint32_t> FILM_LINE{RGB(0x584D42)};
  std::atomic<uint32_t> FILM_LINE_LITE{RGB(0xB6A795)};
}
namespace Common {
  std::atomic<uint32_t> FRAME_OUTER{0x07FF};
  std::atomic<uint32_t> FRAME_INNER{0x0397};
  std::atomic<uint32_t> TOP_ACCENT{0xFFE0};
  std::atomic<uint32_t> BOTTOM_ACCENT{0x07E0};
}
namespace Pixels {
static constexpr uint8_t modes=31;
static constexpr uint8_t capacity=128;
struct Pair { uint16_t from, to; };
struct Mode { uint16_t count=0; Pair pairs[capacity]{}; bool dirty=false; uint32_t revision=0; };
static Mode maps[modes];
static uint16_t *lookup=nullptr;
static uint8_t lookupMode=255;
static uint32_t lookupRevision=0;
static bool lookupSwapped=false;
static uint32_t changedAt=0;
static uint16_t swap16(uint16_t v) {return (uint16_t)((v<<8)|(v>>8));}
bool set(uint8_t mode,uint16_t source,uint16_t target) {
  if(mode>=modes)return false;
  Mode &m=maps[mode];
  for(uint16_t i=0;i<m.count;++i) {
    if(m.pairs[i].from==source || m.pairs[i].to==source) {
      if(source==target && m.pairs[i].from==source)return remove(mode,source);
      m.pairs[i].to=target;m.dirty=true;++m.revision;changedAt=millis();return true;
    }
  }
  if(source==target)return true;
  if(m.count>=capacity)return false;
  m.pairs[m.count++]={source,target};m.dirty=true;++m.revision;changedAt=millis();return true;
}
bool remove(uint8_t mode,uint16_t source) {
  if(mode>=modes)return false;
  Mode &m=maps[mode];
  for(uint16_t i=0;i<m.count;++i)if(m.pairs[i].from==source || m.pairs[i].to==source) {
    for(uint16_t j=i+1;j<m.count;++j)m.pairs[j-1]=m.pairs[j];
    --m.count;m.dirty=true;++m.revision;changedAt=millis();return true;
  }
  return false;
}
void reset() {
  for(uint8_t i=0;i<modes;++i){maps[i].count=0;maps[i].dirty=true;++maps[i].revision;}
  changedAt=millis();
}
void begin() {
  Preferences p;
  if(!p.begin("evo4pixel",true))return;
  for(uint8_t i=0;i<modes;++i) {
    char key[8];snprintf(key,sizeof(key),"m%u",(unsigned)i);
    const size_t bytes=p.getBytesLength(key);
    if(bytes && bytes<=sizeof(maps[i].pairs) && bytes%sizeof(Pair)==0) {
      if(p.getBytes(key,maps[i].pairs,bytes)==bytes)maps[i].count=bytes/sizeof(Pair);
    }
  }
  p.end();
}
void service() {
  if((uint32_t)(millis()-changedAt)<1500UL)return;
  for(uint8_t i=0;i<modes;++i)if(maps[i].dirty) {
    Preferences p;
    if(!p.begin("evo4pixel",false))return;
    char key[8];snprintf(key,sizeof(key),"m%u",(unsigned)i);
    const bool ok=maps[i].count ? p.putBytes(key,maps[i].pairs,maps[i].count*sizeof(Pair))==maps[i].count*sizeof(Pair)
                                 : (!p.isKey(key) || p.remove(key));
    p.end();
    if(ok)maps[i].dirty=false;
    return; // Jedna operacja NVS na przebieg petli.
  }
}
void apply(uint8_t mode,uint16_t *buffer,int32_t width,int32_t height,uint16_t rawSample,uint16_t samplePixel,
           const ProtectedRect *protectedRects,uint8_t protectedCount) {
  if(mode>=modes||!buffer||width<=0||height<=0||!maps[mode].count)return;
  Mode &m=maps[mode];
  const bool swapped=rawSample==swap16(samplePixel) && rawSample!=samplePixel;
  if(!lookup)lookup=(uint16_t*)heap_caps_malloc(65536U*sizeof(uint16_t),MALLOC_CAP_SPIRAM|MALLOC_CAP_8BIT);
  if(lookup && (lookupMode!=mode || lookupRevision!=m.revision || lookupSwapped!=swapped)) {
    for(uint32_t i=0;i<65536U;++i)lookup[i]=(uint16_t)i;
    for(uint16_t i=0;i<m.count;++i){const uint16_t from=swapped?swap16(m.pairs[i].from):m.pairs[i].from;
      lookup[from]=swapped?swap16(m.pairs[i].to):m.pairs[i].to;}
    lookupMode=mode;lookupRevision=m.revision;lookupSwapped=swapped;
  }
  // Zewnetrzne obrazy (logo i okladka) zachowuja oryginalne RGB565.
  for(int32_t y=0;y<height;++y) {
    for(int32_t x=0;x<width;++x) {
      bool artwork=false;
      for(uint8_t k=0;k<protectedCount;++k) {
        const ProtectedRect &r=protectedRects[k];
        if(x>=r.x && x<(int32_t)r.x+r.w && y>=r.y && y<(int32_t)r.y+r.h) {artwork=true;break;}
      }
      if(artwork)continue;
      uint16_t &pixel=buffer[(size_t)y*(size_t)width+(size_t)x];
      if(lookup)pixel=lookup[pixel];
      else for(uint16_t j=0;j<m.count;++j) {
        if(pixel==(swapped?swap16(m.pairs[j].from):m.pairs[j].from)) {
          pixel=swapped?swap16(m.pairs[j].to):m.pairs[j].to;break;
        }
      }
    }
  }
}

String json(uint8_t mode) {
  String s="{\"mode\":"+String(mode)+",\"changes\":[";
  if(mode<modes)for(uint16_t i=0;i<maps[mode].count;++i) {
    if(i)s+=',';
    char b[70];snprintf(b,sizeof(b),"{\"from\":%u,\"to\":%u}",
                         (unsigned)maps[mode].pairs[i].from,(unsigned)maps[mode].pairs[i].to);
    s+=b;
  }
  return s+"]}";
}
}
namespace Native {
static constexpr uint16_t defaults[SLOTS] = {0x0010,0x018C,0x02B5,0xFFFF,0xC638,
                                             0x07FF,0x07E0,0xFFE0,0xFD20,0xF800};
static const char* const names[SLOTS] = {"Tlo","Panel","Karta","Tekst","Tekst pomocniczy",
                                         "Cyan","Zielony","Zolty","Pomaranczowy","Czerwony"};
static std::atomic<uint16_t> colors[MODES][SLOTS];
static std::atomic<uint8_t> selected{0};
static std::atomic<bool> modified{false};
struct NativeBlob { uint32_t version; uint16_t values[MODES][SLOTS]; };
static constexpr uint32_t nativeVersion=0x45564E31UL;
static uint32_t rgb565To888(uint16_t c) {
  const uint32_t r=(c>>11)&31, g=(c>>5)&63, b=c&31;
  return (((r*255+15)/31)<<16) | (((g*255+31)/63)<<8) | ((b*255+15)/31);
}
void select(uint8_t mode) { selected.store(mode<MODES?mode:0,std::memory_order_relaxed); }
uint16_t color(uint8_t slot) { return slot<SLOTS?colors[selected.load(std::memory_order_relaxed)][slot].load(std::memory_order_relaxed):0; }
uint32_t rgb(uint8_t mode,uint8_t slot) {return mode<MODES&&slot<SLOTS?rgb565To888(colors[mode][slot].load()):0;}
const char* name(uint8_t slot) {return slot<SLOTS?names[slot]:"?";}
bool set(uint8_t mode,uint8_t slot,uint32_t value) {
  if(mode>=MODES||slot>=SLOTS||value>0xFFFFFFUL)return false;
  colors[mode][slot].store(RGB(value),std::memory_order_release);
  modified.store(true,std::memory_order_release);
  return true;
}
void reset() {
  for(uint8_t m=0;m<MODES;++m)for(uint8_t k=0;k<SLOTS;++k)colors[m][k].store(defaults[k]);
  modified.store(true,std::memory_order_release);
}
void begin() {
  NativeBlob blob{};
  Preferences prefs;
  bool ok=false;
  if(prefs.begin("evo4native",true)) {
    ok=prefs.getBytesLength("v1")==sizeof(blob) &&
       prefs.getBytes("v1",&blob,sizeof(blob))==sizeof(blob) && blob.version==nativeVersion;
    prefs.end();
  }
  for(uint8_t m=0;m<MODES;++m)for(uint8_t k=0;k<SLOTS;++k)
    colors[m][k].store(ok?blob.values[m][k]:defaults[k],std::memory_order_relaxed);
}
void save() {
  if(!modified.exchange(false,std::memory_order_acq_rel))return;
  NativeBlob blob{};blob.version=nativeVersion;
  for(uint8_t m=0;m<MODES;++m)for(uint8_t k=0;k<SLOTS;++k)blob.values[m][k]=colors[m][k].load();
  Preferences prefs;
  bool ok=false;
  if(prefs.begin("evo4native",false)) {ok=prefs.putBytes("v1",&blob,sizeof(blob))==sizeof(blob);prefs.end();}
  if(!ok)modified.store(true,std::memory_order_release);
}
}
namespace Theme {
static const Entry entries[] = {
  {"Common", "FRAME_OUTER", &Common::FRAME_OUTER, 0x00FFFF},
  {"Common", "FRAME_INNER", &Common::FRAME_INNER, 0x0071BD},
  {"Common", "TOP_ACCENT", &Common::TOP_ACCENT, 0xFFFF00},
  {"Common", "BOTTOM_ACCENT", &Common::BOTTOM_ACCENT, 0x00FF00},
  {"Cassette", "BG", &Cassette::BG, 0x060609},
  {"Cassette", "SHELL", &Cassette::SHELL, 0xAC2428},
  {"Cassette", "SHELL_EDGE", &Cassette::SHELL_EDGE, 0xEA6961},
  {"Cassette", "BODY", &Cassette::BODY, 0x202124},
  {"Cassette", "WINDOW_TRIM", &Cassette::WINDOW_TRIM, 0x781E25},
  {"Cassette", "WHITE", &Cassette::WHITE, 0xFCF7ED},
  {"Cassette", "LABEL_RULE", &Cassette::LABEL_RULE, 0xA93434},
  {"Cassette", "WINDOW_BG", &Cassette::WINDOW_BG, 0x11191C},
  {"Cassette", "WINDOW_BORDER", &Cassette::WINDOW_BORDER, 0xABB1B3},
  {"Cassette", "TAPE_DARK", &Cassette::TAPE_DARK, 0x513429},
  {"Cassette", "TAPE_BROWN", &Cassette::TAPE_BROWN, 0x855339},
  {"Cassette", "HUB_SHADOW", &Cassette::HUB_SHADOW, 0x31353B},
  {"Cassette", "CENTER_BORDER", &Cassette::CENTER_BORDER, 0x8F9293},
  {"Cassette", "TAPE_HIGHLIGHT", &Cassette::TAPE_HIGHLIGHT, 0xCFB17B},
  {"Cassette", "STRIP", &Cassette::STRIP, 0xC91B24},
  {"Cassette", "PLAY_CYAN", &Cassette::PLAY_CYAN, 0x00DCD7},
  {"Cassette", "RED", &Cassette::RED, 0xF13738},
  {"Cassette", "YELLOW", &Cassette::YELLOW, 0xF8D450},
  {"Cassette", "GREEN", &Cassette::GREEN, 0x34CF65},
  {"Cassette", "HUB_METAL", &Cassette::HUB_METAL, 0xCACED0},
  {"Cassette", "HUB_HIGHLIGHT", &Cassette::HUB_HIGHLIGHT, 0xF4F2E9},
  {"Cassette", "HUB_TOOTH", &Cassette::HUB_TOOTH, 0x54595B},
  {"Cassette", "METER_OFF", &Cassette::METER_OFF, 0x343638},
  {"Reel", "BACKDROP", &Reel::BACKDROP, 0x1B1E20},
  {"Reel", "WOOD", &Reel::WOOD, 0x513022},
  {"Reel", "PANEL_FACE", &Reel::PANEL_FACE, 0xC8CFD0},
  {"Reel", "SILVER_TRIM", &Reel::SILVER_TRIM, 0xF3F3EF},
  {"Reel", "PANEL_STRIP", &Reel::PANEL_STRIP, 0xB5A485},
  {"Reel", "PANEL_DARK", &Reel::PANEL_DARK, 0x25292D},
  {"Reel", "ALUMINUM", &Reel::ALUMINUM, 0xD6DAD9},
  {"Reel", "ALUMINUM_EDGE", &Reel::ALUMINUM_EDGE, 0xA5AEAF},
  {"Reel", "ALUMINUM_LIGHT", &Reel::ALUMINUM_LIGHT, 0xF2F2EA},
  {"Reel", "ALUMINUM_MID", &Reel::ALUMINUM_MID, 0xDEE2DF},
  {"Reel", "METAL_GROOVE", &Reel::METAL_GROOVE, 0xA5A9A8},
  {"Reel", "TAPE", &Reel::TAPE, 0x302A25},
  {"Reel", "WHITE", &Reel::WHITE, 0xF8F5EA},
  {"Reel", "BUTTON", &Reel::BUTTON, 0x777C7E},
  {"Reel", "AMBER", &Reel::AMBER, 0xFFD069},
  {"Reel", "GREEN", &Reel::GREEN, 0x42D267},
  {"Reel", "RED", &Reel::RED, 0xDC3033},
  {"Reel", "COUNTER_BG", &Reel::COUNTER_BG, 0x0D1215},
  {"Reel", "VU_FACE", &Reel::VU_FACE, 0xF4E9CA},
  {"Reel", "VU_EDGE", &Reel::VU_EDGE, 0xA08E70},
  {"Reel", "VU_INK", &Reel::VU_INK, 0x34302B},
  {"Reel", "VU_PIN", &Reel::VU_PIN, 0xC79B57},
  {"Turntable", "BG", &Turntable::BG, 0x190F0D},
  {"Turntable", "WOOD", &Turntable::WOOD, 0x713D25},
  {"Turntable", "WOOD_BORDER", &Turntable::WOOD_BORDER, 0xBD8756},
  {"Turntable", "WOOD_GROOVE", &Turntable::WOOD_GROOVE, 0x4C2919},
  {"Turntable", "WOOD_GROOVE2", &Turntable::WOOD_GROOVE2, 0x8B5937},
  {"Turntable", "WOOD_STRIPE", &Turntable::WOOD_STRIPE, 0xA06B44},
  {"Turntable", "PLATTER_RIM", &Turntable::PLATTER_RIM, 0xBABDBA},
  {"Turntable", "PLATTER_SHADE", &Turntable::PLATTER_SHADE, 0x565B5A},
  {"Turntable", "VINYL", &Turntable::VINYL, 0x101315},
  {"Turntable", "GROOVE", &Turntable::GROOVE, 0x2F3337},
  {"Turntable", "GROOVE_DARK", &Turntable::GROOVE_DARK, 0x1A1D20},
  {"Turntable", "LABEL_GOLD", &Turntable::LABEL_GOLD, 0xD2AF65},
  {"Turntable", "WHITE", &Turntable::WHITE, 0xF7F1E4},
  {"Turntable", "GOLD_HIGHLIGHT", &Turntable::GOLD_HIGHLIGHT, 0xFFD782},
  {"Turntable", "VINYL_REFLEX", &Turntable::VINYL_REFLEX, 0x494D4D},
  {"Turntable", "HORN_BRASS", &Turntable::HORN_BRASS, 0xCDA352},
  {"Turntable", "HORN_LIGHT", &Turntable::HORN_LIGHT, 0xF6D58C},
  {"Turntable", "HORN_INSIDE", &Turntable::HORN_INSIDE, 0x805B2F},
  {"Turntable", "HORN_RIB", &Turntable::HORN_RIB, 0xA0743B},
  {"Turntable", "ARM_GOLD", &Turntable::ARM_GOLD, 0xECCB88},
  {"Turntable", "ARM_SHADOW", &Turntable::ARM_SHADOW, 0x967D56},
  {"Turntable", "ARM_BASE", &Turntable::ARM_BASE, 0x686C6C},
  {"Turntable", "ARM_METAL", &Turntable::ARM_METAL, 0xE7E6DD},
  {"Turntable", "GREEN", &Turntable::GREEN, 0x46D266},
  {"Turntable", "RED", &Turntable::RED, 0xE24A3A},
  {"Nixie", "BG", &Nixie::BG, 0x080608},
  {"Nixie", "GLASS", &Nixie::GLASS, 0x181517},
  {"Nixie", "FRAME", &Nixie::FRAME, 0x725035},
  {"Nixie", "TUBE_GLOW", &Nixie::TUBE_GLOW, 0x7A290C},
  {"Nixie", "TUBE_ON", &Nixie::TUBE_ON, 0xFFB343},
  {"Nixie", "TUBE_DIM", &Nixie::TUBE_DIM, 0x28170E},
  {"Nixie", "GLASS_REFLEX", &Nixie::GLASS_REFLEX, 0xB49C82},
  {"Nixie", "GLASS_INNER", &Nixie::GLASS_INNER, 0x251209},
  {"Nixie", "DOT_DIM", &Nixie::DOT_DIM, 0x2B1308},
  {"Nixie", "DOT_GLOW", &Nixie::DOT_GLOW, 0x843009},
  {"Nixie", "DOT_ON", &Nixie::DOT_ON, 0xFFCC65},
  {"Nixie", "TEXT_DIM", &Nixie::TEXT_DIM, 0xA68B69},
  {"Nixie", "DATE", &Nixie::DATE, 0xFFCA67},
  {"Nixie", "TEXT", &Nixie::TEXT, 0xEFDDC1},
  {"Nixie", "NOW_PLAYING", &Nixie::NOW_PLAYING, 0xF0AF57},
  {"Nixie", "PANEL_BORDER", &Nixie::PANEL_BORDER, 0x6C4E34},
  {"Nixie", "PANEL_INNER", &Nixie::PANEL_INNER, 0x2F2018},
  {"Nixie", "FILM_LINE", &Nixie::FILM_LINE, 0x584D42},
  {"Nixie", "FILM_LINE_LITE", &Nixie::FILM_LINE_LITE, 0xB6A795},
};
static constexpr uint32_t version=0x45563460UL; // EVO4 HQ60 palette
static constexpr size_t n=sizeof(entries)/sizeof(entries[0]);
static std::atomic<bool> changed{false};
static std::atomic<uint32_t> changedAt{0}, revision{0};
static constexpr uint32_t FNV_OFFSET=2166136261u, FNV_PRIME=16777619u;
struct Blob { uint32_t version; uint16_t count; uint16_t colors[n]; uint32_t hash; };
static uint32_t checksum(const Blob& b) {
  const uint8_t *p=reinterpret_cast<const uint8_t*>(&b);
  const size_t length=sizeof(Blob)-sizeof(uint32_t);
  uint32_t hash=FNV_OFFSET;
  for(size_t i=0;i<length;++i) {hash^=p[i];hash*=FNV_PRIME;}
  return hash;
}
size_t count(){return n+Native::MODES*Native::SLOTS;}
const Entry* entry(size_t id) {return id<n?&entries[id]:nullptr;}
static uint32_t toRGB888(uint16_t c) {
  const uint32_t r=(c>>11)&31, g=(c>>5)&63, b=c&31;
  return (((r*255+15)/31)<<16) | (((g*255+31)/63)<<8) | ((b*255+15)/31);
}
bool set(size_t id,uint32_t rgb) {
  if(id>=n) {
    const size_t offset=id-n;
    if(!Native::set(offset/Native::SLOTS,offset%Native::SLOTS,rgb))return false;
    revision.fetch_add(1,std::memory_order_relaxed);
    changedAt.store(millis(),std::memory_order_release);
    changed.store(true,std::memory_order_release);
    return true;
  }
  if(rgb>0xffffffUL) return false;
  const uint16_t color=RGB(rgb);
  if(entries[id].value->exchange(color,std::memory_order_acq_rel)!=color) {
    revision.fetch_add(1,std::memory_order_relaxed);
    changedAt.store(millis(),std::memory_order_release);
    changed.store(true,std::memory_order_release);
  }
  return true;
}
void reset(){
  Pixels::reset();
  Native::reset();
  for(size_t i=0;i<n;++i)entries[i].value->store(RGB(entries[i].rgbDefault),std::memory_order_release);
  revision.fetch_add(1,std::memory_order_relaxed);
  changedAt.store(millis(),std::memory_order_release);
  changed.store(true,std::memory_order_release);
}
void begin(){
  Pixels::begin();
  Native::begin();
  Preferences prefs;
  if(!prefs.begin("evo4colors",true))return;
  Blob b={};
  const bool ok=prefs.getBytesLength("palette")==sizeof(b) &&
      prefs.getBytes("palette",&b,sizeof(b))==sizeof(b) &&
      b.version==version && b.count==n && checksum(b)==b.hash;
  prefs.end();
  if(!ok)return;
  for(size_t i=0;i<n;++i)entries[i].value->store(b.colors[i],std::memory_order_relaxed);
  Serial.printf("[COLOR] NVS palette loaded: %u colors\n",(unsigned)n);
}
void service(){
  Pixels::service();
  if(!changed.load(std::memory_order_acquire) ||
       uint32_t(millis()-changedAt.load(std::memory_order_acquire))<1500) return;
  if(!changed.exchange(false,std::memory_order_acq_rel))return;
  Blob b={};b.version=version;b.count=n;
  for(size_t i=0;i<n;++i)b.colors[i]=entries[i].value->load(std::memory_order_acquire);
  b.hash=checksum(b);
  Preferences prefs;
  bool ok=false;
  if(prefs.begin("evo4colors",false)) {
    ok=prefs.putBytes("palette",&b,sizeof(b))==sizeof(b);
    prefs.end();
  }
  if(!ok){
    changedAt.store(millis(),std::memory_order_release);
    changed.store(true,std::memory_order_release);
    Serial.println("[COLOR] NVS save failed; will retry");
  }
  Native::save();
}
uint32_t generation(){return revision.load(std::memory_order_relaxed);}
bool dirty(){return changed.load(std::memory_order_relaxed);}
String json(){
  String out;
  out.reserve((n+Native::MODES*Native::SLOTS)*86+64);
  out="{\"version\":1,\"generation\":"+String(generation())+",\"colors\":[";
  for(size_t i=0;i<n;++i){
    if(i)out+=',';
    out+="{\"id\":"+String(i)+",\"group\":\""+entries[i].group+"\",\"key\":\""+entries[i].key+"\",\"hex\":\"";
    char buf[8];snprintf(buf,sizeof(buf),"#%06lX",(unsigned long)toRGB888(entries[i].value->load(std::memory_order_acquire)));
    out+=buf;out+="\"}";
  }
  for(uint8_t mode=0;mode<Native::MODES;++mode)for(uint8_t slot=0;slot<Native::SLOTS;++slot) {
    out+=',';
    out+="{\"id\":"+String(n+mode*Native::SLOTS+slot)+",\"group\":\"Panel "+String(mode)+"\",\"key\":\""+Native::name(slot)+"\",\"hex\":\"";
    char buf[8];snprintf(buf,sizeof(buf),"#%06lX",(unsigned long)Native::rgb(mode,slot));
    out+=buf;out+="\"}";
  }
  out+="]}";
  return out;
}
static const char kHtml[] PROGMEM = R"EVO4HTML(<!doctype html><html lang="pl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EVO4 · kolory</title><style>
*{box-sizing:border-box}body{margin:0;background:#10151a;color:#f4eee3;font:15px system-ui,Arial}header{background:#1b232b;padding:15px;border-bottom:1px solid #526474}h1{font-size:22px;margin:0 0 5px}small{color:#b9cad7}button,a,select{background:#28516a;color:white;border:0;padding:9px 13px;border-radius:7px;text-decoration:none;cursor:pointer}#status{color:#eed38a;margin-left:12px}main{max-width:1250px;margin:18px auto;padding:0 15px;display:grid;grid-template-columns:minmax(280px,540px) minmax(280px,1fr);gap:16px}section{background:#202c36;padding:16px;border-radius:12px}#frame{width:100%;max-width:480px;aspect-ratio:3/2;object-fit:contain;background:#090d10;image-rendering:pixelated;border:2px solid #4c606f;border-radius:6px;cursor:crosshair}#fields{display:grid;grid-template-columns:repeat(auto-fit,minmax(185px,1fr));gap:9px}.field{display:flex;justify-content:space-between;align-items:center;padding:7px 10px;background:#2b3944;border-radius:8px;gap:8px}.field:hover{outline:2px solid #ecd078}input[type=color]{width:64px;height:38px;border:0;background:transparent;cursor:pointer}#note{color:#b9cad7}@media(max-width:820px){main{grid-template-columns:1fr}}</style></head><body>
<header><h1>EVO4 MULTI · kolory paneli</h1><small>Podgląd używa tych samych pikseli RGB565 co fizyczny TFT; przeglądarka dostaje je bez dodatkowego kolorowania. Wybierz tryb i naciśnij „Pokaż na radiu”. Zmiana koloru pojawi się na TFT oraz w podglądzie.</small><p><a href="/menu">Menu</a> <button onclick="applyNow()">Zastosuj teraz</button> <button onclick="resetAll()">Przywróć wszystkie kolory</button><span id="status">Ładowanie...</span></p></header><main><section><label>Panel: <select id="panel"></select></label> <button id="show" onclick="showPanel()">Pokaż na radiu</button><p><img id="frame" alt="Rzeczywisty obraz TFT" src="/api/colors/frame.bmp"></p><p>Kliknij konkretny kolor na obrazie TFT, wybierz zamiennik: <input id="pickedColor" type="color" value="#ff0000"> <button onclick="applyPixel()">Zastosuj teraz</button></p><p id="sample">Kliknij obraz, aby wskazać kolor.</p><div id="pixelList"></div><p id="note">Podgląd pokazuje aktualny ekran radia. Jeśli chcesz zobaczyć inny panel, wybierz go i użyj przycisku powyżej. Wbudowane tryby nieaktywne mogą przejść do trybu zastępczego.</p></section><section><h2 id="title">Kolory</h2><div id="fields"></div><p>Regulowane są barwy używane przez dany panel. Stałe kolory w starszych fragmentach kodu mogą pozostać bez zmian. Logo i okładki zachowują własne kolory.</p></section></main><script>
const $=id=>document.getElementById(id);let groups={},selected='',shownMode=0,picked='';const labels={Common:'Ramki wspólne',Cassette:'Kaseta (16)',Reel:'Szpulak (18)',Turntable:'Gramofon (17)',Nixie:'Zegar Nixie (20)'};
async function api(url,opts){const r=await fetch(url,opts);if(!r.ok)throw Error('HTTP '+r.status);return r.json()}
function refresh(){const img=$('frame');img.src='/api/colors/frame.bmp?t='+Date.now()}
function select(){selected=$('panel').value;$('title').textContent=labels[selected]||'Tryb '+selected.replace('Panel ','');$('fields').innerHTML='';for(const c of groups[selected]||[]){const lab=document.createElement('label');lab.className='field';lab.textContent=c.key;const inp=document.createElement('input');inp.type='color';inp.value=c.hex;inp.onchange=async()=>{try{await api('/api/colors/set?id='+c.id+'&hex='+encodeURIComponent(inp.value),{method:'POST'});c.hex=inp.value;$('status').textContent='Wybrano kolor; kliknij Zastosuj teraz';}catch(e){$('status').textContent=e.message}};lab.appendChild(inp);$('fields').appendChild(lab)}}
async function showPanel(){let m=({Cassette:16,Reel:18,Turntable:17,Nixie:20}[selected]);if(m===undefined&&selected.startsWith('Panel '))m=parseInt(selected.slice(6),10);if(m===undefined){$('status').textContent='Wybierz konkretny panel';return}try{const result=await api('/api/colors/show?mode='+m,{method:'POST'});shownMode=result.mode;$('status').textContent='Na radiu: panel '+result.mode;setTimeout(refresh,450);loadPixelList()}catch(e){$('status').textContent=e.message}}
async function load(){try{const data=await api('/api/colors');groups={};for(const c of data.colors)(groups[c.group]??=[]).push(c);const old=selected;$('panel').innerHTML='';for(const key of Object.keys(groups)){let o=document.createElement('option');o.value=key;o.textContent=labels[key]||key;$('panel').appendChild(o)}$('panel').value=groups[old]?old:'Panel 0';select();$('status').textContent=data.colors.length+' kolorów';refresh();loadPixelList()}catch(e){$('status').textContent=e.message}}
async function loadPixelList(){try{const data=await api('/api/colors/pixels?mode='+shownMode);$('pixelList').textContent='Zamiany kolorów tego panelu: '+data.changes.length}catch(e){$('pixelList').textContent=e.message}}
$('frame').onclick=(ev)=>{const img=$('frame');if(!img.naturalWidth){$('sample').textContent='Brak obrazu TFT';return}const canvas=document.createElement('canvas');canvas.width=img.naturalWidth;canvas.height=img.naturalHeight;const ctx=canvas.getContext('2d');ctx.drawImage(img,0,0);const rc=img.getBoundingClientRect();const x=Math.max(0,Math.min(canvas.width-1,Math.floor((ev.clientX-rc.left)*canvas.width/rc.width)));const y=Math.max(0,Math.min(canvas.height-1,Math.floor((ev.clientY-rc.top)*canvas.height/rc.height)));const rgba=ctx.getImageData(x,y,1,1).data;picked='#'+[rgba[0],rgba[1],rgba[2]].map(v=>v.toString(16).padStart(2,'0')).join('').toUpperCase();$('pickedColor').value=picked;$('sample').textContent='Kolor z ekranu: '+picked+' (tryb '+shownMode+'). Wybierz nowy odcień i kliknij Zastosuj teraz.'};
async function applyPixel(){if(!picked){$('status').textContent='Najpierw kliknij kolor na obrazie';return}try{await api('/api/colors/pixel?mode='+shownMode+'&from='+encodeURIComponent(picked)+'&to='+encodeURIComponent($('pickedColor').value),{method:'POST'});$('status').textContent='Nowy kolor na TFT; zapis w tle';setTimeout(refresh,200);loadPixelList()}catch(e){$('status').textContent=e.message}}
async function applyNow(){try{await api('/api/colors/apply',{method:'POST'});$('status').textContent='Kolory wysłane na TFT';setTimeout(refresh,200)}catch(e){$('status').textContent=e.message}}
$('panel').onchange=select;async function resetAll(){if(!confirm('Przywrócić kolory wszystkich paneli?'))return;try{await api('/api/colors/reset',{method:'POST'});await load();await applyNow()}catch(e){$('status').textContent=e.message}}setInterval(()=>{if(!document.hidden)refresh()},2500);load();
</script></body></html>)EVO4HTML";
const char* html(){return kHtml;}
} // Theme
} // Evo4Retro
