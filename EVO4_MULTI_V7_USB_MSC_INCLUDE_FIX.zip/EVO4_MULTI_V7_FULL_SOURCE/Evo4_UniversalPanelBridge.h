#pragma once
/*
  ============================================================================
  EVO4 MULTI - Universal Panel Bridge
  Wersja: 2026-05-22-GITHUB-PANELS

  Cel:
    Jedna logika funkcji radia, różne panele i różna grafika.

    OLED SSD1322 / SH1122:
      - pracuje na starych panelach EVO3 256x64
      - nie wymuszamy kolorowego TFT UI

    TFT ILI9341 / ILI9488:
      - pracuje na nowych panelach EVO4 Multi
      - te same role/funkcje co OLED, ale rysowane inną grafiką

  Ten plik nie zastępuje całego programu. Jest warstwą mapowania funkcji:
    displayMode -> rola panelu -> odpowiedni renderer dla OLED/TFT

  Dzięki temu SD Player, SD Recorder, EQ16, zewnętrzne widmo/VU, banki,
  pilot i web mogą mieć tę samą obsługę, a ekran może być inny.
  ============================================================================
*/

#include <Arduino.h>

#ifndef EVO4_UNIVERSAL_PANELS_REV
#define EVO4_UNIVERSAL_PANELS_REV "2026-05-22-GITHUB-PANELS"
#endif

#ifndef EVO4_ENABLE_UNIVERSAL_PANEL_BRIDGE
#define EVO4_ENABLE_UNIVERSAL_PANEL_BRIDGE 1
#endif

#ifndef EVO4_ENABLE_GITHUB_PANEL_ROLES
#define EVO4_ENABLE_GITHUB_PANEL_ROLES 1
#endif

// Role są ważniejsze niż numer trybu. Numer displayMode może się zmieniać,
// ale funkcja panelu zostaje ta sama na OLED i TFT.
enum Evo4PanelRole : uint8_t {
  EVO4_ROLE_RADIO_MAIN = 0,
  EVO4_ROLE_CLOCK,
  EVO4_ROLE_RADIO_INFO,
  EVO4_ROLE_CENTER_INFO,
  EVO4_ROLE_SD_PLAYER,
  EVO4_ROLE_SD_RECORDER,
  EVO4_ROLE_DLNA,
  EVO4_ROLE_SPOTIFY,
  EVO4_ROLE_EVO5_ART,
  EVO4_ROLE_BLUETOOTH,
  EVO4_ROLE_EQ16,
  EVO4_ROLE_SYSTEM,
  EVO4_ROLE_FILES,
  EVO4_ROLE_MOVIE_CLOCK,
  EVO4_ROLE_CASSETTE,
  EVO4_ROLE_TURNTABLE,
  EVO4_ROLE_REEL_TAPE,
  EVO4_ROLE_EXT_ANALYZER,
  EVO4_ROLE_EQ_ANALYZER,
  EVO4_ROLE_FUTURE_HIDDEN,
};

static inline Evo4PanelRole evo4PanelRoleFromMode(uint8_t mode) {
  switch (mode) {
    case 0:  return EVO4_ROLE_RADIO_MAIN;
    case 1:  return EVO4_ROLE_CLOCK;
    case 2:  return EVO4_ROLE_RADIO_INFO;
    case 3:  return EVO4_ROLE_CENTER_INFO;
    case 4:  return EVO4_ROLE_EQ_ANALYZER; // TFT VU removed -> DSP C6
    case 7:  return EVO4_ROLE_SD_PLAYER;
    case 9:  return EVO4_ROLE_SD_RECORDER;
    case 11: return EVO4_ROLE_DLNA;
    case 12: return EVO4_ROLE_BLUETOOTH;
    case 31: return EVO4_ROLE_SPOTIFY;
    case 32: return EVO4_ROLE_EVO5_ART;
    case 13:
#if defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)
      return EVO4_ROLE_EQ_ANALYZER; // TFT: old EQ removed -> DSP C6
#else
      return EVO4_ROLE_EQ16;        // OLED legacy: simple EQ screen
#endif
    case 15: return EVO4_ROLE_SYSTEM;
    case 16: return EVO4_ROLE_CASSETTE;     // animowana kaseta magnetofonowa
    case 17: return EVO4_ROLE_TURNTABLE;    // animowany gramofon / winyl
    case 18: return EVO4_ROLE_REEL_TAPE;   // animowany magnetofon szpulowy
    case 19: return EVO4_ROLE_FILES;
    case 20: return EVO4_ROLE_MOVIE_CLOCK;
    case 21: return EVO4_ROLE_EXT_ANALYZER;
    case 22: return EVO4_ROLE_EXT_ANALYZER;
    case 23: return EVO4_ROLE_EQ_ANALYZER;
    default: return EVO4_ROLE_RADIO_MAIN;
  }
}

static inline const char* evo4PanelRoleName(Evo4PanelRole role) {
  switch (role) {
    case EVO4_ROLE_RADIO_MAIN:   return "RADIO_MAIN";
    case EVO4_ROLE_CLOCK:        return "CLOCK";
    case EVO4_ROLE_RADIO_INFO:   return "RADIO_INFO";
    case EVO4_ROLE_CENTER_INFO:  return "CENTER_INFO";
    case EVO4_ROLE_SD_PLAYER:    return "SD_PLAYER";
    case EVO4_ROLE_SD_RECORDER:  return "SD_RECORDER";
    case EVO4_ROLE_DLNA:         return "DLNA";
    case EVO4_ROLE_SPOTIFY:      return "SPOTIFY";
    case EVO4_ROLE_EVO5_ART:     return "EVO5_ART";
    case EVO4_ROLE_BLUETOOTH:    return "BLUETOOTH";
    case EVO4_ROLE_EQ16:         return "DSP_C6_EQ16";
    case EVO4_ROLE_SYSTEM:       return "SYSTEM";
    case EVO4_ROLE_FILES:        return "FILES";
    case EVO4_ROLE_MOVIE_CLOCK:  return "MOVIE_CLOCK";
    case EVO4_ROLE_CASSETTE:     return "CASSETTE";
    case EVO4_ROLE_TURNTABLE:    return "TURNTABLE";
    case EVO4_ROLE_REEL_TAPE:    return "REEL_TAPE";
    case EVO4_ROLE_EXT_ANALYZER: return "EXTERNAL_ANALYZER";
    case EVO4_ROLE_EQ_ANALYZER:  return "EVO4_EQ_ANALYZER";
    default:                     return "FUTURE";
  }
}

static inline const char* evo4PanelRoleNameFromMode(uint8_t mode) {
  return evo4PanelRoleName(evo4PanelRoleFromMode(mode));
}

#if defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)
// Renderery TFT istnieją w głównym pliku .ino. Tu mamy tylko prototypy.
void tftDrawRadioMain();
void tftDrawClockScreen();
void tftDrawInfoScreen();
void tftDrawMode3SpreadScreen();
void v39PanelSDPlayer();
void v39PanelSDRecorder();
void v39PanelDLNA();
void v39PanelSpotify();
void v39PanelEvo5Art();
void v39PanelBluetooth();
void v47PanelEvo4MultiEqAnalyzer();
void v39PanelSystemMonitor();
void v44PanelFileBrowser();
void tftDrawMovieClockScreen();
void v50PanelCassette();
void v50PanelTurntable();
void v50PanelReelTape();
void v39PanelExternalAnalyzer();

static inline bool evo4RenderTftByRole(Evo4PanelRole role) {
#if EVO4_ENABLE_UNIVERSAL_PANEL_BRIDGE
  switch (role) {
    case EVO4_ROLE_RADIO_MAIN:   tftDrawRadioMain(); return true;
    case EVO4_ROLE_CLOCK:        tftDrawClockScreen(); return true;
    case EVO4_ROLE_RADIO_INFO:   tftDrawInfoScreen(); return true;
    case EVO4_ROLE_CENTER_INFO:  tftDrawMode3SpreadScreen(); return true;
    case EVO4_ROLE_SD_PLAYER:    v39PanelSDPlayer(); return true;
    case EVO4_ROLE_SD_RECORDER:  v39PanelSDRecorder(); return true;
    case EVO4_ROLE_DLNA:         v39PanelDLNA(); return true;
    case EVO4_ROLE_SPOTIFY:      v39PanelSpotify(); return true;
    case EVO4_ROLE_EVO5_ART:     v39PanelEvo5Art(); return true;
    case EVO4_ROLE_BLUETOOTH:    v39PanelBluetooth(); return true;
    case EVO4_ROLE_EQ16:         v47PanelEvo4MultiEqAnalyzer(); return true;
    case EVO4_ROLE_SYSTEM:       v39PanelSystemMonitor(); return true;
    case EVO4_ROLE_FILES:        v44PanelFileBrowser(); return true;
    case EVO4_ROLE_MOVIE_CLOCK:  tftDrawMovieClockScreen(); return true;
    case EVO4_ROLE_CASSETTE:     v50PanelCassette(); return true;
    case EVO4_ROLE_TURNTABLE:    v50PanelTurntable(); return true;
    case EVO4_ROLE_REEL_TAPE:    v50PanelReelTape(); return true;
    case EVO4_ROLE_EXT_ANALYZER: v39PanelExternalAnalyzer(); return true;
    case EVO4_ROLE_EQ_ANALYZER:  v47PanelEvo4MultiEqAnalyzer(); return true;
    default:                     tftDrawRadioMain(); return true;
  }
#else
  (void)role;
  return false;
#endif
}

static inline bool evo4RenderTftByMode(uint8_t mode) {
  return evo4RenderTftByRole(evo4PanelRoleFromMode(mode));
}
#else
static inline bool evo4RenderTftByMode(uint8_t) { return false; }
#endif

// OLED zostaje rysowany przez stare bloki displayRadio() / vuMeterModeX().
// Funkcja jest zostawiona jako punkt zaczepienia na kolejny etap, kiedy
// będziemy przenosić nowe role SD/EQ/REC jako klasyczne ekrany 256x64.
static inline bool evo4OledUsesLegacyPanels() {
#if defined(EVO_PANEL_SSD1322) || defined(EVO_PANEL_SH1122)
  return true;
#else
  return false;
#endif
}

static inline bool evo4TftUsesNativePanels() {
#if defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)
  return true;
#else
  return false;
#endif
}
