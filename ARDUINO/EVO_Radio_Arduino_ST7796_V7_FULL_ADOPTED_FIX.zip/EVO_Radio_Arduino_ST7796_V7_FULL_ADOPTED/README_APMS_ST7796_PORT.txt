APMS ST7796 PORT

Baza: EVO_Radio_Arduino_ILI9488_V7_INFO_WEATHER_DANE_DEGREE_FIX

Co zmieniono:
1. Dodany panel EVO_PANEL_ST7796 jako osobny typ ekranu LovyanGFX.
2. Domyślnie aktywny jest ST7796:
   #define EVO_PANEL_ST7796
3. Klasa LovyanGFX używa:
   lgfx::Panel_ST7796
4. Rozdzielczość fizyczna ustawiona jak typowy ST7796:
   320 x 480, rotation = 1, czyli obraz roboczy 480 x 320.
5. Wszystkie warunki TFT, które wcześniej działały dla ILI9341/ILI9488, zostały rozszerzone o ST7796.
6. PlatformIO build_flags zmienione na:
   -DEVO_PANEL_ST7796

Ustawienia pinów są te same co wcześniej:
SCK  = SPI_SCK_OLED
MOSI = SPI_MOSI_OLED
DC   = DC_OLED
CS   = CS_OLED
RST  = RESET_OLED
BL   = EVO_TFT_BL, domyślnie -1

Jeśli kolory będą zamienione czerwony/niebieski, zmień:
#define EVO_TFT_RGB_ORDER false
na:
#define EVO_TFT_RGB_ORDER true

Jeśli obraz będzie negatywowy, zmień:
#define EVO_TFT_INVERT false
na:
#define EVO_TFT_INVERT true

Jeśli ekran będzie niestabilny, obniż SPI:
#define EVO_TFT_SPI_FREQ 27000000
na 20000000 albo 16000000.
