#pragma once
#define APMS_LOCAL_ASYNC_WEBSERVER_ADAPTER 1

// ============================================================================
// ESPAsyncWebServer.h - lokalny adapter zgodności dla projektu EVO3 V41
// ----------------------------------------------------------------------------
// Projekt V7/V40 ma składnię AsyncWebServer, ale żeby uniknąć konfliktów
// bibliotek ESPAsyncWebServer/AsyncTCP przy Arduino-ESP32 3.x, ta wersja używa
// zwykłego WebServer. To NIE jest pełny zamiennik websocketów async, tylko
// warstwa pozwalająca kompilować i obsługiwać podstawowe trasy HTTP/OTA/pliki.
// ============================================================================

#include <Arduino.h>
#include <WebServer.h>
#include <FS.h>
#include <functional>
#include <vector>


class DefaultHeaders {
public:
  static DefaultHeaders& Instance() {
    static DefaultHeaders instance;
    return instance;
  }

  void addHeader(const String&, const String&) {
    // W adapterze WebServer nagłówki globalne są pomijane.
    // Trasy mogą dalej kompilować się ze składnią AsyncWebServer.
  }
};

class AsyncWebParameter {
  String _name;
  String _value;
public:
  AsyncWebParameter() {}
  AsyncWebParameter(const String& n, const String& v) : _name(n), _value(v) {}
  const String& name() const { return _name; }
  const String& value() const { return _value; }
};

class AsyncWebServerResponse {
public:
  int code = 200;
  String type = "text/plain";
  String body;
  AsyncWebServerResponse() {}
  AsyncWebServerResponse(int c, const String& t, const String& b) : code(c), type(t), body(b) {}
  void addHeader(const String&, const String&) {}
};

class AsyncWebServerResponseStream : public AsyncWebServerResponse, public Print {
public:
  explicit AsyncWebServerResponseStream(const String& contentType) {
    code = 200;
    type = contentType;
  }

  size_t write(uint8_t c) override {
    body += (char)c;
    return 1;
  }

  size_t write(const uint8_t *buffer, size_t size) override {
    if (!buffer) return 0;
    body.reserve(body.length() + size);
    for (size_t i = 0; i < size; ++i) body += (char)buffer[i];
    return size;
  }
};

using AsyncResponseStream = AsyncWebServerResponseStream;

class AsyncWebServerRequest {
  WebServer* _server;
  AsyncWebParameter _tmp;

  static String normalizePath(const String& path) {
    if (path.length() == 0) return "/";
    if (path[0] == '/') return path;
    return "/" + path;
  }

  static String filenameFromPath(const String& path) {
    int p = path.lastIndexOf('/');
    if (p < 0) return path;
    return path.substring(p + 1);
  }

public:
  explicit AsyncWebServerRequest(WebServer* s) : _server(s) {}

  bool hasParam(const String& name, bool post = false) {
    (void)post;
    return _server && _server->hasArg(name);
  }

  AsyncWebParameter* getParam(const String& name, bool post = false) {
    (void)post;
    _tmp = AsyncWebParameter(name, _server ? _server->arg(name) : String());
    return &_tmp;
  }

  bool hasArg(const String& name) { return _server && _server->hasArg(name); }
  String arg(const String& name) { return _server ? _server->arg(name) : String(); }
  String header(const String& name) { return _server ? _server->header(name) : String(); }

  size_t contentLength() {
    if (!_server) return 0;
    String h = _server->header("Content-Length");
    if (h.length()) return (size_t)h.toInt();
    return 0;
  }

  void send(int code) {
    if (_server) _server->send(code, "text/plain", "");
  }

  void send(int code, const String& type, const String& content) {
    if (_server) _server->send(code, type, content);
  }

  void send(int code, const char* type, const String& content) {
    if (_server) _server->send(code, type, content);
  }

  void send(int code, const char* type, const char* content) {
    if (_server) _server->send(code, type, content ? content : "");
  }

  void send(AsyncWebServerResponse* response) {
    if (!_server || !response) return;
    _server->send(response->code, response->type, response->body);
    delete response;
  }

  void send(fs::FS& fs, const String& path, const String& contentType, bool download = false) {
    if (!_server) return;
    String p = normalizePath(path);
    File file = fs.open(p, "r");
    if (!file || file.isDirectory()) {
      if (file) file.close();
      _server->send(404, "text/plain", "File not found");
      return;
    }
    if (download) {
      _server->sendHeader("Content-Disposition", "attachment; filename=\"" + filenameFromPath(p) + "\"");
    }
    _server->streamFile(file, contentType);
    file.close();
  }

  void send(fs::FS& fs, const char* path, const char* contentType, bool download = false) {
    send(fs, String(path ? path : ""), String(contentType ? contentType : "application/octet-stream"), download);
  }

  void send(fs::FS& fs, const String& path, const char* contentType, bool download = false) {
    send(fs, path, String(contentType ? contentType : "application/octet-stream"), download);
  }

  void send_P(int code, const char* type, const char* content) {
    if (_server) _server->send_P(code, type, content);
  }

  void redirect(const String& url) {
    if (!_server) return;
    _server->sendHeader("Location", url, true);
    _server->send(302, "text/plain", "");
  }

  AsyncWebServerResponseStream* beginResponseStream(const String& contentType) {
    return new AsyncWebServerResponseStream(contentType);
  }

  template<typename F>
  void onDisconnect(F) {
    // AsyncWebServer ma callback po rozłączeniu klienta. Zwykły WebServer jest
    // synchroniczny, więc zostawiamy no-op, żeby kod OTA kompilował się bez
    // przerabiania całej logiki.
  }
};

class AsyncWebSocketClient {
public:
  void text(const String&) {}
};

enum AwsEventType {
  WS_EVT_CONNECT,
  WS_EVT_DISCONNECT,
  WS_EVT_DATA,
  WS_EVT_PONG,
  WS_EVT_ERROR
};

struct AwsFrameInfo {
  bool final = true;
  bool masked = false;
  uint8_t opcode = 0;
  uint32_t len = 0;
  uint32_t index = 0;
};

class AsyncWebSocket {
  String _url;
  std::vector<AsyncWebSocketClient> _clients;
public:
  explicit AsyncWebSocket(const char* url) : _url(url ? url : "") {}
  template<typename F> void onEvent(F) {}
  void cleanupClients() {}
  void textAll(const String&) {}
  void closeAll() {}
  std::vector<AsyncWebSocketClient>& getClients() { return _clients; }
};

class AsyncWebServer {
  WebServer _server;
public:
  explicit AsyncWebServer(uint16_t port) : _server(port) {}

  WebServer& raw() { return _server; }
  void begin() { _server.begin(); }
  void handleClient() { _server.handleClient(); }
  void addHandler(AsyncWebSocket*) {}

  template<typename Handler>
  void on(const char* uri, HTTPMethod method, Handler handler) {
    _server.on(uri, method, [this, handler]() mutable {
      AsyncWebServerRequest request(&_server);
      handler(&request);
    });
  }

  template<typename Handler, typename UploadHandler>
  void on(const char* uri, HTTPMethod method, Handler handler, UploadHandler uploadHandler) {
    _server.on(uri, method,
      [this, handler]() mutable {
        AsyncWebServerRequest request(&_server);
        handler(&request);
      },
      [this, uploadHandler]() mutable {
        HTTPUpload& up = _server.upload();
        AsyncWebServerRequest request(&_server);
        bool final = (up.status == UPLOAD_FILE_END);
        size_t index = 0;
        if (up.totalSize >= up.currentSize) index = up.totalSize - up.currentSize;
        uploadHandler(&request, up.filename, index, up.buf, up.currentSize, final);
      }
    );
  }
};
