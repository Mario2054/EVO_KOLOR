#pragma once

// Kompatybilność nazwy z paczkami EVO3 MOD OST.
// W projekcie V41 ekran obsługuje główny obiekt `gfx` w pliku .ino.
// Ten nagłówek jest celowo lekki, żeby nie dublować starej warstwy ekranu.
