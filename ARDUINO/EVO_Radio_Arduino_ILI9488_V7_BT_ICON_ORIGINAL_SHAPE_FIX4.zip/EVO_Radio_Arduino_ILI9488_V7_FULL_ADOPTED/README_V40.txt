EVO3_ILI9488_V40_REAL_V7_BASE_EVO3MOD_OST_WEBSERVER311

Baza programu: EVO_Radio_Arduino_ILI9488_V7_VU_FIXED_27MHz_RECOMMENDED.
Priorytet zostawiony dla rozwiązań V7: LovyanGFX, 27MHz SPI, delta-render, audio.loop() i panele VU 0-6.

Biblioteki docelowe:
- LovyanGFX 1.2.21
- ESP32-audioI2S-master 3.4.5
- WebServer 3.11.0

Ważne zmiany:
1. Zostawiono składnię starego AsyncWebServer z V7, ale dodano lokalny adapter ESPAsyncWebServer.h oparty o WebServer.h.
2. Nie jest wymagany AsyncTCP. Lokalny AsyncTCP.h jest pustym adapterem.
3. Usunięto Audio::msg_t oraz Audio::audio_info_callback. Dodano globalne callbacki audio zgodne z ESP32-audioI2S 3.4.5.
4. Dodano panele 7-14 w stylu V7: SD Player, SD Recorder, DLNA, Bluetooth, EQ16, FFT, Scope, System Monitor.
5. Pełne źródła EVO3 MOD OST są dołączone jako referencja tekstowa w folderze EVO3_MOD_OST_SOURCE_REFERENCE_TXT, aby Arduino nie kompilowało ich drugi raz i nie robiło konfliktów.

Otwieraj tylko plik:
EVO3_ILI9488_V40_REAL_V7_BASE_EVO3MOD_OST_WEBSERVER311.ino

Jeśli po kompilacji pojawi się błąd z konkretną funkcją, podeślij pierwszy błąd z Arduino IDE.
