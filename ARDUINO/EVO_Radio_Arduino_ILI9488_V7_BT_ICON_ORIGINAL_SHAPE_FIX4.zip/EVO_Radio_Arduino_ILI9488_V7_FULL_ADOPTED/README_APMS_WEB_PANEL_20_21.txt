APMS poprawka WWW + panele TFT

1. Przywrocono bazowy wyglad strony Web Radio:
   - szare tlo, centralny wyswietlacz radia, suwak glosnosci, banki pamieci,
   - lista kanalow/stacji w 4 kolumnach po 25 pozycji, podobnie do oryginalnej strony ze zdjecia.

2. Sterowanie WWW nie wymaga WebSocket:
   - /api/state odczytuje stan,
   - /webcmd steruje glosnoscia, bankiem, stacja i trybem ekranu,
   - /api/ping testuje serwer.

3. Zachowano podzial stylow TFT:
   - styl 20 = przywrocony zegar filmowy/lampowy,
   - styl 21 = nowy panel informacyjny z prawdziwym RSSI/WiFi,
   - styl 18 = czarny prostokatny VU z 4 kolorami.

4. Dodano komentarz MAPA PANELI TFT przy displayRadioTFT(),
   z opisem gdzie realizowany jest kazdy panel od 0 do 21.
