APMS compile fix 2026-05-09

Poprawiono blad kompilacji:
  error: 'evoMetaAsciiQuotes' was not declared in this scope

Przyczyna:
  evoMetaClean() wywolywalo funkcje evoMetaAsciiQuotes(), ale funkcja nie byla zdefiniowana w pliku.

Naprawa:
  Dodano funkcje evoMetaAsciiQuotes(String s) przed evoMetaClean().
  Funkcja zamienia typograficzne apostrofy/cudzyslowy z metadanych streamu na zwykle znaki ASCII.

Pozostawiono poprzednie poprawki:
  - osobne pole nazwy stacji
  - osobne pole tytulu/wykonawcy
  - poprawione /api/state
  - poprawke poziomu audio
  - styl 18 prostokatny VU
