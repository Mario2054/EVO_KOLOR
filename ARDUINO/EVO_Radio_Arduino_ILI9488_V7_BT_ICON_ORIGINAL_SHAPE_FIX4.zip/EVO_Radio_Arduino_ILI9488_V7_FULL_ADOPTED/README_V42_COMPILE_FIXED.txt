EVO3 ILI9488 V42 - V7 BASE COMPILE FIXED

To jest poprawiona paczka po błędach z Arduino IDE:

1. Usunięty błąd tftVuL / tftVuR.
   Panele V39/V40 używają teraz wartości V7: displayVuL/displayVuR przez tftVuPct().

2. Dodana obsługa gfx.tftDrawCircle() oraz tftFillCircle() w klasie EvoDisplayLovyanGFX.
   Dzięki temu panel DLNA z V40 kompiluje się z warstwą ekranu V7.

3. Dodany DefaultHeaders::Instance().addHeader() do lokalnego adaptera ESPAsyncWebServer.h.
   Projekt dalej używa składni AsyncWebServer, ale kompiluje się przez lokalny adapter WebServer.

4. Struktura katalogu jest zgodna ze screenem:
   bt, core, network, SDPlayer, SDRecorder + główny plik .ino w katalogu projektu.

5. Moduły V31/V40 w osobnych plikach są domyślnie wyłączone przez EvoLegacyV31Modules.h,
   żeby nie dublować setup(), loop(), obiektów audio i ekranu z bazą V7.

W Arduino IDE otwórz plik:
EVO3_ILI9488_V42_V7_BASE_COMPILE_FIXED.ino

