APMS poprawka VU18

Baza: EVO_Radio_Arduino_ILI9488_V7_WEB_BASE_LIST_MODE20_21_PANEL_COMMENTS_FIX

Zmiana:
- Styl 18 / v44PanelSquareVuMode4(): igła prostokątnego VU została wydłużona jeszcze o około 2 mm.
- Zmieniono obliczanie długości igły z:
  int needleLen = min(h - 30, scaleWidth / 2 + 4);
  na:
  int needleLen = min(h - 26, scaleWidth / 2 + 10);
- Igła nadal jest cienka 1 px.
- Zostawiono czarne tło i kolory: zielony, żółty, niebieski, czerwony.
- Styl 20/21 oraz strona WWW nie były cofane.
