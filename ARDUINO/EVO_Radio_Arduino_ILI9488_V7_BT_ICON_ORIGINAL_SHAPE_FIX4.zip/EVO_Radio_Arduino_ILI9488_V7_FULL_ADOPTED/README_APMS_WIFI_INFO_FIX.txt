APMS WIFI / INFO PANEL FIX

Zmiany w tej paczce:

1. Styl 20 poprawiony jako panel informacyjny:
   - nazwa stacji u góry,
   - osobno wykonawca i tytuł utworu,
   - czytelny wiersz audio: kodek, bitrate, sample rate,
   - duży zegar z sekundami,
   - data,
   - dolne pola: IP, głośność, kanał/stacja, WiFi.

2. Usunięto sztuczne ikonki symulacji sygnału WiFi.
   Zamiast nich dodano prawdziwy wskaźnik WiFi liczony z WiFi.RSSI().

3. Dodano nowy wskaźnik WiFi:
   - ikona anteny,
   - fale anteny,
   - słupki sygnału,
   - kolor zależny od poziomu,
   - w stylu 20 pokazuje też realne dBm.

4. Wspólny realny poziom WiFi jest używany na TFT i w API /api/state.

5. Poprzednie poprawki zostają:
   - styl 18 z czarnym tłem,
   - kolory VU: zielony, żółty, niebieski, czerwony,
   - cienka, wydłużona igła,
   - poprawki EQ3/EQ16,
   - metadane wykonawca/tytuł,
   - zegar standby,
   - strona WWW.

Uwaga: nie każda stacja wysyła poprawne metadane utworu. Jeśli nie ma danych,
program pokazuje komunikat oczekiwania zamiast podstawiać nazwę stacji jako tytuł.
