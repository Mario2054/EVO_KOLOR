EVO3 ILI9488 V41 V7 BASE FIXED

Co zostało poprawione:
1. Główny plik .ino jest na bazie V7 z dołożonymi panelami V40/V39: tryby 0-6 rdzeń V7, tryby 7-14 nowe panele.
2. Nazwa folderu i pliku .ino są zgodne z wymaganiami Arduino IDE.
3. Struktura folderów jest zgodna z układem ze screena: bt, core, network, SDPlayer, SDRecorder oraz pliki .cpp/.h w katalogu głównym.
4. Naprawiony lokalny adapter ESPAsyncWebServer.h -> WebServer: dodane send() dla plików FS/SD/LittleFS, send(204), AsyncResponseStream, onDisconnect() i poprawione include.
5. Include ESPAsyncWebServer.h, AsyncTCP.h i ezButton.h są lokalne, więc projekt nie wpada w konflikt z zainstalowanymi bibliotekami Async.
6. Stare moduły V31/V40 są dołączone jako źródła do dalszej integracji, ale domyślnie nie są kompilowane. Steruje tym EvoLegacyV31Modules.h.

Jak kompilować w Arduino IDE:
- Otwórz EVO3_ILI9488_V41_V7_BASE_FIXED.ino z folderu o tej samej nazwie.
- Płytka: ESP32-S3 zgodna z Twoim modułem.
- PSRAM: włączone, jeżeli Twoja płytka ma PSRAM.
- Partition Scheme: aplikacja z OTA lub większa aplikacja, zależnie od Twojej konfiguracji.
- Wymagane biblioteki: WiFiManager, Audio/ESP32-audioI2S, LovyanGFX, U8g2, Time.

Uwaga:
Warstwa WebServer w tej paczce kompiluje składnię AsyncWebServer, ale websocket jest atrapą kompatybilności. HTTP, OTA i obsługa plików są zostawione w stylu V7/V40. Pełne websockety wymagają powrotu do prawdziwego ESPAsyncWebServer/AsyncTCP i usunięcia server.handleClient().
