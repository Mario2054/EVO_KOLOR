APMS poprawka VU18 + EQ16

Zmiany:
1. Styl 18 ponownie uruchamia v44PanelSquareVuMode4(), czyli prostokatny VU z V7.
2. Tlo panelu i wskaznikow VU18 jest czarne.
3. Kolory skali / igly VU18: zielony -> zolty -> niebieski -> czerwony.
4. Igla VU18 jest cienka, rysowana jedna linia 1 px i skrocona tak, zeby nie wychodzila poza obrys wskaznika.
5. Tryby VU 16/17/18 odswiezaja sie szybciej przez EVO_TFT_VU_DYNAMIC_FRAME_MS = 70.
6. Przycisk AUDIO przelacza EQ3 / EQ16:
   - AUDIO pierwszy raz: EQ3,
   - AUDIO drugi raz: EQ16,
   - AUDIO kolejny raz: znow EQ3.
7. EQ16 z pilota:
   - LEWO / PRAWO wybiera pasmo,
   - OK wlacza regulacje wybranego pasma,
   - GORA / DOL zmienia wzmocnienie,
   - OK zapisuje i wraca do wyboru pasma,
   - DIRECT resetuje EQ16,
   - BACK zapisuje i wychodzi.

Baza: EVO_Radio_Arduino_ILI9488_V7_WLASCIWY_META_AUDIO_LEVEL_COMPILE_FIX.zip
