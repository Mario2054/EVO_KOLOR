APMS WEATHER CITY FIX

Zmiany:
1. W /config dodano pole: Miejscowosc pogody.
2. Nazwa miejscowosci jest zapisywana do pliku /weather_city.txt w STORAGE.
3. Panel RADIO INFO nie pokazuje juz pola Gatunek.
4. W miejscu Gatunek jest teraz Pogoda: przewijana wolno jedna linia.
5. Dane sa pobierane z wttr.in i obejmuja temperature, opis, wiatr, wilgotnosc oraz cisnienie.
6. Dodano reczne odswiezenie: /weather-refresh
7. Zostawiono poprzednie poprawki paneli i zegara standby.

Gdzie szukac w kodzie:
- Zmienne pogody: APMS WEATHER / POGODA W PANELU RADIO INFO
- Funkcje pogody: APMS WEATHER HELPERS
- Panel RADIO INFO: void tftDrawInfoScreen()
- Pole w ustawieniach WWW: name="evoWeatherCity"
