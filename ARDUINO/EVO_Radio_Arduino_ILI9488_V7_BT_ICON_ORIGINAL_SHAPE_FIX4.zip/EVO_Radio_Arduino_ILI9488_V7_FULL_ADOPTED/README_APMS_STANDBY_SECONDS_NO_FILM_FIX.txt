APMS FIX - STANDBY CLOCK SECONDS / NO SIDE FILM

Poprawka dotyczy zegara po POWER OFF.

Zmieniono:
1. Usunieto boczne klisze/perforacje z ekranu standby.
   Zegar rysuje teraz proste statyczne ramki, bez ruchomego tla.

2. Sekundy sa odswiezane rowno co 1 sekunde.
   Poza animacja ESP budzi sie na nastepna pelna sekunde.

3. Cyfra sekund roluje z dolu do gory.
   Czas rolowania skrocony do 680 ms, zeby animacja konczyla sie przed nastepna sekunda.

4. Usunieto podwojne rysowanie zegara po wybudzeniu timerem.
   Wczesniej powerOffClock() bylo wykonywane dwa razy prawie pod rzad, co moglo powodowac opoznienia i szarpanie.

Poprawiane miejsca:
- tftNativeStandbyClock()
- powerOffClock()
- petla while(f_powerOff) przy ESP_SLEEP_WAKEUP_TIMER
- stale EVO_TFT_STANDBY_CLOCK_FRAME_MS / EVO_TFT_STANDBY_CLOCK_ROLL_MS
