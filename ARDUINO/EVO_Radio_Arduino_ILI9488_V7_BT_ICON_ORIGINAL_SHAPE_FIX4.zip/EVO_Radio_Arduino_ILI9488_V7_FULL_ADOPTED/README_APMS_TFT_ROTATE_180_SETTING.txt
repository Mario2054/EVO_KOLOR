APMS FIX - TFT ROTATE 180 SETTING

Dodano opcję w /config:
- TFT obrot obrazu 180 stopni

Działanie:
- checkbox zapisuje wartość do /config.txt jako:
  TFT Rotate 180 =0/1;
- po zapisie konfiguracji program wywołuje readConfig()
  i od razu stosuje obrót.
- bazowa rotacja EVO_TFT_ROTATION zostaje bez zmian,
  a obrót 180 robi (EVO_TFT_ROTATION + 2) & 3.

Najważniejsze miejsca w pliku .ino:
- bool evoTftRotate180
- EvoDisplayLovyanGFX::setTftRotate180()
- evoTftApplyRotation()
- /config: checkbox evoTftRotate180
- saveConfig(): TFT Rotate 180
- readConfig(): configArray[26] oraz evoTftApplyRotation()
