APMS poprawka do wlasciwego pliku V7 AUDIOI2S GITHUB STYLE18 WEB META

Wprowadzone zmiany:
1. Rozdzielono nazwe stacji od metadanych utworu.
   stationNameStream / stationName = nazwa nadawcy.
   evoNowPlayingText / evoNowPlayingArtist / evoNowPlayingTitle = wykonawca i tytul.

2. Pole tytulu nie uzywa juz nazwy stacji jako fallbacku.
   Gdy stacja nie wysle StreamTitle/ID3, program pokazuje:
   Oczekiwanie na tytul utworu...

3. Poprawiono parser metadanych:
   StreamTitle='Artist - Title';
   Title / Artist
   TIT2 / TPE1

4. Poprawiono /api/state:
   stationtext = wykonawca i tytul
   artist = wykonawca
   title = tytul
   metaok = 1 gdy przyszly prawdziwe metadane

5. Dodano krzywa glosnosci legacy loudness dla ESP32-audioI2S, zeby poziom wyjsciowy byl blizszy poprzedniej wersji.

6. Styl 18 i poprzednie poprawki WWW zostaly zachowane.
