APMS FIX - PANEL INFO / POGODA

Poprawki:
1. Linia "Pogoda:" pokazuje miejscowość: Golotczyzna.
2. Linia "Dane:" nie dubluje już miejscowości.
3. Usunięty problem ze znakiem stopnia z internetu.
   Na TFT temperatura jest pokazywana stabilnie jako np. +17C.
4. Zapytanie do wttr.in nie pobiera już nazwy lokalizacji w danych pogodowych,
   bo miejscowość jest pokazywana osobno.
5. Dodane funkcje:
   - evoWeatherTftSafe()
   - evoWeatherLineDataOnly()
