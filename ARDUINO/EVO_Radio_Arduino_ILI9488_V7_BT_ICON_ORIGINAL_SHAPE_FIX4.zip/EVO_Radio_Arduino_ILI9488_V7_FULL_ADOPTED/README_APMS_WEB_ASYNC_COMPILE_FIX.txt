APMS FIX - WEB ASYNC COMPILE FIX

Poprawka błędu kompilacji:
'class AsyncWebServerRequest' has no member named 'beginResponse'

Zmieniono endpointy:
/          -> używa request->beginResponseStream("text/html")
/api/state -> używa request->beginResponseStream("application/json")

Powód:
W używanej bibliotece ESPAsyncWebServer dostępne jest beginResponseStream(),
ale nie ma metody request->beginResponse().

Zostawiono wcześniejsze poprawki:
- realny wskaźnik WiFi z WiFi.RSSI()
- panel informacyjny stylu 20
- styl 18: czarne tło, zielony/żółty/niebieski/czerwony, cienka dłuższa igła
- webcmd, api/state, api/ping
