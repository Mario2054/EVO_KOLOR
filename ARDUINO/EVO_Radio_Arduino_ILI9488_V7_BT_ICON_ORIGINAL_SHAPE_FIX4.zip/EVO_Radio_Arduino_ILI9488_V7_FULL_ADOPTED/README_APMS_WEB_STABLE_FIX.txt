APMS WEB STABLE FIX

Poprawka strony WWW:
- strona glowna / zostala uproszczona i odchudzona
- usunieto duze generowanie listy wszystkich stacji w HTML, bo na ESP32 potrafilo blokowac odpowiedz WWW
- strona dziala przez zwykle HTTP/AJAX, bez WebSocket
- /api/state dziala przez request->send(), bez beginResponse i bez beginResponseStream
- dodano aliasy: /radio oraz /apms
- dodano /api/ping do szybkiego testu
- dodano /api/state do testu JSON
- dodano onNotFound z lista dostepnych endpointow

Test po wgraniu:
1. Otworz: http://IP_RADIA/api/ping
   Ma pokazac: OK
2. Otworz: http://IP_RADIA/api/state
   Ma pokazac JSON ze stanem radia
3. Otworz: http://IP_RADIA/
   Ma pokazac panel APMS EVO Radio

Jesli /api/ping nie odpowiada, problem nie jest w HTML, tylko w polaczeniu WiFi, IP, porcie 80 albo uruchomieniu server.begin().
