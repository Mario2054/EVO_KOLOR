APMS poprawka standby clock + VU18

Zmiany:
1. Zegar standby po POWER OFF zmienia sekundy co 1 sekunde.
2. Zmiana cyfry sekund jest przewijana z dolu do gory, nie przeskakuje.
3. Podczas animacji cyfry ekran odswieza sie co ok. 45 ms.
4. Po zakonczeniu animacji ESP budzi zegar na nastepna pelna sekunde.
5. Cyfry zegara standby sa lekko mniejsze i lepiej wycentrowane.
6. Styl 18 zostaje czarny, z kolorami: zielony, zolty, niebieski, czerwony.
7. Igla w stylu 18 zostala wydluzona delikatnie o ok. 2 mm, nadal cienka 1 px i ograniczona do obrysu wskaznika.

Baza: EVO_Radio_Arduino_ILI9488_V7_STANDBY_CLOCK_SMOOTH_FIX.zip
