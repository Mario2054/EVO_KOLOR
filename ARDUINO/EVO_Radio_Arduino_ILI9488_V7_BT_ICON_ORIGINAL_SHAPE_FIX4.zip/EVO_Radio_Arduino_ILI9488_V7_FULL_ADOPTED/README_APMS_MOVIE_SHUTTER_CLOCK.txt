APMS poprawka trybu 20 - Movie Clock fullscreen

Dodano:
1. Tryb 20 jako pelnoekranowy zegar, bez stacji i bez metadanych radia.
2. Animacja wejscia do zegara:
   - migawka/klisza aparatu,
   - efekt starej tasmy filmowej,
   - przejscie do duzego zegara.
3. Duzy zegar punktowy z cyframi rolowanymi z dolu do gory.
4. Data wyswietlana duzym tekstem na dole ekranu.
5. Nowa animacja Power OFF na TFT:
   - bialy blysk,
   - zamkniecie migawki aparatu,
   - zanik do cienkiej linii.

Styl 18 nie byl zmieniany: zostaje czarny prostokatny VU z kolorami zielony/zolty/niebieski/czerwony.
