#include "EvoLegacyV31Modules.h"
#if EVO3_ENABLE_LEGACY_V31_MODULES
#include "SDPlayer/SDPlayerAdvanced.cpp"
#include "SDPlayer/SDPlayerManager.cpp"
#include "SDPlayer/SDPlayerOLED.cpp"
#include "SDPlayer/SDPlayerWebUI.cpp"
#endif
