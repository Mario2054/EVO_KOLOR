APMS - poprawka panelu zegara jak na filmie

Dodano nowy tryb wyswietlacza:
20 Movie Clock

Co robi panel:
- czarne tlo,
- gorna linia z malymi cyframi w stylu lamp/nixie,
- duzy dolny zegar punktowy w kolorze czerwono-pomaranczowym,
- zmiana cyfr jest animowana: stara cyfra przesuwa sie do gory, nowa wchodzi od dolu,
- na dole zostaje data, nazwa stacji i przewijany tytul utworu.

Jak wlaczyc:
- pilotem / przyciskiem zmiany trybu przewinac do trybu 20,
- albo w menu WWW ustawic Display Mode = 20.

Pozostawiono poprzednie poprawki:
- styl 18: czarny prostokatny VU, kolory zielony-zolty-niebieski-czerwony, cienka igla,
- VU18 korzysta z poziomu wysterowania z menu serwisowego,
- EQ3/EQ16 z przyciskiem AUDIO,
- poprawki metadanych,
- poprawki poziomu audio dla ESP32-audioI2S.
