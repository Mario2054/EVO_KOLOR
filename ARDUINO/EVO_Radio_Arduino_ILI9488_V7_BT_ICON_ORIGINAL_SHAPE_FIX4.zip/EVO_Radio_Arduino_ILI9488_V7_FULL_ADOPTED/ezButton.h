#pragma once
#include <Arduino.h>

// Lokalna prosta zgodność z ezButton 1.0.x.
// Jeśli masz zainstalowaną bibliotekę ezButton, Arduino i tak może użyć tej lokalnej wersji z folderu projektu.
class ezButton {
  uint8_t _pin;
  unsigned long _debounce = 50;
  bool _last = HIGH;
  bool _state = HIGH;
  bool _pressedEdge = false;
  bool _releasedEdge = false;
  unsigned long _lastChange = 0;
public:
  explicit ezButton(uint8_t pin) : _pin(pin) { pinMode(_pin, INPUT_PULLUP); _last = _state = digitalRead(_pin); }
  void setDebounceTime(unsigned long t) { _debounce = t; }
  void loop() {
    bool r = digitalRead(_pin);
    _pressedEdge = false;
    _releasedEdge = false;
    if (r != _last) { _lastChange = millis(); _last = r; }
    if ((millis() - _lastChange) > _debounce && r != _state) {
      bool old = _state;
      _state = r;
      if (old == HIGH && _state == LOW) _pressedEdge = true;
      if (old == LOW && _state == HIGH) _releasedEdge = true;
    }
  }
  bool isPressed() { return _pressedEdge; }
  bool isReleased() { return _releasedEdge; }
  int getState() { return _state; }
};
