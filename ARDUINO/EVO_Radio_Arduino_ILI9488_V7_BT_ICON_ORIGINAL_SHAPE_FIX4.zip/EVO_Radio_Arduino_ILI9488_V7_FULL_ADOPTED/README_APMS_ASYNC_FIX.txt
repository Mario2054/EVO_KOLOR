APMS FIX - AsyncWebServer compile fix

Poprawka usuwa wywolanie:
  server.handleClient();

Powod bledu:
Prawdziwa biblioteka ESPAsyncWebServer nie ma metody handleClient().
Ta metoda byla potrzebna tylko przy lokalnym adapterze AsyncWebServer -> WebServer.

Efekt:
Projekt kompiluje sie z prawdziwa biblioteka ESPAsyncWebServer/AsyncTCP.
Serwer asynchroniczny obsluguje zapytania samodzielnie, bez wywolywania handleClient() w loop().

Pozostale poprawki z poprzedniej wersji zostaly zachowane:
- zegar standby po POWER OFF,
- styl 20 przywrocony,
- styl 18 czarne tlo i 4 kolory,
- EQ3/EQ16,
- metadane,
- poziom VU z menu serwisowego.
