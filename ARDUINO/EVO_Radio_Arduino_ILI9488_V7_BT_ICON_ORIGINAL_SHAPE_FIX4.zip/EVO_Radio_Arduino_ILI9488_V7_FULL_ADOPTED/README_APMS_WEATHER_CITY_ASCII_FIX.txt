APMS FIX - MIEJSCOWOSC POGODY / CONFIG

Poprawiony blad po zatwierdzeniu w /config:
- poprzednio nazwa mogla zmienic sie na GoL_otczyzna albo Gołotczyzna,
  bo znak ł nie byl dobrze obslugiwany przez panel TFT/formularz.
- teraz nazwa jest zapisywana stabilnie jako ASCII: Golotczyzna.
- funkcja evoWeatherCityDisplayName() naprawia tez stary bledny zapis GoL_otczyzna.
- w panelu INFO i w /config bedzie wyswietlane: Golotczyzna.

Najwazniejsze miejsce:
- evoWeatherCityDisplayName()
- obsluga pola evoWeatherCity w /config
