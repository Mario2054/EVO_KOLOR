Poprawka: panel MAGIC EYE VU zostal usuniety z trybu 18.

Tryb 18 zostal zastapiony panelem VU Square / VU kwadratowy-prostokatny.
Panel bazuje na kodzie vuMeterMode4() przeslanym przez uzytkownika:
- dwa prostokatne wskazniki L/R,
- skala dB -20, -10, -5, 0, +3, +6, +9,
- igly analogowe,
- bezwladnosc vuSmooth, vuRiseNeedleSpeed, vuFallNeedleSpeed,
- respektuje reversColorMode4.

Zmienione miejsca:
- v44PanelMagicEye() usuniety/zastapiony przez v44PanelSquareVuMode4(),
- displayMode == 18 uruchamia v44PanelSquareVuMode4(),
- opisy w konfiguracji WWW i /modes zmienione z "Magic Eye" na "VU Square",
- zachowano baze V7 i reszte funkcji projektu.

Dodatkowo zachowano poprawke kompilacji:
- drugi adapter displayEqualizer() ma nazwe displayEqualizerFullAdopted(),
- rzutowanie max() w vuMeterMode0new() poprawione pod ESP32 Arduino Core 3.3.8.
