EVO3 MOD KOLOR V44 - baza V7 + funkcje EVO3 MOD OST
====================================================

GLOWNY PLIK DO OTWARCIA W ARDUINO IDE:
EVO3_MOD_KOLOR_V44_V7_FULL_REWRITE.ino

ZALOZENIA:
- baza programu: V7 ILI9488 VU FIXED 27MHz,
- ekran: LovyanGFX 1.2.21, panel ILI9488,
- wszystkie nowe panele rysowane w siatce 320x240 i skalowane na ILI9488 przez warstwe V7,
- stare funkcje EVO3 MOD OST zostaly przepisane do kolorowych paneli bez bezposredniego kompilowania starego main.cpp,
- oryginalne zrodla z paczki EVO3.zip sa zachowane w folderze original_EVO3_MOD_OST jako wzorzec porownawczy.

MAPA TRYBOW DISPLAY MODE:
0  Radio main V7
1  Clock V7
2  Info V7
3  Center / Mode 3 V7
4  VU Analog 4 kolory
5  Analyzer Bars - odpowiednik EVO3 mode 5
6  Analyzer Segments - odpowiednik EVO3 mode 6
7  SD Player
8  Analyzer Wide Bars - odpowiednik EVO3 mode 8
9  SD Recorder
10 Floating Peaks - odpowiednik EVO3 mode 10
11 DLNA / UPNP
12 Bluetooth RX/TX UART
13 Graphic EQ16
14 Analyzer Scope
15 System Monitor
16 V7 Crystal VU
17 V7 Side Spread VU
18 Magic Eye / Style 11
19 Files / Storage Browser

ENDPOINTY WWW:
/sdplayer
/sdplayer/api/list
/sdplayer/api/play
/sdplayer/api/pause
/sdplayer/api/stop
/sdplayer/api/next
/sdplayer/api/prev
/sdplayer/api/up
/sdplayer/api/back
/rec/start
/rec/stop
/rec/status
/dlna
/dlna/api/save
/bt
/bt/api/mode?m=RX|TX|OFF|AUTO
/bt/api/uart?en=1|0
/bt/api/cmd?c=...
/bt/api/log
/eq16
/eq16/api/set
/eq16/api/reset
/eq16/api/preset?p=0..6
/eq16/api/band?b=0..15&v=-12..12
/analyzer
/mode?m=0..19
/modes
/sys

BIBLIOTEKI:
- ESP32 core 3.x
- LovyanGFX 1.2.21
- ESP32-audioI2S
- WiFiManager
- ArduinoJson
- U8g2

UWAGI:
Stare pliki z EVO3 MOD OST nie sa wlaczone bezposrednio do kompilacji, bo maja wlasny main.cpp, stary obiekt u8g2 i konflikty z baza V7. Zostaly potraktowane jako wzorzec funkcji, a panele i obsluga zostaly przepisane do warstwy V44.
