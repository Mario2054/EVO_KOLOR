APMS FIX - VU18 SIGNAL LEVEL / SERVICE MENU
Data: 2026-05-10

Poprawka dotyczy stylu 18 - czarny prostokatny VU z 4 kolorami.

Problem:
W menu serwisowym / konfiguracji bylo ustawienie:
  Poziom wysterowania VU / Analyzer = evo46VuDrive 10-200%
ale styl 18 liczyl wychylenie bezposrednio z audio.getVUlevel() przez map(0..255 -> 0..100).
Dlatego zmiana poziomu sygnalu nie miala wplywu na wskazniki prostokatne.

Zmiana:
W funkcji v44PanelSquareVuMode4() zamieniono:
  map(rawL, 0, 255, 0, 100)
  map(rawR, 0, 255, 0, 100)
na:
  tftVuPct(rawL)
  tftVuPct(rawR)

Teraz styl 18 korzysta z parametru evo46VuDrive tak samo jak pozostale panele VU/analyzer.

Zostawione bez zmian:
- czarne tlo wskaznikow,
- 4 kolory: zielony, zolty, niebieski, czerwony,
- cienka igla,
- poprawki EQ3/EQ16,
- poprawki metadanych,
- poprawki poziomu audio.
