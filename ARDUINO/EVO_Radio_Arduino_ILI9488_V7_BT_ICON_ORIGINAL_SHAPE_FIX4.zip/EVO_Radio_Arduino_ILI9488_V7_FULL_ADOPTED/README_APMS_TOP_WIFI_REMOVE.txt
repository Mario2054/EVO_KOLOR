APMS FIX - USUNIECIE GORNEGO WSKAZNIKA WIFI ZE WSZYSTKICH PANELI

Zmiany:
1. Dodano zabezpieczenie w tftDrawRealWifiIndicator(): gdy funkcja jest wywolana w gornej belce ekranu (Y < 60), czysci obszar i nic nie rysuje.
2. Dodano zabezpieczenie w tftNeoSignalBars(): stary wskaznik sygnalu nie moze juz pojawic sie w gornej belce.
3. W tftDrawTitleBar() dodano mocniejsze czyszczenie lewego gornego rogu.
4. W tftDrawOriginalHeader() dodano mocniejsze czyszczenie lewego gornego rogu.

Efekt:
Gorny wskaznik WiFi zniknie z paneli RMS, V-METER, MODE18, EQ16, SD Player, Bluetooth, DLNA, Analyzer i pozostalych ekranow korzystajacych z gornego naglowka.
Dolny prawdziwy wskaznik WiFi z antena i RSSI zostaje bez zmian.
