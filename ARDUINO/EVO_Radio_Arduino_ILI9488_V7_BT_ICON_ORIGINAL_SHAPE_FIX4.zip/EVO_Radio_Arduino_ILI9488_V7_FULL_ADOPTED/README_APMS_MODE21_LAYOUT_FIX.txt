APMS FIX - MODE 21 LAYOUT

Poprawiono panel 21 na podstawie zdjecia z TFT:
- zmniejszono zegar srodkowy z size 4 na size 3,
- przesunieto zegar wyzej,
- rozdzielono date i dzien tygodnia na osobne pola,
- dodano kolorowe linie pod data,
- zostawiono prawdziwy wskaznik WiFi z WiFi.RSSI(),
- dolne panele IP / glosnosc / kanal / WiFi zostaly uporzadkowane,
- styl 20 i styl 18 nie zostaly cofnięte.

Glowna funkcja:
void tftDrawWifiInfoPanelScreen()

Szukaj w pliku .ino:
MODE 21 - PANEL INFORMACYJNY / WIFI / ZEGAR / METADANE
