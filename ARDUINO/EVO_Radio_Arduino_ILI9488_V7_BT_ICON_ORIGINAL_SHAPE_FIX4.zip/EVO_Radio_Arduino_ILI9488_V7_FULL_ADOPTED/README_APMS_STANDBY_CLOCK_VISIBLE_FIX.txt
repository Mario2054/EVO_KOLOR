APMS poprawka zegara standby po POWER OFF

Problem:
Po wyłączeniu radia z pilota zegar mógł się nie pojawić, ponieważ:
1) był zależny od starej opcji OLED "Display Clock in Sleep",
2) jasność standby używała dimmerSleepDisplayBrightness, domyślnie 1, co na TFT jest praktycznie czarne.

Zmiany:
- Na TFT po POWER OFF zawsze działa sekwencja: animacja -> zegar standby.
- Dodano minimalną jasność zegara standby: EVO_TFT_STANDBY_CLOCK_BRIGHTNESS_MIN = 45.
- Zegar standby nadal korzysta z animowanych cyfr i daty.
- Styl 20 pozostaje osobnym panelem jak wcześniej.
- Styl 18 nie był ruszany.
