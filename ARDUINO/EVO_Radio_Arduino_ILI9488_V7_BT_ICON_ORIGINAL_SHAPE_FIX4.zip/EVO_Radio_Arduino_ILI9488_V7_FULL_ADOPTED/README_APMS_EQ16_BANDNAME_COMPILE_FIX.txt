APMS FIX - EQ16 BandName compile fix

Poprawka usuwa blad kompilacji:
'evo43Eq16BandName' was not declared in this scope

Dodano funkcje:
static const char* evo43Eq16BandName(uint8_t band)

Funkcja znajduje sie przed v39PanelEQ16(), aby Arduino IDE widzialo ja przed uzyciem.
Nazwy pasm EQ16:
32Hz, 45Hz, 63Hz, 90Hz, 125Hz, 180Hz, 250Hz, 355Hz,
500Hz, 710Hz, 1kHz, 1.4kHz, 2kHz, 4kHz, 8kHz, 16kHz.

Zostawiono wcześniejsze poprawki:
- styl 18: czarne tlo, 4 kolory zielony/zolty/niebieski/czerwony,
- cienka igla,
- poziom wysterowania VU z menu serwisowego evo46VuDrive,
- obsluga EQ3/EQ16 przyciskiem AUDIO,
- regulacja EQ16 po OK klawiszami UP/DOWN.
