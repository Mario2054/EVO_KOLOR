EVO Radio ILI9488 - V7 FULL ADOPTED

Baza programu:
- EVO_Radio_Arduino_ILI9488_V7_VU_FIXED_27MHz_RECOMMENDED.ino

Dodatkowe źródła użyte do integracji:
- EVO3_MOD_KOLOR_V46_V7_FULL_WEB_ANALYZER.zip
- EVO 3 mod ost.zip

Co zostało zrobione:
1. Główny szkic oparty jest na V7/V46, ale zachowuje poprawki ekranów z V7:
   - poprawiony ekran radia,
   - dzień tygodnia obok daty,
   - przewijane tytuły audycji na ekranach VU,
   - poprawiony ekran INFO.

2. Z V46 zostają aktywne funkcje i panele:
   - SD Player,
   - SD Recorder,
   - DLNA,
   - Bluetooth,
   - EQ16,
   - Analyzer FFT / Scope / Wide / Floating Peaks,
   - System Monitor,
   - Magic Eye,
   - File Browser,
   - strony WWW: /sdplayer, /sdrecorder, /dlna, /bt, /eq16, /analyzer, /wifi, /sys, /modes.

3. Dołożono blok adapterów V47 / FULL ADOPTED:
   - SDPlayerOLED_init(), SDPlayerOLED_loop(), SDPlayerWebUI_registerHandlers(),
   - SDRecorder_init(), SDRecorder_loop(), SDRecorder_displayCallback(),
   - BTWebUI_init(), BTWebUI_loop(), BTWebUI_registerHandlers(),
   - DLNAWebUI_init(), DLNAWebUI_loop(), DLNAWebUI_registerHandlers(),
   - getStorage(), isAudioFile(), scanDirectory(),
   - saveSDPlayerSessionState(), loadSDPlayerSessionState(), clearSDPlayerSessionCompleted(),
   - readDLNAConfig(), saveDLNAConfig(), activateDLNAMode(),
   - loadWifiNetworks(), saveWifiNetworks(), connectMultiWifi(),
   - performSeekAction(), updateSpeakersPin(), displayBasicInfo(), displayEqualizer(), displayTracks(),
   - win1250ToUtf8(), isValidUtf8(), vuMeterMode0new().

4. Pełne oryginalne źródła z EVO 3 mod ost są dołączone w katalogu:
   EVO3_MOD_OST_FULL_SOURCE_REFERENCE_NOT_COMPILED
   Nie są kompilowane jako drugi rdzeń, bo stare pliki mają własną logikę OLED/U8G2 i dublowałyby ekran oraz audio.
   Ich wejścia zostały przepisane przez adaptery w głównym .ino.

Jak uruchamiać:
- Otwórz folder: EVO_Radio_Arduino_ILI9488_V7_FULL_ADOPTED
- Otwórz plik: EVO_Radio_Arduino_ILI9488_V7_FULL_ADOPTED.ino
- Nie otwieraj osobno plików z katalogu reference jako szkicu Arduino.

Uwaga:
Nie uruchomiłem tutaj pełnej kompilacji Arduino, bo środowisko nie ma Twoich bibliotek ESP32/LovyanGFX/Audio.
Kod został przygotowany strukturalnie jako pełniejszy merge V7 + V46 + adaptery z EVO3 MOD OST.
