EVO3 MOD KOLOR V43 - V7 BASE FULL

Bazą programu jest V7: EVO_Radio_Arduino_ILI9488_V7_VU_FIXED_27MHz_RECOMMENDED.
Nie jest to czyste przepisanie main.cpp z EVO3 MOD OST, bo tamten plik ma własny main/setup/loop i stary układ paneli.
W V43 funkcje zostały przeniesione jako nowa warstwa EVO3 MOD KOLOR, żeby kompilacja nie robiła konfliktów.

Najważniejsze zmiany:
1. Tryby 0-6 zostają z V7.
2. Tryby 7-14 to nowe panele EVO3 MOD KOLOR:
   7  SD Player
   8  SD Recorder
   9  DLNA / UPNP
   10 Bluetooth
   11 Graphic EQ16
   12 Analyzer FFT
   13 Analyzer Scope
   14 System Monitor
3. Dodane strony WWW:
   /sdplayer
   /rec/start
   /rec/stop
   /rec/status
   /dlna
   /bt
   /eq16
   /analyzer
   /sys
4. Stare pliki EVO3 MOD OST są zostawione jako źródło odniesienia, ale nie są kompilowane bezpośrednio.
   Pliki .cpp z katalogu głównego zostały przeniesione do legacy_mod_ost_source, żeby Arduino IDE nie kompilowało drugiego programu obok V7.
5. Dla Arduino IDE otwieraj tylko:
   EVO3_MOD_KOLOR_V43_V7_BASE_FULL.ino

Biblioteki:
- ESP32 core 3.x
- LovyanGFX aktualna 1.2.x
- U8g2
- WiFiManager
- ESP32-audioI2S
- Time

Uwaga o recorderze:
Recorder V43 zapisuje strumienie HTTP do /RECORDINGS jako kopię danych MP3/AAC/OGG zależnie od źródła.
HTTPS nie jest jeszcze nagrywany w tej lekkiej warstwie, żeby nie blokować audio i nie zwiększać błędów kompilacji.
