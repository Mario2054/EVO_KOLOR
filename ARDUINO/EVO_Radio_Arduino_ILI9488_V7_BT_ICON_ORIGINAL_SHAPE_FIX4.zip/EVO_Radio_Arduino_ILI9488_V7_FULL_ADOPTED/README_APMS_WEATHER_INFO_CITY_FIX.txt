APMS FIX - WEATHER CITY / PANEL INFO

Poprawki:
1. Panel RADIO INFO pokazuje miejscowość pogody z dużej litery, np. Gołotczyzna.
2. Pole pogody w panelu INFO ma teraz:
   Pogoda: Gołotczyzna
   Dane: przewijany tekst pogody z temperaturą, opisem, wiatrem, wilgotnością i ciśnieniem.
3. Miejscowość wpisana w /config jest normalizowana przed zapisem do /weather_city.txt.
4. Domyślna miejscowość ustawiona na Gołotczyzna.
5. Pole Region: GOLOTCZYZNA zostało usunięte z panelu INFO, żeby nie dublować informacji.

Najważniejsze miejsca:
- evoWeatherCityDisplayName()
- evoWeatherLine()
- tftDrawInfoScreen()
- obsługa pola evoWeatherCity w /config
