#include "../EvoLegacyV31Modules.h"
#if EVO3_ENABLE_LEGACY_V31_MODULES
#include "../core/options.h"
#ifdef USE_DLNA
#include "dlna_http_guard.h"
SemaphoreHandle_t g_dlnaHttpMux = nullptr;
#endif
#endif // EVO3_ENABLE_LEGACY_V31_MODULES
