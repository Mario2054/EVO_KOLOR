APMS FIX - STYLE 18 / WEB / METADATA
====================================

Zmiany w tej wersji:

1. Styl 18 zostal przelaczony na prostokatny VU meter z V7:
   - displayMode == 18 wywoluje tftDrawVuScreen()
   - uzywa funkcji tftDrawAnalogVuOne()
   - tlo wskaznikow zmienione na czarne
   - kolory skali zostaja: zolty, zielony, niebieski, czerwony

2. Poprawiona obsluga WWW bez prawdziwego WebSocket:
   - lokalny ESPAsyncWebServer.h w tej paczce jest adapterem na zwykly WebServer,
     wiec WebSocket w przegladarce nie mial realnego polaczenia
   - dodano /api/state do pobierania stanu radia i metadanych
   - dodano /webcmd do sterowania: glosnosc, stacja, bank, zmiana trybu wyswietlania
   - strona glowna i URL Play maja fallback HTTP oraz odswiezanie danych co ok. 2 s

3. Poprawione metadane:
   - audio_showstreamtitle zapisuje teraz dane do stationString/stationStringWeb/stationStringScroll
   - audio_id3data parsuje Title i Artist
   - dodano audio_showstreaminfo jako dodatkowe zrodlo informacji
   - strona WWW pobiera tytul/metadane przez /api/state, nawet gdy WebSocket nie dziala

4. Poprawiona strona WiFi:
   - formularze dodawania/usuwania sieci wysylaja dane jako x-www-form-urlencoded,
     bo lokalny WebServer lepiej obsluguje taki format niz FormData/multipart

Uwaga:
Nie kompilowano fizycznie na plytce. Poprawki sa wprowadzone bez zmiany struktury katalogow projektu.
