APMS - poprawka płynności zegara standby

Zmiany w tej paczce:

1. Zegar standby po POWER OFF nie odświeża się już tylko raz na sekundę.
   W czasie zmiany cyfry ekran odświeża się co ok. 55 ms.

2. Animacja zmiany cyfr z dołu do góry działa teraz rzeczywiście płynnie.
   Wcześniej kod miał animację, ale ekran dostawał tylko jedną klatkę na sekundę.

3. Dodano łagodne przyspieszanie i hamowanie ruchu cyfry, żeby nie było skoku na początku i końcu.

4. Tło kliszy w zegarze standby zostało spowolnione.
   Nie przesuwa się w każdej klatce, bo to obciążało SPI i powodowało szarpanie.

5. Styl 20 nie został zmieniony.
   Styl 18 nie został zmieniony.
   Poprawki EQ3/EQ16, metadanych, poziomu audio i poziomu VU z menu serwisowego zostały zachowane.
