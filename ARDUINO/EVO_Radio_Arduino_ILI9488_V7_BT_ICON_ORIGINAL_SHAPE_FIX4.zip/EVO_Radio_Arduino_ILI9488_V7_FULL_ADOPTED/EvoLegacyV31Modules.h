#pragma once

// Pełne źródła z EVO3 MOD OST są w katalogu:
// EVO3_MOD_OST_FULL_SOURCE_REFERENCE_NOT_COMPILED
//
// Uwaga praktyczna:
// pełne stare moduły OLED/U8G2 nie są kompilowane jako osobny rdzeń,
// bo baza V7 ma własną warstwę LovyanGFX i własny obiekt ekranu `gfx`.
// Ich funkcje wejściowe zostały zaadaptowane w pliku .ino przez blok:
// V47 / FULL ADOPTED - adapter funkcji z EVO3 MOD OST do bazy V7/V46.
//
// Zostawiamy flagę 0, żeby Arduino IDE nie kompilowało podwójnej logiki ekranu/audio.
#ifndef EVO3_ENABLE_LEGACY_V31_MODULES
  #define EVO3_ENABLE_LEGACY_V31_MODULES 0
#endif
