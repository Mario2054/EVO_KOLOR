#pragma once
// Lokalny pusty adapter. Projekt V41 używa WebServer przez ESPAsyncWebServer.h.
