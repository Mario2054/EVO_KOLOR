EVO3 MOD KOLOR V45 - poprawka kompilacji po V44

Baza: V7.
Panel: ILI9488 / LovyanGFX 1.2.21.
Zakres: EVO3 MOD OST przepisany na kolorowe panele LovyanGFX.

Poprawki względem V44:
1. Naprawiono błędne wywołanie tftTextCenter() w panelu V-Meter 4 kolory.
2. Naprawiono błędne wywołanie tftTextCenter() w dolnej belce paneli.
3. Dodano przeciążenie tftTextCenter(centerX, y, text, size, color), żeby nowe panele mogły bezpiecznie centrować tekst po punkcie środka.
4. Zmieniono oznaczenie wersji na V45.

Otwieraj w Arduino IDE:
EVO3_MOD_KOLOR_V45_V7_FULL_COMPILE_FIX.ino

Nie kompiluj plików ze starych katalogów jako osobnych szkiców. Arduino IDE ma być otwarte z katalogu V45.
