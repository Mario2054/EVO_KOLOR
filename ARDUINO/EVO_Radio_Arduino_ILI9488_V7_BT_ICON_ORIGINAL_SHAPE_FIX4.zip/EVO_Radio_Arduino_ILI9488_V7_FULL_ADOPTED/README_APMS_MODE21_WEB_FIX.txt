APMS poprawka:
- usunieto server.onNotFound(), bo lokalny adapter ESPAsyncWebServer.h go nie obsluguje,
- dodano bezpieczne server.handleClient() tylko dla lokalnego adaptera WebServer,
- przywrocono styl 20 jako poprzedni zegar filmowy/lampowy,
- obecny panel informacyjny z prawdziwym WiFi przeniesiono na styl 21,
- displayModeMax ustawiony na 21,
- lista trybow /modes oraz menu WWW uwzglednia styl 21.

Test po wgraniu:
1. http://IP_RADIA/api/ping powinno pokazac OK
2. http://IP_RADIA/ powinno otworzyc panel WWW
3. Ekran 20 = zegar filmowy
4. Ekran 21 = panel informacyjny z WiFi RSSI
