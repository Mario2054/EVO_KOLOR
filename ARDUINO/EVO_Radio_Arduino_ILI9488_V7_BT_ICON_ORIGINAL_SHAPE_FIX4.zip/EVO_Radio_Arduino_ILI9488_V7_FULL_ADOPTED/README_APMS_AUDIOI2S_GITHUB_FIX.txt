APMS AUDIOI2S GITHUB FIX - v3.20.06

Wersja przygotowana pod bibliotekę:
https://github.com/schreibfaul1/ESP32-audioI2S.git

Najważniejsze poprawki:
1. Dodano nowy callback Audio::audio_info_callback zgodny z aktualną biblioteką ESP32-audioI2S.
2. Callback Audio::msg_t przekierowuje zdarzenia do istniejących funkcji EVO:
   - evt_info -> audio_info()
   - evt_bitrate -> audio_bitrate()
   - evt_name -> audio_showstation()
   - evt_streamtitle -> audio_showstreamtitle()
   - evt_id3data -> audio_id3data()
   - evt_eof -> audio_eof_mp3()
   - evt_icyurl / evt_icydescription / evt_lasthost -> odpowiednie funkcje logujące.
3. Stare globalne funkcje audio_xxx zostały zostawione, żeby projekt był nadal zgodny ze starszymi wariantami biblioteki.
4. Metadane streamtitle i ID3 aktualizują TFT oraz stronę WWW przez stationString, stationStringWeb i stationStringScroll.
5. PlatformIO pobiera bibliotekę bezpośrednio z GitHuba: https://github.com/schreibfaul1/ESP32-audioI2S.git
6. Poprawiono src_filter w platformio.ini, żeby kompilował właściwy plik .ino z tej paczki.
7. Zostawiono wcześniejsze poprawki: styl 18 = prostokątny VU z V7, HTTP /api/state oraz /webcmd zamiast niedziałającego WebSocket w lokalnym adapterze.

Uwaga:
Biblioteka ESP32-audioI2S wymaga ESP32/ESP32-S3/ESP32-P4 z PSRAM i zewnętrznego DAC/I2S.
