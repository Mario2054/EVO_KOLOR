Poprawka wykonana na bazie V7_FULL_ADOPTED_SQUARE_VU_FIX.

Zmiany:
1. Panel 18 VU Square ma teraz ciemne/czarno-granatowe tlo, bez bialej tarczy.
2. Cyfry skali, kreski i igla zmieniaja kolor wg wychylu: zielony, zolty, pomaranczowy, czerwony.
3. Na panelu jest pasek NOW z informacja co teraz nadaje stacja.
4. tftNowPlaying() nie zwraca juz mylacego tekstu No audio stream, tylko bierze kolejno: stationString, stationStringWeb, stationStringScroll, stationNameStream, nazwe stacji.
5. audio_showstreamtitle() zapisuje tytul od razu do stationStringWeb i stationStringScroll dla natywnych ekranow TFT.
