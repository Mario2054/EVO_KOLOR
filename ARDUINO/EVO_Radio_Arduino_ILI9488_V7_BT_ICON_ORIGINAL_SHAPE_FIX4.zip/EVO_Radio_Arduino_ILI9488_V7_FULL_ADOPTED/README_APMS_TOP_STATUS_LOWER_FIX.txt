APMS FIX - obnizenie linii stacji i IP

Zmieniona funkcja:
  static void evo43DrawTopMiniStatus(const String &modeName)

Co poprawiono:
  - nazwa stacji pod belka tytulu zostala przesunieta z Y=28 na Y=36
  - adres IP zostal przesuniety z Y=28 na Y=36
  - dodano czyszczenie paska tła, zeby tekst nie smuzyl przy odswiezaniu

Dotyczy paneli korzystajacych z evo43DrawTopMiniStatus, m.in.:
  - SD PLAYER
  - GRAPHIC EQ16
  - ANALYZER STYLE 5/6/8/10
  - ANALYZER SCOPE
  - FILES / STORAGE
  - VU METER 4 COLOR
  - SYSTEM MONITOR
