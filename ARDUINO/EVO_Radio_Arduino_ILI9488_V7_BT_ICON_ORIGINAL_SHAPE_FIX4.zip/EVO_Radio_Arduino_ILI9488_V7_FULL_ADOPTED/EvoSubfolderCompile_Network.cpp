#include "EvoLegacyV31Modules.h"
#if EVO3_ENABLE_LEGACY_V31_MODULES
#include "network/DLNAWebUI.cpp"
#include "network/dlna_desc.cpp"
#include "network/dlna_http_guard.cpp"
#include "network/dlna_index.cpp"
#include "network/dlna_service.cpp"
#include "network/dlna_ssdp.cpp"
#include "network/dlna_worker.cpp"
#endif
