APMS WEB FIX
============
Poprawka strony WWW:
- glowna strona / zostala przepisana na czysty HTTP/AJAX bez zaleznosci od WebSocket,
- dziala z prawdziwym ESPAsyncWebServer,
- sterowanie idzie przez /webcmd,
- odczyt stanu/metadanych idzie przez /api/state,
- dodany test /api/ping,
- usunieto problem starego HTML/JS z mieszaniem WebSocket i HTTP.

Sprawdzenie po wgraniu:
1. Otworz w przegladarce: http://ADRES_IP_RADIA/api/ping
   Ma pokazac: OK
2. Otworz: http://ADRES_IP_RADIA/api/state
   Ma pokazac dane JSON.
3. Otworz: http://ADRES_IP_RADIA/
   Ma pokazac nowy panel web radia.
