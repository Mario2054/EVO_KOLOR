APMS FIX 2026-05-10

Zmiana:
- Usunieto gorny wskaznik WiFi z naglowka paneli TFT.
- Realny wskaznik WiFi z antena i RSSI zostaje na dole ekranu.
- Nazwa stacji w naglowku dostala szersze pole.

Miejsce zmiany w pliku .ino:
- void tftDrawOriginalHeader(const String &station)
- okolice linii 5355

Stary element usuniety:
- tftDrawRealWifiIndicator(9, 8, 54, 22, false);

Nowe pole stacji:
- tftNeoMiniBadge(14, 9, 214, tftClipText(station, 28), ...);
