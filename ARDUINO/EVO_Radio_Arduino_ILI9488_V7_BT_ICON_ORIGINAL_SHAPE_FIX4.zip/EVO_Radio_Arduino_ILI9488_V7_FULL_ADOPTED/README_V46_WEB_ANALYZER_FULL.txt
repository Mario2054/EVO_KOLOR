EVO3 MOD KOLOR V46 - V7 BASE + pelniejsze przeniesienie funkcji EVO3 MOD OST

Baza programu: V7.
Grafika: LovyanGFX / ILI9488, panele 320x240 skalowane przez warstwe TFT V7.

Co dodano/poprawiono w V46:
1. Rozbudowana strona /analyzer jak w EVO3 MOD OST:
   - peak hold time,
   - paleta kolorow,
   - tlo panelu,
   - siatka,
   - poziom analizatora,
   - edycja stylu 5,
   - edycja stylu 6,
   - edycja stylu 8,
   - edycja stylu 10 Floating Peaks,
   - zapis do /analyzer.cfg,
   - presety Classic / Modern / Compact / Retro / Floating Peaks.

2. Dodany globalny poziom wysterowania VU/Analyzer w /config:
   - pole: Poziom wysterowania VU / Analyzer (10-200%),
   - domyslnie 65%, aby wskazniki nie pracowaly stale na 100%.

3. Menu web uzupelnione o:
   - SD Recorder,
   - Bluetooth Settings,
   - Remote Control,
   - WiFi Networks,
   - Graphic EQ16,
   - Analyzer Edit.

4. Dodana strona /sdrecorder:
   - status nagrywania,
   - start/stop,
   - podglad pliku i rozmiaru.

5. Rozbudowana strona /bt:
   - status,
   - UART RX19/TX20,
   - tryby OFF/RX/TX/AUTO,
   - regulacja volume BT RX,
   - akcje scan/disconnect/delete paired,
   - terminal diagnostyczny UART.

6. Dodana strona /wifi:
   - zapis do /wifi_multi.cfg,
   - lista sieci,
   - skan sieci,
   - dodawanie/usuwanie.

7. Kolorowe panele analizatora korzystaja z ustawien z /analyzer:
   - Style 5 Bars,
   - Style 6 Segments,
   - Style 8 Wide Bars,
   - Style 10 Floating Peaks.

Otwieraj w Arduino IDE plik:
EVO3_MOD_KOLOR_V46_V7_FULL_WEB_ANALYZER.ino

Zalecane biblioteki:
- ESP32 core 3.x
- LovyanGFX 1.2.21
- ESP32-audioI2S
- WiFiManager
- ArduinoJson
