APMS STANDBY CLOCK FIX

Zmiany:
1. Styl 20 przywrocony do poprzedniego wygladu panelu zegara/radia.
2. Po POWER OFF z pilota, jezeli wlaczony jest zegar w sleep/standby, pojawia sie sekwencja: kolorowa klisza -> migawka aparatu -> zegar standby.
3. Animacja przy POWER OFF wlacza sie przed zegarem standby; zegar standby ma mniejsze cyfry niz poprzedni pelnoekranowy wariant, rolowane z dolu do gory, oraz date na ekranie.
4. Animacja kliszy/migawki jest wolniejsza i ma kolorowe elementy.
5. Styl 18 nie byl ruszany: czarne tlo, cztery kolory VU, cienka igla.

Uwaga: zegar standby korzysta z ustawienia menu: OLED Display Clock in Sleep Mode / Display Clock in Sleep.
