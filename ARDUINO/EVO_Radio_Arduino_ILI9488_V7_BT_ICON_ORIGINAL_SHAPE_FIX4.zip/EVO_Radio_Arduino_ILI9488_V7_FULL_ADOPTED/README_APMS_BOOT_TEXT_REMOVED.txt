APMS FIX - BOOT VERSION TEXT REMOVED

Usunieto zolty napis wersji/trybu z gornej czesci ekranu startowego.
Poprawiona funkcja: tftNativeStartupSplash().
Zakomentowana linia: tftTextRight(310, 12, String(rev), 1, EVO_TFT_NATIVE_YELLOW);
