// ################################################################################################################### //
// Evo Internet Radio                                                                                                  //
// ################################################################################################################### //
// Author:   Robgold 2026, Made in Poland                                                                              //
// Source -> https://github.com/dzikakuna/ESP32_radio_evo3/tree/main/src/ESP32_radio_evo3.20                           //
// ################################################################################################################### //
//                                                                                                                     //
// Compilator: Arduino, Platformio                                                                                     //
// ESP32 by Espressif:                          3.3.7  plus recomiled TCP/IP libs for FLAC                             //
// ESP32-audioI2S-master by schreibfaul1:       3.4.4x with commits 23.02.2026,                                        //
// WebServer:                                   3.11.0 / lokalny adapter AsyncWebServer -> WebServer                                                                 //
// AsyncTCP:                                    lokalny pusty adapter                                                                 // 
// ezButton:                                    1.0.6                                                                  //
// LovyanGFX by lovyan03:                     panel SSD1322/ILI9341/ILI9488, sprite + U8g2 fonts                          //
// WiFiManager by tzapu                         2.0.17                                                                 //
// ################################################################################################################### //

#include "Arduino.h"           // Standardowy nagłówek Arduino, który dostarcza podstawowe funkcje i definicje
#include <WiFiManager.h>       // Biblioteka do zarządzania konfiguracją sieci WiFi, opis jak ustawić połączenie WiFi przy pierwszym uruchomieniu jest opisany tu: https://github.com/tzapu/WiFiManager
#include <Audio.h>             // Biblioteka do obsługi funkcji związanych z dźwiękiem i audio
#include "SPI.h"               // Biblioteka do obsługi komunikacji SPI
#include "FS.h"                // Biblioteka do obsługi systemu plików
#define LGFX_USE_V1
#include <LovyanGFX.hpp>       // Nowa biblioteka do obsługi paneli TFT/OLED
#include <new>                 // placement new dla przełączania fontów U8g2 w LovyanGFX
#include <stdarg.h>            // obsługa printf w warstwie ekranu
#include <U8g2lib.h>           // TYLKO źródło tablic fontów u8g2_font_* dla lgfx::U8g2font
#include "ezButton.h"          // Biblioteka do obsługi enkodera z przyciskiem
#include <HTTPClient.h>        // Biblioteka do wykonywania żądań HTTP, umożliwia komunikację z serwerami przez protokół HTTP
#include <Ticker.h>            // Mechanizm tickera do odświeżania timera 1s, pomocny do cyklicznych akcji w pętli głównej
#include <EEPROM.h>            // Bilbioteka obsługi emulacji pamięci EEPROM
#include <Time.h>              // Biblioteka do obsługi funkcji związanych z czasem, np. odczytu daty i godziny
#include "ESPAsyncWebServer.h" // Bliblioteka asyncrhionicznego serwera web
#include "AsyncTCP.h"          // Bliblioteka TCP dla serwera web
#include <Update.h>            // Blibioteka dla aktulizacji OTA
#include <ESPmDNS.h>           // Blibioteka mDNS dla ESP

#include "soc/rtc_cntl_reg.h"   // Biblioteki ESP aby móc zrobic pełny reset 
#include "soc/rtc_cntl_struct.h"// Biblioteki ESP aby móc zrobic pełny reset 
#include <esp_sleep.h>
#include "esp_system.h"
#include "freertos/semphr.h"

#include "esp_heap_caps.h"
#include "driver/spi_common.h"   // spi_host_device_t / SPI2_HOST dla LovyanGFX na Arduino-ESP32 3.x

//#include "rom/gpio.h"     // Biblioteka do mapowania pinu CS_SD
//#include "esp_wifi.h"     // Biblioteka do ustawienia pasma 20MHz


// --------------- DEFINICJA WERSJI RADIA i NAZWY HOSTA ---------------
#define softwareRev "v3.20.11-APMS-WEATHER-CITY"  // Wersja oprogramowania radia
#define hostname "evoradio"     // Definicja nazwy hosta widoczna w sieci
// --------------------------------------------------------------------


   
// ################ KONFIGURACJA UZYTKOWNIKA - START ################
// -- WYŚWIETLACZ / PANEL LovyanGFX --
// Uniwersalna konfiguracja dla trzech paneli:
//   EVO_PANEL_SSD1322  - OLED 256x64, układ jak w oryginalnym Evo Radio
//   EVO_PANEL_ILI9341  - TFT 320x240 po obrocie = 1
//   EVO_PANEL_ILI9488  - TFT 480x320 po obrocie = 1
//
// Wybierz tylko jeden panel. Możesz odkomentować jedną linię tutaj albo podać ją w build_flags PlatformIO.
// Jeżeli nic nie wybierzesz, domyślnie zostanie użyty SSD1322.
//#define EVO_PANEL_SSD1322
//#define EVO_PANEL_ILI9341
#define EVO_TFT_SPI_FREQ 27000000
#define EVO_TFT_NATIVE_FRAME_MS 110
#define EVO_TFT_NATIVE_DOUBLE_BUFFER 1   // V4: rysowanie do pelnego bufora 320x240 i dopiero potem push na TFT
#define EVO_TFT_NATIVE_ANIMATIONS 1      // V5: animacja startowa jak w oryginale, bez migotania ramek
#define EVO_TFT_NATIVE_BLOCK_LEGACY_BUFFER 1
#define EVO_TFT_NATIVE_DELTA_RENDER 1      // AUDIO SAFE: wysylaj na ILI9488 tylko zmienione fragmenty sprite 320x240
#define EVO_AUDIO_PRIORITY_MODE 1          // AUDIO SAFE: mniej blokowania petli audio.loop()
#define EVO_AUDIO_SAFE_FRAME_MS 110        // Odswiezanie glownego ekranu ok. 9 FPS, bez szarpania audio
#define EVO_TFT_VU_DYNAMIC_FRAME_MS 70      // APMS: szybsze odswiezanie VU 16/17/18
#define EVO_TFT_CLOCK_MOVIE_FRAME_MS 70     // APMS: plynna animacja cyfr zegara jak na filmie
#define EVO_AUDIO_SAFE_CLOCK_FRAME_MS 1000 // Zegar nie musi odswiezac TFT szybciej niz 1x/s
#define EVO_STANDBY_CLOCK_ALWAYS_AFTER_POWER_OFF 1  // APMS: po POWER OFF zawsze pokazuj zegar standby na TFT
#define EVO_TFT_STANDBY_CLOCK_BRIGHTNESS_MIN 45     // APMS: minimalna jasnosc zegara standby na TFT, bo 1 jest niewidoczne
#define EVO_TFT_STANDBY_CLOCK_FRAME_MS 40            // APMS: odswiezanie zegara standby podczas przewijania cyfr ok. 25 FPS
#define EVO_TFT_STANDBY_CLOCK_IDLE_MS 1000           // APMS: poza animacja budzimy zegar rowno na nastepna sekunde
#define EVO_TFT_STANDBY_CLOCK_ROLL_MS 680            // APMS: czas rolowania cyfry z dolu do gory, konczy sie przed nastepna sekunda
#define EVO_AUDIO_SAFE_MENU_FRAME_MS 180   // Menu i ekrany statyczne
#define EVO_AUDIO_LOOP_YIELD_EVERY 96      // vTaskDelay(1) tylko co kilkadziesiat petli, nie w kazdej petli
#define EVO_PANEL_ILI9488

#if !defined(EVO_PANEL_SSD1322) && !defined(EVO_PANEL_ILI9341) && !defined(EVO_PANEL_ILI9488)
  #define EVO_PANEL_SSD1322
#endif

#if (defined(EVO_PANEL_SSD1322) + defined(EVO_PANEL_ILI9341) + defined(EVO_PANEL_ILI9488)) != 1
  #error "Wybierz dokładnie jeden panel: EVO_PANEL_SSD1322, EVO_PANEL_ILI9341 albo EVO_PANEL_ILI9488"
#endif

// Interfejs radia był projektowany dla 256x64.
// SSD1322 pracuje natywnie 256x64, więc bez skalowania.
// ILI9341/ILI9488 dostają obraz z bufora 256x64 i skalują go na większy TFT.
#ifndef EVO_LGFX_SCALE_TO_PANEL
  #if defined(EVO_PANEL_SSD1322)
    #define EVO_LGFX_SCALE_TO_PANEL 0
  #else
    #define EVO_LGFX_SCALE_TO_PANEL 1
  #endif
#endif
#ifndef EVO_LGFX_CENTER_ON_TFT
  #define EVO_LGFX_CENTER_ON_TFT  1
#endif

// Opcjonalne strojenie panelu. Możesz zmienić przez build_flags albo tutaj.
#ifndef EVO_TFT_SPI_FREQ
  #if defined(EVO_PANEL_SSD1322)
    #define EVO_TFT_SPI_FREQ 27000000   // bezpieczna predkosc dla OLED SSD1322
  #elif defined(EVO_PANEL_ILI9341)
    #define EVO_TFT_SPI_FREQ 27000000    // ULTRA ILI9341
  #else
    #define EVO_TFT_SPI_FREQ 27000000   // stabilniejszy start dla ILI9488
  #endif
#endif
#ifndef EVO_TFT_BL

  #define EVO_TFT_BL -1          // pin podświetlenia TFT; dla SSD1322 zwykle zostaje -1
#endif
#ifndef EVO_TFT_BL_INVERT
  #define EVO_TFT_BL_INVERT false
#endif
#ifndef EVO_TFT_INVERT
  #define EVO_TFT_INVERT false
#endif
#ifndef EVO_TFT_RGB_ORDER
  #define EVO_TFT_RGB_ORDER false
#endif
#ifndef EVO_TFT_MISO
  #define EVO_TFT_MISO -1        // większość modułów TFT/OLED działa bez MISO
#endif


// Kolorowanie starego interfejsu OLED na TFT.
// Logika programu nadal rysuje w trybie 0/1 jak U8g2, ale na ILI9341
// pola, ramki i paski dostają kolor, a nie tylko biel.
#ifndef EVO_TFT_COLOR_BG
  #define EVO_TFT_COLOR_BG      0x0008  // bardzo ciemny niebieski
#endif
#ifndef EVO_TFT_COLOR_TEXT
  #define EVO_TFT_COLOR_TEXT    0xFFFF  // bialy tekst
#endif
#ifndef EVO_TFT_COLOR_ACCENT
  #define EVO_TFT_COLOR_ACCENT  0x07FF  // cyan - paski i wypelnienia
#endif
#ifndef EVO_TFT_COLOR_FRAME
  #define EVO_TFT_COLOR_FRAME   0xFD20  // pomaranczowy - ramki i linie
#endif
#ifndef EVO_TFT_COLOR_BITMAP
  #define EVO_TFT_COLOR_BITMAP  0xF81F  // magenta - bitmapy/ikony
#endif
#ifndef EVO_TFT_FAST_SCALE
  #define EVO_TFT_FAST_SCALE 1          // ULTRA: bufor ramki + jeden pushImage
#endif

// TURBO DELTA: wysyłamy na TFT tylko zmienione fragmenty obrazu, a nie całą klatkę.
#ifndef EVO_TFT_DELTA_RENDER
  #define EVO_TFT_DELTA_RENDER 0
#endif
#ifndef EVO_TFT_MIN_FRAME_MS
  #define EVO_TFT_MIN_FRAME_MS 80       // ULTRA limit odswiezania
#endif
#ifndef EVO_TFT_DIRTY_PAD_X
  #define EVO_TFT_DIRTY_PAD_X 2
#endif
#ifndef EVO_TFT_FULL_FRAMEBUFFER
  #define EVO_TFT_FULL_FRAMEBUFFER 1
#endif
#ifndef EVO_TFT_SHOW_STARTUP_TEST
  #define EVO_TFT_SHOW_STARTUP_TEST 0
#endif

#ifndef EVO_TFT_FONT_Y_OFFSET
  #define EVO_TFT_FONT_Y_OFFSET 2   // korekta pozycji tekstu U8g2 na LovyanGFX; usuwa scinanie gory liter
#endif


// ===== EVO TFT NATIVE UI v4 STABLE DOUBLE BUFFER =====
// 0 = stary interfejs OLED skalowany na TFT
// 1 = nowe ekrany kolorowe rysowane natywnie na calej powierzchni ILI9341 320x240 / ILI9488 480x320
#ifndef EVO_TFT_NATIVE_UI
  #define EVO_TFT_NATIVE_UI 1
#endif

#ifndef EVO_TFT_NATIVE_FRAME_MS
  #define EVO_TFT_NATIVE_FRAME_MS 55
#endif

#ifndef EVO_TFT_NATIVE_ALL_SCREENS
  #define EVO_TFT_NATIVE_ALL_SCREENS 1
#endif

#ifndef EVO_TFT_NATIVE_BLOCK_LEGACY_BUFFER
  #define EVO_TFT_NATIVE_BLOCK_LEGACY_BUFFER 1
#endif

#ifndef EVO_TFT_NATIVE_DOUBLE_BUFFER
  #define EVO_TFT_NATIVE_DOUBLE_BUFFER 1
#endif

#ifndef EVO_TFT_NATIVE_ANIMATIONS
  #define EVO_TFT_NATIVE_ANIMATIONS 1
#endif

#ifndef EVO_TFT_NATIVE_DELTA_RENDER
  #define EVO_TFT_NATIVE_DELTA_RENDER 1
#endif
#ifndef EVO_AUDIO_PRIORITY_MODE
  #define EVO_AUDIO_PRIORITY_MODE 1
#endif
#ifndef EVO_AUDIO_SAFE_FRAME_MS
  #define EVO_AUDIO_SAFE_FRAME_MS 110
#endif
#ifndef EVO_AUDIO_SAFE_CLOCK_FRAME_MS
  #define EVO_AUDIO_SAFE_CLOCK_FRAME_MS 1000
#endif
#ifndef EVO_AUDIO_SAFE_MENU_FRAME_MS
  #define EVO_AUDIO_SAFE_MENU_FRAME_MS 180
#endif
#ifndef EVO_AUDIO_LOOP_YIELD_EVERY
  #define EVO_AUDIO_LOOP_YIELD_EVERY 96
#endif

// Natywny interfejs radia jest rysowany logicznie w ukladzie 320x240,
// a dla ILI9488 gotowa klatka jest skalowana na pelny ekran 480x320.
#ifndef EVO_TFT_NATIVE_VIRTUAL_W
  #define EVO_TFT_NATIVE_VIRTUAL_W 320
#endif
#ifndef EVO_TFT_NATIVE_VIRTUAL_H
  #define EVO_TFT_NATIVE_VIRTUAL_H 240
#endif

#ifndef EVO_TFT_NATIVE_BG
  #define EVO_TFT_NATIVE_BG       0x0010
#endif
#ifndef EVO_TFT_NATIVE_PANEL
  #define EVO_TFT_NATIVE_PANEL    0x018C
#endif
#ifndef EVO_TFT_NATIVE_CARD
  #define EVO_TFT_NATIVE_CARD     0x02B5
#endif
#ifndef EVO_TFT_NATIVE_TEXT
  #define EVO_TFT_NATIVE_TEXT     0xFFFF
#endif
#ifndef EVO_TFT_NATIVE_MUTED
  #define EVO_TFT_NATIVE_MUTED    0xC638
#endif
#ifndef EVO_TFT_NATIVE_CYAN
  #define EVO_TFT_NATIVE_CYAN     0x07FF
#endif
#ifndef EVO_TFT_NATIVE_GREEN
  #define EVO_TFT_NATIVE_GREEN    0x07E0
#endif
#ifndef EVO_TFT_NATIVE_YELLOW
  #define EVO_TFT_NATIVE_YELLOW   0xFFE0
#endif
#ifndef EVO_TFT_NATIVE_ORANGE
  #define EVO_TFT_NATIVE_ORANGE   0xFD20
#endif
#ifndef EVO_TFT_NATIVE_RED
  #define EVO_TFT_NATIVE_RED      0xF800
#endif
// SSD1322 nie występuje w wielu standardowych wydaniach LovyanGFX jako Panel_SSD1322.
// Dlatego domyślnie SSD1322 działa przez bezpieczny backend U8g2, ale cały program nadal używa jednego obiektu `gfx`.
// ILI9341 oraz ILI9488 działają przez czysty LovyanGFX.
#ifndef EVO_SSD1322_USE_U8G2_FALLBACK
  #define EVO_SSD1322_USE_U8G2_FALLBACK 1
#endif

// Jeżeli masz własny fork LovyanGFX z klasą SSD1322, ustaw:
//   -DEVO_SSD1322_USE_U8G2_FALLBACK=0
//   -DEVO_SSD1322_PANEL_CLASS=TwojaKlasaPaneluSSD1322
#if defined(EVO_PANEL_SSD1322) && !EVO_SSD1322_USE_U8G2_FALLBACK
  #ifndef EVO_SSD1322_PANEL_CLASS
    #error "Dla czystego LovyanGFX SSD1322 podaj -DEVO_SSD1322_PANEL_CLASS=... albo zostaw fallback U8g2"
  #endif
#endif

//-- SPI wydajnosc pradowa --
//#define LOWNOISESPI   // Ustawia wydajnosc pradowa pinow SPI (0 - najnizsza, niskie szumy; 3-najwyzsza, duze szumy), redukcja EMI

//-- OBSLUGA PAMIECI STORAGE --
#define AUTOSTORAGE   // Definicja czy mamy właczony autostorage  (automatyczny wybor karta SD/ pamiec LittleFS lub SPIFFS w zaleznosci od ponizszej delkaracji)
#define USE_SD        // Uzywamy karty SD , zostawiamy w przypadku AUTOSTORAGE lub gdy chcemy tylko uzywać karty SD
//#define USE_SPIFFS  // Definijuemy czy w przypadku uzywania pamieci wewnetrznej bedzie to SPIFFS czy LittleFS. Odkomentowac TYLKO jedno LittleFS lub SPIFFS !
#define USE_LittleFS  // Patrz powyzej

// -- DRUGI ENKODER --
//#define twoEncoders // Wlaczamy drugi enkoder

// -- DODATKi - Komunikacja RS232, Wzmacniacz TAS itp. --
//#define SERIALCOM   // Komunikacja dwukierunkowa RS232
//#define TAS5805       // Kompilacja dla wersji ze Wzmacniacz TAS5805 z wbudowanym DAC, zakomentowac w przypadku tandardowe PCM5102

const bool f_logoSlowBrightness = 1; // Zalaczenie powolnego rozjasniania logo

// --------------- PRZYCISKI i LEDy ---------------
//#define SW_POWER 8        // Dedykowany przycisk Power
#define STANDBY_LED 17    // LED do informowania o trybie Standby
#define IR_LED 17        // LED aktywności odbiornika IR
//#define SD_LED 17       // LED aktywnosci karty SD, sygnalizacja syngału CS karty, klon pinu uzyteczny w przypadku uzywania czytnika SD
#define IR_LED_ON 1
#define IR_LED_OFF 0
// ################ KONFIGURACJA UZYTKOWNIKA - KONIEC ################



// --------------- TAS5805 / PCM5102 ---------------
#ifdef TAS5805 //PowerAmp with I2S & DSP                 
  #include <Wire.h>           // I2C dla komunikacji z TI TAS5805
  #define I2C_CLK 9           // GPIO CLOCK I2C
  #define I2C_DATA 8          // GPIO DATA I2C
  #define TAS5805_ADDR 0x2D   // Adres I2C TAS5805, pull-up na ADR/#FAULT 10k podbicie adresu o 1
  
  // --------------- TAS5805 - definicja pinow AMPa z przetwornikiem ---------------
  #define I2S_DOUT 16        // Podłączenie do pinu DIN na DAC TAS
  #define I2S_BCLK 14        // Podłączenie po pinu BCK na DAC TAS
  #define I2S_LRC 15         // Podłączenie do pinu LCK na DAC TAS 
  #define recv_pin 7
#else //PCM5012 simple DAC
  // --------------- PCM5102A - definicja pinow przetwornika ---------------
  #define I2S_DOUT 13             // Podłączenie do pinu DIN na DAC
  #define I2S_BCLK 12             // Podłączenie po pinu BCK na DAC
  #define I2S_LRC 14              // Podłączenie do pinu LCK na DAC 
  //#define I2S_MCLK 18           // Pełny I2S z MCLK dla SPDIF/TOSLINK
  
  // --------------- IR odbiornik podczerwieni ---------------
  #define recv_pin 15
#endif


// --------------- CZYTNIK KART SD (Opcjonalny) ---------------
#define SD_CS 47    // Pin CS (Chip Select) dla karty SD wybierany jako interfejs SPI
#define SD_SCLK 45  // Pin SCK (Serial Clock) dla karty SD
#define SD_MISO 21  // Pin MISO (Master In Slave Out) dla karty SD
#define SD_MOSI 48  // pin MOSI (Master Out Slave In) dla karty SD

// ------ AUTO WYKRYWANIE STORAGE - Karta SD / LittleFS -----
#ifdef AUTOSTORAGE
  
  #ifdef USE_SPIFFS 
    #include "SPIFFS.h"
  #endif

  #ifdef USE_LittleFS
    #include "LittleFS.h"
  #endif
  
  #include "SD.h"
  #define STORAGE (*_storage)
  bool initStorage();
  bool useSD = false;
  const char* storageTextName = nullptr;
  fs::FS* _storage = nullptr;
#else
  #ifdef USE_SD
    #include "SD.h"
    #define STORAGE SD
    #define STORAGE_BEGIN() SD.begin(SD_CS, customSPI)
    const bool useSD = true;
    #define storageTextName "SD"

  #elif defined(USE_LittleFS) 
    #include "LittleFS.h"
    #define STORAGE LittleFS
    #define STORAGE_BEGIN() LittleFS.begin(true)  // Dla LittleFS, stabilniej działa i nie przerywa audio
    const bool useSD = false;
    #define storageTextName "LittleFS"
  
  #elif defined(USE_SPIFFS)
    #include "SPIFFS.h" 
    #define STORAGE LittleFS
    #define STORAGE_BEGIN() SPIFFS.begin(true)  // Stary system plikow dla kompatybilnosci
    const bool useSD = false;
    #define storageTextName "SPIFFS"
  #endif 
#endif
 
// --------------- OLED Wyswietlacz - definicja pinow ---------------
#define SPI_MOSI_OLED 39  // Pin MOSI (Master Out Slave In) dla interfejsu SPI OLED
#define SPI_MISO_OLED -1  // brak MISO dla wyswietlacza TFT
#define SPI_SCK_OLED 38   // Pin SCK (Serial Clock) dla interfejsu SPI OLED
#define CS_OLED -1          // CS ekranu fizycznie do GND - sprawdzone na ILI9488
#define DC_OLED 40         // DC/RS ekranu ILI9488
#define RESET_OLED 41      // RST ekranu ILI9488


// Rozmiar wysweitlacz OLED (potrzebny do wyświetlania grafiki)
#define SCREEN_WIDTH 256        // Szerokość ekranu w pikselach
#define SCREEN_HEIGHT 64        // Wysokość ekranu w pikselach

 

// --------------- ENCODER 2 (MAIN) ---------------
// Jesli jedyny to Volume/Stacje/Banki/PowerOff/PowerOn jesli z Enkoderem1 to Stacje/Banki
#define CLK_PIN2 10             // Podłączenie z pinu 10 do CLK na enkoderze
#define DT_PIN2 11              // Podłączenie z pinu 11 do DT na enkoderze lewym
#define SW_PIN2 1               // Podłączenie z pinu 1 do SW na enkoderze lewym (przycisk)

// --------------- ENCODER 1 (dodatkowy) ---------------
// Jesli zdefinionway to Volume/Mute/PowerOff/PowerOn
#ifdef twoEncoders
  #define CLK_PIN1 6              // Podłączenie z pinu 6 do CLK na enkoderze prawym
  #define DT_PIN1 5               // Podłączenie z pinu 5 do DT na enkoderze prawym
  #define SW_PIN1 4               // Podłączenie z pinu 4 do SW na enkoderze prawym (przycisk)
  const bool use2encoders = true;
  // Zmienne enkodera 1
  int CLK_state1 = 0;
  int prev_CLK_state1 = 0;
  int buttonLongPressTime1 = 150;
  int buttonSuperLongPressTime1 = 2000;
  bool action4Taken = false;        // Flaga Akcji 4 - enkoder 1, powerOFF
  bool action5Taken = false;        // Flaga Akcji 5 - enkoder 1, Menu Bank
#else
  const bool use2encoders = false;
#endif


// --------------- USTAWIENIE TIMERa dla trybu POWEROFF --------------- 
#define WAKEUP_INTERVAL_US (60ULL * 1000000ULL) // 1 minuta

// definicja dlugosci ilosci stacji w banku, dlugosci nazwy stacji w PSRAM/EEPROM, maksymalnej ilosci plikow audio (odtwarzacz)
#define MAX_STATIONS 99          // Maksymalna liczba stacji radiowych, które mogą być przechowywane w jednym banku
#define STATION_NAME_LENGTH 220  // Nazwa stacji wraz z bankiem i numerem stacji do wyświetlenia w pierwszej linii na ekranie
#define MAX_FILES 100            // Maksymalna liczba plików lub katalogów w tablicy directoriesz
#define bank_nr_max 17           // Numer jaki może osiągnac maksymalnie zmienna bank_nr czyli ilość banków
#define displayModeMax 21        // APMS: 20 Movie Clock, 21 panel informacyjny WiFi

// DEBUG PRINTS - ON/OFF
#define f_debug_web_on 0         // Flaga właczenia wydruku debug_web
#define f_debug_on 0             // Flaga właczenia wydruku debug

//String STATIONS_URL1 = "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank01.txt";   // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL1  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank01.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL2  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank02.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL3  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank03.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL4  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank04.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL5  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank05.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL6  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank06.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL7  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank07.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL8  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank08.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL9  "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank09.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL10 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank10.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL11 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank11.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL12 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank12.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL13 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank13.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL14 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank14.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL15 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank15.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL16 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank16.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL17 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank17.txt"  // Adres URL do pliku z listą stacji radiowych
#define STATIONS_URL18 "https://raw.githubusercontent.com/dzikakuna/ESP32_radio_streams/main/bank18.txt"  // Adres URL do pliku z listą stacji radiowych


// --------------- DEFINICJA TEKSTOW ---------------
#define SLEEP_STRING "SLEEP "
#define SLEEP_STRING_VAL " MINUTES"
#define SLEEP_STRING_OFF "OFF"

#ifdef LANG_EN
static const char* months[] = {
    "JANUARY",
    "FEBRUARY",
    "MARCH",
    "APRIL",
    "MAY",
    "JUNE",
    "JULY",
    "AUGUST",
    "SEPTEMBER",
    "OCTOBER",
    "NOVEMBER",
    "DECEMBER"
};
#endif

// --------------- KOMUNIKACJA MODUŁU RADIA PO RS232 ---------------
#ifdef SERIALCOM
  #include "serialcom.h"   // Integracja jako moduł z komunikacja po RS232
#endif


// --------------- Zmienne  DLA PILOTa IR w standardzie NEC - przeniesiona do pliku txt ---------------
uint16_t rcCmdVolumeUp = 0;   // Głosnosc +
uint16_t rcCmdVolumeDown = 0; // Głośnosc -
uint16_t rcCmdArrowRight = 0; // strzałka w prawo - nastepna stacja
uint16_t rcCmdArrowLeft = 0;  // strzałka w lewo - poprzednia stacja  
uint16_t rcCmdArrowUp = 0;    // strzałka w góre - lista stacji krok do gory
uint16_t rcCmdArrowDown = 0;  // strzałka w dół - lista stacj krok na dół
uint16_t rcCmdBack = 0;	      // Przycisk powrotu
uint16_t rcCmdOk = 0;         // Przycisk Ent - zatwierdzenie stacji
uint16_t rcCmdSrc = 0;        // Przełączanie źródła radio, odtwarzacz
uint16_t rcCmdMute = 0;       // Wyciszenie dzwieku
uint16_t rcCmdAud = 0;        // Equalizer dzwieku
uint16_t rcCmdDirect = 0;     // Janość ekranu, dwa tryby 1/16 lub pełna janość     
uint16_t rcCmdBankMinus = 0;  // Wysweitla wybór banku
uint16_t rcCmdBankPlus = 0;   // Wysweitla wybór banku
uint16_t rcCmdRed = 0;        // Przełacza ładowanie banku kartaSD - serwer GitHub w menu bank
uint16_t rcCmdGreen = 0;      // VU wyłaczony, VU tryb 1, VU tryb 2, zegar
uint16_t rcCmdKey0 = 0;       // Przycisk "0"
uint16_t rcCmdKey1 = 0;       // Przycisk "1"
uint16_t rcCmdKey2 = 0;       // Przycisk "2"
uint16_t rcCmdKey3 = 0;       // Przycisk "3"
uint16_t rcCmdKey4 = 0;       // Przycisk "4"
uint16_t rcCmdKey5 = 0;       // Przycisk "5"
uint16_t rcCmdKey6 = 0;       // Przycisk "6"
uint16_t rcCmdKey7 = 0;       // Przycisk "7"
uint16_t rcCmdKey8 = 0;       // Przycisk "8"
uint16_t rcCmdKey9 = 0;       // Przycisk "9"
uint16_t rcCmdPower = 0;       // Przycisk Power
// Koniec definicji pilota IR

bool  f_callInfo = 0;       // Flaga czy wsiwetlamy "INFO" również na OLED
bool  f_logo = 0;           // Flaga czy wyswietlamy logo
bool  f_simpleMode3 =0;

int currentSelection = 0;                     // Numer aktualnego wyboru na ekranie OLED
int firstVisibleLine = 0;                     // Numer pierwszej widocznej linii na ekranie OLED
uint8_t station_nr = 0;                       // Numer aktualnie wybranej stacji radiowej z listy
int stationFromBuffer = 0;                    // Numer stacji radiowej przechowywanej w buforze do przywrocenia na ekran po bezczynności
uint8_t bank_nr;                              // Numer aktualnie wybranego banku stacji z listy
uint8_t previous_bank_nr = 0;                 // Numer banku przed wejsciem do menu zmiany banku
//int bankFromBuffer = 0;                       // Numer aktualnie wybranego banku stacji z listy do przywrócenia na ekran po bezczynności

//Enkoder 2 (podstawowy)
int CLK_state2;                               // Aktualny stan CLK enkodera lewego
int prev_CLK_state2;                          // Poprzedni stan CLK enkodera lewego
int stationsCount = 0;                        // Aktualna liczba przechowywanych stacji w tablicy
int buttonLongPressTime2 = 2000;              // Czas reakcji na długie nacisniecie enkoder 2
int buttonShortPressTime2 = 500;              // Czas rekacjinna krótkie nacisniecie enkodera 2
int buttonSuperLongPressTime2 = 3000;         // Czas reakcji na super długie nacisniecie enkoder 2

uint8_t volumeValue = 10;                     // Wartość głośności, domyślnie ustawiona na 10
uint8_t maxVolume = 21;
bool maxVolumeExt =  false;                   // 0(false) -  zakres standardowy Volume 1-21 , 1 (true) - zakres rozszerzony 0-42
uint8_t volumeBufferValue = 0;                // Wartość głośności, domyślnie ustawiona na 10
int maxVisibleLines = 4;                      // Maksymalna liczba widocznych linii na ekranie OLED
int bitrateStringInt = 0;                     // Deklaracja zmiennej do konwersji Bitrate string na wartosc Int aby podzelic bitrate przez 1000
int SampleRate = 0;
int SampleRateRest = 0;
int audioBufferTime = 0;                      // Zienna trzymajca informacje o ilosci sekund muzyki w buforze audio

uint8_t stationNameLenghtCut = 24;            // 24-> 25 znakow, 25-> 26 znaków, zmienna określająca jak długa nazwę ma nazwa stacji w plikach Bankow liczone od 0- wartosci ustalonej
const uint8_t yPositionDisplayScrollerMode0 = 33;   // Wysokosc (y) wyswietlania przewijanego/stalego tekstu stacji w danym trybie
const uint8_t yPositionDisplayScrollerMode1 = 61;   // Wysokosc (y) wyswietlania przewijanego/stalego tekstu stacji w danym trybie
const uint8_t yPositionDisplayScrollerMode2 = 25;   // Wysokosc (y) wyswietlania przewijanego/stalego tekstu stacji w danym trybie
const uint8_t yPositionDisplayScrollerMode3 = 49;   // Wysokosc (y) wyswietlania przewijanego/stalego tekstu stacji w danym trybie
const uint8_t yPositionDisplayScrollerMode5 = 35;   // Wysokosc (y) wyswietlania przewijanego/stalego tekstu stacji w danym trybie
const uint8_t stationNamePositionYmode3 = 31;
const uint8_t stationNamePositionYmode5 = 26;
uint16_t stationStringScrollLength = 0;
uint8_t maxStationVisibleStringScrollLength = 46;
bool stationNameFromStream = 0;               // Flaga definiujaca czy wyswietlamy nazwe stacji z plikow Banku pamieci czy z informacji nadawanych w streamie
bool f_powerOff = 0;                          // Flaga aktywnego trybu power off (ESP light sleep)
bool f_sleepTimerOn = false;
uint8_t sleepTimerValueSet = 0;           // Zmiena przechowujaca ustawiony czas - nie uzywana obecnie
uint8_t sleepTimerValueCounter = 0;         // Licznik funkcji sleep timer dekrementowany przez Timer3 co 1 minute
uint8_t sleepTimerValueStep = 15;           // Krok funkcji sleep timer o ile zwieksza się timer
uint8_t sleepTimerValueMax = 90;            // Maksymalna wartosc sleep timera jaka da się ustawić
//uint8_t bank_nr_max = 16;


// ---- Głosowe odtwarzanie czasu co godzinę ---- //
bool f_requestVoiceTimePlay = false; 
bool timeVoiceInfoEveryHour = true;
unsigned long voiceTimeMillis = 0;
uint16_t voiceTimeReturnTime = 4000;


// ---- Auto dimmer / auto przyciemnianie wyswietlacza ---- //
uint8_t displayDimmerTimeCounter = 0;  // Zmienna inkrementowana w przerwaniu timera2 do przycimniania wyswietlacz
uint8_t dimmerDisplayBrightness = 10;   // Wartość przyciemnienia wyswietlacza po czasie niekatywnosci
uint8_t dimmerSleepDisplayBrightness = 1; // Wartość przyciemnienia wyswietlacza po czasie niekatywnosci
uint8_t displayBrightness = 180;        // Domyślna maksymalna janość wyswietlacza
uint16_t displayAutoDimmerTime = 5;   // Czas po jakim nastąpi przyciemninie wyswietlacza, liczony w sekundach
bool displayAutoDimmerOn = false;       // Automatyczne przyciemnianie wyswietlacza, domyślnie włączone
bool displayDimmerActive = false;       // Aktywny tryb przyciemnienia
uint16_t displayPowerSaveTime = 30;    // Czas po jakim zostanie wyłączony wyswietlacz OLED (tryb power save)
uint16_t displayPowerSaveTimeCounter = 0;    // Timer trybu Power Save wyswietlacza OLED
bool displayPowerSaveEnabled = false;   // Flaga okreslajaca czy tryb wyłączania wyswietlacza OLED jest właczony
uint8_t displayMode = 0;               // Tryb wyswietlacza 0-displayRadio z przewijaniem "scroller" / 1-Zegar / 2- tryb 3 stałych linijek tekstu stacji

// ---- Equalzier ---- //
int8_t toneLowValue = 0;               // Wartosc filtra dla tonow niskich
int8_t toneMidValue = 0;               // Wartosc flitra dla tonow srednich
int8_t toneHiValue = 0;                // Wartość filtra dla tonow wysokich
int8_t balanceValue = 0;                // Wartość balansu
uint8_t toneSelect = 1;                // Zmienna okreslająca, który filtr equalizera regulujemy, startujemy od pierwszego

bool equalizerMenuEnable = false;      // Flaga wyswietlania menu Equalizera

// ------ Wprowadzaeni cyfr z pilota / klawiatury ------ //
uint8_t rcInputDigit1 = 0xFF;      // Pierwsza cyfra w przy wprowadzaniu numeru stacji z pilota
uint8_t rcInputDigit2 = 0xFF;      // Druga cyfra w przy wprowadzaniu numeru stacji z pilota
bool f_Presets = false;     // Flaga okreslajaca czy przelaczamy stacje czy wprowadzamy numer stacji czy 1-10 jako ulubione stacje
bool f_Presets2 = false;
bool f_Presets3 = false;



// ---- Zmienne konfiguracji ---- //
#define CONFIG_COUNT 26
uint16_t configArray[CONFIG_COUNT] = {0};
uint8_t rcPage = 0;
#define CONFIGREMOTE_COUNT 26
uint16_t configRemoteArray[CONFIGREMOTE_COUNT] = {0};   // Tablica przechowująca kody pilota podczas odczytu z pliku

/*
struct RemoteMap
{
  const char* name;
  //uint8_t index;
};
RemoteMap remoteMap[CONFIGREMOTE_COUNT] = {
    {"cmdVolumeUp"},
    {"cmdVolumeDown"},
    {"cmdArrowRight"},
    {"cmdArrowLeft"},
    {"cmdArrowUp"},
    {"cmdArrowDown"},
    {"cmdBack"},
    {"cmdOk"},
    {"cmdSrc"},
    {"cmdMute"},
    {"cmdAud"},
    {"cmdDirect"},
    {"cmdBankMinus"},
    {"cmdBankPlus"},
    {"cmdRed"},
    {"cmdGreen"},
    {"cmdKey0"},
    {"cmdKey1"},
    {"cmdKey2"},
    {"cmdKey3"},
    {"cmdKey4"},
    {"cmdKey5"},
    {"cmdKey6"},
    {"cmdKey7"},
    {"cmdKey8"},
    {"cmdKey9"}
};

*/

uint16_t configAdcArray[24] = {0};      // Tablica przechowująca wartosci ADC dla przyciskow klawiatury
bool configExist = true;                  // Flaga okreslajaca czy istnieje plik konfiguracji
bool f_displayPowerOffClock = false;      // Flaga okreslajaca czy w trybie sleep ma się wyswietlac zegar
bool f_sleepAfterPowerFail = false;       // Flaga czy idziemy do powerOFF po powrocie zasilania
bool f_saveVolumeStationAlways = false;   // Flaga określająca czy zapisujemy stacje, bank i poziom volume zawsze czy tylko przy power OFF
//bool f_statusLED = false;
bool f_powerOffAnimation = false;             // Animacja przy power OFF
bool remoteConfig = false;

bool encoderButton2 = false;      // Flaga określająca, czy przycisk enkodera 2 został wciśnięty
bool encoderFunctionOrder = false; // Flaga okreslająca kolejność funkcji enkodera 2
bool displayActive = false;       // Flaga określająca, czy wyświetlacz jest aktywny

bool mp3 = false;                 // Flaga określająca, czy aktualny plik audio jest w formacie MP3
bool flac = false;                // Flaga określająca, czy aktualny plik audio jest w formacie FLAC
bool aac = false;                 // Flaga określająca, czy aktualny plik audio jest w formacie AAC
bool vorbis = false;              // Flaga określająca, czy aktualny plik audio jest w formacie VORBIS
bool opus = false;
bool timeDisplay = true;          // Flaga określająca kiedy pokazać czas na wyświetlaczu, domyślnie od razu po starcie
bool listedStations = false;      // Flaga określająca czy na ekranie jest pokazana lista stacji do wyboru
bool bankMenuEnable = false;      // Flaga określająca czy na ekranie jest wyświetlone menu wyboru banku
bool bitratePresent = false;      // Flaga określająca, czy na serial terminalu pojawiła się informacja o bitrate - jako ostatnia dana spływajaca z info
bool bankNetworkUpdate = false;   // Flaga wyboru aktualizacji banku z sieci lub karty SD - True aktulizacja z interNETu
bool volumeMute = false;          // Flaga okreslająca stan funkcji wyciszczenia - Mute
bool volumeSet = false;           // Flaga wejscia menu regulacji głosnosci na enkoderze 2

bool action3Taken = false;        // Flaga Akcji 3

bool ActionNeedUpdateTime = false;// Zmiena okresaljaca dla displayRadio potrzebe odczytu aktulizacji czasu
bool debugAudioBuffor = false;    // Wyswietlanie bufora Audio
bool f_audioInfoRefreshStationString = false;    // Flaga wymuszjąca wymagane odsiwezenie ze względu na zmianę info stream - stationstring, title, 
bool f_audioInfoRefreshDisplayRadio = false;    // Flaga wymuszjąca wymagane odsiwezenie ze względu na zmianę info stream - linia kbps, khz, format streamu
bool resumePlay = false;            // Flaga wymaganego uruchomienia odtwarzania po zakonczeniu komunikatu głosowego
bool fwupd = false;               // Flaga blokujaca main loop podczas aktualizacji oprogramowania
bool configIrExist = false;       // Flaga informująca o istnieniu poprawnej konfiguracji pilota IR
bool wsAudioRefresh = false;      // Flaga informujaca o potrzebe odswiezeninia Station Text za pomoca Web Sokcet
bool f_voiceTimeBlocked = false;
bool f_displaySleepTime = false;    // Flaga wysiwetlania menu timera
bool f_displaySleepTimeSet = false;    // Flaga ustawienia sleep timera

bool noSDcard = false;              // flaga ustawiana przy braku wykrycia karty SD
bool noStorage = false;             // flaga ustawiana przy problemie z pamiecia SPIFFS/LittleFS

unsigned long debounceDelay = 300;    // Czas trwania debouncingu w milisekundach
unsigned long displayTimeout = 3000;  // Czas wyświetlania komunikatu na ekranie w milisekundach
unsigned long displayStartTime = 0;   // Czas rozpoczęcia wyświetlania komunikatu
unsigned long seconds = 0;            // Licznik sekund timera
unsigned int PSRAM_lenght = MAX_STATIONS * (STATION_NAME_LENGTH) + MAX_STATIONS; // deklaracjia długości pamięci PSRAM
unsigned long lastCheckTime = 0;      // No stream audio blink
//uint8_t stationNameStreamWidth = 0;   // Test pełnej nazwy stacji
uint64_t seconds2nextMinute;
uint64_t micros2nextMinute;

// ---- VU Meter ---- //
unsigned long vuMeterTime;                 // Czas opznienia odswiezania wskaznikow VU w milisekundach
uint8_t vuMeterL;                          // Wartosc VU dla L kanału zakres 0-255
uint8_t vuMeterR;                          // Wartosc VU dla R kanału zakres 0-255
uint8_t peakL = 0;                         // Wartosc peakHold dla kanalu lewego
uint8_t peakR = 0;                         // Wartosc peakHold dla kanalu prawego
uint8_t peakHoldTimeL = 0;                 // Licznik peakHold dla kanalu lewego
uint8_t peakHoldTimeR = 0;                 // Licznik peakHold dla kanalu prawego
const uint8_t peakHoldThreshold = 5;       // Liczba cykli zanim peak opadnie
const uint8_t vuLy = 41;                   // Koordynata Y wskaznika VU L-lewego (wyzej)
const uint8_t vuRy = 47;                   // Koordynata Y wskaznika VU R-prawego (nizej)
const uint8_t vuLyMode3 = 54;              // Koordynata Y wskaznika VU L-lewego (wyzej)
const uint8_t vuRyMode3 = 60;              // Koordynata Y wskaznika VU R-prawego (nizej
const uint8_t vuLyMode5 = 43;                   // Koordynata Y wskaznika VU L-lewego (wyzej)
const uint8_t vuRyMode5 = 49;                   // Koordynata Y wskaznika VU R-prawego (nizej)
const uint8_t vuThicknessMode3 = 1;        // Grubosc kreseczki wskaznika VU w trybie Mode3
const int vuCenterXmode3 = 128;            // Pozycja centralna startu VU w trybie Mode 3
const int vuYmode3 = 62;                   // Polozenie wyokosci (Y) VU w trybie Mode 3
bool vuPeakHoldOn = 1;                     // Flaga okreslajaca czy funkcja Peak & Hold na wskazniku VUmeter jest wlaczona
bool vuMeterOn = true;                     // Flaga właczajaca wskazniki VU
bool vuMeterMode = false;                  // tryb rysowania vuMeter
uint8_t displayVuL = 0;                    // wartosc VU do wyswietlenia po procesie smooth
uint8_t displayVuR = 0;                    // wartosc VU do wyswietlenia po procesie smooth
uint8_t vuRiseSpeed = 24;                  // szybkość narastania VU
uint8_t vuFallSpeed = 6;                   // szybkość opadania VU
bool vuSmooth = 1;                         // Flaga zalaczenia funkcji smootht (domyslnie wlaczona=1)
uint8_t evo46VuDrive = 65;                  // Globalny poziom wysterowania VU/analizatorow 10-200%, domyslnie 65 aby wskazniki nie byly stale na 100%
uint8_t vuRiseNeedleSpeed = 2;                  // szybkość narastania VU
uint8_t vuFallNeedleSpeed = 6;                   // szybkość opadania VU
bool reversColorMode4 = true;

// Volume Fade
unsigned long lastFadeTime = 0;
const unsigned long fadeStepDelay = 20; // ms
bool fadingIn = false;
uint8_t targetVolume = 0;
uint8_t currentVolume = 0;
bool f_volumeFadeOn = 0;
uint8_t volumeFadeOutTime = 20; //ms * volumeValue
uint8_t volumeSleepFadeOutTime = 50;

unsigned long scrollingStationStringTime;  // Czas do odswiezania scorllingu
uint8_t scrollingRefresh = 50;              // Czas w ms przewijania tekstu funkcji Scroller

uint8_t vuMeterRefreshCounterSet = 0;      // Mnoznik co ile petli loopRefreshTime ma byc odswiezony VU Meter
uint8_t scrollerRefreshCounterSet = 0;     // Mnoznik co ile petli loopRefreshTime ma byc odswiezony i przewiniety o 1px Scroller

uint16_t stationStringScrollWidth;         // szerokosc Stringu nazwy stacji w funkcji Scrollera
uint16_t xPositionStationString = 0;       // Pozycja początkowa dla przewijania tekstu StationString
uint16_t offset;                           // Zminnna offsetu dla funkcji Scrollera - przewijania streamtitle na ekranie OLED
unsigned char * psramData;                 // zmienna do trzymania danych stacji w pamieci PSRAM

unsigned long vuMeterMilisTimeUpdate;           // Zmienna przechowujaca czas dla funkci millis VU Meter refresh
uint8_t vuMeterRefreshTime = 50;                // Czas w ms odswiezania VUmetera

uint8_t wifiSignalLevel = 0;
uint8_t wifiSignalLevelLast = 7;          // Pamiecm poprzedniego stanu signalLevel

// ---- Serwer Web ---- //
unsigned long currentTime = millis();
unsigned long previousTime = 0;
const long timeoutTime = 2000;
bool urlToPlay = false;
bool urlPlaying = false;


// ---- Sprawdzenie funkcji pilota, zminnne do pomiaru róznicy czasów ---- //
unsigned long runTime = 0;
unsigned long runTime1 = 0;
unsigned long runTime2 = 0;


String stationStringScroll = "";     // Zmienna przechowująca tekst do przewijania na ekranie
String stationName;                  // Nazwa aktualnie wybranej stacji radiowej
String stationString;                // Dodatkowe dane stacji radiowej (jeśli istnieją)
String stationStringWeb;                // Dodatkowe dane stacji radiowej (jeśli istnieją)
String bitrateString;                // Zmienna przechowująca informację o bitrate
String sampleRateString;             // Zmienna przechowująca informację o sample rate
String bitsPerSampleString;          // Zmienna przechowująca informację o liczbie bitów na próbkę
String currentIP;


// ==================== APMS WEATHER / POGODA W PANELU RADIO INFO ====================
// Miasto ustawiane z poziomu /config. Dane pobierane okresowo z wttr.in.
// W panelu RADIO INFO zastępuje pole "Gatunek" przewijaną pogodą dla wybranej miejscowości.
String evoWeatherCity = "Golotczyzna";
String evoWeatherText = "Pogoda: czekam na dane...";
String evoWeatherLastError = "";
bool evoWeatherOk = false;
unsigned long evoWeatherLastFetchMs = 0;
const unsigned long EVO_WEATHER_REFRESH_MS = 15UL * 60UL * 1000UL; // 15 minut
const char* EVO_WEATHER_CFG_FILE = "/weather_city.txt";
// ================================================================================
String stationNameStream;           // Nazwa stacji wyciągnieta z danych wysylanych przez stream

// APMS META FIX: osobne pola dla metadanych utworu.
// Nazwa stacji nie moze nadpisywac miejsca, w ktorym ma byc wykonawca i tytul.
String evoNowPlayingRaw = "";
String evoNowPlayingArtist = "";
String evoNowPlayingTitle = "";
String evoNowPlayingText = "";
bool evoNowPlayingValid = false;
unsigned long evoNowPlayingMs = 0;
String streamCodec;
String stationLogoUrl;
String timezone;


String header;                      // Zmienna dla serwera www
String sliderValue = "0";
String url2play = "";


File myFile;  // Uchwyt pliku



static void evoHardResetTFT()
{
  #if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && (RESET_OLED >= 0)
    pinMode(RESET_OLED, OUTPUT);
    digitalWrite(RESET_OLED, HIGH);
    delay(20);
    digitalWrite(RESET_OLED, LOW);
    delay(120);
    digitalWrite(RESET_OLED, HIGH);
    delay(250);
  #endif
}

// ################################################################################################################### //
// WARSTWA WYŚWIETLACZA LovyanGFX
//
// Stary obiekt U8G2 został usunięty. Obiekt `gfx` rysuje przez LovyanGFX + LGFX_Sprite.
// Zachowany jest logiczny bufor 256x64, aby istniejący interfejs radia nie wymagał ręcznego przepisywania layoutu.
// SSD1322 pracuje natywnie 256x64, a ILI9341/ILI9488 mogą skalować ten bufor na większy TFT.
// ################################################################################################################### //

#if defined(EVO_PANEL_SSD1322)
  #define EVO_TFT_PANEL_WIDTH   256
  #define EVO_TFT_PANEL_HEIGHT  64
  #define EVO_TFT_ROTATION      0
#elif defined(EVO_PANEL_ILI9341)
  #define EVO_TFT_PANEL_WIDTH   240
  #define EVO_TFT_PANEL_HEIGHT  320
  #define EVO_TFT_ROTATION      1
#elif defined(EVO_PANEL_ILI9488)
  #define EVO_TFT_PANEL_WIDTH   320
  #define EVO_TFT_PANEL_HEIGHT  480
  #define EVO_TFT_ROTATION      1
#endif

#ifndef EVO_TFT_SPI_HOST
  #if defined(SPI2_HOST)
    #define EVO_TFT_SPI_HOST SPI2_HOST
  #elif defined(HSPI_HOST)
    #define EVO_TFT_SPI_HOST HSPI_HOST
  #elif defined(VSPI_HOST)
    #define EVO_TFT_SPI_HOST VSPI_HOST
  #else
    #define EVO_TFT_SPI_HOST SPI2_HOST
  #endif
#endif

#ifndef SPI_DMA_CH_AUTO
  #define SPI_DMA_CH_AUTO 1
#endif

#if !defined(EVO_PANEL_SSD1322) || !EVO_SSD1322_USE_U8G2_FALLBACK
class EvoLGFXDevice : public lgfx::LGFX_Device
{
private:
  lgfx::Bus_SPI _bus_instance;
  #if defined(EVO_PANEL_SSD1322)
    EVO_SSD1322_PANEL_CLASS _panel_instance;
  #elif defined(EVO_PANEL_ILI9341)
    lgfx::Panel_ILI9341 _panel_instance;
  #elif defined(EVO_PANEL_ILI9488)
    lgfx::Panel_ILI9488 _panel_instance;
  #endif
  lgfx::Light_PWM _light_instance;

public:
  EvoLGFXDevice()
  {
    {
      auto cfg = _bus_instance.config();
      cfg.spi_host = (spi_host_device_t)EVO_TFT_SPI_HOST;
      cfg.spi_mode = 0;
      cfg.freq_write = EVO_TFT_SPI_FREQ;
      cfg.freq_read = 1000000;
      cfg.spi_3wire = false;
      cfg.use_lock = true;
      cfg.dma_channel = SPI_DMA_CH_AUTO;
      cfg.pin_sclk = SPI_SCK_OLED;
      cfg.pin_mosi = SPI_MOSI_OLED;
      cfg.pin_miso = EVO_TFT_MISO;
      cfg.pin_dc   = DC_OLED;
      _bus_instance.config(cfg);
      _panel_instance.setBus(&_bus_instance);
    }

    {
      auto cfg = _panel_instance.config();
      cfg.pin_cs  = CS_OLED;
      cfg.pin_rst = RESET_OLED;
      cfg.pin_busy = -1;
      cfg.panel_width  = EVO_TFT_PANEL_WIDTH;
      cfg.panel_height = EVO_TFT_PANEL_HEIGHT;
      cfg.memory_width  = EVO_TFT_PANEL_WIDTH;
      cfg.memory_height = EVO_TFT_PANEL_HEIGHT;
      cfg.offset_x = 0;
      cfg.offset_y = 0;
      cfg.offset_rotation = 0;
      cfg.dummy_read_pixel = 8;
      cfg.dummy_read_bits = 1;
      cfg.readable = false;
      cfg.invert = EVO_TFT_INVERT;
      cfg.rgb_order = EVO_TFT_RGB_ORDER;
      cfg.dlen_16bit = false;
      cfg.bus_shared = false;
      _panel_instance.config(cfg);
    }

    #if EVO_TFT_BL >= 0
    {
      auto cfg = _light_instance.config();
      cfg.pin_bl = EVO_TFT_BL;
      cfg.invert = EVO_TFT_BL_INVERT;
      cfg.freq = 44100;
      cfg.pwm_channel = 7;
      _light_instance.config(cfg);
      _panel_instance.setLight(&_light_instance);
    }
    #endif

    setPanel(&_panel_instance);
  }
};

#endif

#if defined(EVO_PANEL_SSD1322) && EVO_SSD1322_USE_U8G2_FALLBACK
class EvoDisplayLovyanGFX : public Print
{
private:
  U8G2_SSD1322_NHD_256X64_F_4W_HW_SPI _oled;
  uint8_t _brightness = 180;

public:
  EvoDisplayLovyanGFX()
    : _oled(U8G2_R2, CS_OLED, DC_OLED, RESET_OLED)
  {
  }

  void begin()
  {
    _oled.begin();
    _oled.setContrast(_brightness);
    clearBuffer();
    sendBuffer();
  }

  void clearBuffer() { _oled.clearBuffer(); }
  void sendBuffer() { _oled.sendBuffer(); }
  void setPowerSave(uint8_t save) { _oled.setPowerSave(save); }

  void setContrast(uint8_t contrast)
  {
    _brightness = contrast;
    _oled.setContrast(contrast);
  }

  void setDrawColor(uint8_t color) { _oled.setDrawColor(color); }
  void setFont(const uint8_t *font) { _oled.setFont(font); }
  void setCursor(int16_t x, int16_t y) { _oled.setCursor(x, y); }

  size_t write(uint8_t c) override
  {
    return _oled.write(c);
  }

  size_t write(const uint8_t *buffer, size_t size) override
  {
    size_t n = 0;
    while (size--) n += write(*buffer++);
    return n;
  }

  int printf(const char *fmt, ...)
  {
    char buf[160];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if (len <= 0) return len;
    return print(buf);
  }

  int drawStr(int16_t x, int16_t y, const char *text) { return _oled.drawStr(x, y, text ? text : ""); }
  int drawGlyph(int16_t x, int16_t y, uint16_t glyph) { return _oled.drawGlyph(x, y, glyph); }
  void drawXBMP(int16_t x, int16_t y, int16_t w, int16_t h, const uint8_t *bitmap) { _oled.drawXBMP(x, y, w, h, bitmap); }
  void drawBox(int16_t x, int16_t y, int16_t w, int16_t h) { _oled.drawBox(x, y, w, h); }
  void drawFrame(int16_t x, int16_t y, int16_t w, int16_t h) { _oled.drawFrame(x, y, w, h); }
  void drawRBox(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r) { _oled.drawRBox(x, y, w, h, r); }
  void drawRFrame(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r) { _oled.drawRFrame(x, y, w, h, r); }
  void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1) { _oled.drawLine(x0, y0, x1, y1); }
  void drawHLine(int16_t x, int16_t y, int16_t w) { _oled.drawHLine(x, y, w); }
  int getStrWidth(const char *text) { return _oled.getStrWidth(text ? text : ""); }
  int getMaxCharHeight() { return _oled.getMaxCharHeight(); }
  int getDisplayWidth() { return _oled.getDisplayWidth(); }
  int getDisplayHeight() { return _oled.getDisplayHeight(); }
};
#else
class EvoDisplayLovyanGFX : public Print
{
private:
  EvoLGFXDevice _lcd;
  LGFX_Sprite _canvas;
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
  LGFX_Sprite _native;
  bool _nativeReady = false;
  bool _nativeActive = false;
#if EVO_TFT_NATIVE_DELTA_RENDER
  uint16_t *_nativePrevFrame = nullptr;
  uint16_t *_nativeScaleLine = nullptr;
  int32_t   _nativePrevW = 0;
  int32_t   _nativePrevH = 0;
  int32_t   _nativeScaleLineW = 0;
  bool      _nativeForceFullFrame = true;
#endif
#endif
  lgfx::U8g2font _font;

  uint16_t *_scaleLine = nullptr;
  int32_t   _scaleLineW = 0;
  uint16_t *_scaledFrame = nullptr;
  int32_t   _scaledFrameW = 0;
  int32_t   _scaledFrameH = 0;
  uint16_t *_prevFrame = nullptr;
  uint32_t  _lastPushMs = 0;
  bool      _screenClearedOnce = false;
  bool      _forceFullFrame = true;

  uint16_t _drawColor = EVO_TFT_COLOR_TEXT;
  uint16_t _backColor = EVO_TFT_COLOR_BG;
  uint8_t  _brightness = 180;
  bool     _powerSave = false;

  void applyTextColor()
  {
    // Jak w U8g2: rysujemy tylko piksele znaku, bez wypelniania prostokata tla.
    // W LovyanGFX tlo tekstu potrafilo podcinac gore liter w czcionkach U8g2.
    _canvas.setTextColor(_drawColor);
  }

  uint16_t colorForFill() const
  {
    if (_drawColor == EVO_TFT_COLOR_TEXT) return EVO_TFT_COLOR_ACCENT;
    return _drawColor;
  }

  uint16_t colorForFrame() const
  {
    if (_drawColor == EVO_TFT_COLOR_TEXT) return EVO_TFT_COLOR_FRAME;
    return _drawColor;
  }

  uint16_t colorForBitmap() const
  {
    if (_drawColor == EVO_TFT_COLOR_TEXT) return EVO_TFT_COLOR_BITMAP;
    return _drawColor;
  }

  void *evoTftAlloc(size_t bytes)
  {
#if defined(ESP32)
    if (psramFound())
    {
      void *p = ps_malloc(bytes);
      if (p != nullptr) return p;
    }
#endif
    return malloc(bytes);
  }

#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER && EVO_TFT_NATIVE_DELTA_RENDER
  bool ensureNativeDeltaBuffers(int32_t srcW, int32_t srcH, int32_t outW)
  {
    const size_t frameBytes = (size_t)srcW * (size_t)srcH * sizeof(uint16_t);

    if (_nativePrevFrame == nullptr || _nativePrevW != srcW || _nativePrevH != srcH)
    {
      if (_nativePrevFrame != nullptr) free(_nativePrevFrame);
      _nativePrevFrame = (uint16_t *)evoTftAlloc(frameBytes);
      _nativePrevW = (_nativePrevFrame != nullptr) ? srcW : 0;
      _nativePrevH = (_nativePrevFrame != nullptr) ? srcH : 0;
      if (_nativePrevFrame != nullptr)
      {
        memset(_nativePrevFrame, 0xA5, frameBytes);
        _nativeForceFullFrame = true;
      }
    }

    if (_nativeScaleLine == nullptr || _nativeScaleLineW < outW)
    {
      if (_nativeScaleLine != nullptr) free(_nativeScaleLine);
      _nativeScaleLine = (uint16_t *)evoTftAlloc((size_t)outW * sizeof(uint16_t));
      _nativeScaleLineW = (_nativeScaleLine != nullptr) ? outW : 0;
    }

    return _nativePrevFrame != nullptr && _nativeScaleLine != nullptr;
  }

  void pushNativeScaledFull(uint16_t *src, int32_t srcW, int32_t srcH, int32_t lcdW, int32_t lcdH)
  {
    _lcd.startWrite();
    const float zoomX = (float)lcdW / (float)srcW;
    const float zoomY = (float)lcdH / (float)srcH;
    _native.pushRotateZoom(&_lcd, lcdW >> 1, lcdH >> 1, 0.0f, zoomX, zoomY);
    _lcd.endWrite();

    if (_nativePrevFrame != nullptr && src != nullptr)
    {
      memcpy(_nativePrevFrame, src, (size_t)srcW * (size_t)srcH * sizeof(uint16_t));
    }
    _nativeForceFullFrame = false;
  }

  void pushNativeScaledDelta()
  {
    uint16_t *src = (uint16_t *)_native.getBuffer();
    if (src == nullptr)
    {
      return;
    }

    const int32_t srcW = _native.width();
    const int32_t srcH = _native.height();
    const int32_t outW = _lcd.width();
    const int32_t outH = _lcd.height();

    if (srcW <= 0 || srcH <= 0 || outW <= 0 || outH <= 0)
    {
      return;
    }

    if (!ensureNativeDeltaBuffers(srcW, srcH, outW))
    {
      _lcd.startWrite();
      const float zoomX = (float)outW / (float)srcW;
      const float zoomY = (float)outH / (float)srcH;
      _native.pushRotateZoom(&_lcd, outW >> 1, outH >> 1, 0.0f, zoomX, zoomY);
      _lcd.endWrite();
      return;
    }

    if (_nativeForceFullFrame)
    {
      pushNativeScaledFull(src, srcW, srcH, outW, outH);
      return;
    }

    // Delta render: logika dalej moze rysowac cala klatke 320x240 do sprite,
    // ale na ILI9488 wysylamy tylko te linie/fragmenty, ktore faktycznie zmienily kolor.
    // To odciaza SPI i zostawia wiecej czasu dla audio.loop().
    const int32_t padX = 2;
    _lcd.startWrite();

    for (int32_t sy = 0; sy < srcH; ++sy)
    {
      uint16_t *row = src + ((size_t)sy * (size_t)srcW);
      uint16_t *old = _nativePrevFrame + ((size_t)sy * (size_t)srcW);

      int32_t minX = srcW;
      int32_t maxX = -1;

      for (int32_t sx = 0; sx < srcW; ++sx)
      {
        if (row[sx] != old[sx])
        {
          if (sx < minX) minX = sx;
          if (sx > maxX) maxX = sx;
        }
      }

      if (maxX >= 0)
      {
        minX -= padX;
        maxX += padX;
        if (minX < 0) minX = 0;
        if (maxX >= srcW) maxX = srcW - 1;

        int32_t dx0 = (int32_t)(((int64_t)minX * outW) / srcW);
        int32_t dx1 = (int32_t)((((int64_t)(maxX + 1) * outW) + srcW - 1) / srcW) - 1;
        if (dx0 < 0) dx0 = 0;
        if (dx1 >= outW) dx1 = outW - 1;
        const int32_t segW = dx1 - dx0 + 1;

        int32_t dy0 = (int32_t)(((int64_t)sy * outH) / srcH);
        int32_t dy1 = (int32_t)((((int64_t)(sy + 1) * outH) + srcH - 1) / srcH) - 1;
        if (dy0 < 0) dy0 = 0;
        if (dy1 >= outH) dy1 = outH - 1;
        if (dy1 < dy0) dy1 = dy0;

        for (int32_t dx = 0; dx < segW; ++dx)
        {
          int32_t sx = (int32_t)(((int64_t)(dx0 + dx) * srcW) / outW);
          if (sx < 0) sx = 0;
          if (sx >= srcW) sx = srcW - 1;
          _nativeScaleLine[dx] = row[sx];
        }

        for (int32_t dy = dy0; dy <= dy1; ++dy)
        {
          _lcd.pushImage(dx0, dy, segW, 1, _nativeScaleLine);
        }

        memcpy(old, row, (size_t)srcW * sizeof(uint16_t));
      }
    }

    _lcd.endWrite();
  }
#endif

  bool ensureScaleBuffers(int32_t outW, int32_t outH = 0)
  {
    if (_scaleLine == nullptr || _scaleLineW < outW)
    {
      if (_scaleLine != nullptr) free(_scaleLine);
      _scaleLine = (uint16_t *)malloc(outW * sizeof(uint16_t));
      _scaleLineW = (_scaleLine != nullptr) ? outW : 0;
    }

#if EVO_TFT_FULL_FRAMEBUFFER
    if (outH > 0 && (_scaledFrame == nullptr || _scaledFrameW != outW || _scaledFrameH != outH))
    {
      if (_scaledFrame != nullptr) free(_scaledFrame);
      _scaledFrame = (uint16_t *)malloc((size_t)outW * (size_t)outH * sizeof(uint16_t));
      _scaledFrameW = (_scaledFrame != nullptr) ? outW : 0;
      _scaledFrameH = (_scaledFrame != nullptr) ? outH : 0;
    }
#endif

    if (_prevFrame == nullptr)
    {
      _prevFrame = (uint16_t *)malloc(SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(uint16_t));
      if (_prevFrame != nullptr)
      {
        memset(_prevFrame, 0xA5, SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(uint16_t));
        _forceFullFrame = true;
      }
    }

#if EVO_TFT_FULL_FRAMEBUFFER
    return _scaleLine != nullptr && (outH <= 0 || _scaledFrame != nullptr);
#else
    return _scaleLine != nullptr;
#endif
  }

  void pushScaledFull(uint16_t *src, int32_t outW, int32_t outH, int32_t ox, int32_t oy)
  {
    if (!ensureScaleBuffers(outW, outH))
    {
      const int32_t lcdW = _lcd.width();
      const int32_t lcdH = _lcd.height();
      _canvas.pushRotateZoom(&_lcd, lcdW >> 1, lcdH >> 1, 0.0f, (float)outW / SCREEN_WIDTH, (float)outH / SCREEN_HEIGHT);
      return;
    }

    _lcd.startWrite();
    if (!_screenClearedOnce)
    {
      _lcd.fillScreen(EVO_TFT_COLOR_BG);
      _screenClearedOnce = true;
    }

#if EVO_TFT_FULL_FRAMEBUFFER
    if (_scaledFrame != nullptr)
    {
      for (int32_t y = 0; y < outH; ++y)
      {
        const int32_t sy = (int32_t)(((int64_t)y * SCREEN_HEIGHT) / outH);
        uint16_t *row = src + (sy * SCREEN_WIDTH);
        uint16_t *dst = _scaledFrame + ((size_t)y * (size_t)outW);
        for (int32_t x = 0; x < outW; ++x)
        {
          const int32_t sx = (int32_t)(((int64_t)x * SCREEN_WIDTH) / outW);
          dst[x] = row[sx];
        }
      }
      _lcd.pushImage(ox, oy, outW, outH, _scaledFrame);
    }
    else
#endif
    {
      for (int32_t y = 0; y < outH; ++y)
      {
        const int32_t sy = (int32_t)(((int64_t)y * SCREEN_HEIGHT) / outH);
        uint16_t *row = src + (sy * SCREEN_WIDTH);
        for (int32_t x = 0; x < outW; ++x)
        {
          const int32_t sx = (int32_t)(((int64_t)x * SCREEN_WIDTH) / outW);
          _scaleLine[x] = row[sx];
        }
        _lcd.pushImage(ox, oy + y, outW, 1, _scaleLine);
      }
    }
    _lcd.endWrite();

    if (_prevFrame != nullptr)
    {
      memcpy(_prevFrame, src, SCREEN_WIDTH * SCREEN_HEIGHT * sizeof(uint16_t));
    }
    _forceFullFrame = false;
  }

  void pushScaledDelta(uint16_t *src, int32_t outW, int32_t outH, int32_t ox, int32_t oy)
  {
    if (!ensureScaleBuffers(outW) || _scaleLine == nullptr || _prevFrame == nullptr)
    {
      pushScaledFull(src, outW, outH, ox, oy);
      return;
    }

    if (!_screenClearedOnce || _forceFullFrame)
    {
      pushScaledFull(src, outW, outH, ox, oy);
      return;
    }

    _lcd.startWrite();

    for (int32_t sy = 0; sy < SCREEN_HEIGHT; ++sy)
    {
      uint16_t *row = src + (sy * SCREEN_WIDTH);
      uint16_t *old = _prevFrame + (sy * SCREEN_WIDTH);

      int32_t minX = SCREEN_WIDTH;
      int32_t maxX = -1;

      for (int32_t sx = 0; sx < SCREEN_WIDTH; ++sx)
      {
        if (row[sx] != old[sx])
        {
          if (sx < minX) minX = sx;
          if (sx > maxX) maxX = sx;
        }
      }

      if (maxX >= 0)
      {
        minX -= EVO_TFT_DIRTY_PAD_X;
        maxX += EVO_TFT_DIRTY_PAD_X;
        if (minX < 0) minX = 0;
        if (maxX >= SCREEN_WIDTH) maxX = SCREEN_WIDTH - 1;

        int32_t dx0 = (int32_t)(((int64_t)minX * outW) / SCREEN_WIDTH);
        int32_t dx1 = (int32_t)((((int64_t)(maxX + 1) * outW) + SCREEN_WIDTH - 1) / SCREEN_WIDTH) - 1;
        if (dx0 < 0) dx0 = 0;
        if (dx1 >= outW) dx1 = outW - 1;
        const int32_t segW = dx1 - dx0 + 1;

        int32_t dy0 = (int32_t)((((int64_t)sy * outH) + SCREEN_HEIGHT - 1) / SCREEN_HEIGHT);
        int32_t dy1 = (int32_t)((((int64_t)(sy + 1) * outH) + SCREEN_HEIGHT - 1) / SCREEN_HEIGHT) - 1;
        if (dy0 < 0) dy0 = 0;
        if (dy1 >= outH) dy1 = outH - 1;
        if (dy1 < dy0) dy1 = dy0;

        for (int32_t dx = 0; dx < segW; ++dx)
        {
          const int32_t sx = (int32_t)(((int64_t)(dx0 + dx) * SCREEN_WIDTH) / outW);
          _scaleLine[dx] = row[sx];
        }

        for (int32_t dy = dy0; dy <= dy1; ++dy)
        {
          _lcd.pushImage(ox + dx0, oy + dy, segW, 1, _scaleLine);
        }

        memcpy(old, row, SCREEN_WIDTH * sizeof(uint16_t));
      }
    }

    _lcd.endWrite();
  }

  void pushScaledFast()
  {
    uint16_t *src = (uint16_t *)_canvas.getBuffer();
    if (src == nullptr) return;

    const int32_t lcdW = _lcd.width();
    const int32_t lcdH = _lcd.height();
    int32_t outW = lcdW;
    int32_t outH = (int32_t)(((int64_t)SCREEN_HEIGHT * outW) / SCREEN_WIDTH);

    if (outH > lcdH)
    {
      outH = lcdH;
      outW = (int32_t)(((int64_t)SCREEN_WIDTH * outH) / SCREEN_HEIGHT);
    }

    if (outW <= 0 || outH <= 0) return;

    const int32_t ox = (lcdW - outW) / 2;
    const int32_t oy = (lcdH - outH) / 2;

#if EVO_TFT_DELTA_RENDER
    pushScaledDelta(src, outW, outH, ox, oy);
#else
    pushScaledFull(src, outW, outH, ox, oy);
#endif
  }

public:
  EvoDisplayLovyanGFX()
    : _canvas(&_lcd)
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    , _native(&_lcd)
#endif
    , _font(nullptr)
  {
  }

  void begin()
  {
    evoHardResetTFT();
    _lcd.init();
    _lcd.setRotation(EVO_TFT_ROTATION);
    _lcd.setColorDepth(16);
    _lcd.setBrightness(_brightness);
    _lcd.fillScreen(EVO_TFT_COLOR_BG);
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    // V4 STABLE: caly nowy ekran 320x240 rysujemy najpierw poza panelem.
    // Na TFT trafia gotowa klatka, wiec nie widac czyszczenia ekranu i migotania.
    _native.setColorDepth(16);
    if (psramFound()) _native.setPsram(true);
    _native.createSprite(EVO_TFT_NATIVE_VIRTUAL_W, EVO_TFT_NATIVE_VIRTUAL_H);
    _native.setTextDatum(lgfx::textdatum_t::top_left);
    if (_native.getBuffer() != nullptr)
    {
      _nativeReady = true;
      _native.fillScreen(EVO_TFT_NATIVE_BG);
#if EVO_TFT_NATIVE_DELTA_RENDER
      _nativeForceFullFrame = true;
#endif
    }
#endif
    #if defined(EVO_PANEL_ILI9341) && EVO_TFT_SHOW_STARTUP_TEST
      _lcd.setTextColor(0xFFFF, 0x0000);
      _lcd.setTextSize(2);
      _lcd.setCursor(10, 10);
      #if defined(EVO_PANEL_ILI9488)
      _lcd.print("EVO ILI9488 OK");
#else
      _lcd.print("EVO ILI9341 OK");
#endif
      _lcd.setCursor(10, 38);
      _lcd.print("RST41 CS=GND SPI38/39");
      delay(120);
    #endif

    _canvas.setColorDepth(16);
    _canvas.createSprite(SCREEN_WIDTH, SCREEN_HEIGHT);
    _canvas.setTextDatum(lgfx::textdatum_t::baseline_left);
    clearBuffer();
    sendBuffer();
  }

  void clearBuffer()
  {
    if (_canvas.getBuffer() == nullptr) return;
    _canvas.fillScreen(EVO_TFT_COLOR_BG);
    setDrawColor(1);
  }

  void sendBuffer()
  {
    if (_canvas.getBuffer() == nullptr || _powerSave) return;

#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_BLOCK_LEGACY_BUFFER
    // V3 CLEAN: na TFT ILI9341/ILI9488 rysujemy nowe ekrany bezpośrednio na TFT.
    // Stary bufor OLED 256x64 nie może być już wysyłany, bo nakładał się
    // na pełnoekranowy interfejs i wyglądało to jak dwa ekrany na zmianę.
    return;
#endif

    #if EVO_TFT_MIN_FRAME_MS > 0
      uint32_t nowMs = millis();
      if (!_forceFullFrame && (uint32_t)(nowMs - _lastPushMs) < EVO_TFT_MIN_FRAME_MS) return;
      _lastPushMs = nowMs;
    #endif

    #if EVO_LGFX_SCALE_TO_PANEL
      #if EVO_TFT_FAST_SCALE
        pushScaledFast();
      #else
        const int32_t lcdW = _lcd.width();
        const int32_t lcdH = _lcd.height();
        const float sx = (float)lcdW / (float)SCREEN_WIDTH;
        const float sy = (float)lcdH / (float)SCREEN_HEIGHT;
        const float scale = (sx < sy) ? sx : sy;

        _lcd.startWrite();
        if (!_screenClearedOnce)
        {
          _lcd.fillScreen(EVO_TFT_COLOR_BG);
          _screenClearedOnce = true;
        }
        #if EVO_LGFX_CENTER_ON_TFT
          _canvas.pushRotateZoom(&_lcd, lcdW >> 1, lcdH >> 1, 0.0f, scale, scale);
        #else
          _canvas.pushRotateZoom(&_lcd, (int32_t)((SCREEN_WIDTH * scale) / 2), (int32_t)((SCREEN_HEIGHT * scale) / 2), 0.0f, scale, scale);
        #endif
        _lcd.endWrite();
      #endif
    #else
      _canvas.pushSprite(0, 0);
    #endif
  }

  void setPowerSave(uint8_t save)
  {
    _powerSave = save != 0;
    if (_powerSave)
    {
      _lcd.setBrightness(0);
      _lcd.sleep();
    }
    else
    {
      _lcd.wakeup();
      _lcd.setBrightness(_brightness);
      _forceFullFrame = true;
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER && EVO_TFT_NATIVE_DELTA_RENDER
      _nativeForceFullFrame = true;
#endif
      sendBuffer();
    }
  }

  void setContrast(uint8_t contrast)
  {
    _brightness = contrast;
    if (!_powerSave) _lcd.setBrightness(contrast);
  }

  void setDrawColor(uint8_t color)
  {
    // U8g2 pracowal w trybie 0/1. Na TFT mapujemy to na kolory:
    // 0 = kasowanie tlem, 1 = tekst/linie z akcentem kolorystycznym.
    if (color == 0)
    {
      _drawColor = EVO_TFT_COLOR_BG;
    }
    else
    {
      _drawColor = EVO_TFT_COLOR_TEXT;
    }
    _backColor = EVO_TFT_COLOR_BG;
    applyTextColor();
  }

  void setFont(const uint8_t *font)
  {
    _font.~U8g2font();
    new (&_font) lgfx::U8g2font(font);
    _canvas.setFont(&_font);
    _canvas.setTextDatum(lgfx::textdatum_t::baseline_left);
    applyTextColor();
  }

  void setCursor(int16_t x, int16_t y)
  {
    _canvas.setCursor(x, y + EVO_TFT_FONT_Y_OFFSET);
  }

  size_t write(uint8_t c) override
  {
    return _canvas.write(c);
  }

  int printf(const char *fmt, ...)
  {
    char buf[160];
    va_list args;
    va_start(args, fmt);
    int len = vsnprintf(buf, sizeof(buf), fmt, args);
    va_end(args);
    if (len <= 0) return len;
    return print(buf);
  }

  int drawStr(int16_t x, int16_t y, const char *text)
  {
    setCursor(x, y);
    return _canvas.print(text ? text : "");
  }

  int drawGlyph(int16_t x, int16_t y, uint16_t glyph)
  {
    setCursor(x, y);
    if (glyph < 0x100)
    {
      return _canvas.write((uint8_t)glyph);
    }

    char buf[5] = {0, 0, 0, 0, 0};
    if (glyph < 0x800)
    {
      buf[0] = (char)(0xC0 | (glyph >> 6));
      buf[1] = (char)(0x80 | (glyph & 0x3F));
    }
    else
    {
      buf[0] = (char)(0xE0 | (glyph >> 12));
      buf[1] = (char)(0x80 | ((glyph >> 6) & 0x3F));
      buf[2] = (char)(0x80 | (glyph & 0x3F));
    }
    return _canvas.print(buf);
  }

  void drawXBMP(int16_t x, int16_t y, int16_t w, int16_t h, const uint8_t *bitmap)
  {
    _canvas.drawXBitmap(x, y, bitmap, w, h, colorForBitmap());
  }

  void drawBox(int16_t x, int16_t y, int16_t w, int16_t h)
  {
    _canvas.fillRect(x, y, w, h, colorForFill());
  }

  void drawFrame(int16_t x, int16_t y, int16_t w, int16_t h)
  {
    _canvas.drawRect(x, y, w, h, colorForFrame());
  }

  void drawRBox(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r)
  {
    _canvas.fillRoundRect(x, y, w, h, r, colorForFill());
  }

  void drawRFrame(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r)
  {
    _canvas.drawRoundRect(x, y, w, h, r, colorForFrame());
  }

  void drawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1)
  {
    _canvas.drawLine(x0, y0, x1, y1, colorForFrame());
  }

  void drawHLine(int16_t x, int16_t y, int16_t w)
  {
    _canvas.drawFastHLine(x, y, w, colorForFrame());
  }

  int getStrWidth(const char *text)
  {
    return _canvas.textWidth(text ? text : "");
  }


#if defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)
  int tftWidth()
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
    return EVO_TFT_NATIVE_VIRTUAL_W;
#else
    return _lcd.width();
#endif
  }

  int tftHeight()
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
    return EVO_TFT_NATIVE_VIRTUAL_H;
#else
    return _lcd.height();
#endif
  }

  void tftStartWrite()
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeReady)
    {
      _nativeActive = true;
      return;
    }
#endif
    _lcd.startWrite();
  }

  void tftEndWrite()
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady)
    {
#if EVO_TFT_NATIVE_DELTA_RENDER
      pushNativeScaledDelta();
#else
      _lcd.startWrite();
      const int32_t lcdW = _lcd.width();
      const int32_t lcdH = _lcd.height();
      const float zoomX = (float)lcdW / (float)EVO_TFT_NATIVE_VIRTUAL_W;
      const float zoomY = (float)lcdH / (float)EVO_TFT_NATIVE_VIRTUAL_H;
      _native.pushRotateZoom(&_lcd, lcdW >> 1, lcdH >> 1, 0.0f, zoomX, zoomY);
      _lcd.endWrite();
#endif
      _nativeActive = false;
      return;
    }
#endif
    _lcd.endWrite();
  }

  void tftFillScreen(uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.fillScreen(color); return; }
#endif
    _lcd.fillScreen(color);
  }
  void tftFillRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.fillRect(x, y, w, h, color); return; }
#endif
    _lcd.fillRect(x, y, w, h, color);
  }
  void tftDrawRect(int16_t x, int16_t y, int16_t w, int16_t h, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawRect(x, y, w, h, color); return; }
#endif
    _lcd.drawRect(x, y, w, h, color);
  }
  void tftDrawCircle(int16_t x, int16_t y, int16_t r, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawCircle(x, y, r, color); return; }
#endif
    _lcd.drawCircle(x, y, r, color);
  }
  void tftFillCircle(int16_t x, int16_t y, int16_t r, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.fillCircle(x, y, r, color); return; }
#endif
    _lcd.fillCircle(x, y, r, color);
  }
  void tftFillRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.fillRoundRect(x, y, w, h, r, color); return; }
#endif
    _lcd.fillRoundRect(x, y, w, h, r, color);
  }
  void tftDrawRoundRect(int16_t x, int16_t y, int16_t w, int16_t h, int16_t r, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawRoundRect(x, y, w, h, r, color); return; }
#endif
    _lcd.drawRoundRect(x, y, w, h, r, color);
  }
  void tftDrawLine(int16_t x0, int16_t y0, int16_t x1, int16_t y1, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawLine(x0, y0, x1, y1, color); return; }
#endif
    _lcd.drawLine(x0, y0, x1, y1, color);
  }
  void tftDrawFastHLine(int16_t x, int16_t y, int16_t w, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawFastHLine(x, y, w, color); return; }
#endif
    _lcd.drawFastHLine(x, y, w, color);
  }
  void tftDrawFastVLine(int16_t x, int16_t y, int16_t h, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawFastVLine(x, y, h, color); return; }
#endif
    _lcd.drawFastVLine(x, y, h, color);
  }
  void tftDrawXBitmap(int16_t x, int16_t y, int16_t w, int16_t h, const uint8_t *bitmap, uint16_t color)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady) { _native.drawXBitmap(x, y, bitmap, w, h, color); return; }
#endif
    _lcd.drawXBitmap(x, y, bitmap, w, h, color);
  }
  void tftText(int16_t x, int16_t y, const char *text, uint8_t size, uint16_t fg)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady)
    {
      _native.setFont(nullptr);
      _native.setTextSize(size);
      _native.setTextColor(fg);
      _native.setCursor(x, y);
      _native.print(text ? text : "");
      return;
    }
#endif
    _lcd.setFont(nullptr);
    _lcd.setTextSize(size);
    _lcd.setTextColor(fg);
    _lcd.setCursor(x, y);
    _lcd.print(text ? text : "");
  }
  void tftTextBg(int16_t x, int16_t y, const char *text, uint8_t size, uint16_t fg, uint16_t bg)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeActive && _nativeReady)
    {
      _native.setFont(nullptr);
      _native.setTextSize(size);
      _native.setTextColor(fg, bg);
      _native.setCursor(x, y);
      _native.print(text ? text : "");
      return;
    }
#endif
    _lcd.setFont(nullptr);
    _lcd.setTextSize(size);
    _lcd.setTextColor(fg, bg);
    _lcd.setCursor(x, y);
    _lcd.print(text ? text : "");
  }
  int tftTextWidth(const char *text, uint8_t size)
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_DOUBLE_BUFFER
    if (_nativeReady)
    {
      _native.setFont(nullptr);
      _native.setTextSize(size);
      return _native.textWidth(text ? text : "");
    }
#endif
    _lcd.setFont(nullptr);
    _lcd.setTextSize(size);
    return _lcd.textWidth(text ? text : "");
  }
#endif

  int getMaxCharHeight()
  {
    return _canvas.fontHeight();
  }

  int getDisplayWidth()
  {
    return SCREEN_WIDTH;
  }

  int getDisplayHeight()
  {
    return SCREEN_HEIGHT;
  }
};

#endif

EvoDisplayLovyanGFX gfx;

// Przypisujemy port serwera www
AsyncWebServer server(80);
AsyncWebSocket ws("/ws"); //Start obsługi Websocketów


// Inicjalizacja WiFiManagera
WiFiManager wifiManager;


// Konfiguracja nowego SPI z wybranymi pinami dla czytnika kart SD
SPIClass customSPI = SPIClass(HSPI);  // Używamy HSPI, ale z własnymi pinami

#ifdef twoEncoders
  ezButton button1(SW_PIN1);  // Utworzenie obiektu przycisku z enkodera 2 ezButton
#endif

ezButton button2(SW_PIN2);  // Utworzenie obiektu przycisku z enkodera 2 ezButton
Audio audio;                // Obiekt do obsługi funkcji związanych z dźwiękiem i audio


// ================================================================
// APMS FIX: poziom wyjściowy audio dla biblioteki schreibfaul1/ESP32-audioI2S
// ---------------------------------------------------------------
// Nowsza wersja biblioteki ma inna krzywa glosnosci. Ta krzywa
// podnosi srodkowy zakres regulacji, ale nie przekracza 0 dB na maksimum.
// ================================================================
#define EVO_AUDIO_LEGACY_LOUDNESS_FIX 1
#define EVO_AUDIO_LEGACY_MIN_DB      -48.0f
#define EVO_AUDIO_LEGACY_GAMMA         0.72f

static float evoAudioLegacyLoudnessCurve(float t)
{
  if (t <= 0.0f) return -60.0f;
  if (t >= 1.0f) return 0.0f;
  t = constrain(t, 0.0f, 1.0f);
  return EVO_AUDIO_LEGACY_MIN_DB + ((0.0f - EVO_AUDIO_LEGACY_MIN_DB) * powf(t, EVO_AUDIO_LEGACY_GAMMA));
}

static void evoAudioApplyVolumeProfile()
{
#if EVO_AUDIO_LEGACY_LOUDNESS_FIX
  audio.setVolumeCurve(evoAudioLegacyLoudnessCurve);
#endif
  audio.setVolumeSteps(maxVolume);
  if (volumeValue > maxVolume) volumeValue = maxVolume;
}

Ticker timer1;             // Timer do aktualizacji Zegara
Ticker timer2;             // Timer funkcji Dimmer
Ticker timer3;             // Timer dla funkcji Sleep
Ticker timer4;             // Timer startu migania LED
WiFiClient client;         // Obiekt do obsługi połączenia WiFi dla klienta HTTP


// ------------------- STRON HTML zaszyte w kodzie -------------------
const char stylehead_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML><html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html {font-family: Arial; display: inline-block; text-align: center;}
      h2 {font-size: 1.3rem;}
      p {font-size: 0.95rem;}
      table {border: 1px solid black; border-collapse: collapse; margin: 0px 0px;}
      td, th {font-size: 0.8rem; border: 1px solid gray; border-collapse: collapse;}
      td:hover {font-weight:bold;}
      a {color: black; text-decoration: none;}
      body {max-width: 1380px; margin:0px auto; padding-bottom: 25px; background: #D0D0D0;}
      .slider {-webkit-appearance: none; margin: 14px; width: 330px; height: 10px; background: #4CAF50; outline: none; -webkit-transition: .2s; transition: opacity .2s; border-radius: 5px;}
      .slider::-webkit-slider-thumb {-webkit-appearance: none; appearance: none; width: 35px; height: 25px; background: #4a4a4a; cursor: pointer; border-radius: 5px;}
      .slider::-moz-range-thumb { width: 35px; height: 35px; background: #4a4a4a; cursor: pointer; border-radius: 5px;} 
      .button { background-color: #4CAF50; border: 1; color: white; padding: 10px 20px; border-radius: 5px;}
      .buttonBank { background-color: #4CAF50; border: 1; color: white; padding: 8px 8px; border-radius: 5px; width: 35px; height: 35px; margin: 0 1.5px;}
      .buttonBankSelected { background-color: #505050; border: 1; color: white; padding: 8px 8px; border-radius: 5px; width: 35px; height: 35px; margin: 0 1.5px;}
      .buttonBank:active {background-color: #4a4a4a; box-shadow: 0 4px #666; transform: translateY(2px);}
      .buttonBank:hover {background-color: #4a4a4a;}
      .button:hover {background-color: #4a4a4a;}
      .button:active {background-color: #4a4a4a; box-shadow: 0 4px #666; transform: translateY(2px);}
      .column {padding: 5px; display: flex; justify-content: space-between;}
      .columnlist {padding: 10px; display: flex; justify-content: center;}
      .stationList {text-align:left; margin-top: 0px; width: 280px; margin-bottom:0px;cursor: pointer;}
      .stationNumberList {text-align:center; margin-top: 0px; width: 35px; margin-bottom:0px;}
      .stationListSelected {text-align:left; margin-top: 0px; width: 280px; margin-bottom:0px;cursor: pointer; background-color: #4CAF50;}
      .stationNumberListSelected {text-align:center; margin-top: 0px; width: 35px; margin-bottom:0px; background-color: #4CAF50;}
      .station-name {}  
    </style>
  </head>
)rawliteral";

const char index_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML><html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html {font-family: Arial; display: inline-block; text-align: center;}
      h2 {font-size: 1.3rem;}
      p {font-size: 0.95rem;}
      table {border: 1px solid black; border-collapse: collapse; margin: 0px 0px;}
      td, th {font-size: 0.8rem; border: 1px solid gray; border-collapse: collapse;}
      td:hover {font-weight:bold;}
      a {color: black; text-decoration: none;}
      body {max-width: 1380px; margin:0px auto; padding-bottom: 25px; background: #D0D0D0;}
      .slider {-webkit-appearance: none; margin: 14px; width: 330px; height: 10px; background: #4CAF50; outline: none; -webkit-transition: .2s; transition: opacity .2s; border-radius: 5px;}
      .slider::-webkit-slider-thumb {-webkit-appearance: none; appearance: none; width: 35px; height: 25px; background: #4a4a4a; cursor: pointer; border-radius: 5px;}
      .slider::-moz-range-thumb { width: 35px; height: 35px; background: #4a4a4a; cursor: pointer; border-radius: 5px;} 
      .button { background-color: #4CAF50; border: 1; color: white; padding: 10px 20px; border-radius: 5px;}
      .buttonBank { background-color: #4CAF50; border: 1; color: white; padding: 8px 8px; border-radius: 5px; width: 35px; height: 35px; margin: 0 1.5px;}
      .buttonBankSelected { background-color: #505050; border: 1; color: white; padding: 8px 8px; border-radius: 5px; width: 35px; height: 35px; margin: 0 1.5px;}
      .buttonBank:active {background-color: #4a4a4a box-shadow: 0 4px #666; transform: translateY(2px);}
      .buttonBank:hover {background-color: #4a4a4a;}
      .button:hover {background-color: #4a4a4a;}
      .button:active {background-color: #4a4a4a; box-shadow: 0 4px #666; transform: translateY(2px);}
      .column { align: center; padding: 5px; display: flex; justify-content: space-between;}
      .columnlist { align: center; padding: 10px; display: flex; justify-content: center;}
      .stationList {text-align:left; margin-top: 2px; width: 280px; height:18px; margin-bottom:0px;cursor: pointer;}
      .stationNumberList {text-align:center; margin-top: 2px; width: 35px; height:18px; margin-bottom:0px;}
      .stationListSelected {text-align:left; margin-top: 2px; width: 280px; height:18px; margin-bottom:0px;cursor: pointer; background-color: #4CAF50;}
      .stationNumberListSelected {text-align:center; margin-top: 2px; width: 35px; height:18px; margin-bottom:0px; background-color: #4CAF50;} 
      .wifi-wrapper {display: flex; align-items: flex-end; gap: 1px; height: 13px; margin-top: -3px; margin-bottom: 3px; justify-content: center; }
      .wifiBar {width: 2px;background-color: #555; border-radius: 2px; transition: background-color 0.2s;}
      .bar1 { height: 2px; }
      .bar2 { height: 4px; }
      .bar3 { height: 6px; }
      .bar4 { height: 8px; }
      .bar5 { height: 10px; }
      .bar6 { height: 12px; }
    </style>
  </head>

  <body>
    <h2>Evo Web Radio</h2>
  
    <div id="display" style="display: inline-block; padding: 6px; border: 2px solid #4CAF50; border-radius: 15px; background-color: #4a4a4a; font-size: 1.45rem; 
      color: #AAA; width: 345px; text-align: center; white-space: nowrap; box-shadow: 0 0 20px #4CAF50;" onClick="flashBackground(); displayMode()">
      
      <div style="margin-bottom: 10px; font-weight: bold; overflow: hidden; text-overflow: ellipsis; -webkit-text-stroke: 0.3px black; text-stroke: 0.3px black;">
        <span id="textStationName"><b>STATIONNAME</b></span>
      </div>
      
      <div style="width: 345px; margin-bottom: 10px;">
        <div id="stationTextDiv" style="display: block; text-overflow: ellipsis; white-space: normal; font-size: 1.0rem; color: #999; margin-bottom: 10px; text-align: center; align-items: center; height: 4.2em; justify-content: center; overflow: hidden; line-height: 1.4em;">
          <span id="stationText">STATIONTEXT</span>
        </div>
        <div id="muteIndicatorDiv" style="text-align:center; color:#4CAF50; font-weight:bold; font-size:1.0rem; height:1.4em; margin-top:-5px;">
        <span id="muteIndicator"></span>
        </div>
      </div>
      
      <div style="height: 1px; background-color: #4CAF50; margin: 5px 0;"></div>

      
      <div style="display: flex; justify-content: center; gap: 13px; font-size: 1.00rem; color: #999;">
        <div><span id="bankValue">Bank: --</span></div>
          <div style="display: flex; justify-content: center; gap: 6px; font-size: 0.55rem; color: #999;margin: 4px 0;">
            <div><span id="samplerate">---.-kHz</span></div>
            <div><span id="bitrate">---kbps</span></div>
            <div><span id="bitpersample">---bit</span></div>
            <div><span id="streamformat">----</span></div>
            WiFi: <div class="wifi-wrapper">
            <div class="wifiBar bar1" id="wifiBar1"></div>
            <div class="wifiBar bar2" id="wifiBar2"></div>
            <div class="wifiBar bar3" id="wifiBar3"></div>
            <div class="wifiBar bar4" id="wifiBar4"></div>
            <div class="wifiBar bar5" id="wifiBar5"></div>
            <div class="wifiBar bar6" id="wifiBar6"></div>
  	      </div>
        </div>
        <div><span id="stationNumber">Station: --</span></div>
      </div>

  </div>
  <br>
  <br>
  <script>

  var websocket;

  function updateSliderVolume(element) 
  {
    var sliderValue = document.getElementById("volumeSlider").value;
    document.getElementById("textSliderValue").innerText = sliderValue;

    if (websocket && websocket.readyState === WebSocket.OPEN) 
    {
      websocket.send("volume:" + sliderValue);
    } 
    else 
    {
      console.warn("WebSocket niepołączony");
    }
  }

  function changeStation(number) 
  {
    if (websocket.readyState === WebSocket.OPEN) 
    {
      websocket.send("station:" + number);
    } 
    else 
    {
      console.log("WebSocket nie jest otwarty");
    }
  }

  function changeBank(number) 
  {
    if (websocket.readyState === WebSocket.OPEN) 
    {
      websocket.send("bank:" + number);
    } 
    else 
    {
      console.log("WebSocket nie jest otwarty");
    }
  }


  function displayMode() 
  {
    //fetch("/displayMode")
    if (websocket.readyState === WebSocket.OPEN) 
    {
      websocket.send("displayMode");
    } 
    else 
    {
      console.log("WebSocket nie jest otwarty");
    }
  }
  
  function setWifi(level) 
  {
    for (let i = 1; i <= 6; i++) 
    {
      const bar = document.getElementById("wifiBar" + i);
      if (bar) {bar.style.backgroundColor = (i <= level) ? "#4CAF50" : "#555";}
    }
  }


  function connectWebSocket() 
  {
    websocket = new WebSocket('ws://' + window.location.hostname + '/ws');
    websocket.onopen = function () 
    {
      console.log("WebSocket polaczony");
    };
    
    websocket.onclose = function (event) 
    {
      console.log("WebSocket zamkniety. Proba ponownego polaczenia za 3 sekundy...");
      setTimeout(connectWebSocket, 3000); // próba ponownego połączenia
    };

    websocket.onerror = function (error) 
    {
      console.error("Blad WebSocket: ", error);
      websocket.close(); // zamyka połączenie, by wywołać reconnect
    };
    
    websocket.onmessage = function(event) 
    {
      if (event.data === "reload") 
      {
        location.reload();
      }  
      
      if (event.data.startsWith("volume:")) 
      {
        var vol = parseInt(event.data.split(":")[1]);
        document.getElementById("volumeSlider").value = vol;
        document.getElementById("textSliderValue").innerText = vol;
      }
      
      if (event.data.startsWith("station:")) 
      {
        var station = parseInt(event.data.split(":")[1]);
        highlightStation(station);
        //document.getElementById('stationNumber').innerText = event.data.split(':')[1];
        document.getElementById('stationNumber').innerText ='Station: ' + station; 
      }
      
      if (event.data.startsWith("stationname:")) 
      {
        var value = event.data.split(":")[1];
        document.getElementById("textStationName").innerHTML = `<b>${value}</b>`;
        //checkStationTextLength();
      }  

      if (event.data.startsWith("stationtext$")) 
      {
        //var stationtext = event.data.split("$")[1];
        //document.getElementById("stationText").innerHTML = `${stationtext}`;
        
        var stationtext = event.data.substring(event.data.indexOf("$") + 1);
        //document.getElementById("stationText").innerHTML = stationtext;       
        document.getElementById("stationText").textContent = stationtext;
      }  

      if (event.data.startsWith("bank:")) 
      {
        var bankValue = parseInt(event.data.split(":")[1]);
        document.getElementById('bankValue').innerText = 'Bank: ' + bankValue;
      } 

      //if (event.data.startsWith("samplerate:")) 
      //{
      //  var samplerate = parseInt(event.data.split(":")[1]);
      //  var formattedRate = (samplerate / 1000).toFixed(1) + "kHz";
      //  document.getElementById('samplerate').innerText = formattedRate;
      //}
      
      if (event.data.startsWith("samplerate:")) 
      {
        var raw = event.data.split(":")[1];
        var samplerate = parseInt(raw);

        if (isNaN(samplerate)) 
        {
          document.getElementById('samplerate').innerText = '---.-kHz';
        } 
        else 
        {
          var formattedRate = (samplerate / 1000).toFixed(1) + "kHz";
          document.getElementById('samplerate').innerText = formattedRate;
        }
      }

      //if (event.data.startsWith("bitrate:")) 
      //{	
      //  var bitrate = parseInt(event.data.split(":")[1]);
      //  document.getElementById('bitrate').innerText = bitrate + 'kbps';
      //}

      if (event.data.startsWith("bitrate:")) 
      {	
        var raw = event.data.split(":")[1];
        var bitrate = parseInt(raw);

        if (isNaN(bitrate)) 
        {
          document.getElementById('bitrate').innerText = '---kbps';
        } 
        else 
        {
          document.getElementById('bitrate').innerText = bitrate + 'kbps';
        }
      }

      
      //if (event.data.startsWith("bitpersample:")) 
      //{	
      //  var bitpersample = parseInt(event.data.split(":")[1]);
      //  document.getElementById('bitpersample').innerText = bitpersample + 'bit';
      //}

      if (event.data.startsWith("bitpersample:")) 
      {	
        var raw = event.data.split(":")[1];
        var bitpersample = parseInt(raw);

        if (isNaN(bitpersample)) 
        {
          document.getElementById('bitpersample').innerText = '---bit';
        } 
        else 
        {
          document.getElementById('bitpersample').innerText = bitpersample + 'bit';
        }
      }

      
      if (event.data.startsWith("streamformat:")) 
      {	
        var streamformat = event.data.split(":")[1];
        document.getElementById('streamformat').innerText = streamformat;
      }  

      if (event.data.startsWith("mute:")) 
      {
        //var muteInd = parseInt(event.data.split(":")[1]);
        const muteInd = event.data.split(":")[1] === "1" ? 1 : 0;
        document.getElementById('muteIndicator').textContent = (muteInd === 1) ? 'MUTED' : '';       
      }

      if (event.data.startsWith("wifi:")) 
      {
        const level = parseInt(event.data.split(":")[1]);
        if (!isNaN(level)) {setWifi(Math.min(Math.max(level, 1), 6));}
      }


    }

  };
  
  function highlightStation(stationId) 
  {
    // Usuń poprzednie zaznaczenia
    document.querySelectorAll(".stationList").forEach(el => {
    el.classList.remove("stationListSelected");
    //el.innerHTML = el.dataset.stationName || el.innerText; // przywróć oryginalny numer
    el.innerText = el.dataset.stationName || el.innerText;


    });

    document.querySelectorAll(".stationNumberList").forEach(el => {
      el.classList.remove("stationNumberListSelected");
      el.innerHTML = el.dataset.stationNumber || el.innerText; // przywróć oryginalny numer
    });

    // Zaznacz nową stację
    const numCells = document.querySelectorAll(".stationNumberList");
    const stationCells = document.querySelectorAll(".stationList");

    const numCell = numCells[stationId - 1];
    const stationCell = stationCells[stationId - 1];

    if (numCell && stationCell) 
    {
      numCell.classList.add("stationNumberListSelected");
      stationCell.classList.add("stationListSelected");
      
      // Pogrub nazwę stacji
      stationCell.dataset.stationName = stationCell.innerText; // zapisz oryginalny tekst
      stationCell.innerHTML = `<b>${stationCell.innerText}</b>`; // pogrubienie nazwy stacji

      //const original = stationCell.dataset.originalName || stationCell.innerText;
      //stationCell.dataset.originalName = original;
      //stationCell.innerText = original;
      //stationCell.style.fontWeight = "bold";

        
      // Pogrub numer
      numCell.dataset.stationNumber = numCell.innerText; // zapisz oryginalny numer
      numCell.innerHTML = `<b>${numCell.innerText}</b>`; 
      //const originalNum = numCell.dataset.originalNumber || numCell.innerText;
      //numCell.dataset.originalNumber = originalNum;
      //numCell.innerText = originalNum;
      //numCell.style.fontWeight = "bold";


    }
  }
  
  function flashBackground() 
	{
	  const div = document.getElementById('display');
	  const originalColor = div.style.backgroundColor;

	  const textSpan = document.getElementById('textStationName');
    const originalText = textSpan.innerText;


	  div.style.backgroundColor = '#115522'; // kolor flash
	  //textSpan.innerText = 'OLED Display Mode Changed';
    textSpan.innerHTML = '<b>Display Mode Changed</b>';  

	  setTimeout(() => 
	  {
		  div.style.backgroundColor = originalColor;
		  //textSpan.innerText = originalText;
      textSpan.innerHTML = `<b>${originalText}</b>`;
	  }, 150); // czas w ms flasha
	}



  // APMS FIX: zapasowa komunikacja HTTP, bo lokalny adapter WebServer nie obsluguje realnego WebSocket.
  function evoApplyState(data)
  {
    if (!data) return;
    const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
    const stationEl = document.getElementById("textStationName");
    if (stationEl) stationEl.textContent = data.stationname || "EVO RADIO";
    setText("stationText", data.stationtext || "Brak tytulu audycji");
    setText("stationNumber", "Station: " + (data.station !== undefined ? data.station : "--"));
    setText("bankValue", "Bank: " + (data.bank !== undefined ? data.bank : "--"));
    setText("textSliderValue", data.volume !== undefined ? data.volume : "--");
    const slider = document.getElementById("volumeSlider");
    if (slider && data.volume !== undefined) slider.value = data.volume;
    setText("muteIndicator", data.mute ? "MUTED" : "");
    setText("samplerate", data.samplerate || "---.-kHz");
    setText("bitrate", data.bitrate || "---kbps");
    setText("bitpersample", data.bitpersample || "---bit");
    setText("streamformat", data.streamformat || "----");
    if (typeof setWifi === "function" && data.wifi !== undefined) setWifi(Math.min(Math.max(parseInt(data.wifi), 1), 6));
    if (typeof highlightStation === "function" && data.station) highlightStation(parseInt(data.station));
  }

  function evoRefreshState()
  {
    fetch("/api/state", {cache:"no-store"}).then(r => r.json()).then(evoApplyState).catch(()=>{});
  }

  function evoSendCommand(cmd, value)
  {
    const url = "/webcmd?cmd=" + encodeURIComponent(cmd) + "&value=" + encodeURIComponent(value || "");
    return fetch(url, {cache:"no-store"}).then(r => r.json()).then(evoApplyState).catch(()=>{});
  }

  // W tej paczce sterowanie WWW idzie przez HTTP. Nie robimy ciaglych prob /ws.
  function connectWebSocket() { evoRefreshState(); }

  function updateSliderVolume(element)
  {
    const sliderValue = document.getElementById("volumeSlider").value;
    document.getElementById("textSliderValue").innerText = sliderValue;
    if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("volume:" + sliderValue);
    else evoSendCommand("volume", sliderValue);
  }

  function changeStation(number)
  {
    if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("station:" + number);
    else evoSendCommand("station", number);
  }

  function changeBank(number)
  {
    if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("bank:" + number);
    else evoSendCommand("bank", number);
  }

  function displayMode()
  {
    if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("displayMode");
    else evoSendCommand("displayMode", "");
  }

  document.addEventListener("DOMContentLoaded", function () 
  {
    connectWebSocket(); // podlaczamy websockety
    evoRefreshState();
    setInterval(evoRefreshState, 2000);

    const slider = document.getElementById("volumeSlider");
    slider.addEventListener("wheel", function (event) 
    {
      event.preventDefault(); // zapobiega przewijaniu strony

      let currentValue = parseInt(slider.value);
      const step = parseInt(slider.step) || 1;
      const max = parseInt(slider.max);
      const min = parseInt(slider.min);

      if (event.deltaY < 0) {
        // przewijanie w górę (zwiększ)
        slider.value = Math.min(currentValue + step, max);
      } else {
        // przewijanie w dół (zmniejsz)
        slider.value = Math.max(currentValue - step, min);
      }

      updateSliderVolume(slider); // wywołaj aktualizację
    });
  });

  window.onpageshow = function(event) 
  {
    if (event.persisted) 
    {
      window.location.reload();
    }
  };

 </script>
)rawliteral";

const char list_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML><html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html {font-family: Arial; display: inline-block; text-align: center;}
      h2 {font-size: 1.3rem;}
      p {font-size: 1.1rem;}
      table {border: 1px solid black; border-collapse: collapse; margin: 0px 0px;}
      td, th {font-size: 0.8rem; border: 1px solid gray; border-collapse: collapse;}
      td:hover {font-weight:bold;}
      a {color: black; text-decoration: none;}
      body {max-width: 1380px; margin:0px auto; padding-bottom: 25px;}
      .columnlist { align: center; padding: 10px; display: flex; justify-content: center;}
    </style>
  </head>
)rawliteral";

const char config_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML>
  <html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html {font-family: Arial; display: inline-block; text-align: center;}
      h1 {font-size: 2.3rem;}
      h2 {font-size: 1.3rem;}
      table {border: 1px solid black; border-collapse: collapse; margin: 20px auto; width: 80%;}
      th, td {font-size: 1rem; border: 1px solid gray; padding: 8px; text-align: left;}
      td:hover {font-weight: bold;}
      a {color: black; text-decoration: none;}
      body {max-width: 1380px; margin:0 auto; padding-bottom: 25px;}
      .tableSettings {border: 2px solid #4CAF50; border-collapse: collapse; margin: 10px auto; width: 60%;}
      input[type="checkbox"] {accent-color: #66BB6A; color: #FFFF50; width: 13px; height: 13px; }
      input[type="text"] { width: 240px; max-width: 95%; box-sizing: border-box;}
      @media (max-width:768px){.about-box,.tableSettings{width:90%!important;} table{width:100%!important;} th,td{font-size:0.9rem;}}
    </style>
    </head>

  <body>
  <h2>Evo Web Radio - Settings</h2>
  <form action="/configupdate" method="POST">
  <table class="tableSettings">
  <tr><th>Display Setting</th><th>Value</th></tr>
  <tr><td>Normal Display Brightness (0-255), default:180</td><td><input type="number" name="displayBrightness" min="1" max="255" value="%D1"></td></tr>
  <tr><td>Dimmed Display Brightness (0-200), default:20</td><td><input type="number" name="dimmerDisplayBrightness" min="1" max="200" value="%D2"></td></tr>
  <tr><td>Dimmed Display Brightness in Sleep Mode (0-50), default:1</td><td><input type="number" name="dimmerSleepDisplayBrightness" min="1" max="50" value="%D12"></td></tr>
  <tr><td>Auto Dimmer Delay Time (1-255 sec.), default:5</td><td><input type="number" name="displayAutoDimmerTime" min="1" max="255" value="%D3"></td></tr>
  <tr><td>Auto Dimmer, default:On</td><td><input type="checkbox" name="displayAutoDimmerOn" value="1" %S1_checked></td></tr>
  <tr><td>OLED Display Clock in Sleep Mode default:Off</td><td><input type="checkbox" name="f_displayPowerOffClock" value="1" %S19_checked></td></tr>
  <tr><td>OLED Display Power Save Mode, default:Off</td><td><input type="checkbox" name="displayPowerSaveEnabled" value="1" %S9_checked></td></tr>
  <tr><td>OLED Display Power Save Time (1-600sek.), default:20</td><td><input type="number" name="displayPowerSaveTime" min="1" max="600" value="%D9"></td></tr>
  <tr><td>Display Mode - 0 Radio, 1 Clock, 2 Info, 3 Center, 4 VU Analog, 5 Analyzer Bars, 6 Analyzer Segments, 7 SD Player, 8 Analyzer Bars Wide, 9 SD Recorder, 10 Floating Peaks, 11 DLNA, 12 Bluetooth, 13 EQ16, 14 Scope, 15 System, 16 V7 Crystal, 17 V7 Side, 18 VU Square, 19 Files, 20 Movie Clock, 21 Info WiFi</td><td><input type="number" name="displayMode" min="0" max="21" value="%D6"></td></tr>
  <tr><td><b>Miejscowosc pogody</b><br>Ta nazwa jest uzywana w panelu RADIO INFO. Wpisz np. Warszawa, Krakow, Golotczyzna.</td><td><input type="text" name="evoWeatherCity" maxlength="48" value="%WEATHER_CITY"></td></tr>

  <tr><th>Other Setting</th><th></th></tr>
  <tr><td>Time Voice Info Every Hour, default:On</td><td><input type="checkbox" name="timeVoiceInfoEveryHour" value="1" %S3_checked></td></tr>
  <tr><td>Encoder Function Order (0-1), 0-Volume, click for station list, 1-Station list, click for Volume</td><td><input type="number" name="encoderFunctionOrder" min="0" max="1" value="%D5"></td></tr>
  <tr><td>Radio Scroller & VU Meter Refresh Time (15-100ms), default:50</td><td><input type="number" name="scrollingRefresh" min="15" max="100" value="%D8"></td></tr>
  <tr><td>ADC Keyboard Enabled, default:Off</td><td><input type="checkbox" name="adcKeyboardEnabled" value="1" %S7_checked></td></tr>
  <tr><td>Volume Steps 1-21 [Off], 1-42 [On], default:Off</td><td><input type="checkbox" name="maxVolumeExt" value="1" %S11_checked></td></tr>
  <tr><td>Station Name Read From Stream [On-From Stream, Off-From Bank] EXPERIMENTAL</td><td><input type="checkbox" name="stationNameFromStream" value="1" %S17_checked></td></tr>
  <tr><td>Radio switch to Standby After Power Fail, default:On</td><td><input type="checkbox" name="f_sleepAfterPowerFail" value="1" %S21_checked></td></tr>
  <tr><td>Volume Fade on Station Change and Power Off, default:Off</td><td><input type="checkbox" name="f_volumeFadeOn" value="1" %S22_checked></td></tr>
  <tr><td>Save ALWAYS Station No., Bank No., Volume, default:Off</td><td><input type="checkbox" name="f_saveVolumeStationAlways" value="1" %S23_checked></td></tr>
  <tr><td>Power Off Animation, default:Off</td><td><input type="checkbox" name="f_powerOffAnimation" value="1" %S24_checked></td></tr>
  <tr><td>Timezone Settings</td><td><button type="button" class="button" onclick="location.href='/timezone'">Set</button></td></tr>
  <tr><td>Remote Control Settings</td><td><button type="button" class="button" onclick="location.href='/remoteconfig'">Set</button></td></tr>
  <tr><td>Presets On (Key 0-9 switching stations 1 to 10), default:Off</td><td><input type="checkbox" name="f_Presets" value="1" %S25_checked></td></tr>

  <tr><th><b>VU Meter Settings</b></th></tr>
  <tr><td>VU Meter Mode (0-1), 0-dashed lines, 1-continuous lines</td><td><input type="number" name="vuMeterMode" min="0" max="1" value="%D4"></td></tr>
  <tr><td>VU Meter Visible (Mode 0, 3 only), default:On</td><td><input type="checkbox" name="vuMeterOn" value="1" %S5_checked></td></tr>
  <tr><td>VU Meter Peak & Hold Function, default:On</td><td><input type="checkbox" name="vuPeakHoldOn" value="1" %S13_checked></td></tr>
  <tr><td>VU Meter Smooth Function, default:On</td><td><input type="checkbox" name="vuSmooth" value="1" %S15_checked></td></tr>
  <tr><td>VU Meter Smooth Rise Speed [1 low - 32 High], default:24</td><td><input type="number" name="vuRiseSpeed" min="1" max="32" value="%D10"></td></tr>
  <tr><td>VU Meter Smooth Fall Speed [1 low - 32 High], default:6</td><td><input type="number" name="vuFallSpeed" min="1" max="32" value="%D11"></td></tr>
  <tr><td><b>Poziom wysterowania VU / Analyzer (10-200%), default:65</b><br>Zmniejsz gdy wskazniki i analizatory dochodza stale do 100%.</td><td><input type="number" name="evo46VuDrive" min="10" max="200" value="%D46VU"></td></tr>
  <tr><td>FFT / Analyzer for Styles 5,6,8,10, default:On</td><td><input type="checkbox" name="fftAnalyzerOn" value="1" %S46AON_checked></td></tr>
  <tr><td>Analyzer Styles: 0=Classic, 1=Reduced, 2=All</td><td><input type="number" name="analyzerStyles" min="0" max="2" value="%D46AST"></td></tr>
  <tr><td>Analyzer Preset: 0=Classic, 1=Modern, 2=Compact, 3=Retro, 4=Custom</td><td><input type="number" name="analyzerPreset" min="0" max="4" value="%D46APR"></td></tr>
  <tr><td>Analyzer Settings</td><td><button type="button" class="button" onclick="location.href='/analyzer'">Configure</button></td></tr>

  <tr><th>SD Player Style Selection (SRC Button)</th><th></th></tr>
  <tr><td>Select which SD Player styles should be available in SRC button cycle:</td><td></td></tr>
  <tr><td>Enable SD Player Style 1 (List with top bar)</td><td><input type="checkbox" name="sdPlayerStyle1" value="1" %S46SD1_checked></td></tr>
  <tr><td>Enable SD Player Style 2 (Large track text)</td><td><input type="checkbox" name="sdPlayerStyle2" value="1" %S46SD2_checked></td></tr>
  <tr><td>Enable SD Player Style 3 (VU meter + track)</td><td><input type="checkbox" name="sdPlayerStyle3" value="1" %S46SD3_checked></td></tr>
  <tr><td>Enable SD Player Style 4 (Frequency spectrum)</td><td><input type="checkbox" name="sdPlayerStyle4" value="1" %S46SD4_checked></td></tr>
  <tr><td>Enable SD Player Style 5 (Minimalist)</td><td><input type="checkbox" name="sdPlayerStyle5" value="1" %S46SD5_checked></td></tr>
  <tr><td>Enable SD Player Style 6 (Album art simulation)</td><td><input type="checkbox" name="sdPlayerStyle6" value="1" %S46SD6_checked></td></tr>
  <tr><td>Enable SD Player Style 7 (Retro analyzer triangles)</td><td><input type="checkbox" name="sdPlayerStyle7" value="1" %S46SD7_checked></td></tr>
  <tr><td>Enable SD Player Style 9 (VU meters below scroll)</td><td><input type="checkbox" name="sdPlayerStyle9" value="1" %S46SD9_checked></td></tr>
  <tr><td>Enable SD Player Style 10 (Fullscreen animation)</td><td><input type="checkbox" name="sdPlayerStyle10" value="1" %S46SD10_checked></td></tr>
  <tr><td>Enable SD Player Style 11 (Based on Radio Mode 0)</td><td><input type="checkbox" name="sdPlayerStyle11" value="1" %S46SD11_checked></td></tr>
  <tr><td>Enable SD Player Style 12 (Based on Radio Mode 1)</td><td><input type="checkbox" name="sdPlayerStyle12" value="1" %S46SD12_checked></td></tr>
  <tr><td>Enable SD Player Style 13 (Based on Radio Mode 2)</td><td><input type="checkbox" name="sdPlayerStyle13" value="1" %S46SD13_checked></td></tr>
  <tr><td>Enable SD Player Style 14 (Based on Radio Mode 3)</td><td><input type="checkbox" name="sdPlayerStyle14" value="1" %S46SD14_checked></td></tr>

  <tr><th>Bluetooth Module (UART)</th><th></th></tr>
  <tr><td>Enable BT UART Module (RX=19, TX=20), default:Off</td><td><input type="checkbox" name="btUartEnabled" value="1" %S46BT_checked></td></tr>
  <tr><td>BT RX Volume (0-42)</td><td><input type="number" name="btVolume" min="0" max="42" value="%D46BTV"></td></tr>

  </table>
  <input type="submit" value="Update">
  </form>


  <p style='font-size: 0.8rem;'><a href='/menu'>Go Back</a></p>
  </body>
  </html>
)rawliteral";

const char remoteconfig_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML>
  <html>
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Evo Web Radio</title>

  <link rel="icon" href="/favicon.ico" type="image/x-icon">
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

  <style>
  html{font-family:Arial;display:inline-block;text-align:center;}
  body{max-width:1380px;margin:0 auto;padding-bottom:25px;}
  h1{font-size:2.3rem;}h2{font-size:1.3rem;}
  table{border:1px solid #000;border-collapse:collapse;margin:20px auto;width:40%;}
  th,td{font-size:1rem;border:1px solid gray;padding:8px;text-align:left;}
  td:hover{font-weight:bold;}
  tr.selected{background:#d0f0d0;}
  a{color:black;text-decoration:none;}
  .tableSettings{border:2px solid #4CAF50;border-collapse:collapse;margin:5px auto;width:40%;}
  input[type="checkbox"]{accent-color:#66BB6A;color:#FFFF50;width:13px;height:13px;}
  input[type="text"]{width:70px;box-sizing:border-box;}
  #wsBox{border:2px solid #4CAF50;padding:10px;margin:15px auto;width:38%;background:#f5fff5;font-size:1.1rem;}
  #wsDetails{padding:5px;margin:5px auto;width:100%;background:#f5fff5;font-size:0.8rem;}
  p{font-size:0.7rem;}
  #AddrValue { margin-right: 10px; font-size:0.8rem;}
  #CmdValue { margin-right: 10px; font-size:0.8rem;}
  #Learn{background:#f5fff5;font-size:0.8rem; color:#4CAF50; font-weight:bold;}
  @media(max-width:768px){.about-box,.tableSettings,#wsBox{width:90%!important;}table{width:100%!important;}th,td{font-size:.9rem;}}
  </style>
  </head>

  <body>

  <h2>Evo Web Radio - Remote Control Config</h2>

  <div id="wsBox">
    <strong>Received code:</strong> <span id="codeValue">—</span>
    <div id="wsDetails">
      <p>Address:<span id="AddrValue">—</span>  Command:<span id="CmdValue">—</span></p>
    </div>
    <div id="Learn"><span id="LearnIndicator"></span></div>
  </div>

  <p></p>

  <div style="margin:10px;">
    <button onclick="toggleRemoteConfig()">Learning Mode - ON/OFF</button>
    <label><input type="checkbox" id="autoMode">AUTO Mode</label>&nbsp;&nbsp;
    <button type="button" onclick="skipCurrent()">Skip Sellected</button>
  </div>

  <p> Single Mouse Click on Row - Select, Double Mouse Click - Reset Value (set 0xFEFE)</p>
  <p> Auto Mode, auto increment and select next cell affer receiving IR code</p>

  <form action="/remoteconfigupdate" method="POST">
  <table class="tableSettings">
  <tr><th>Codes:</th><th>Value</th></tr>

  <tr><td>Volume Up +</td><td><input type="text" name="cmdVolumeUp" value="%D0" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Volume Down -</td><td><input type="text" name="cmdVolumeDown" value="%D1" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Arrow Right (Next Station / Next Bank)</td><td><input type="text" name="cmdArrowRight" value="%D2" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Arrow Left (Prev Station / Prev Bank)</td><td><input type="text" name="cmdArrowLeft" value="%D3" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Arrow Up (Station List Up)</td><td><input type="text" name="cmdArrowUp" value="%D4" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Arrow Down (Station List Down)</td><td><input type="text" name="cmdArrowDown" value="%D5" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Back</td><td><input type="text" name="cmdBack" value="%D6" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>OK / Enter</td><td><input type="text" name="cmdOk" value="%D7" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Display Screen Mode</td><td><input type="text" name="cmdSrc" value="%D8" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Mute</td><td><input type="text" name="cmdMute" value="%D9" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Equalizer</td><td><input type="text" name="cmdAud" value="%D10" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Display Brightness / Bank Network Update</td><td><input type="text" name="cmdDirect" value="%D11" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Bank Menu (-)</td><td><input type="text" name="cmdBankMinus" value="%D12" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Bank Menu (+)</td><td><input type="text" name="cmdBankPlus" value="%D13" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Power On / Off</td><td><input type="text" name="cmdRedPower" value="%D14" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Sleep</td><td><input type="text" name="cmdGreen" value="%D15" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  <tr><td>Key 0</td><td><input type="text" name="cmdKey0" value="%D16" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 1</td><td><input type="text" name="cmdKey1" value="%D17" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 2</td><td><input type="text" name="cmdKey2" value="%D18" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 3</td><td><input type="text" name="cmdKey3" value="%D19" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 4</td><td><input type="text" name="cmdKey4" value="%D20" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 5</td><td><input type="text" name="cmdKey5" value="%D21" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 6</td><td><input type="text" name="cmdKey6" value="%D22" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 7</td><td><input type="text" name="cmdKey7" value="%D23" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 8</td><td><input type="text" name="cmdKey8" value="%D24" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>
  <tr><td>Key 9</td><td><input type="text" name="cmdKey9" value="%D25" pattern="0x[0-9A-Fa-f]{4}" maxlength="6" title="Format: 0xFFFF"></td></tr>

  </table>

  <input type="submit" value="Update">
  </form>

  <p style="font-size:.8rem;"><a href="/menu">Go Back</a></p>

  <script>
  let websocket;
  let activeInput = null;
  let inputs = [];
  let currentIndex = -1;
  let autoMode = false;

  function toggleRemoteConfig() {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/toggleRemoteConfig", true);
    xhr.send();
  }

  function clearSelection() {
    document.querySelectorAll(".tableSettings tr")
      .forEach(r => r.classList.remove("selected"));
    activeInput = null;
    currentIndex = -1;
  }

  function selectInputByIndex(index) {
    if (index >= inputs.length) {
      autoMode = false;
      document.getElementById("autoMode").checked = false;
      clearSelection();
      return;
    }

    clearSelection();
    currentIndex = index;
    activeInput = inputs[index];
    const row = activeInput.closest("tr");
    row.classList.add("selected");
    activeInput.focus();
  }

  function moveNext() {
    selectInputByIndex(currentIndex + 1);
  }

  function skipCurrent() {
    if (!activeInput) return;
    activeInput.value = "0xFEFE";
    if (autoMode) moveNext();
  }

  document.getElementById("autoMode").addEventListener("change", function () {
    autoMode = this.checked;
    if (autoMode) selectInputByIndex(0);
    else clearSelection();
  });

  document.addEventListener("DOMContentLoaded", function () {
    inputs = Array.from(
      document.querySelectorAll('.tableSettings input[type="text"]')
    );

    inputs.forEach((input, index) => {
      const row = input.closest("tr");

      row.onclick = () => selectInputByIndex(index);
      row.ondblclick = () => {
        input.value = "0xFEFE";
        selectInputByIndex(index);
      };
    });

    websocket = new WebSocket('ws://' + window.location.hostname + '/ws');

    websocket.onmessage = function (event) {
      if (event.data.startsWith("addr:"))
        document.getElementById('AddrValue').innerText = event.data.split(":")[1];

      if (event.data.startsWith("cmd:"))
        document.getElementById('CmdValue').innerText = event.data.split(":")[1];

      if (event.data.startsWith("learn:"))
        document.getElementById("LearnIndicator").innerText =
          parseInt(event.data.split(":")[1]) ? "LEARNING MODE ON" : "";

      if (event.data.startsWith("ircode:")) {
        const codeStr = event.data.split(":")[1].trim();
        document.getElementById('codeValue').innerText = codeStr;

        if (activeInput) {
          activeInput.value = codeStr;
          if (autoMode) moveNext();
        }
      }
    };
  });
  </script>

  </body>
  </html>
)rawliteral";

const char adc_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML>
  <html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html {font-family: Arial; display: inline-block; text-align: center;}
      h1 {font-size: 2.3rem;}
      h2 {font-size: 1.3rem;}
      table {border: 1px solid black; border-collapse: collapse; margin: 10px auto; width: 40%;}
      th, td {font-size: 1rem; border: 1px solid gray; padding: 8px; text-align: left;}
      td:hover {font-weight: bold;}
      a {color: black; text-decoration: none;}
      body {max-width: 1380px; margin:0 auto; padding-bottom: 15px;}
      .tableSettings {border: 2px solid #4CAF50; border-collapse: collapse; margin: 10px auto; width: 40%;}
      .button { background-color: #4CAF50; border: 1; color: white; padding: 10px 20px; border-radius: 5px; width:200px;}
      .button:hover {background-color: #4a4a4a;}
      .button:active {background-color: #4a4a4a; box-shadow: 0 4px #666; transform: translateY(2px);}
    </style>
    </head>

  <body>
  <h2>Evo Web Radio - ADC Settings</h2>
  <form action="/configadc" method="POST">
  <table class="tableSettings">
  <tr><th>Button</th><th>Value</th></tr>
  <tr><td>Key 0</td><td><input type="number" name="keyboardButtonThreshold_0" min="0" max="4100" value="%D0"></td></tr>
  <tr><td>Key 1</td><td><input type="number" name="keyboardButtonThreshold_1" min="0" max="4100" value="%D1"></td></tr>
  <tr><td>Key 2</td><td><input type="number" name="keyboardButtonThreshold_2" min="0" max="4100" value="%D2"></td></tr>
  <tr><td>Key 3</td><td><input type="number" name="keyboardButtonThreshold_3" min="0" max="4100" value="%D3"></td></tr>
  <tr><td>Key 4</td><td><input type="number" name="keyboardButtonThreshold_4" min="0" max="4100" value="%D4"></td></tr>
  <tr><td>Key 5</td><td><input type="number" name="keyboardButtonThreshold_5" min="0" max="4100" value="%D5"></td></tr>
  <tr><td>Key 6</td><td><input type="number" name="keyboardButtonThreshold_6" min="0" max="4100" value="%D6"></td></tr>
  <tr><td>Key 7</td><td><input type="number" name="keyboardButtonThreshold_7" min="0" max="4100" value="%D7"></td></tr>
  <tr><td>Key 8</td><td><input type="number" name="keyboardButtonThreshold_8" min="0" max="4100" value="%D8"></td></tr>
  <tr><td>Key 9</td><td><input type="number" name="keyboardButtonThreshold_9" min="0" max="4100" value="%D9"></td></tr>
  <tr><td>OK / Enter Key</td><td><input type="number" name="keyboardButtonThreshold_Ok" min="0" max="4100" value="%D10"></td></tr>
  <tr><td>Display Bank Menu Key</td><td><input type="number" name="keyboardButtonThreshold_BankMenu" min="0" max="4100" value="%D11"></td></tr>
  <tr><td>Back Key</td><td><input type="number" name="keyboardButtonThreshold_Back" min="0" max="4100" value="%D12"></td></tr>
  <tr><td>OLED Display Mode Key</td><td><input type="number" name="keyboardButtonThreshold_DisplayMode" min="0" max="4100" value="%D13"></td></tr>
  <tr><td>Dimmer / Network Bank Update Key</td><td><input type="number" name="keyboardButtonThreshold_Dimmer" min="0" max="4100" value="%D14"></td></tr>
  <tr><td>Mute Key</td><td><input type="number" name="keyboardButtonThreshold_Mute" min="0" max="4100" value="%D15"></td></tr>
  
  <tr><td>Navigation Left - Previous Station / Bank</td><td><input type="number" name="keyboardButtonThreshold_ArrowLeft" min="0" max="4100" value="%D19"></td></tr>
  <tr><td>Navigation Right - Next Statition / Bank</td><td><input type="number" name="keyboardButtonThreshold_ArrowRight" min="0" max="4100" value="%D20"></td></tr>
  <tr><td>Navigation Up - Station List Up</td><td><input type="number" name="keyboardButtonThreshold_ArrowUp" min="0" max="4100" value="%D21"></td></tr>
  <tr><td>Navigation Down - Station List Down</td><td><input type="number" name="keyboardButtonThreshold_ArrowDown" min="0" max="4100" value="%D22"></td></tr>
  
  <tr><td>Presets On Key</td><td><input type="number" name="keyboardButtonThreshold_PresetsOn" min="0" max="4100" value="%D23"></td></tr>

  <tr><td>Keyboard Buttons Threshold Tolerance</td><td><input type="number" name="keyboardButtonThresholdTolerance" min="0" max="50" value="%D16"></td></tr>
  <tr><td>Keyboard Buttons Neutral</td><td><input type="number" name="keyboardButtonNeutral" min="0" max="4100" value="%D17"></td></tr>
  <tr><td>Keyboard Sample Delay (30-300ms)</td><td><input type="number" name="keyboardSampleDelay" min="30" max="300" value="%D18"></td></tr>
  </table>
  <input type="submit" value="ADC Thresholds Update">
  </form>
  <br>
  <button onclick="toggleAdcDebug()">ADC Debug ON/OFF</button>
  <script>
  function toggleAdcDebug() {
      const xhr = new XMLHttpRequest();
      xhr.open("POST", "/toggleAdcDebug", true);
      xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
      xhr.onload = function() {
          if (xhr.status === 200) {
              alert("ADC Debug is now " + (xhr.responseText === "1" ? "ON" : "OFF"));
          } else {
              alert("Error: " + xhr.statusText);
          }
      };
      xhr.send(); // Wysyłanie pustego zapytania POST
  }
  </script>

  <p style='font-size: 0.8rem;'><a href='/menu'>Go Back</a></p>
  </body>
  </html>
)rawliteral";


// ==================== V46 WIFI NETWORKS MANAGEMENT PAGE ====================
const char wifi_html[] PROGMEM = R"rawliteral(
<!DOCTYPE HTML><html><head><meta charset="UTF-8">
<link rel='icon' href='/favicon.ico' type='image/x-icon'>
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Evo Web Radio - WiFi</title>
<style>
html{font-family:Arial;text-align:center}body{max-width:650px;margin:0 auto;padding:10px;background:#fafafa}h2{font-size:1.4rem}table{width:100%;border-collapse:collapse;margin:10px 0;background:white}th,td{padding:8px;border:1px solid #ccc;font-size:.9rem;text-align:left}.btn{padding:7px 14px;border:none;border-radius:5px;cursor:pointer;color:#fff}.btn-del{background:#e53935}.btn-add{background:#4CAF50;width:100%;padding:11px;font-size:1rem}.btn-scan{background:#2196F3;margin-top:4px}input[type=text],input[type=password],select{width:100%;padding:8px;box-sizing:border-box;margin:5px 0;font-size:.95rem}.note{font-size:.82rem;color:#555;margin-top:14px}a{color:#2b5bb3}.card{background:white;border:1px solid #ddd;border-radius:10px;padding:12px;margin:10px 0;box-shadow:0 2px 8px #0001}</style>
</head><body>
<h2>WiFi Networks</h2>
<div class="card"><p style="font-size:.9rem;color:#555">Sieci WiFi sa zapisane lokalnie w <b>/wifi_multi.cfg</b>. Przy kolejnej wersji mozna je podpiac do automatycznego wyboru sieci przy starcie; strona i zapis sa zgodne z EVO3 MOD OST.</p></div>
<table id="netTable"><tr><th>#</th><th>SSID</th><th>Haslo</th><th></th></tr></table>
<div class="card"><h3>Dodaj siec</h3><input type="text" id="ssidIn" placeholder="Nazwa sieci (SSID)"><button class="btn btn-scan" onclick="doScan()">📶 Skanuj sieci</button><select id="scanSel" style="display:none;margin-top:4px" onchange="document.getElementById('ssidIn').value=this.value"></select><input type="password" id="passIn" placeholder="Haslo WiFi"><button class="btn btn-add" onclick="doAdd()">+ Dodaj siec</button><p class="note">Maksymalnie 5 sieci.</p></div>
<p><a href="/menu">← Wróć do Menu</a></p>
<script>
function load(){fetch('/wifi-list').then(r=>r.json()).then(data=>{const t=document.getElementById('netTable');while(t.rows.length>1)t.deleteRow(1);if(data.length===0){const r=t.insertRow();const c=r.insertCell();c.colSpan=4;c.textContent='Brak zapisanych sieci';c.style.textAlign='center';}data.forEach((n,i)=>{const r=t.insertRow();r.insertCell().textContent=i+1;r.insertCell().textContent=n.ssid;r.insertCell().textContent=n.pass?'••••••':'(brak)';const c=r.insertCell();const b=document.createElement('button');b.textContent='Usun';b.className='btn btn-del';b.onclick=()=>doRemove(i);c.appendChild(b);});});}
function doScan(){const btn=document.querySelector('.btn-scan');btn.textContent='Skanowanie...';btn.disabled=true;fetch('/wifi-scan').then(r=>r.json()).then(data=>{btn.textContent='📶 Skanuj sieci';btn.disabled=false;const sel=document.getElementById('scanSel');sel.innerHTML='';if(data.length===0){alert('Nie znaleziono sieci');return;}data.forEach(s=>{const o=document.createElement('option');o.value=s;o.textContent=s;sel.appendChild(o);});sel.style.display='block';document.getElementById('ssidIn').value=data[0];}).catch(()=>{btn.textContent='📶 Skanuj sieci';btn.disabled=false;});}
function doAdd(){const ss=document.getElementById('ssidIn').value.trim();const pp=document.getElementById('passIn').value;if(!ss){alert('Wpisz nazwe sieci');return;}const fd=new URLSearchParams();fd.append('ssid',ss);fd.append('pass',pp);fetch('/wifi-add',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()}).then(r=>r.text()).then(t=>{alert(t);load();document.getElementById('ssidIn').value='';document.getElementById('passIn').value='';document.getElementById('scanSel').style.display='none';});}
function doRemove(i){if(!confirm('Usunac siec #'+(i+1)+'?'))return;const fd=new URLSearchParams();fd.append('idx',i);fetch('/wifi-remove',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:fd.toString()}).then(r=>r.text()).then(t=>{alert(t);load();});}
load();
</script></body></html>
)rawliteral";
// ========================================================================

const char menu_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML><html>
  <head>
  <link rel='icon' href='/favicon.ico' type='image/x-icon'>
  <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
  <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Evo Web Radio</title>
  <style>
    html {font-family: Arial; display: inline-block; text-align: center;}
    h2 {font-size: 1.3rem;}
    p {font-size: 1.1rem;}
    a {color: black; text-decoration: none;}
    body {max-width: 1380px; margin:0px auto; padding-bottom: 25px;}
    .button { background-color: #4CAF50; border: 1; color: white; padding: 10px 20px; border-radius: 5px; width:200px;}
    .button:hover {background-color: #4a4a4a;}
    .button:active {background-color: #4a4a4a; box-shadow: 0 4px #666; transform: translateY(2px);}
    
  </style>
  </head>
  <body>
  <h2>Evo Web Radio - Menu</h2>
  <!-- <br><button class="button" onclick="location.href='/fwupdate'">OTA Update (Old)</button><br> -->
  <br><button class="button" onclick="location.href='/info'">Info</button><br>
  <br><button class="button" onclick="location.href='/ota'">OTA Update</button><br>
  <br><button class="button" onclick="location.href='/sdplayer'">SD Player</button><br>
  <br><button class="button" onclick="location.href='/sdrecorder'">SD Recorder</button><br>
  <br><button class="button" onclick="location.href='/dlna'">DLNA Browser</button><br>
  <br><button class="button" onclick="location.href='/bt'">Bluetooth Settings</button><br>
  <br><button class="button" onclick="location.href='/remoteconfig'">Remote Control</button><br>
  <br><button class="button" onclick="location.href='/wifi'">WiFi Networks</button><br>
  <br><button class="button" onclick="location.href='/eq16'">Graphic EQ16</button><br>
  <br><button class="button" onclick="location.href='/analyzer'">Analyzer Edit</button><br>
  <br><button class="button" onclick="location.href='/adc'">ADC Keyboard Settings</button><br>
  <br><button class="button" onclick="location.href='/list'">Storage Memory Explorer</button><br>
  <br><button class="button" onclick="location.href='/editor'">Memory Bank Editor</button><br>
  <br><button class="button" onclick="location.href='/browser'">Radio Browser API</button><br>
  <br><button class="button" onclick="location.href='/playurl'">Play from URL</button><br>
  <br><button class="button" onclick="location.href='/config'">Settings</button><br>
  <br><p style='font-size: 0.8rem;'><a href="#" onclick="window.location.replace('/')">Go Back</a></p>
  </body></html>

)rawliteral";

const char info_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML>
  <html>
  <head>
    <link rel='icon' href='/favicon.ico' type='image/x-icon'>
    <link rel="shortcut icon" href="/favicon.ico" type="image/x-icon">
    <link rel="apple-touch-icon" sizes="180x180" href="/icon.png">
    <link rel="icon" type="image/png" sizes="192x192" href="/icon.png">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Evo Web Radio</title>
    <style>
      html{font-family:Arial;display:inline-block;text-align:center;} 
      h2{font-size:1.3rem;} 
      table{border:1px solid black;border-collapse:collapse;margin:10px auto;width:40%;} 
      th,td{font-size:1rem;border:1px solid gray;padding:8px;text-align:left;} 
      td:hover{font-weight:bold;} 
      a{color:black;text-decoration:none;} 
      body{max-width:1380px;margin:0 auto;padding-bottom:15px;} 
      .tableSettings{border:2px solid #4CAF50;border-collapse:collapse;margin:10px auto;width:40%;} 
      .signal-bars{display:inline-block;vertical-align:middle;margin-left:10px;} 
      .bar{display:inline-block;width:5px;margin-right:2px;background-color:#F2F2F2;height:10px;} 
      .bar.active{background-color:#4CAF50;} 
      .about-box{border:2px solid #4CAF50;border-collapse:collapse;margin:10px auto;width:40%;text-align:left;font-size:0.9rem;line-height:1.4rem;color:#222;} 
      .about-box h3{color:#2f7a2f;margin-top:0;text-align:center;font-size:1.05rem;} 
      .about-box a{color:#2b5bb3;text-decoration:none;} 
      .about-box a:hover{text-decoration:underline;}
      @media (max-width:768px){.about-box,.tableSettings{width:90%!important;} table{width:100%!important;} th,td{font-size:0.9rem;}}
    </style>
  </head>
  <body>
  <h2>Evo Web Radio - Info</h2>

  <div class="about-box">
    <h3>Project Info</h3>
    <p>This is a project of an Internet radio streamer called <strong>"Evo"</strong>. The hardware was built using an <strong>ESP32-S3</strong> microcontroller and a <strong>PCM5102A DAC codec</strong>.</p>
    <p>The design allows listening to various music stations from all around the world and works properly with streams encoded in <strong>MP3</strong>, <strong>AAC</strong>, 
    <strong>VORBIS</strong>, <strong>OPUS</strong>, and <strong>FLAC</strong> (up to 2000kbs, 24bit).</p>
    <p>All operations (volume control, station change, memory bank selection, power on/off) are handled via a single rotary encoder. It also supports infrared remote controls working on the <strong>NEC standard (38&nbsp;kHz)</strong>.</p>
    <p></p>
    <p>Source code and documentation are available at: <b><a href="https://github.com/dzikakuna/ESP32_radio_evo3" target="_blank">Link: https://github.com/dzikakuna/ESP32_radio_evo3</a></b></p>
    <p>Robgold 2026, Made in Poland</p>
  </div>

  <table class="tableSettings">
      <tr><td>ESP Serial Number:</td><td><input name="espSerial" value="%D0"></td></tr>
      <tr><td>Firmware Version:</td><td><input name="espFw" value="%D1"></td></tr>
      <tr><td>Hostname:</td><td><input name="hostnameValue" value="%D2"></td></tr>
      <tr><td>WiFi Signal Strength [dBm]:</td><td><input id="wifiSignal" value="%D3"></td></tr>
      <tr><td>WiFi SSID:</td><td><input name="wifiSsid" value="%D4"></td></tr>
      <tr><td>IP Address:</td><td><input name="ipValue" value="%D5"></td></tr>
      <tr><td>MAC Address:</td><td><input name="macValue" value="%D6"></td></tr>
      <tr><td>Memory type:</td><td><input name="memValue" value="%D7"></td></tr>
    </table>
  <br>
  <p style="font-size:0.8rem;"><a href="/menu">Go Back</a></p>
  </body>
  </html>
)rawliteral";

const char urlplay_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE HTML>
  <html>
    <head>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Evo Web Radio</title>

      <style>
        html {font-family: Arial; text-align: center;}
        body {max-width: 1380px; margin: 0 auto; background: #D0D0D0; padding-bottom: 25px;}
        h2 {font-size: 1.3rem;}
        p {font-size: 0.95rem;}
        .slider{-webkit-appearance:none;margin:14px;width:330px;height:10px;background:#4CAF50;outline:none;-webkit-transition:.2s;transition:opacity .2s;border-radius:5px}
        .slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:35px;height:25px;background:#4a4a4a;cursor:pointer;border-radius:5px}
        .slider::-moz-range-thumb{width:35px;height:35px;background:#4a4a4a;cursor:pointer;border-radius:5px}
        .button {background-color:#4CAF50;border:1; color:white; padding:10px 20px; border-radius:5px;cursor:pointer;}
        .button:hover {background-color:#4a4a4a;}
        .button.active {background-color: #115522; transform: scale(1.05); transition: all 0.15s ease;}
        #urlInput {width:350px; padding:5px; border-radius:5px; font-size:0.9rem;}
        #playBtn {padding:5px 10px; font-size:0.9rem;}
        #display {display:inline-block; padding:5px; border:2px solid #4CAF50; border-radius:15px; background-color:#4a4a4a; font-size:1.45rem; color:#AAA; width:345px; text-align:center; white-space:nowrap; box-shadow:0 0 20px #4CAF50;}
        #stationTextDiv {display:block; text-overflow:ellipsis; white-space:normal; font-size:1.0rem; color:#999; margin-bottom:10px; text-align:center; height:4.2em; overflow:hidden; line-height:1.4em;}
        #muteIndicatorDiv {text-align:center; color:#4CAF50; font-weight:bold; font-size:1.0rem; height:1.4em;}
        #urlInput.flash {background-color: #4CAF50;color: #fff; transition: background-color 0.3s ease;}
        .wifi-wrapper {display: flex; align-items: flex-end; gap: 1px; height: 13px; margin-top: -3px; margin-bottom: 3px; justify-content: center; }
        .wifiBar {width: 2px;background-color: #555; border-radius: 2px; transition: background-color 0.2s;}
        .bar1 { height: 2px; }
        .bar2 { height: 4px; }
        .bar3 { height: 6px; }
        .bar4 { height: 8px; }
        .bar5 { height: 10px; }
        .bar6 { height: 12px; }
      </style>
  </head>

  <body>
  <h2>Evo Web Radio - URL Play</h2>

  <div id="display" onclick="flashBackground(); displayMode();">
      <div style="margin-bottom:10px; font-weight:bold; overflow:hidden; text-overflow:ellipsis;">
          <span id="textStationName"><b>STATIONNAME</b></span>
      </div>

      <div style="width:345px; margin-bottom:10px;">
          <div id="stationTextDiv">
              <span id="stationText">STATIONTEXT</span>
          </div>
          <div id="muteIndicatorDiv">
              <span id="muteIndicator"></span>
          </div>
      </div>

      <div style="height:1px; background-color:#4CAF50; margin:5px 0;"></div>

      <div style="display:flex; justify-content:center; gap:13px; font-size:1.0rem; color:#999;">
          <div><span id="bankValue">Bank: --</span></div>
            <div style="display:flex; gap:6px; font-size:0.55rem; color:#999;margin:4px 0;">
              <div><span id="samplerate">---.-kHz</span></div>
              <div><span id="bitrate">---kbps</span></div>
              <div><span id="bitpersample">---bit</span></div>
              <div><span id="streamformat">----</span></div>
              WiFi: <div class="wifi-wrapper">
              <div class="wifiBar bar1" id="wifiBar1"></div>
              <div class="wifiBar bar2" id="wifiBar2"></div>
              <div class="wifiBar bar3" id="wifiBar3"></div>
              <div class="wifiBar bar4" id="wifiBar4"></div>
              <div class="wifiBar bar5" id="wifiBar5"></div>
              <div class="wifiBar bar6" id="wifiBar6"></div>
  	        </div>
          </div>
          <div><span id="stationNumber">Station: --</span></div>
      </div>
  </div>

  <br><br>

  <!-- URL + PLAY -->
  <p><input id="urlInput" type="text" placeholder="Put your URL here"></p>
  <p><button id="playBtn" class="button" onclick="playStream()">PLAY</button></p>

  <br>

  <!-- Volume -->
  <p>Volume: <span id="textSliderValue">--</span></p>
  <p><input type="range" onchange="updateSliderVolume()" id="volumeSlider" min="1" max="21" value="1" step="1" class="slider"></p>

  <p style='font-size: 0.8rem;'><a href="#" onclick="window.location.replace('/menu')">Go Back</a></p>

  <script>
  var websocket;

  function setWifi(level) 
  {
    for (let i = 1; i <= 6; i++) 
    {
      const bar = document.getElementById("wifiBar" + i);
      if (bar) {bar.style.backgroundColor = (i <= level) ? "#4CAF50" : "#555";}
    }
  }


  function connectWebSocket() 
  {
      websocket = new WebSocket('ws://' + window.location.hostname + '/ws');

      websocket.onopen = function() {
          console.log("WebSocket połączony");
      };

      websocket.onclose = function() {
          console.log("WebSocket zamknięty, reconnect za 3s...");
          setTimeout(connectWebSocket, 3000);
      };

      websocket.onerror = function(err) {
          console.error("Błąd WebSocket:", err);
          websocket.close();
      };

      websocket.onmessage = function(event) {
          const data = event.data;

          if (data.startsWith("volume:")) {
              const vol = parseInt(data.split(":")[1]);
              document.getElementById("volumeSlider").value = vol;
              document.getElementById("textSliderValue").innerText = vol;
          }

          if (data.startsWith("stationname:")) {
              const value = data.split(":")[1];
              document.getElementById("textStationName").innerHTML = "<b>" + value + "</b>";
          }

          if (data.startsWith("stationtext$")) {
              const text = data.substring(data.indexOf("$") + 1);
              document.getElementById("stationText").textContent = text;
          }

          if (data.startsWith("station:")) {
              const station = parseInt(data.split(":")[1]);
              document.getElementById("stationNumber").innerText = "Station: " + station;
          }

          if (data.startsWith("bank:")) {
              const bank = parseInt(data.split(":")[1]);
              document.getElementById("bankValue").innerText = "Bank: " + bank;
          }

          if (data.startsWith("samplerate:")) {
              const rate = parseInt(data.split(":")[1]);
              document.getElementById("samplerate").innerText = (rate / 1000).toFixed(1) + "kHz";
          }

          if (data.startsWith("bitrate:")) {
              document.getElementById("bitrate").innerText = data.split(":")[1] + "kbps";
          }

          if (data.startsWith("bitpersample:")) {
              document.getElementById("bitpersample").innerText = data.split(":")[1] + "bit";
          }

          if (data.startsWith("streamformat:")) {
              document.getElementById("streamformat").innerText = data.split(":")[1];
          }

          if (data.startsWith("mute:")) {
              const mute = parseInt(data.split(":")[1]);
              document.getElementById("muteIndicator").innerText = mute === 1 ? "MUTED" : "";
          }

          if (event.data.startsWith("wifi:")) {
            const level = parseInt(event.data.split(":")[1]);
            if (!isNaN(level)) {setWifi(Math.min(Math.max(level, 1), 6));}
          }
      };
  }

  function updateSliderVolume() {
      const slider = document.getElementById("volumeSlider");
      const value = slider.value;
      document.getElementById("textSliderValue").innerText = value;

      if (websocket && websocket.readyState === WebSocket.OPEN) {
          websocket.send("volume:" + value);
      }
  }

  function playStream() {
      const urlInput = document.getElementById("urlInput");
      const url = urlInput.value.trim();
      const host = window.location.hostname;

      urlInput.classList.add("flash");
      setTimeout(() => urlInput.classList.remove("flash"), 300);

      if (!url) return;

      fetch("http://" + host + "/update?url=" + encodeURIComponent(url))
          .catch(err => console.error("Błąd połączenia:", err));
  }

  function flashBackground() {
      const div = document.getElementById("display");
      const text = document.getElementById("textStationName");
      const origColor = div.style.backgroundColor;
      const origText = text.innerHTML;

      div.style.backgroundColor = "#115522";
      text.innerHTML = "<b>Display Mode Changed</b>";

      setTimeout(() => {
          div.style.backgroundColor = origColor;
          text.innerHTML = origText;
      }, 150);
  }

  function displayMode() {
      if (websocket && websocket.readyState === WebSocket.OPEN) {
          websocket.send("displayMode");
      }
  }


  // APMS FIX: zapasowa komunikacja HTTP dla strony URL Play.
  function evoApplyState(data) {
      if (!data) return;
      const setText = (id, value) => { const el = document.getElementById(id); if (el) el.textContent = value; };
      setText("textStationName", data.stationname || "EVO RADIO");
      setText("stationText", data.stationtext || "Brak tytulu audycji");
      setText("stationNumber", "Station: " + (data.station !== undefined ? data.station : "--"));
      setText("bankValue", "Bank: " + (data.bank !== undefined ? data.bank : "--"));
      setText("textSliderValue", data.volume !== undefined ? data.volume : "--");
      const slider = document.getElementById("volumeSlider");
      if (slider && data.volume !== undefined) slider.value = data.volume;
      setText("muteIndicator", data.mute ? "MUTED" : "");
      setText("samplerate", data.samplerate || "---.-kHz");
      setText("bitrate", data.bitrate || "---kbps");
      setText("bitpersample", data.bitpersample || "---bit");
      setText("streamformat", data.streamformat || "----");
      if (typeof setWifi === "function" && data.wifi !== undefined) setWifi(Math.min(Math.max(parseInt(data.wifi), 1), 6));
  }

  function evoRefreshState() {
      fetch("/api/state", {cache:"no-store"}).then(r => r.json()).then(evoApplyState).catch(()=>{});
  }

  function evoSendCommand(cmd, value) {
      return fetch("/webcmd?cmd=" + encodeURIComponent(cmd) + "&value=" + encodeURIComponent(value || ""), {cache:"no-store"})
          .then(r => r.json()).then(evoApplyState).catch(()=>{});
  }

  // W tej paczce sterowanie WWW idzie przez HTTP. Nie robimy ciaglych prob /ws.
  function connectWebSocket() { evoRefreshState(); }

  function updateSliderVolume() {
      const slider = document.getElementById("volumeSlider");
      const value = slider.value;
      document.getElementById("textSliderValue").innerText = value;
      if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("volume:" + value);
      else evoSendCommand("volume", value);
  }

  function displayMode() {
      if (websocket && websocket.readyState === WebSocket.OPEN) websocket.send("displayMode");
      else evoSendCommand("displayMode", "");
  }
  document.addEventListener("DOMContentLoaded", () => {
      connectWebSocket();
      evoRefreshState();
      setInterval(evoRefreshState, 2000);
  });
  </script>
  </body>
  </html>
)rawliteral";

const char timezone_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE html>
  <html>
  <head>
  <meta charset="UTF-8">
  <title>Timezone Settings</title>
  <style>
  body { font-family: Arial; background: #D0D0D0; text-align: center; padding: 20px; }
  .tzField { width: 380px; padding: 8px; border-radius: 6px; border: 2px solid #4CAF50; font-size: 1rem; margin-bottom: 10px; text-align: left; }
  input#tzCustom { width: 380px; display: block; margin: 10px auto; text-align: center; }
  button { padding: 10px 20px; background: #4CAF50; color: white; border: 1; border-radius: 6px; cursor: pointer; font-size: 1rem; }
  button:hover { background: #3e8e41;}
  #msg { margin-top: 15px; font-weight: bold; }
  </style>
  </head>
  <body>

  <h2>Evo Web Radio - Timezone Set</h2>
  <p>Current timezone:
  <b id="currentTZ">Loading...</b></p>

  <p>Select timezone from list</p>

  <select id="tzSelect" class="tzField" onchange="selectChanged()">
      <option value="custom">Custom...</option>

      <!-- Europe -->
      <optgroup label="Europe">
          <option value="UTC0">UTC / GMT - UTC0</option>
          <option value="GMT0BST,M3.5.0/1,M10.5.0/2">United Kingdom - GMT0BST,M3.5.0/1,M10.5.0/2</option>
          <option value="CET-1CEST,M3.5.0/2,M10.5.0/3">Central Europe - CET-1CEST,M3.5.0/2,M10.5.0/3</option>
          <option value="EET-2EEST,M3.5.0/3,M10.5.0/4">Eastern Europe - EET-2EEST,M3.5.0/3,M10.5.0/4</option>
          <option value="GMT-1">Azores - GMT-1</option>
          <option value="WET0WEST,M3.5.0/1,M10.5.0/2">Portugal - WET0WEST,M3.5.0/1,M10.5.0/2</option>
          <option value="MSK-3">Moscow - MSK-3</option>
      </optgroup>

      <!-- North America -->
      <optgroup label="North America">
          <option value="EST5EDT,M3.2.0/2,M11.1.0/2">US Eastern - EST5EDT,M3.2.0/2,M11.1.0/2</option>
          <option value="CST6CDT,M3.2.0/2,M11.1.0/2">US Central - CST6CDT,M3.2.0/2,M11.1.0/2</option>
          <option value="MST7MDT,M3.2.0/2,M11.1.0/2">US Mountain - MST7MDT,M3.2.0/2,M11.1.0/2</option>
          <option value="PST8PDT,M3.2.0/2,M11.1.0/2">US Pacific - PST8PDT,M3.2.0/2,M11.1.0/2</option>
          <option value="AKST9AKDT,M3.2.0/2,M11.1.0/2">Alaska - AKST9AKDT,M3.2.0/2,M11.1.0/2</option>
          <option value="HST10">Hawaii - HST10</option>
      </optgroup>

      <!-- South America -->
      <optgroup label="South America">
          <option value="ART-3">Argentina - ART-3</option>
          <option value="BRT-3">Brazil - BRT-3</option>
          <option value="CLT-4CLST,M9.1.0/0,M4.1.0/0">Chile - CLT-4CLST,M9.1.0/0,M4.1.0/0</option>
      </optgroup>

      <!-- Asia -->
      <optgroup label="Asia">
          <option value="IST-5.5">India - IST-5.5</option>
          <option value="CST-8">China - CST-8</option>
          <option value="JST-9">Japan - JST-9</option>
          <option value="KST-9">Korea - KST-9</option>
          <option value="SGT-8">Singapore - SGT-8</option>
          <option value="WIB-7">Indonesia (WIB) - WIB-7</option>
          <option value="ICT-7">Thailand - ICT-7</option>
      </optgroup>

      <!-- Australia / Oceania -->
      <optgroup label="Australia">
          <option value="AEST-10AEDT,M10.1.0/2,M4.1.0/3">Australia Eastern - AEST-10AEDT,M10.1.0/2,M4.1.0/3</option>
          <option value="ACST-9.5ACDT,M10.1.0/2,M4.1.0/3">Australia Central - ACST-9.5ACDT,M10.1.0/2,M4.1.0/3</option>
          <option value="AWST-8">Australia Western - AWST-8</option>
      </optgroup>

      <!-- Africa -->
      <optgroup label="Africa">
          <option value="CAT-2">Central Africa - CAT-2</option>
          <option value="EAT-3">East Africa - EAT-3</option>
          <option value="WAT-1">West Africa - WAT-1</option>
          <option value="SAST-2">South Africa - SAST-2</option>
      </optgroup>
  </select>

  <input id="tzCustom" class="tzField" type="text" placeholder="Enter custom Timezone string..." readonly>

  <p id="msg"></p>
  <br>
  <button onclick="saveTZ()">Save</button>

  <p style="font-size: 0.8rem;"><a href="/menu">Go Back</a></p>

  <script>
  function loadTZ() {
      fetch("/getTZ").then(r => r.text()).then(tz => {
          document.getElementById("currentTZ").textContent = tz;
          let select = document.getElementById("tzSelect");
          let input = document.getElementById("tzCustom");
          let found = false;

          for (let i = 0; i < select.options.length; i++) {
              if (select.options[i].value === tz) {
                  select.selectedIndex = i;
                  input.value = tz;
                  input.readOnly = true;
                  input.style.display = "block";
                  found = true;
                  break;
              }
          }

          if (!found) {
              select.value = "custom";
              input.value = tz;
              input.readOnly = false;
              input.style.display = "block";
          }
      });
  }

  function selectChanged() {
      let select = document.getElementById("tzSelect");
      let input = document.getElementById("tzCustom");

      if (select.value === "custom") {
          input.readOnly = false;
          input.value = "";
          input.style.display = "block";
      } else {
          input.value = select.value;
          input.readOnly = true;
          input.style.display = "block";
      }
  }

  function saveTZ() {
      let input = document.getElementById("tzCustom");
      let tzToSave = input.value.trim();

      if (!tzToSave) {
          document.getElementById("msg").style.color = "red";
          document.getElementById("msg").textContent = "Please enter a timezone!";
          return;
      }

      fetch("/setTZ?value=" + encodeURIComponent(tzToSave))
          .then(r => r.text())
          .then(() => {
              document.getElementById("msg").style.color = "green";
              document.getElementById("msg").textContent = "Timezone saved and set.";
              loadTZ();
          })
          .catch(err => {
              document.getElementById("msg").style.color = "red";
              document.getElementById("msg").textContent = "Error: " + err;
          });
  }
  loadTZ();
  </script>
  </body>
  </html>
)rawliteral";

const char ota_html[] PROGMEM = R"rawliteral(
  <!DOCTYPE html>
  <html lang='en'>
  <head>
  <meta charset='UTF-8' />
  <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
  <title>ESP OTA Update</title>
  <style>
  body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f3f4f6; color: #333; padding: 40px; text-align: center; }
  h2 { margin-bottom: 30px; color: #111; font-size: 1.3rem;}
  #uploadSection { background-color: white; padding: 30px; border-radius: 8px; display: inline-block; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); }
  input[type='file'] { padding: 10px; }
  button { margin-top: 20px; padding: 10px 20px; background-color: #4CAF50; border: none; color: white; font-size: 16px; border-radius: 5px; cursor: pointer; }
  button:disabled { background-color: #ccc; cursor: not-allowed; }
  progress { width: 100%; height: 20px; margin-top: 20px; border-radius: 5px; appearance: none; -webkit-appearance: none; }
  progress::-webkit-progress-bar { background-color: #eee; border-radius: 5px; }
  progress::-webkit-progress-value { background-color: #4CAF50; border-radius: 5px; }
  progress::-moz-progress-bar { background-color: #4CAF50; border-radius: 5px; }
  #status { margin-top: 15px; font-weight: bold; }
  #fileInfo { color: #555; margin-top: 10px; }
  </style>
  </head>
  <body>
  <div id='uploadSection'>
  <h2>Evo Web Radio - OTA Firmware Update</h2>
  <input type='file' id='fileInput' name='update' /><br />
  <div id='fileInfo'>No file selected</div>
  <button id='uploadBtn'>Upload</button>
  <p id='status'></p>
  </div>

  <script>
  const fileInput = document.getElementById('fileInput');
  const uploadBtn = document.getElementById('uploadBtn');
  const status = document.getElementById('status');
  const fileInfo = document.getElementById('fileInfo');

  fileInput.addEventListener('change', function () {
    const file = this.files[0];
    if (file) {
      fileInfo.textContent = `Selected: ${file.name} (${(file.size / 1024).toFixed(2)} KB)`;
    } else {
      fileInfo.textContent = 'No file selected';
    }
  });

  uploadBtn.addEventListener('click', function () {
    const file = fileInput.files[0];
    if (!file) { alert('Please select a file first.'); return; }
    uploadBtn.disabled = true;
    status.textContent = 'Uploading...';

    const xhr = new XMLHttpRequest();
    const formData = new FormData();
    formData.append('update', file);

    xhr.open('POST', '/firmwareota', true);

    xhr.onload = function () {
      if (xhr.status === 200) {
        status.textContent = '✅ Upload completed, reboot in 3 sec.';
        setTimeout(() => { window.location.href = '/'; }, 10000);
      } else {
        status.textContent = '❌ Upload failed.';
      }
      uploadBtn.disabled = false;
    };

    xhr.onerror = function () {
      status.textContent = '❌ Network error.';
      uploadBtn.disabled = false;
    };

    xhr.send(formData);
  });
  </script>

  </body>
  </html>
)rawliteral";


// ------------------- KONIEC STRON HTML zaszytych w kodzie -------------------

char stations[MAX_STATIONS][STATION_NAME_LENGTH + 1];  // Tablica przechowująca linki do stacji radiowych (jedna na stację) +1 dla terminatora null

const char *ntpServer1 = "pool.ntp.org";  // Adres serwera NTP używany do synchronizacji czasu
const char *ntpServer2 = "time.nist.gov"; // Adres serwera NTP używany do synchronizacji czasu
//const long gmtOffset_sec = 3600;          // Przesunięcie czasu UTC w sekundach
//const int daylightOffset_sec = 3600;      // Przesunięcie czasu letniego w sekundach, dla Polski to 1 godzina

const int LOGO_SIZE = (SCREEN_WIDTH * SCREEN_HEIGHT) / 8;
uint8_t logo_bits[LOGO_SIZE];

//Czcionka SPLEEN z polskimi znakami do obslugi radio stream tittle
const uint8_t spleen6x12PL[2958] U8G2_FONT_SECTION("spleen6x12PL") =
  "\340\1\3\2\3\4\1\3\4\6\14\0\375\10\376\11\377\1\225\3]\13q \7\346\361\363\237\0!\12"
  "\346\361#i\357`\316\0\42\14\346\361\3I\226dI\316/\0#\21\346\361\303I\64HI\226dI"
  "\64HIN\6$\22\346q\205CRK\302\61\311\222,I\206\60\247\0%\15\346\361cQK\32\246"
  "I\324\316\2&\17\346\361#Z\324f\213\22-Zr\42\0'\11\346\361#i\235\237\0(\13\346\361"
  "ia\332s\254\303\0)\12\346\361\310\325\36\63\235\2*\15\346\361S\243L\32&-\312\31\1+\13"
  "\346\361\223\323l\320\322\234\31,\12\346\361\363)\15s\22\0-\11\346\361s\32t\236\0.\10\346\361"
  "\363K\316\0/\15\346q\246a\32\246a\32\246\71\15\60\21\346\361\3S\226DJ\213\224dI\26\355"
  "d\0\61\12\346\361#\241\332\343N\6\62\16\346\361\3S\226\226\246\64\35t*\0\63\16\346\361\3S"
  "\226fr\232d\321N\6\64\14\346q\247\245\236\6\61\315\311\0\65\16\346q\17J\232\16qZ\31r"
  "\62\0\66\20\346\361\3S\232\16Q\226dI\26\355d\0\67\13\346q\17J\226\206\325v\6\70\20\346"
  "\361\3S\226d\321\224%Y\222E;\31\71\17\346\361\3S\226dI\26\15ii'\3:\11\346\361"
  "\263\346L\71\3;\13\346\361\263\346\264\64\314I\0<\12\346\361cak\334N\5=\13\346\361\263\15"
  ":\60\350\334\0>\12\346\361\3qk\330\316\2\77\14\346\361\3S\226\206\325\34\314\31@\21\346\361\3"
  "S\226dI\262$K\262\304CN\5A\22\346\361\3S\226dI\226\14J\226dI\226S\1B\22"
  "\346q\17Q\226d\311\20eI\226d\311\220\223\1C\14\346\361\3C\222\366<\344T\0D\22\346q"
  "\17Q\226dI\226dI\226d\311\220\223\1E\16\346\361\3C\222\246C\224\226\207\234\12F\15\346\361"
  "\3C\222\246C\224\266\63\1G\21\346\361\3C\222V\226,\311\222,\32r*\0H\22\346qgI"
  "\226d\311\240dI\226dI\226S\1I\12\346\361\3c\332\343N\6J\12\346\361\3c\332\233\316\2"
  "K\21\346qgI\226D\321\26\325\222,\311r*\0L\12\346q\247}\36r*\0M\20\346qg"
  "\211eP\272%Y\222%YN\5N\20\346qg\211\224HI\77)\221\222\345T\0O\21\346\361\3"
  "S\226dI\226dI\226d\321N\6P\17\346q\17Q\226dI\226\14QZg\2Q\22\346\361\3"
  "S\226dI\226dI\226d\321\252\303\0R\22\346q\17Q\226dI\226\14Q\226dI\226S\1S"
  "\16\346\361\3C\222\306sZ\31r\62\0T\11\346q\17Z\332w\6U\22\346qgI\226dI\226"
  "dI\226d\321\220S\1V\20\346qgI\226dI\226dI\26m;\31W\21\346qgI\226d"
  "I\226\264\14\212%\313\251\0X\21\346qgI\26%a%\312\222,\311r*\0Y\20\346qgI"
  "\226dI\26\15ie\310\311\0Z\14\346q\17j\330\65\35t*\0[\13\346\361\14Q\332\257C\16"
  "\3\134\15\346q\244q\32\247q\32\247\71\14]\12\346\361\14i\177\32r\30^\12\346\361#a\22e"
  "\71\77_\11\346\361\363\353\240\303\0`\11\346\361\3q\235_\0a\16\346\361S\347hH\262$\213\206"
  "\234\12b\20\346q\247\351\20eI\226dI\226\14\71\31c\14\346\361S\207$m\36r*\0d\21"
  "\346\361ci\64$Y\222%Y\222ECN\5e\17\346\361S\207$K\262dP\342!\247\2f\14"
  "\346\361#S\32\16Y\332\316\2g\21\346\361S\207$K\262$K\262hN\206\34\1h\20\346q\247"
  "\351\20eI\226dI\226d\71\25i\13\346\361#\71\246v\325\311\0j\13\346\361C\71\230\366\246S"
  "\0k\16\346q\247\245J&&YT\313\251\0l\12\346\361\3i\237u\62\0m\15\346\361\23\207("
  "\351\337\222,\247\2n\20\346\361\23\207(K\262$K\262$\313\251\0o\16\346\361S\247,\311\222,"
  "\311\242\235\14p\21\346\361\23\207(K\262$K\262d\210\322*\0q\20\346\361S\207$K\262$K"
  "\262hH[\0r\14\346\361S\207$K\322v&\0s\15\346\361S\207$\236\323d\310\311\0t\13"
  "\346\361\3i\70\246\315:\31u\20\346\361\23\263$K\262$K\262h\310\251\0v\16\346\361\23\263$"
  "K\262$\213\222\60gw\17\346\361\23\263$KZ\6\305\222\345T\0x\16\346\361\23\263$\213\266)"
  "K\262\234\12y\22\346\361\23\263$K\262$K\262hH\223!G\0z\14\346\361\23\7\65l\34t"
  "*\0{\14\346\361iiM\224\323\262\16\3|\10\346q\245\375;\5}\14\346\361\310iY\324\322\232"
  "N\1~\12\346\361s\213\222D\347\10\177\7\346\361\363\237\0\200\6\341\311\243\0\201\6\341\311\243\0\202"
  "\6\341\311\243\0\203\6\341\311\243\0\204\6\341\311\243\0\205\6\341\311\243\0\206\6\341\311\243\0\207\6\341"
  "\311\243\0\210\6\341\311\243\0\211\6\341\311\243\0\212\6\341\311\243\0\213\6\341\311\243\0\214\16\346\361e"
  "C\222\306sZ\31r\62\0\215\6\341\311\243\0\216\6\341\311\243\0\217\14\346qe\203T\354\232\16:"
  "\25\220\6\341\311\243\0\221\6\341\311\243\0\222\6\341\311\243\0\223\6\341\311\243\0\224\6\341\311\243\0\225"
  "\6\341\311\243\0\226\6\341\311\243\0\227\16\346\361eC\222\306sZ\31r\62\0\230\6\341\311\243\0\231"
  "\6\341\311\243\0\232\6\341\311\243\0\233\6\341\311\243\0\234\16\346\361\205\71\66$\361\234&CN\6\235"
  "\6\341\311\243\0\236\21\346\361#%i\210\6eP\206(\221*\71\25\237\15\346\361\205\71\64\250a\343"
  "\240S\1\240\7\346\361\363\237\0\241\23\346\361\3S\226dI\226\14J\226dI\26\306\71\0\242\21\346"
  "\361\23\302!\251%Y\222%\341\220\345\24\0\243\14\346q\247-\231\230\306CN\5\244\22\346\361\3S"
  "\226dI\226\14J\226dI\26\346\4\245\22\346\361\3S\226dI\226\14J\226dI\26\346\4\246\16"
  "\346\361eC\222\306sZ\31r\62\0\247\17\346\361#Z\224\245Z\324\233\232E\231\4\250\11\346\361\3"
  "I\316\237\1\251\21\346\361\3C\22J\211\22)\221bL\206\234\12\252\15\346\361#r\66\325vd\310"
  "\31\1\253\17\346\361\223\243$J\242\266(\213r\42\0\254\14\346qe\203T\354\232\16:\25\255\10\346"
  "\361s\333y\3\256\21\346\361\3C\22*\226d\261$c\62\344T\0\257\14\346qe\203\32vM\7"
  "\235\12\260\12\346\361#Z\324\246\363\11\261\20\346\361S\347hH\262$\213\206\64\314\21\0\262\14\346\361"
  "#Z\224\206\305!\347\6\263\13\346\361\3i\252\251\315:\31\264\11\346\361Ca\235\337\0\265\14\346\361"
  "\23\243\376i\251\346 \0\266\16\346\361\205\71\66$\361\234&CN\6\267\10\346\361s\314y\4\270\11"
  "\346\361\363\207\64\14\1\271\20\346\361S\347hH\262$\213\206\64\314\21\0\272\15\346\361#Z\324\233\16"
  "\15\71#\0\273\17\346\361\23\243,\312\242\226(\211r\62\0\274\15\346\361\205\71\64\250a\343\240S\1"
  "\275\17\346\361\204j-\211\302\26\245\24\26\207\0\276\21\346\361hQ\30'\222\64\206ZR\33\302\64\1"
  "\277\15\346\361#\71\64\250a\343\240S\1\300\21\346\361\304\341\224%Y\62(Y\222%YN\5\301\21"
  "\346\361\205\341\224%Y\62(Y\222%YN\5\302\22\346q\205I\66eI\226\14J\226dI\226S"
  "\1\303\23\346\361DI\242MY\222%\203\222%Y\222\345T\0\304\20\346\361S\347hH\262$\213\206"
  "\64\314\21\0\305\16\346\361eC\222\306sZ\31r\62\0\306\14\346\361eC\222\366<\344T\0\307\15"
  "\346\361\3C\222\366<di\30\2\310\17\346\361\304\341\220\244\351\20\245\361\220S\1\311\17\346\361\205\341"
  "\220\244\351\20\245\361\220S\1\312\20\346\361\3C\222\246C\224\226\207\64\314\21\0\313\17\346\361\324\241!"
  "I\323!J\343!\247\2\314\13\346\361\304\341\230v\334\311\0\315\13\346\361\205\341\230v\334\311\0\316\14"
  "\346q\205I\66\246\35w\62\0\317\13\346\361\324\241\61\355\270\223\1\320\15\346\361\3[\324\262D}\332"
  "\311\0\321\20\346\361EIV\221\22)\351'%\322\251\0\322\20\346\361\304\341\224%Y\222%Y\222E"
  ";\31\323\20\346\361\205\341\224%Y\222%Y\222E;\31\324\21\346q\205I\66eI\226dI\226d"
  "\321N\6\325\22\346\361DI\242MY\222%Y\222%Y\264\223\1\326\21\346\361\324\241)K\262$K"
  "\262$\213v\62\0\327\14\346\361S\243L\324\242\234\33\0\330\20\346qFS\226DJ_\244$\213\246"
  "\234\6\331\21\346\361\304Y%K\262$K\262$\213\206\234\12\332\21\346\361\205Y%K\262$K\262$"
  "\213\206\234\12\333\23\346q\205I\224%Y\222%Y\222%Y\64\344T\0\334\22\346\361\324\221,\311\222"
  ",\311\222,\311\242!\247\2\335\17\346\361\205Y%K\262hH+CN\6\336\21\346\361\243\351\20e"
  "I\226dI\226\14QN\3\337\17\346\361\3Z\324%\213j\211\224$:\31\340\20\346q\305\71\64G"
  "C\222%Y\64\344T\0\341\20\346\361\205\71\66GC\222%Y\64\344T\0\342\11\346\361Ca\235\337"
  "\0\343\21\346\361DI\242Cs\64$Y\222ECN\5\344\20\346\361\3I\16\315\321\220dI\26\15"
  "\71\25\345\20\346q\205I\30\316\321\220dI\26\15\71\25\346\15\346\361Ca\70$i\363\220S\1\347"
  "\15\346\361S\207$m\36\262\64\14\1\350\20\346q\305\71\64$Y\222%\203\22\17\71\25\351\20\346\361"
  "\205\71\66$Y\222%\203\22\17\71\25\352\20\346\361S\207$K\262dP\342!\254C\0\353\21\346\361"
  "\3I\16\15I\226d\311\240\304CN\5\354\13\346q\305\71\244v\325\311\0\355\13\346\361\205\71\246v"
  "\325\311\0\356\14\346q\205I\16\251]u\62\0\357\14\346\361\3I\16\251]u\62\0\360\21\346q$"
  "a%\234\262$K\262$\213v\62\0\361\21\346\361\205\71\64DY\222%Y\222%YN\5\362\20\346"
  "q\305\71\64eI\226dI\26\355d\0\363\20\346\361\205\71\66eI\226dI\26\355d\0\364\20\346"
  "q\205I\16MY\222%Y\222E;\31\365\21\346\361c\222\222HI\226dI\66\15\221N\4\366\20"
  "\346\361\3I\16MY\222%Y\222E;\31\367\13\346\361\223sh\320\241\234\31\370\17\346\361\223\242)"
  "RZ\244$\213\246\234\6\371\21\346q\305\71\222%Y\222%Y\222ECN\5\372\21\346\361\205\71\224"
  "%Y\222%Y\222ECN\5\373\22\346q\205I\216dI\226dI\226d\321\220S\1\374\22\346\361"
  "\3I\216dI\226dI\226d\321\220S\1\375\23\346\361\205\71\224%Y\222%Y\222ECZ\31\42"
  "\0\376\22\346q\247\351\20eI\226dI\226\14Q\232\203\0\377\23\346\361\3I\216dI\226dI\226"
  "d\321\220V\206\10\0\0\0\4\377\377\0"
;

//Czcionka przerobiona na momospace do obslugi napisu kodeka i bitrate (np.: MP3/AAC/FLAC)
const uint8_t mono04b03b[912] U8G2_FONT_SECTION("mono04b03b") = 
  "`\1\3\3\3\3\1\1\4\5\6\0\377\5\377\5\0\1$\2c\3s \6s{D\0!\10r"
  "\212HZ\14\0\42\10t\214Hv\64\0#\14v\236\244R$T\212\304!\0$\12u\235I\22)"
  "\22\231\3%\14v\16QD\22L\221\204\344\0&\13v\216Y\264\22\12\321!\0'\7r\212H\34"
  "\4(\10s\233\244\264 \0)\10s\213X(%\12*\11t\214H(%\16\6+\10t\334\320("
  "\16\3,\7s{p$\4-\7t|\310\34\14.\7rzH\14\0/\7v\316\274\3\1\60\14"
  "u\15J(\22\212\204\42d\0\61\10u\35a\266\61\0\62\11u\15b\204\22$\3\63\11u\15b"
  "\204\30!\3\64\14u\215P$\24\11E\210a\0\65\11u\15J\220\30!\3\66\12u\215Q\220\22"
  "\212\220\1\67\11u\15b,\61\16\1\70\13u\15J(B\11E\310\0\71\12u\15J(B\14\215"
  "\1:\7r\252X\24\0;\7r\252X$\6<\7t\254\214\251\0=\7t\314\351\34\4>\10t"
  "\214`R:\0\77\12u\15bh\16\210C\0@\14v\216J,\22\231d\241C\0A\14u\15J"
  "(B\11EBa\0B\13u\215Q$D\11E\310\0C\10u\15J\60\221\14D\13u\215QJ"
  "(\22\212\314\1E\11u\15J\220\22$\3F\12u\15J\220\22\214\203\0G\13u\15J\60\42\11"
  "E\310\0H\15u\215P$\24\241\204\42\241\60\0I\10u\235Y\60m\14J\11u-aJ(B"
  "\6K\14u\215P$\24\31\245\204\302\0L\10u\215`F\62\0M\10v\216J\376\357\0N\15u"
  "\215PD\222\42\11EBa\0O\14u\15J(\22\212\204\42d\0P\14u\15J(\22\212P\342"
  " \0Q\14u\15J(\22\212D$d\0R\13u\15J(BI\212\210\1S\11u\15J\220\30"
  "!\3T\10t\214Q,\63\0U\15u\215P$\24\11EB\21\62\0V\15u\215P$\24I\212"
  "\304\342\20\0W\11v\216H\376\227:\0X\14u\215P$\24\22\245\204\302\0Y\13u\215P$\24"
  "!F\310\0Z\11u\15bH\24$\3[\10s\13I(I\10\134\7v\216p\356\0]\10s\13"
  "Q\26!\0^\10t\234P$\216\6_\7u}d\62\0`\7s\213X\34\14a\11u}\340$"
  "\24!\3b\11u\335 %\24!\3c\10t|\310$\66\5d\12u}H\204\22\212\220\1e\10"
  "u}\30%m\14f\11u\355Q\214\24\207\0g\12u}\30%\24\241\205\0h\12u\335 %\24"
  "\11\205\1i\7r\252X$\6j\10r\252X$\5\0k\11u\335`(\62J\6l\7r\252H"
  "\66\0m\10v~h%\337\1n\12u}\30%\24\11\205\1o\11u}\30%\24!\3p\12u"
  "}\30%\24\241\4\1q\12u}\30%\24!F\0r\10t|\310$\26\7s\10u}\30)F"
  "\6t\10t\334\320(&\5u\12u}X(\22\212\220\1v\12u}X(\22\12\311\1w\11v"
  "~h$/u\0x\11t|HRJ\24\0y\13u}X(\22\212\20#\0z\10u}\30-"
  "D\6{\10t\34QbL\12|\7r\212Hn\0}\11t\14Y\60\24\22\3~\7u\235\334\261"
  "\0\177\7t\14\221\316\0\0\0\0\4\377\377\0"
;

// Ikona karty SD wyswietlana przy braku karty podczas startu
static unsigned char sdcard[] PROGMEM = {
  0xf0, 0xff, 0xff, 0x0f, 0xf8, 0xff, 0xff, 0x1f, 0xf8, 0xcf, 0xf3, 0x3f,
  0x38, 0x49, 0x92, 0x3c, 0x38, 0x49, 0x92, 0x3c, 0x38, 0x49, 0x92, 0x3c,
  0x38, 0x49, 0x92, 0x3c, 0x38, 0x49, 0x92, 0x3c, 0x38, 0x49, 0x92, 0x3c,
  0x38, 0x49, 0x92, 0x3c, 0xf8, 0xff, 0xff, 0x3f, 0xf8, 0xff, 0xff, 0x3f,
  0xf8, 0xff, 0xff, 0x3f, 0xf8, 0xff, 0xff, 0x3f, 0xf8, 0xff, 0xff, 0x3f,
  0xfc, 0xff, 0xff, 0x3f, 0xfe, 0xff, 0xff, 0x3f, 0xff, 0xff, 0xff, 0x3f,
  0xff, 0xff, 0xff, 0x3f, 0xff, 0xff, 0xff, 0x3f, 0xff, 0xff, 0xff, 0x3f,
  0xfc, 0xff, 0xff, 0x3f, 0xfc, 0xc0, 0x80, 0x3f, 0x7c, 0xc0, 0x00, 0x3f,
  0x3c, 0xc0, 0x00, 0x3e, 0x1c, 0xfc, 0x38, 0x3e, 0x1e, 0xfc, 0x78, 0x3c,
  0x1f, 0xe0, 0x78, 0x3c, 0x3f, 0xc0, 0x78, 0x3c, 0x7f, 0x80, 0x78, 0x3c,
  0xff, 0x87, 0x78, 0x3c, 0xff, 0x87, 0x38, 0x3e, 0x3f, 0x80, 0x00, 0x3e,
  0x1f, 0xc0, 0x00, 0x3f, 0x3f, 0xe0, 0x80, 0x3f, 0xff, 0xff, 0xff, 0x3f,
  0xff, 0xff, 0xff, 0x3f, 0xff, 0xff, 0xff, 0x3f, 0xfe, 0xff, 0xff, 0x1f,
  0xfc, 0xff, 0xff, 0x0f 
};


// Obrazek NUTKI wyswietlany przy starcie
#define notes_width 256
#define notes_height 46
static unsigned char notes[] PROGMEM = {
  0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x80, 0x0f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x80, 0x0c, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0xc0, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x40, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x0c, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x60, 0x0c, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x20, 0x0e, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x0e, 0x00,
  0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x0e, 0x00, 0x02, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x20, 0x07, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xa0, 0x07, 0x00,
  0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x03, 0x80, 0x05, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00,
  0x00, 0xf0, 0x01, 0xc0, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x40, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0xf8, 0x00, 0x40,
  0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x78, 0x00, 0x08,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00,
  0x00, 0x01, 0x00, 0x00, 0x00, 0x7c, 0x00, 0x40, 0x08, 0x00, 0x00, 0x00,
  0x00, 0x60, 0x00, 0x00, 0x00, 0x5e, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00,
  0x60, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
  0x00, 0x5e, 0x00, 0x80, 0x08, 0x00, 0x00, 0x07, 0x00, 0xe0, 0x01, 0x00,
  0xc0, 0x47, 0x00, 0x08, 0x00, 0x00, 0x07, 0x00, 0xe0, 0x01, 0x00, 0x00,
  0x40, 0x00, 0x18, 0x00, 0x80, 0x00, 0x00, 0x0e, 0x00, 0x4e, 0x00, 0x00,
  0x19, 0x00, 0xf0, 0x07, 0x00, 0x20, 0x01, 0x00, 0xf8, 0x41, 0x00, 0x18,
  0x00, 0xf0, 0x07, 0x00, 0x20, 0x01, 0x00, 0x18, 0x40, 0x00, 0x78, 0x00,
  0x80, 0x00, 0xe0, 0x0f, 0x00, 0x47, 0x00, 0x00, 0x10, 0x00, 0xf0, 0x07,
  0x00, 0x20, 0x03, 0x00, 0x3c, 0x40, 0x00, 0x10, 0x00, 0xf0, 0x07, 0x00,
  0x20, 0x03, 0x00, 0x1c, 0x40, 0x00, 0xe8, 0x00, 0x80, 0x00, 0xe0, 0x0f,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc0, 0x41, 0x00, 0x00,
  0x10, 0x00, 0x3f, 0x04, 0x00, 0xe0, 0x04, 0xe0, 0x11, 0x40, 0x00, 0x10,
  0x00, 0x3f, 0x04, 0x00, 0xe0, 0x04, 0xe0, 0x11, 0x40, 0x00, 0x38, 0x01,
  0x40, 0x00, 0x7e, 0x08, 0xc0, 0xe0, 0x0f, 0x00, 0x10, 0x00, 0x0f, 0x04,
  0x00, 0xb0, 0x01, 0x78, 0x10, 0x40, 0x00, 0x10, 0x00, 0x0f, 0x04, 0x00,
  0xb0, 0x01, 0x78, 0x10, 0x40, 0x00, 0x68, 0x01, 0x40, 0x00, 0x1e, 0x08,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x40, 0x70, 0x3e, 0x00,
  0x1c, 0x00, 0x01, 0x04, 0x00, 0x10, 0x00, 0x0e, 0x10, 0x40, 0x00, 0x18,
  0x00, 0x01, 0x04, 0x00, 0x10, 0x00, 0x0e, 0x10, 0x40, 0x00, 0xa8, 0x00,
  0x2f, 0x00, 0x02, 0x08, 0x40, 0x98, 0x78, 0x00, 0x1f, 0x00, 0x01, 0x04,
  0x00, 0x10, 0x00, 0x06, 0x10, 0x40, 0x00, 0x1f, 0x00, 0x01, 0x04, 0x00,
  0x10, 0x00, 0x06, 0x10, 0x40, 0x00, 0x48, 0xc0, 0x1f, 0x00, 0x02, 0x08,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x40, 0x88, 0x70, 0x80,
  0x0f, 0x00, 0x01, 0x04, 0x80, 0x17, 0x00, 0x02, 0x10, 0x7c, 0x80, 0x0f,
  0x00, 0x01, 0x04, 0x80, 0x17, 0x00, 0x02, 0x10, 0x7c, 0x00, 0x08, 0x80,
  0x0f, 0x00, 0x02, 0x08, 0x40, 0x88, 0x70, 0x00, 0x07, 0x00, 0x01, 0x04,
  0xc0, 0x1f, 0x00, 0x02, 0x10, 0x7e, 0x00, 0x07, 0x00, 0x01, 0x04, 0xc0,
  0x1f, 0x00, 0x02, 0x10, 0x7e, 0x80, 0x0f, 0x00, 0x00, 0x00, 0x02, 0x08,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc0, 0x00, 0x71, 0x00,
  0x00, 0x00, 0xc1, 0x07, 0xe0, 0x07, 0x00, 0x02, 0x1e, 0x00, 0x00, 0x00,
  0x00, 0xc1, 0x07, 0xe0, 0x07, 0x00, 0x02, 0x1e, 0x00, 0xc0, 0x07, 0x00,
  0x00, 0x00, 0x82, 0x0f, 0x80, 0x01, 0x39, 0x00, 0x00, 0x00, 0xe1, 0x07,
  0xc0, 0x03, 0x00, 0x02, 0x1f, 0x00, 0x00, 0x00, 0x00, 0xe1, 0x07, 0xc0,
  0x03, 0x00, 0x02, 0x1f, 0x00, 0x80, 0x03, 0x00, 0x00, 0x00, 0xc2, 0x0f,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff,
  0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x0f, 0x1e, 0x00,
  0x00, 0xf0, 0x81, 0x03, 0x00, 0x00, 0x80, 0x03, 0x0e, 0x00, 0x00, 0x00,
  0xf0, 0x81, 0x03, 0x00, 0x00, 0x80, 0x03, 0x0e, 0x00, 0x00, 0x00, 0x00,
  0x00, 0xe0, 0x03, 0x07, 0x00, 0xfc, 0x0f, 0x00, 0x00, 0xf8, 0x01, 0x00,
  0x00, 0x00, 0xc0, 0x03, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x01, 0x00, 0x00,
  0x00, 0xc0, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x03, 0x00,
  0x00, 0xf0, 0x03, 0x00, 0x00, 0xf8, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x03,
  0x00, 0x00, 0x00, 0x00, 0xf8, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x03, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0xf0, 0x01, 0x00, 0x00, 0x00, 0x02, 0x00,
  0x00, 0x70, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x01, 0x00, 0x00, 0x00, 0x00,
  0x70, 0x00, 0x00, 0x00, 0x00, 0xe0, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0xe0, 0x00, 0x00, 0x00, 0x00, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0xc0, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x0c, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0e, 0x02, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x0e, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x0c, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x0c, 0x01, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0xf8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x60, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
  0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
};


// Funkcja odwracania bitów MSL-LSB <-> LSB-MSB potrzebna dla symulacji komend pilota 
uint32_t reverse_bits(uint32_t inval, int bits)
{
  if ( bits > 0 )
  {
    bits--;
    return reverse_bits(inval >> 1, bits) | ((inval & 1) << bits);
  }
  return 0;
}


/*---------- Definicja portu i deklaracje zmiennych do obsługi odbiornika IR ----------*/

// Zmienne obsługi  pilota IR
bool pulse_ready = false;                // Flaga sygnału gotowości
unsigned long pulse_start_high = 0;      // Czas początkowy impulsu
unsigned long pulse_end_high = 0;        // Czas końcowy impulsu
unsigned long pulse_duration = 0;        // Czas trwania impulsu
unsigned long pulse_duration_9ms = 0;    // Tylko do analizy - Czas trwania impulsu
unsigned long pulse_duration_4_5ms = 0;  // Tylko do analizy - Czas trwania impulsu
unsigned long pulse_duration_560us = 0;  // Tylko do analizy - Czas trwania impulsu
unsigned long pulse_duration_1690us = 0; // Tylko do analizy - Czas trwania impulsu

bool pulse_ready9ms = false;            // Flaga sygnału gotowości puls 9ms
bool pulse_ready_low = false;           // Flaga sygnału gotowości 
unsigned long pulse_start_low = 0;      // Czas początkowy impulsu
unsigned long pulse_end_low = 0;        // Czas końcowy impulsu
unsigned long pulse_duration_low = 0;   // Czas trwania impulsu


volatile unsigned long ir_code = 0;  // Zmienna do przechowywania kodu IR
volatile int bit_count = 0;          // Licznik bitów w odebranym kodzie

// Progi przełączeń dla sygnałów czasowych pilota IR
const int LEAD_HIGH = 9050;         // 9 ms sygnał wysoki (początkowy)
const int LEAD_LOW = 4500;          // 4,5 ms sygnał niski (początkowy)
const int TOLERANCE = 150;          // Tolerancja (w mikrosekundach)
const int HIGH_THRESHOLD = 1690;    // Sygnał "1"
const int LOW_THRESHOLD = 600;      // Sygnał "0"

bool data_start_detected = false;  // Flaga dla sygnału wstępnego
bool rcInputDigitsMenuEnable = false;

//================ Definicja portów i pinów dla klaiwatury numerycznej ===========================//
const int keyboardPin = 9;  // wejscie klawiatury (ADC) 

unsigned long keyboardValue = 0;
unsigned long keyboardLastSampleTime = 0;
unsigned long keyboardSampleDelay = 50;


// ---- Progi przełaczania ADC dla klawiatury matrycowej 5x3 w tunrze Sony ST-120 ---- //
int keyboardButtonThresholdTolerance = 20; // Tolerancja dla pomiaru ADC
int keyboardButtonNeutral = 4095;          // Pozycja neutralna
int keyboardButtonThreshold_0 = 2375;      // Przycisk 0
int keyboardButtonThreshold_1 = 10;        // Przycisk 1
int keyboardButtonThreshold_2 = 545;       // Przycisk 2
int keyboardButtonThreshold_3 = 1390;      // Przycisk 3
int keyboardButtonThreshold_4 = 1925;      // Przycisk 4
int keyboardButtonThreshold_5 = 2285;      // Przycisk 5
int keyboardButtonThreshold_6 = 385;       // Przycisk 6
int keyboardButtonThreshold_7 = 875;       // Przycisk 7
int keyboardButtonThreshold_8 = 1585;      // Przycisk 8
int keyboardButtonThreshold_9 = 2055;      // Przycisk 9
int keyboardButtonThreshold_Ok = 2455;  // Shift - funkcja Enter/OK
int keyboardButtonThreshold_BankMenu = 2170; // Memory - funkcja Bank menu
int keyboardButtonThreshold_Back = 1640;   // Przycisk Band - funkcja Back
int keyboardButtonThreshold_DisplayMode = 730;    // Przycisk Auto - przelacza Radio/Zegar
int keyboardButtonThreshold_Dimmer = 1760;   // Przycisk Scan - funkcja Dimmer ekranu OLED
int keyboardButtonThreshold_Mute = 1130;   // Przycisk Mute - funkcja MUTE

int keyboardButtonThreshold_ArrowLeft = 4100;   // Strzalka w lewo (poprzednia stacja, bank)
int keyboardButtonThreshold_ArrowRight = 4100;  // Strzalka w prawo (nastepna stacja, bak)
int keyboardButtonThreshold_ArrowUp = 4100;     // Strzalka w gore (przewijanie listy)
int keyboardButtonThreshold_ArrowDown = 4100;   // Strzalka w dol (przewijanie listy)

int keyboardButtonThreshold_PresetsOn = 4100;  // Przełaczenie pomiedzy wpisywanie stacji a presetami

// Flagi do monitorowania stanu klawiatury
bool keyboardButtonPressed = false; // Wcisnięcie klawisza
bool debugKeyboard = false;         // Wyłącza wywoływanie funkcji i zostawia tylko wydruk pomiaru ADC
bool adcKeyboardEnabled = false;    // Flaga właczajaca działanie klawiatury ADC

// ===== PROTOTYPY Funkcji =====
void displayDimmer(bool dimmerON);
void displayDimmerTimer();
void displayPowerSave(bool mode);
void setPreset(uint8_t preset);
void displayInfo();
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
void displayRadioTFT();
#endif

#ifdef IR_LED
  void irLedBlink();
#endif


#ifdef AUTOSTORAGE
  #define STORAGE_BEGIN() initStorage()
  bool initStorage() 
  {
    if (SD.begin(SD_CS, customSPI)) 
    {
      _storage = &SD;
      useSD = true;
      storageTextName = "SD";
      Serial.println("debug STORAGE -> Uzywamy Karty SD");
      //#define SD_LED 17          // LED - sygnalizacja CS, aktywność karty SD, klon pinu uzyteczny w przypadku uzywania tylnego czytnika SD na PCB
      noSDcard = false;
      return true;
    }

    Serial.println("debug STORAGE -> Brak karty SD, przelaczam na LittleFS");
    noSDcard = true; // Flag braku karty SD

    #ifdef USE_LittleFS
    if (LittleFS.begin(true)) 
    {
      _storage = &LittleFS;
      useSD = false;
      storageTextName = "LittleFS";
      noSDcard = true;
      return true;
    }
    #endif
    
    Serial.println("debug STORAGE -> Brak karty SD, przelaczam na SPIFFS");
    noSDcard = true; // Flag braku karty SD

    #ifdef USE_SPIFFS
    if (SPIFFS.begin(true)) 
    {
      _storage = &SPIFFS;
      useSD = false;
      storageTextName = "SPIFFS";
      noSDcard = true;
      return true;
    }
    #endif

    Serial.println("debug SD -> BLAD: brak systemu plikow, zapis tylko podstawowych wartosci do EEPROM");
    storageTextName = "EEPROM";
    return false;
  }
#endif

/*
void mDnsRestart()
{
  if (!MDNS.isRunning()) 
  {
    Serial.println("debug net -> Błąd: mDNS nie dziala");
    MDNS.end();                // zatrzymuje stare mDNS
    delay(50);
    if (MDNS.begin(hostname)) {Serial.println("debug net -> mDNS zrestartowane!");} 
    else {Serial.println("debug net -> Błąd restartu mDNS");}
  } 
  else 
  {
    Serial.println("debug net -> mDNS działa!");
  }

}
*/

void updateStandbyLED()
{
  //digitalWrite(STANDBY_LED, HIGH);
  digitalWrite(STANDBY_LED, !digitalRead(STANDBY_LED));
}

void switchOffstartupLED()
{
  digitalWrite(STANDBY_LED, LOW); 
}

void removeUtf8Bom(String &text) 
{
  if (text.length() >= 3 &&
      (uint8_t)text[0] == 0xEF &&
      (uint8_t)text[1] == 0xBB &&
      (uint8_t)text[2] == 0xBF) {
        text.remove(0, 3);  // usuń bajty EF BB BF
      }
}

// Funkcja przetwarza tekst, zamieniając polskie znaki diakrytyczne

void processText(String &text) 
{
  removeUtf8Bom(text); // Usuwamy znaki BOM na początku nazwy utworu

  for (int i = 0; i < text.length() - 1; i++) 
  {
    if (i + 1 >= text.length()) break; // zabezpieczenie przed wyjściem poza bufor

    switch ((uint8_t)text[i]) 
    {
      case 0xC3:
        switch ((uint8_t)text[i + 1]) {
          case 0xB3: text.setCharAt(i, 0xF3); break;  // ó
          case 0x93: text.setCharAt(i, 0xD3); break;  // Ó
        }
        text.remove(i + 1, 1);
        break;

      case 0xC4:
        switch ((uint8_t)text[i + 1]) {
          case 0x85: text.setCharAt(i, 0xB9); break;  // ą
          case 0x84: text.setCharAt(i, 0xA5); break;  // Ą
          case 0x87: text.setCharAt(i, 0xE6); break;  // ć
          case 0x86: text.setCharAt(i, 0xC6); break;  // Ć
          case 0x99: text.setCharAt(i, 0xEA); break;  // ę
          case 0x98: text.setCharAt(i, 0xCA); break;  // Ę
        }
        text.remove(i + 1, 1);
        break;

      case 0xC5:
        switch ((uint8_t)text[i + 1]) {
          case 0x82: text.setCharAt(i, 0xB3); break;  // ł
          case 0x81: text.setCharAt(i, 0xA3); break;  // Ł
          case 0x84: text.setCharAt(i, 0xF1); break;  // ń
          case 0x83: text.setCharAt(i, 0xD1); break;  // Ń
          case 0x9B: text.setCharAt(i, 0x9C); break;  // ś
          case 0x9A: text.setCharAt(i, 0x8C); break;  // Ś
          case 0xBA: text.setCharAt(i, 0x9F); break;  // ź
          case 0xB9: text.setCharAt(i, 0x8F); break;  // Ź
          case 0xBC: text.setCharAt(i, 0xBF); break;  // ż
          case 0xBB: text.setCharAt(i, 0xAF); break;  // Ż
        }
        text.remove(i + 1, 1);
        break;
    }
  }
}

bool sanitizeUtf8(String& s)
{
  String out;
  out.reserve(s.length() * 2);

  const uint8_t* p = (const uint8_t*)s.c_str();

  while (*p)
  {
    uint8_t c = *p;

    // ASCII
    if (c < 0x80) {
      out += (char)c;
      p++;
      continue;
    }

    // Poprawny UTF-8 (2–4 bajty)
    uint8_t len = 0;
    if ((c & 0xE0) == 0xC0) len = 2;
    else if ((c & 0xF0) == 0xE0) len = 3;
    else if ((c & 0xF8) == 0xF0) len = 4;

    if (len) {
      bool ok = true;
      for (uint8_t i = 1; i < len; i++) {
        if ((p[i] & 0xC0) != 0x80) {
          ok = false;
          break;
        }
      }
      if (ok) {
        for (uint8_t i = 0; i < len; i++)
          out += (char)p[i];
        p += len;
        continue;
      }
    }

    // Win-1250 na UTF-8 (PL)
    switch (c)
    {
      case 0xA5: out += "Ą"; break;
      case 0xB9: out += "ą"; break;
      case 0xC6: out += "Ć"; break;
      case 0xE6: out += "ć"; break;
      case 0xCA: out += "Ę"; break;
      case 0xEA: out += "ę"; break;
      case 0xA3: out += "Ł"; break;
      case 0xB3: out += "ł"; break;
      case 0xD1: out += "Ń"; break;
      case 0xF1: out += "ń"; break;
      case 0xD3: out += "Ó"; break;
      case 0xF3: out += "ó"; break;
      case 0xA6: out += "Ś"; break;
      case 0xB6: out += "ś"; break;
      case 0xAF: out += "Ż"; break;
      case 0xBF: out += "ż"; break;
      case 0xAC: out += "Ź"; break;
      case 0xBC: out += "ź"; break;
      case 0x8C: out += "Ś"; break;
      case 0x9C: out += "ś"; break;
      case 0x8F: out += "Ź"; break;
      case 0x9F: out += "ź"; break;
      default:   Serial.print("debug - > UTF8 Web Sanitizer, Nieznany znak:"); Serial.println(c, HEX); out += '?'; break;
    }

    p++;
  }

  if (out != s) {
    s = out;
    return true;   // coś poprawiono
  }
  return false;    // było OK
}

void wsStationChange(uint8_t stationId, uint8_t bankId) 
{
  // iteracja po wszystkich podłączonych klientach
  for (auto& client : ws.getClients()) 
  {
 
    client.text("stationname:" + String(stationName.substring(0, stationNameLenghtCut)));

    if (urlPlaying) 
    {
      client.text("bank:" + String(0));
      client.text("station:" + String(0));
    } 
    else 
    {
      client.text("bank:" + String(bankId));
      client.text("station:" + String(stationId));
    }

    client.text("volume:" + String(volumeValue));
    client.text("mute:" + String(volumeMute)); 

    client.text("bitrate:" + String(bitrateString)); 
    client.text("samplerate:" + String(sampleRateString)); 
    client.text("bitpersample:" + String(bitsPerSampleString)); 

    if (mp3)    client.text("streamformat:MP3");
    if (flac)   client.text("streamformat:FLAC");
    if (aac)    client.text("streamformat:AAC");
    if (vorbis) client.text("streamformat:VORBIS");
    if (opus)   client.text("streamformat:OPUS");
    
    

  }
}

void wsRefreshPage() // Funckja odswiezania strony za pomocą WebSocket
{
  ws.textAll("reload");  // wyślij komunikat do wszystkich klientów
}

void wsStreamInfoRefresh()
{
  // iteracja po wszystkich podłączonych klientach
  for (auto& client : ws.getClients()) 
  {
 
    client.text("stationname:" + String(stationName.substring(0, stationNameLenghtCut)));

    if (audio.isRunning() == true)
    {  
      String nowText = evoWebNowPlayingText();
      sanitizeUtf8(nowText);
      client.text("stationtext$" + nowText); 
    }
    else
    {
      client.text("stationtext$Oczekiwanie na tytul utworu...");
    }

    /*
    if (urlPlaying) 
    {
      client.text("bank:" + String(0));
      client.text("station:" + String(0));
    } 
    else 
    {
      client.text("bank:" + String(bank_nr));
      client.text("station:" + String(station_nr));
    }
    */

    //client.text("volume:" + String(volumeValue));
    //client.text("mute:" + String(volumeMute)); 

    client.text("bitrate:" + String(bitrateString)); 
    client.text("samplerate:" + String(sampleRateString)); 
    client.text("bitpersample:" + String(bitsPerSampleString)); 

    if (mp3)    client.text("streamformat:MP3");
    if (flac)   client.text("streamformat:FLAC");
    if (aac)    client.text("streamformat:AAC");
    if (vorbis) client.text("streamformat:VORBIS");
    if (opus)   client.text("streamformat:OPUS");

  }
}

void wsVolumeChange()  
{
  ws.textAll("volume:" + String(volumeValue)); // wysyła wartosc volume do wszystkich połączonych klientów
  ws.textAll("mute:" + String(volumeMute)); // wysyła wartosc mute do wszystkich połączonych klientów
}

void wsIrCodeClear()
{
  for (auto& client : ws.getClients()) 
  {
    client.text("learn:" + String(remoteConfig));
    client.text(String("clear"));
  }
}

// WebSockets do nauki pilota
void wsIrCode(uint16_t code, uint8_t add, uint8_t cm)
{
  char buf1[7];                    
  char buf2[5];
  char buf3[5];

  sprintf(buf1, "0x%04X", code); // Formatowanie "0xFFFF" + \0
  sprintf(buf2, "0x%02X", add);
  sprintf(buf3, "0x%02X", cm);

  Serial.print("wsIRCode:"); Serial.println(buf1);
  //Serial.print("addr:"); Serial.print(buf2);
  //Serial.print(" cmd:"); Serial.println(buf3);

  for (auto& client : ws.getClients()) 
  {
    client.text(String("ircode:") + buf1);
    client.text(String("addr:") + buf2);
    client.text(String("cmd:") + buf3);
    client.text("learn:" + String(remoteConfig));
    
    //client.text("pulse9" + String(pulse_duration_9ms));
    //client.text("pulse45:" + String(pulse_duration_4_5ms));
    //client.text("pulse1690:" + String(pulse_duration_1690us));
    //client.text("pulse560:" + String(pulse_duration_560us));
  }
}

void wsSignalLevel()
{
  ws.textAll("wifi:" + String(wifiSignalLevel)); // wysyła wartosc sygnalu wifi do wszystkich połączonych klientów
}

//Funkcja odpowiedzialna za zapisywanie informacji o stacji do pamięci PSRAM
void saveStationToPSRAM(const char *station) 
{
  
  // Sprawdź, czy istnieje jeszcze miejsce na kolejną stację w pamięci PSRAM
  if (stationsCount < MAX_STATIONS) {
    int length = strlen(station);

    // Sprawdź, czy długość linku nie przekracza ustalonego maksimum.
    if (length <= STATION_NAME_LENGTH) {
      // Zapisz długość linku jako pierwszy bajt.
      psramData[stationsCount * (STATION_NAME_LENGTH + 1)] = length;
      // Zapisz link jako kolejne bajty w pamięci PSRAM
      for (int i = 0; i < length; i++) 
      {
        psramData[stationsCount * (STATION_NAME_LENGTH + 1) + 1 + i] = station[i];
      }

      // Wydrukuj informację o zapisanej stacji na Serialu.
      Serial.println(String(stationsCount + 1) + "   " + String(station));  // Drukowanie na serialu od nr 1 jak w banku na serwerze

      // Zwiększ licznik zapisanych stacji.
      stationsCount++;

#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
      tftNativeLoadingBankProgress(stationsCount, bank_nr);
      return;
#endif
      // progress bar pobieranych stacji
      gfx.setFont(spleen6x12PL);  
      gfx.drawStr(21, 36, "Progress:");
      //gfx.drawStr(21, 36, "Loading: ");
      gfx.drawStr(75, 36, String(stationsCount).c_str());  // Napisz licznik pobranych stacji

      gfx.drawRFrame(21, 42, 212, 12, 3);  // Ramka paska postępu ladowania stacji stacji w>8 h>8
      
      int x = (stationsCount * 2) + 8;          // Dodajemy gdy stationCount=1 + 8 aby utrzymac warunek dla zaokrąglonego drawRBox - szerokość W>6 h>6 ma byc W>=2*(r+1), h >= 2*(r+1)
      gfx.drawRBox(23, 44, x, 8, 2);       // Pasek postepu ladowania stacji z serwera lub karty SD / SPIFFS       
      
      gfx.sendBuffer();  
    } else {
      // Informacja o błędzie w przypadku zbyt długiego linku do stacji.
      Serial.println("Błąd: Link do stacji jest zbyt długi");
    }
  } else {
    // Informacja o błędzie w przypadku osiągnięcia maksymalnej liczby stacji.
    Serial.println("Błąd: Osiągnięto maksymalną liczbę zapisanych stacji");
  }
}

// Funkcja przetwarza i zapisuje stację do pamięci PSRAM
void sanitizeAndSaveStation(const char *station) {
  // Bufor na przetworzoną stację - o jeden znak dłuższy niż maksymalna długość linku
  char sanitizedStation[STATION_NAME_LENGTH + 1];

  // Indeks pomocniczy dla przetwarzania
  int j = 0;

  // Przeglądaj każdy znak stacji i sprawdź czy jest to drukowalny znak ASCII
  for (int i = 0; i < STATION_NAME_LENGTH && station[i] != '\0'; i++) {
    // Sprawdź, czy znak jest drukowalnym znakiem ASCII
    if (isprint(station[i])) {
      // Jeśli tak, dodaj do przetworzonej stacji
      sanitizedStation[j++] = station[i];
    }
  }

  // Dodaj znak końca ciągu do przetworzonej stacji
  sanitizedStation[j] = '\0';

  // Zapisz przetworzoną stację do pamięci PSRAM
  saveStationToPSRAM(sanitizedStation);
}

// Odczyt banku z PIFFS lub karty SD (jesli dany bank istnieje juz na tej karcie)
void readSDStations() 
{
  stationsCount = 0;
  Serial.println("debuf SD -> Plik Banu isnieje lokalnie, czytamy TYLKO z karty");
  mp3 = flac = aac = vorbis = opus = false;
  evoAudioClearNowPlaying();  // Kasujemy metadane utworu po zmianie banku/listy

  // Tworzymy nazwę pliku banku
  String fileName = String("/bank") + (bank_nr < 10 ? "0" : "") + String(bank_nr) + ".txt";

  // Sprawdzamy, czy plik istnieje
  if (!STORAGE.exists(fileName)) 
  {
    Serial.println("Błąd: Plik banku nie istnieje.");
    return;
  }

  // Otwieramy plik w trybie do odczytu
  File bankFile = STORAGE.open(fileName, FILE_READ);
  if (!bankFile)  // jesli brak pliku to...
  {
    Serial.println("Błąd: Nie można otworzyć pliku banku.");
    return;
  }

  // Przechodzimy do odpowiedniego wiersza pliku
  int currentLine = 0;
  String stationUrl = "";

  while (bankFile.available())  // & currentLine <= MAX_STATIONS)
  {
    //if (currentLine < MAX_STATIONS)
    //{
    String line = bankFile.readStringUntil('\n');
    currentLine++;

    stationName = line.substring(0, 42);
    int urlStart = line.indexOf("http");  // Szukamy miejsca, gdzie zaczyna się URL
    if (urlStart != -1) 
    {
      stationUrl = line.substring(urlStart);  // Wyciągamy URL od "http"
      stationUrl.trim();                      // Usuwamy białe znaki na początku i końcu
      //Serial.print(" URL stacji:");
      //Serial.println(stationUrl);
      //String station = currentLine + "   " + stationName + "  " + stationUrl;
      String station = stationName + "  " + stationUrl;
      sanitizeAndSaveStation(station.c_str());  // przepisanie stacji do EEPROMu  (RAMU)
    }
  }

  Serial.print("Zamykamy plik bankFile na wartosci currentLine:");
  Serial.println(currentLine);
  bankFile.close();  // Zamykamy plik po odczycie
}


void fetchStationsFromServer() 
{
  displayActive = true;
  gfx.setFont(spleen6x12PL);
  gfx.clearBuffer();
  gfx.setCursor(21, 23);
  gfx.print("Loading bank:" + String(bank_nr) + " from:");
  gfx.sendBuffer();

  currentSelection = 0;
  firstVisibleLine = 0;
  station_nr = 1;
  previous_bank_nr = bank_nr; // jesli ładujemy stacje to ustawiamy zmienna previous_bank

  HTTPClient http; // Utwórz obiekt klienta HTTP
  String url; // URL stacji dla danego banku

  // ---------------------- WYBÓR URL BANKU ----------------------
  switch (bank_nr) 
  {
    case 1:  url = STATIONS_URL1; break;
    case 2:  url = STATIONS_URL2; break;
    case 3:  url = STATIONS_URL3; break;
    case 4:  url = STATIONS_URL4; break;
    case 5:  url = STATIONS_URL5; break;
    case 6:  url = STATIONS_URL6; break;
    case 7:  url = STATIONS_URL7; break;
    case 8:  url = STATIONS_URL8; break;
    case 9:  url = STATIONS_URL9; break;
    case 10: url = STATIONS_URL10; break;
    case 11: url = STATIONS_URL11; break;
    case 12: url = STATIONS_URL12; break;
    case 13: url = STATIONS_URL13; break;
    case 14: url = STATIONS_URL14; break;
    case 15: url = STATIONS_URL15; break;
    case 16: url = STATIONS_URL16; break;
    case 17: url = STATIONS_URL17; break;
    case 18: url = STATIONS_URL18; break;
    default:
      Serial.println("Nieprawidłowy numer banku");
      return;
  }

  // Tworzenie nazwy pliku dla danego banku
  String fileName = String("/bank") + (bank_nr < 10 ? "0" : "") + String(bank_nr) + ".txt";

  // ---------------------- JEŚLI PLIK ISTNIEJE ----------------------
  if (STORAGE.exists(fileName) && bankNetworkUpdate == false) 
  {
    Serial.println("debug SD -> Plik banku " + fileName + " już istnieje.");
    //if (useSD) { gfx.print("SD Card"); } else { gfx.print("SPIFFS"); }
    gfx.print(storageTextName); 
    gfx.sendBuffer();

    readSDStations(); // Jesli dany plik banku istnieje to odczytujemy go TYLKO z karty
    wsRefreshPage();
    return;
  }

  bankNetworkUpdate = false;

  gfx.print("GitHub");
  gfx.sendBuffer();

  // ---------------------- TWORZENIE PUSTEGO PLIKU ----------------------
  {
    File bankFile = STORAGE.open(fileName, FILE_WRITE);
    if (bankFile) 
    {
      Serial.println("debug SD -> Utworzono plik banku: " + fileName);
      bankFile.close(); // Zamykanie pliku po utworzeniu
    } 
    else 
    {
      Serial.println("debug SD -> Błąd tworzenia pliku: " + fileName);
    }
  }

  // ---------------------- POBIERANIE DANYCH HTTP ----------------------

  Serial.println("debug http -> Pobieram URL: " + url);

  http.begin(url); // Inicjalizuj żądanie HTTP do podanego adresu URL
  http.setUserAgent("ESP32-WebRadio");   // ustaweinie userAgent
  
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  http.useHTTP10(true);                 // <<< NAJWAŻNIEJSZE
  http.addHeader("Connection", "close");
  
  http.setTimeout(5000);                // 5 sekund timeout
  
  http.setConnectTimeout(3000);

  int httpCode = http.GET();  
  Serial.print("debug http -> Kod HTTP: ");
  Serial.println(httpCode); // Wydrukuj dodatkowe informacje o kodzie http

  // ----------- OBSŁUGA REDIRECTÓW 301 / 302 (GitHub to często robi!) -----------
  if (httpCode == HTTP_CODE_MOVED_PERMANENTLY || httpCode == HTTP_CODE_FOUND) // jesli GitHub ustawił redirect
  {
    String newUrl = http.getLocation();
    Serial.println("debug http -> Redirect: " + newUrl);

    http.end();

    http.begin(newUrl);
    http.setUserAgent("ESP32-WebRadio");
  
    http.useHTTP10(true);                 // <<< NAJWAŻNIEJSZE
    http.addHeader("Connection", "close");
    
    http.setTimeout(5000);                // 5 sekund timeout
  
    http.setConnectTimeout(3000);

    httpCode = http.GET();
    Serial.println("debug http -> Kod HTTP po redirect: " + String(httpCode));
  }

  // ---------------------- NIE UDAŁO SIĘ POBRAĆ ----------------------
  if (httpCode != HTTP_CODE_OK) 
  {
    Serial.printf("debug http -> Błąd pobierania. Kod HTTP: %d\n", httpCode);
    http.end();
    return;
  }

  // ---------------------- POBRANIE GETSTRING ----------------------
  String payload = http.getString();

  Serial.println("debug http -> Długość pobranych danych: " + String(payload.length()));

  // Zabezpieczenie przed pustym stringiem
  if (payload.length() == 0) 
  {
    Serial.println("debug http -> BŁĄD! Pobieranie zwróciło pusty payload. Usuwam plik.");
    STORAGE.remove(fileName);
    http.end();
    return;
  }

  // ---------------------- ZAPIS DO PLIKU ----------------------
  File bankFile = STORAGE.open(fileName, FILE_WRITE);
  if (bankFile) 
  {
    bankFile.print(payload);
    bankFile.close();
    Serial.println("debug SD -> Dane zapisane do pliku: " + fileName);
  } 
  else 
  {
    Serial.println("debug SD -> Błąd: Nie można otworzyć pliku do zapisu!");
  }

  http.end();

  // ---------------------- SANITYZACJA STACJI  ----------------------
  int startIndex = 0;
  int endIndex;
  stationsCount = 0;

  while ((endIndex = payload.indexOf('\n', startIndex)) != -1 && stationsCount < MAX_STATIONS) 
  {
    String station = payload.substring(startIndex, endIndex);
    if (!station.isEmpty())
      sanitizeAndSaveStation(station.c_str());

    startIndex = endIndex + 1;
  }

  wsRefreshPage();
}


void readEEPROM() // Funkcja kontrolna DEBUG odczytu EEPROMu, nie uzywan przez inne funkcje
{
  EEPROM.get(0, station_nr);
  EEPROM.get(1, bank_nr);
  EEPROM.get(2, volumeValue); 
}


void calcNec() // Funkcja umozliwajaca przeliczanie odwrotne aby "udawac" przyciski pilota IR w standardzie NEC
{
  //składamy kod pilota do postaci ADDR/CMD/CMD/ADDR aby miec 4 bajty
  uint8_t CMD = (ir_code >> 8) & 0xFF; 
  uint8_t ADDR = ir_code & 0xFF;        
  ir_code =  ADDR;
  ir_code = (ir_code << 8) | CMD;
  ir_code = (ir_code << 8) | CMD;
  ir_code = (ir_code << 8) | ADDR;
  ADDR = (ir_code >> 24) & 0xFF;           // Pierwszy bajt
  uint8_t IADDR = (ir_code >> 16) & 0xFF; // Drugi bajt (inwersja adresu)
  CMD = (ir_code >> 8) & 0xFF;            // Trzeci bajt (komenda)
  uint8_t ICMD = ir_code & 0xFF;          // Czwarty bajt (inwersja komendy)
  
  // Dorabiamy brakujące odwórcone bajty 
  IADDR = IADDR ^ 0xFF;
  ICMD = ICMD ^ 0xFF;

  // Składamy bajty w jeden ciąg          
  ir_code =  ICMD;
  ir_code = (ir_code << 8) | ADDR;
  ir_code = (ir_code << 8) | IADDR;
  ir_code = (ir_code << 8) | CMD;
  ir_code = reverse_bits(ir_code,32);     // rotacja bitów do porządku LSB-MSB jak w NEC        
}


// Funkcja formatowania dla scorllera stationString/stationName  **** stationStringScroll ****
void stationStringFormatting() 
{
  // ----------- MODE 0 - > STACJA, Stream, dwa wskazniki VU, linijka status na dole -----------
  if (displayMode == 0) 
  {   
    if (stationString == "") // Jeżeli stationString jest pusty i stacja go nie nadaje to podmieniamy pusty stationString na nazwę staji - stationNameStream
    {    
      if (stationNameStream == "") // jezeli nie ma równiez stationName to wstawiamy 3 kreseczki
      { 
        stationStringScroll = "---" ;
        stationStringWeb = "---" ;
      } 
      else // jezeli jest station name to prawiamy w "-- NAZWA --" i wysylamy do scrollera
      { 
        stationStringScroll = ("-- " + stationNameStream + " --");
        stationStringWeb = ("-- " + stationNameStream + " --");
      }  // Zmienna stationStringScroller przyjmuje wartość stationNameStream
    }
    else // Jezeli stationString zawiera dane to przypisujemy go do stationStringScroll do funkcji scrollera
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      stationStringScroll = stationString + "    "; // dodajemy separator do przewijanego tekstu jesli się nie miesci na ekranie
    }             
    
    //Liczymy długość napisu stationStringScroll 
    stationStringScrollWidth = stationStringScroll.length() * 6;    
    if (f_debug_on) 
    {
      Serial.print("debug -> StationStringScroll Lenght [chars]:");  Serial.println(stationStringScroll.length());
      Serial.print("debug -> StationStringScroll Width (Lenght * 6px) [px]:"); Serial.println(stationStringScrollWidth);
      
      Serial.print("debug -> Display Mode-0 stationStringScroll Text: @");
      Serial.print(stationStringScroll);
      Serial.println("@");
    }
  }
  // ------ MODE1 - DUZY ZEGAR -------
  else if (displayMode == 1) // Tryb wświetlania zegara z 1 linijką radia na dole
  {
    char StationNrStr[4];
    snprintf(StationNrStr, sizeof(StationNrStr), "%02d", station_nr);  //Formatowanie informacji o stacji i banku do postaci 00
    
    if (urlPlaying) 
    {
      strncpy(StationNrStr, "URL", sizeof(StationNrStr) - 1);
      StationNrStr[sizeof(StationNrStr) - 1] = '\0';  
    }

    int StationNameEnd = stationName.indexOf("  "); // Wycinamy nazwe stacji tylko do miejsca podwojnej spacji 
    stationName = stationName.substring(0, StationNameEnd);
 
    if (stationString == "")                // Jeżeli stationString jest pusty i stacja go nie nadaje
    {   
      if (stationNameStream == "")          // i jezeli nie ma równiez stationName
      {
        stationStringScroll = String(StationNrStr) + "." + stationName + ", ---" ;
        stationStringWeb = "---" ;
      }      // wstawiamy trzy kreseczki do wyswietlenia
      else  // jezeli jest brak "stationString" ale jest "stationName" to składamy NR.Nazwa stacji z pliku, nadawany stationNameStream + separator przerwy
      {       
        stationStringScroll = String(StationNrStr) + "." + stationName + ", " + stationNameStream + "     ";
        //stationStringScroll = String(StationNrStr) + "." + stationName;

        // Obcinnanie scrollera do 43 znakow - ABY BYŁ STAŁY TEKST mode 1
        //if (stationStringScroll.length() > 43) {stationStringScroll = stationStringScroll.substring(0,40) + "..."; }  
        stationStringWeb = stationNameStream;
      }
    }
    else //stationString != "" -> ma wartość
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      
      stationStringScroll = String(StationNrStr) + "." + stationName + ", " + stationString + "     "; 
      //stationStringScroll = String(StationNrStr) + "." + stationName; 
      
      // Obcinnanie scrollera do 43 znakow - ABY BYŁ STAŁY TEKST mode 1
      //stationStringScroll = String(StationNrStr) + "." + stationName + ", " + stationString; 
      //if (stationStringScroll.length() > 43) {stationStringScroll = stationStringScroll.substring(0,40) + "..."; }
      
      //Serial.println(stationStringScroll);
    }
    //Serial.print("debug -> Display1 (zegar) stationStringScroll: ");
    //Serial.println(stationStringScroll);

    //Liczymy długość napisu stationStringScrollWidth 
    stationStringScrollWidth = stationStringScroll.length() * 6;
  }
  // ----------- MODE 2 ekran bez scrollera 3 linijki tekstu ----------- //
  else if (displayMode == 2)
  {             
    // Jesli stacja nie nadaje stationString to podmieniamy pusty stationString na nazwę staji - stationNameStream
    if (stationString == "") // Jeżeli stationString jest pusty i stacja go nie nadaje
    {    
      if (stationNameStream == "") // jezeli nie ma równiez stationName
      { 
        stationStringScroll = "---" ;
        stationStringWeb = "---" ;
      } // wstawiamy trzy kreseczki do wyswietlenia
      else // jezeli jest station name to oprawiamy w "-- NAZWA --" i wysylamy do scrollera
      { 
        stationStringScroll = ("-- " + stationNameStream + " --");
        stationStringWeb = stationNameStream;
      }  // Zmienna stationStringScroller przyjmuje wartość stationNameStream
    }
    else // Jezeli stationString zawiera dane to przypisujemy go do stationStringScroll do funkcji scrollera
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      stationStringScroll = stationString;
    }  
  }
  else if (displayMode == 3) // Tryb wświetlania mode 3 i mode 5 (małe spectrum)
  {
    if (stationString == "") // Jeżeli stationString jest pusty i stacja go nie nadaje to podmieniamy pusty stationString na nazwę staji - stationNameStream
    {    
      if (stationNameStream == "") // jezeli nie ma równiez stationName to wstawiamy 3 kreseczki
      { 
        stationStringScroll = "---" ;
        stationStringWeb = "---" ;
      } 
      else // jezeli jest station name to oprawiamy w "-- NAZWA --" i wysylamy do scrollera
      { 
        stationStringScroll = ("-- " + stationNameStream + " --");
        stationStringWeb = ("-- " + stationNameStream + " --");
      }  // Zmienna stationStringScroller przyjmuje wartość stationNameStream
    }
    else // Jezeli stationString zawiera dane to przypisujemy go do stationStringScroll do funkcji scrollera
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      stationStringScroll = "  " + stationString + "  " ; // Nie dodajemy separator do tekstu aby wyswietlał się rowno na srodku
    }             
    //Liczymy długość napisu stationStringScroll 
    stationStringScrollWidth = stationStringScroll.length() * 6;
    //Serial.print("debug -> Display Mode-3 stationStringScroll:@");
    //Serial.print(stationStringScroll);
    //Serial.println("@");
  }
  else if (displayMode == 4) // Tryb wświetlania mode 4 formater dla potrzeb Web
  {
    if (stationString == "") // Jeżeli stationString jest pusty i stacja go nie nadaje to podmieniamy pusty stationString na nazwę staji - stationNameStream
    {    
      if (stationNameStream == "") // jezeli nie ma równiez stationName to wstawiamy 3 kreseczki
      { 
        stationStringScroll = "---" ;
        stationStringWeb = "---" ;
      } 
      else // jezeli jest station name to oprawiamy w "-- NAZWA --" i wysylamy do scrollera
      { 
        stationStringScroll = ("-- " + stationNameStream + " --");
        stationStringWeb = ("-- " + stationNameStream + " --");
      }  // Zmienna stationStringScroller przyjmuje wartość stationNameStream
    }
    else // Jezeli stationString zawiera dane to przypisujemy go do stationStringScroll do funkcji scrollera
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      stationStringScroll = "  " + stationString + "  " ; // Nie dodajemy separator do tekstu aby wyswietlał się rowno na srodku
    }             
    //Liczymy długość napisu stationStringScroll 
    stationStringScrollWidth = stationStringScroll.length() * 6;
    //Serial.print("debug -> Display Mode-3 stationStringScroll:@");
    //Serial.print(stationStringScroll);
    //Serial.println("@");
  }
  else if (displayMode == 7)
  {   
    if (stationString == "") // Jeżeli stationString jest pusty i stacja go nie nadaje to podmieniamy pusty stationString na nazwę staji - stationNameStream
    {    
      if (stationNameStream == "") // jezeli nie ma równiez stationName to wstawiamy 3 kreseczki
      { 
        stationStringScroll = "---" ;
        stationStringWeb = "---" ;
      } 
      else // jezeli jest station name to prawiamy w "-- NAZWA --" i wysylamy do scrollera
      { 
        stationStringScroll = ("-- " + stationNameStream + " --");
        stationStringWeb = ("-- " + stationNameStream + " --");
      }  // Zmienna stationStringScroller przyjmuje wartość stationNameStream
    }
    else // Jezeli stationString zawiera dane to przypisujemy go do stationStringScroll do funkcji scrollera
    {
      stationStringWeb = stationString;
      processText(stationString);  // przetwarzamy polsie znaki
      stationStringScroll = stationString + "    "; // dodajemy separator do przewijanego tekstu jesli się nie miesci na ekranie
    }             
    
    //Liczymy długość napisu stationStringScroll 
    stationStringScrollWidth = stationStringScroll.length() * 6;    
    if (f_debug_on) 
    {
      Serial.print("debug -> StationStringScroll Lenght [chars]:");  Serial.println(stationStringScroll.length());
      Serial.print("debug -> StationStringScroll Width (Lenght * 6px) [px]:"); Serial.println(stationStringScrollWidth);
      
      Serial.print("debug -> Display Mode-0 stationStringScroll Text: @");
      Serial.print(stationStringScroll);
      Serial.println("@");
    }
  }

}


#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI

// ============================================================================
// EVO TFT ILI9341/ILI9488 V5 ORIGINAL STYLE UI
// Cel: zachowac logike i klimat oryginalnego OLED 256x64, ale rozrysowac go
// natywnie na calym panelu TFT, logicznie 320x240 i skalowanie na ILI9488 / ILI9488 480x320. Bez wysylania starego bufora OLED.
// ============================================================================

String tftCleanText(String s)
{
  s.replace("\r", " ");
  s.replace("\n", " ");
  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  s.trim();
  return s;
}

String tftStationName()
{
  String s = stationName;
  int e = s.indexOf("  ");
  if (e > 0) s = s.substring(0, e);
  s = tftCleanText(s);
  if (s.length() == 0) s = tftCleanText(stationNameStream);
  if (s.length() == 0) s = "EVO RADIO";
  return s;
}

String tftClipText(String s, uint16_t maxChars)
{
  s = tftCleanText(s);
  if (s.length() <= maxChars) return s;
  if (maxChars < 4) return s.substring(0, maxChars);
  return s.substring(0, maxChars - 3) + "...";
}

String tftClockText(bool seconds = false)
{
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 0)) return seconds ? "--:--:--" : "--:--";
  char buf[12];
  if (seconds) snprintf(buf, sizeof(buf), "%02d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
  else snprintf(buf, sizeof(buf), "%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
  return String(buf);
}

String tftDateText()
{
  struct tm timeinfo;
  if (!getLocalTime(&timeinfo, 0)) return "--.--.----";
  char buf[16];
  snprintf(buf, sizeof(buf), "%02d.%02d.%04d", timeinfo.tm_mday, timeinfo.tm_mon + 1, timeinfo.tm_year + 1900);
  return String(buf);
}

String tftScrollWindow(String src, uint16_t visibleChars, uint16_t speedMs)
{
  src = tftCleanText(src);
  if (src.length() == 0) src = "---";
  if (src.length() <= visibleChars) return src;
  src += "     ";
  uint16_t start = (millis() / max(1, (int)speedMs)) % src.length();
  String out = src.substring(start) + src.substring(0, start);
  if (out.length() > visibleChars) out = out.substring(0, visibleChars);
  return out;
}


// ==================== APMS WEATHER HELPERS ====================
String evoWeatherUrlEncode(String s)
{
  String out = "";
  const char *hex = "0123456789ABCDEF";
  for (uint16_t i = 0; i < s.length(); i++)
  {
    uint8_t c = (uint8_t)s[i];
    if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') || c == '-' || c == '_' || c == '.')
    {
      out += (char)c;
    }
    else if (c == ' ')
    {
      out += "%20";
    }
    else
    {
      out += '%';
      out += hex[(c >> 4) & 0x0F];
      out += hex[c & 0x0F];
    }
  }
  return out;
}

String evoWeatherClean(String s)
{
  s.replace("\r", " ");
  s.replace("\n", " ");
  s.replace("\t", " ");
  s.replace("Weather report:", "");
  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  s.trim();
  return s;
}

String evoWeatherTftSafe(String s)
{
  s = evoWeatherClean(s);

  // APMS FIX:
  // Znak stopnia z internetu jest UTF-8 i na tej czcionce TFT potrafil
  // pokazac sie jako dziwny znak. Na TFT zapisujemy stabilnie jako "C".
  s.replace("°C", "C");
  s.replace("℃", "C");
  s.replace("°", "");

  // Usluga wttr potrafi zwrocic miejscowosc malymi literami albo z blednym znakiem.
  // W linii "Dane:" nie pokazujemy miejscowosci, bo jest juz w linii "Pogoda:".
  String city = evoWeatherCityDisplayName(evoWeatherCity);
  String low = s;
  low.toLowerCase();
  String lowCity = city;
  lowCity.toLowerCase();

  if (low.startsWith(lowCity + ":"))
  {
    s = s.substring(city.length() + 1);
    s.trim();
  }

  String lowCity2 = lowCity;
  lowCity2.replace("ł", "l");
  lowCity2.replace("Ł", "l");

  String low2 = low;
  low2.replace("ł", "l");
  low2.replace("Ł", "l");

  if (low2.startsWith(lowCity2 + ":"))
  {
    int colon = s.indexOf(':');
    if (colon >= 0)
    {
      s = s.substring(colon + 1);
      s.trim();
    }
  }

  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  return s;
}

String evoWeatherLineDataOnly()
{
  String line = evoWeatherTftSafe(evoWeatherText);
  if (line.length() == 0) line = "czekam na dane pogody";
  return line;
}


// APMS WEATHER CITY FIX 2:
// Nie zapisujemy polskiego "ł" w nazwie miejscowosci, bo czcionka TFT i formularz WWW
// w tym sofcie potrafily pokazac to jako "GoL_otczyzna" albo pusty znak.
// Wewnatrz programu trzymamy stabilny zapis ASCII, np. "Golotczyzna".
String evoWeatherCityDisplayName(String s)
{
  s = evoWeatherClean(s);
  if (s.length() == 0) s = "Golotczyzna";

  // Naprawa blednego zapisu po poprzedniej wersji, np. GoL_otczyzna.
  s.replace("_", "");
  s.replace("ł", "l");
  s.replace("Ł", "L");

  String low = s;
  low.toLowerCase();

  if (low == "golotczyzna") return "Golotczyzna";
  if (low == "warszawa") return "Warszawa";
  if (low == "krakow" || low == "kraków") return "Krakow";
  if (low == "lodz" || low == "łódź") return "Lodz";
  if (low == "wroclaw" || low == "wrocław") return "Wroclaw";
  if (low == "gdansk" || low == "gdańsk") return "Gdansk";
  if (low == "poznan" || low == "poznań") return "Poznan";

  bool upperNext = true;
  for (uint16_t i = 0; i < s.length(); i++)
  {
    char c = s[i];
    if (upperNext && c >= 'a' && c <= 'z')
    {
      s.setCharAt(i, c - 32);
      upperNext = false;
    }
    else if (c == ' ' || c == '-' || c == '_')
    {
      if (c == '_') s.setCharAt(i, ' ');
      upperNext = true;
    }
    else if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
    {
      upperNext = false;
    }
  }
  return s;
}

void evoWeatherReadConfig()
{
  if (STORAGE.exists(EVO_WEATHER_CFG_FILE))
  {
    File f = STORAGE.open(EVO_WEATHER_CFG_FILE, FILE_READ);
    if (f)
    {
      String c = f.readStringUntil('\n');
      c.trim();
      if (c.length() > 0) evoWeatherCity = evoWeatherCityDisplayName(c);
      f.close();
    }
  }
  if (evoWeatherCity.length() == 0) evoWeatherCity = "Golotczyzna";
  evoWeatherCity = evoWeatherCityDisplayName(evoWeatherCity);
}

void evoWeatherSaveConfig()
{
  File f = STORAGE.open(EVO_WEATHER_CFG_FILE, FILE_WRITE);
  if (f)
  {
    evoWeatherCity = evoWeatherCityDisplayName(evoWeatherCity);
    f.println(evoWeatherCity);
    f.close();
  }
}

bool evoWeatherFetchNow()
{
  if (WiFi.status() != WL_CONNECTED)
  {
    evoWeatherOk = false;
    evoWeatherLastError = "brak WiFi";
    return false;
  }

  String city = evoWeatherCityDisplayName(evoWeatherCity);
  if (city.length() == 0) city = "Golotczyzna";
  evoWeatherCity = city;

  // Prosty tekst bez JSON, lekki dla ESP32.
  // Format zawiera temperature, opis, wiatr, wilgotnosc i cisnienie.
  String url = String("http://wttr.in/") + evoWeatherUrlEncode(city) + String("?format=%t+%C+wiatr:%w+wilg:%h+cisn:%P");

  HTTPClient http;
  http.setTimeout(3500);
  http.setFollowRedirects(HTTPC_STRICT_FOLLOW_REDIRECTS);
  bool ok = false;

  if (http.begin(url))
  {
    int code = http.GET();
    if (code == HTTP_CODE_OK)
    {
      String payload = evoWeatherClean(http.getString());
      if (payload.length() > 0)
      {
        evoWeatherText = evoWeatherTftSafe(payload);
        evoWeatherOk = true;
        evoWeatherLastError = "";
        ok = true;
      }
    }
    else
    {
      evoWeatherOk = false;
      evoWeatherLastError = String("HTTP ") + String(code);
    }
    http.end();
  }
  else
  {
    evoWeatherOk = false;
    evoWeatherLastError = "HTTP start error";
  }

  evoWeatherLastFetchMs = millis();
  if (!ok)
  {
    evoWeatherText = evoWeatherCityDisplayName(city) + ": brak danych pogody";
  }
  return ok;
}

void evoWeatherMaybeUpdate(bool force)
{
  if (force || evoWeatherLastFetchMs == 0 || (millis() - evoWeatherLastFetchMs > EVO_WEATHER_REFRESH_MS))
  {
    evoWeatherFetchNow();
  }
}

String evoWeatherLine()
{
  String city = evoWeatherCityDisplayName(evoWeatherCity);
  if (city.length() == 0) city = "Golotczyzna";

  String line = evoWeatherText;
  line = evoWeatherClean(line);
  if (line.length() == 0) line = city + ": czekam na dane pogody";

  // Gdy usluga zwroci sama pogode bez nazwy, dopisz miejscowosc na poczatku.
  String low = line;
  low.toLowerCase();
  String lowCity = city;
  lowCity.toLowerCase();

  String lowNoPolish = low;
  lowNoPolish.replace("ł", "l");
  lowNoPolish.replace("Ł", "l");
  String cityNoPolish = lowCity;
  cityNoPolish.replace("ł", "l");
  cityNoPolish.replace("Ł", "l");

  if (low.indexOf(lowCity) < 0 && lowNoPolish.indexOf(cityNoPolish) < 0)
  {
    line = city + ": " + line;
  }
  return line;
}
// ================================================================================

bool tftIsEmptyNowPlayingText(String s)
{
  s = tftCleanText(s);
  String low = s;
  low.toLowerCase();

  if (s.length() == 0) return true;
  if (s == "-" || s == "--" || s == "---") return true;
  if (low.indexOf("no audio stream") >= 0) return true;
  if (low.indexOf("loading stream") >= 0) return true;
  return false;
}

String tftNormalizeNowPlaying(String s)
{
  s = tftCleanText(s);

  // Niektore serwery ICY potrafia wyslac tytul jako: StreamTitle='Artist - Title';
  int p = s.indexOf("StreamTitle='");
  if (p >= 0) {
    int start = p + 13;
    int end = s.indexOf("';", start);
    if (end < 0) end = s.length();
    s = s.substring(start, end);
    s = tftCleanText(s);
  }

  s.replace("StreamTitle=", "");
  s.replace("'", "");
  s.replace(";", "");
  s = tftCleanText(s);
  return s;
}

String tftNowPlaying()
{
  // APMS META FIX:
  // W miejscu tytulu NIE wolno uzywac stationNameStream/stationName jako fallbacku,
  // bo wtedy radio pokazuje nazwe stacji zamiast wykonawcy i utworu.
  String s = tftNormalizeNowPlaying(evoNowPlayingText);
  if (tftIsEmptyNowPlayingText(s)) s = tftNormalizeNowPlaying(stationString);
  if (tftIsEmptyNowPlayingText(s) || !evoNowPlayingValid) s = "Oczekiwanie na tytul utworu...";
  return s;
}

uint16_t tftVuColorOrig(int value)
{
  value = constrain(value, 0, 255);
  int pct = map(value, 0, 255, 0, 100);
  // Kolejnosc kolorow wg zalozenia: zolty -> zielony -> niebieski -> czerwony.
  if (pct < 35) return EVO_TFT_NATIVE_YELLOW;
  if (pct < 62) return EVO_TFT_NATIVE_GREEN;
  if (pct < 82) return 0x03DF;   // jasny niebieski / electric blue
  return EVO_TFT_NATIVE_RED;
}

uint16_t tftPanelBgForVu(int value)
{
  value = constrain(value, 0, 255);
  int pct = map(value, 0, 255, 0, 100);
  if (pct < 35) return 0x2120;
  if (pct < 62) return 0x0340;
  if (pct < 82) return 0x0011;
  return 0x3000;
}

uint16_t tftVuScaleBandColor(int pct)
{
  pct = constrain(pct, 0, 100);
  if (pct < 35) return EVO_TFT_NATIVE_YELLOW;
  if (pct < 62) return EVO_TFT_NATIVE_GREEN;
  if (pct < 82) return 0x03DF;  // niebieski
  return EVO_TFT_NATIVE_RED;
}

uint16_t tftVuInactiveTickColor(bool number = false)
{
  // Cyfry i kreski maja byc jasne nawet bez sygnalu.
  return number ? 0xFFFF : 0xBDF7;
}

uint16_t tftVuLitScaleColor(int tickPct, int needlePct, bool number = false)
{
  tickPct = constrain(tickPct, 0, 100);
  needlePct = constrain(needlePct, 0, 100);
  if (tickPct <= needlePct) return tftVuScaleBandColor(tickPct);
  return tftVuInactiveTickColor(number);
}

int tftVuPct(int value)
{
  // APMS VU DRIVE FIX 2026-05-10:
  // Wczesniej liczono: raw * evo46VuDrive / 255.
  // Przy ustawieniu 65 wskaznik mogl dojsc najwyzej do ok. 65%,
  // wiec styl 18 nigdy nie wchodzil w czerwone pole.
  // Teraz 65 traktujemy jako normalne pelne wysterowanie VU.
  // Dodatkowa kalibracja 50 kompensuje nizszy poziom VU z ESP32-audioI2S.
  // Efekt: przy ustawieniu 65 wskaznik moze dojsc do 100% i czerwonego pola,
  // a nizsze wartosci w menu nadal zmniejszaja czulosc.
  int v = constrain(value, 0, 255);
  int drive = constrain((int)evo46VuDrive, 10, 200);

  const int VU_DRIVE_FULL_SCALE_REF = 50;  // mniejsza liczba = mocniejsze wychylenie
  int pct = ((int32_t)v * 100L * drive) / (255L * VU_DRIVE_FULL_SCALE_REF);

  if (v > 8 && drive >= 65) pct += 2;
  return constrain(pct, 0, 100);
}

void tftNativeUpdateVuValues()
{
  // Natywny TFT ma wlasne, szybsze odswiezanie VU. Bez tego style TFT potrafily
  // wygladac ospale, bo korzystaly z wolniejszego odswiezania starego OLED.
  static uint32_t lastVuMs = 0;
  uint32_t now = millis();
  if ((uint32_t)(now - lastVuMs) < 18) return;
  lastVuMs = now;

  uint16_t raw = audio.getVUlevel();
  int targetL = (raw >> 8) & 0xFF;
  int targetR = raw & 0xFF;
  if (volumeMute) { targetL = 0; targetR = 0; }

  auto follow = [](uint8_t current, int target) -> uint8_t {
    int c = current;
    if (target > c) {
      int step = max(5, (target - c) / 2);
      c += step;
      if (c > target) c = target;
    } else if (target < c) {
      int step = max(2, (c - target) / 7);
      c -= step;
      if (c < target) c = target;
    }
    return (uint8_t)constrain(c, 0, 255);
  };

  displayVuL = follow(displayVuL, targetL);
  displayVuR = follow(displayVuR, targetR);
  vuMeterL = displayVuL;
  vuMeterR = displayVuR;

  if (displayVuL >= peakL) peakL = displayVuL;
  else if (peakL > 2) peakL -= 2;
  else peakL = 0;

  if (displayVuR >= peakR) peakR = displayVuR;
  else if (peakR > 2) peakR -= 2;
  else peakR = 0;
}

void tftTextRight(int xRight, int y, const String &text, uint8_t size, uint16_t color)
{
  int w = gfx.tftTextWidth(text.c_str(), size);
  gfx.tftText(xRight - w, y, text.c_str(), size, color);
}

void tftTextCenter(int x, int y, int w, const String &text, uint8_t size, uint16_t color)
{
  int tw = gfx.tftTextWidth(text.c_str(), size);
  int tx = x + max(0, (w - tw) / 2);
  gfx.tftText(tx, y, text.c_str(), size, color);
}

// V46: pomocnicza wersja zgodna z nowymi panelami.
// centerX oznacza środek tekstu, szerokość jest liczona automatycznie.
void tftTextCenter(int centerX, int y, const String &text, uint8_t size, uint16_t color)
{
  int tw = gfx.tftTextWidth(text.c_str(), size);
  int tx = centerX - tw / 2;
  gfx.tftText(tx, y, text.c_str(), size, color);
}


// ======================================================
// APMS REAL WIFI INDICATOR
// Zamiast sztucznych ikonek rysujemy rzeczywisty poziom
// z WiFi.RSSI(). Funkcja aktualizuje tez wifiSignalLevel,
// wiec WWW dostaje ten sam realny poziom.
// ======================================================
uint8_t evoWifiRealLevel()
{
  uint8_t level = 0;
  if (WiFi.status() == WL_CONNECTED) {
    int rssi = WiFi.RSSI();
    if      (rssi >= -50) level = 6;
    else if (rssi >= -57) level = 5;
    else if (rssi >= -66) level = 4;
    else if (rssi >= -74) level = 3;
    else if (rssi >= -81) level = 2;
    else if (rssi >= -88) level = 1;
    else                  level = 0;
  }
  wifiSignalLevel = level;
  return level;
}

String evoWifiRssiLabel()
{
  if (WiFi.status() != WL_CONNECTED) return String("NO WIFI");
  return String(WiFi.RSSI()) + "dBm";
}

uint16_t evoWifiLevelColor(uint8_t level)
{
  if (level >= 4) return EVO_TFT_NATIVE_GREEN;
  if (level >= 2) return EVO_TFT_NATIVE_YELLOW;
  if (level >= 1) return EVO_TFT_NATIVE_RED;
  return EVO_TFT_NATIVE_MUTED;
}

void tftDrawRealWifiIndicator(int x, int y, int w, int h, bool showText)
{
  // APMS FIX: nie rysujemy wskaznika WiFi w gornej belce paneli.
  // Prawdziwy wskaznik WiFi zostaje tylko w dolnej stopce / panelu informacyjnym.
  // Zabezpiecza to wszystkie panele, nawet jesli ktorys jeszcze wywola te funkcje przy Y < 60.
  if (y < 60)
  {
    gfx.tftFillRect(max(0, x - 3), max(0, y - 3), min(320, w + 6), min(240, h + 6), 0x0000);
    return;
  }

  uint8_t level = evoWifiRealLevel();
  uint16_t active = evoWifiLevelColor(level);
  uint16_t frame = (WiFi.status() == WL_CONNECTED) ? EVO_TFT_NATIVE_CYAN : EVO_TFT_NATIVE_RED;
  uint16_t dim = 0x18C3;

  gfx.tftFillRoundRect(x, y, w, h, 5, 0x0000);
  gfx.tftDrawRoundRect(x, y, w, h, 5, frame);

  // Antena po lewej stronie panelu.
  int ax = x + 12;
  int baseY = y + h - 5;
  int topY = y + 7;
  gfx.tftDrawLine(ax, topY, ax, baseY, frame);
  gfx.tftDrawLine(ax, baseY, ax - 7, y + h - 2, frame);
  gfx.tftDrawLine(ax, baseY, ax + 7, y + h - 2, frame);
  gfx.tftFillCircle(ax, topY, 2, frame);

  // Fale anteny - proste odcinki, bez ciezkich lukow.
  gfx.tftDrawLine(ax - 5, topY + 2, ax - 9, topY + 7, frame);
  gfx.tftDrawLine(ax - 9, topY + 7, ax - 5, topY + 12, frame);
  gfx.tftDrawLine(ax + 5, topY + 2, ax + 9, topY + 7, frame);
  gfx.tftDrawLine(ax + 9, topY + 7, ax + 5, topY + 12, frame);

  if (WiFi.status() != WL_CONNECTED) {
    gfx.tftDrawLine(x + w - 17, y + 7, x + w - 6, y + h - 7, EVO_TFT_NATIVE_RED);
    gfx.tftDrawLine(x + w - 6, y + 7, x + w - 17, y + h - 7, EVO_TFT_NATIVE_RED);
    if (showText) tftTextCenter(x, y + h - 9, w, "NO", 1, EVO_TFT_NATIVE_RED);
    return;
  }

  // Prawdziwy slupkowy wskaznik RSSI.
  const int bars = 6;
  int bw = 3;
  int gap = 2;
  int barsW = bars * bw + (bars - 1) * gap;
  int bx0 = x + w - barsW - 5;
  int by0 = y + h - 6;
  for (int i = 0; i < bars; i++) {
    int bh = 4 + i * 3;
    uint16_t c = (i < level) ? active : dim;
    gfx.tftFillRoundRect(bx0 + i * (bw + gap), by0 - bh, bw, bh, 1, c);
  }

  if (showText) {
    gfx.tftFillRect(x + 2, y + h - 10, w - 4, 8, 0x0000);
    tftTextCenter(x, y + h - 10, w, evoWifiRssiLabel(), 1, EVO_TFT_NATIVE_TEXT);
  }
}

String tftNowPlayingArtistText()
{
  String s = tftCleanText(evoNowPlayingArtist);
  if (s.length() > 0 && evoNowPlayingValid) return s;
  String np = tftNowPlaying();
  int sep = np.indexOf(" - ");
  if (sep > 0) return tftCleanText(np.substring(0, sep));
  return String("");
}

String tftNowPlayingTitleText()
{
  String s = tftCleanText(evoNowPlayingTitle);
  if (s.length() > 0 && evoNowPlayingValid) return s;
  String np = tftNowPlaying();
  int sep = np.indexOf(" - ");
  if (sep > 0) return tftCleanText(np.substring(sep + 3));
  return np;
}

String tftSecondText()
{
  String t = tftClockText(true);
  if (t.length() >= 8) return t.substring(6, 8);
  return String("--");
}

void tftDrawSmallSpeaker(int x, int y, uint16_t c)
{
  gfx.tftFillRect(x, y + 7, 5, 9, c);
  gfx.tftDrawLine(x + 5, y + 7, x + 12, y + 2, c);
  gfx.tftDrawLine(x + 5, y + 15, x + 12, y + 20, c);
  gfx.tftDrawLine(x + 12, y + 2, x + 12, y + 20, c);
  gfx.tftDrawLine(x + 16, y + 6, x + 20, y + 10, c);
  gfx.tftDrawLine(x + 16, y + 16, x + 20, y + 12, c);
}

void tftDrawSleepZZZ(int x, int y)
{
  gfx.tftText(x, y + 9, "z", 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftText(x + 8, y + 4, "z", 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftText(x + 16, y, "z", 1, EVO_TFT_NATIVE_YELLOW);
}

void tftDrawStationBadge(int x, int y, int w, int h)
{
  gfx.tftFillRoundRect(x, y, w, h, 5, 0xFFFF);
  gfx.tftDrawRoundRect(x, y, w, h, 5, EVO_TFT_NATIVE_YELLOW);
  String nr = urlPlaying ? String("URL") : String(station_nr < 10 ? "0" : "") + String(station_nr);
  tftTextCenter(x, y + 8, w, nr, nr == "URL" ? 2 : 3, 0x0000);
}



// ======================================================
// EVO FULL NEON PANELS - funkcje pomocnicze
// Umieszczone przed pierwszym użyciem, żeby Arduino IDE
// nie zgłaszało: "tftNeoPanel was not declared".
// ======================================================







// ======================================================
// EVO UI FONT MOD - funkcje paneli i własne fonty segmentowe
// Start zostaje ze starego softu, reszta UI dostaje nowy styl.
// ======================================================
void tftNeoPanel(int x, int y, int w, int h, uint16_t fill = 0x0841)
{
  gfx.tftFillRoundRect(x, y, w, h, 8, fill);
  gfx.tftDrawRoundRect(x, y, w, h, 8, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(x + 1, y + 1, w - 2, h - 2, 7, 0x39E7);
  gfx.tftDrawFastHLine(x + 8, y + 3, w - 16, 0x02DF);
  gfx.tftDrawFastHLine(x + 8, y + h - 4, w - 16, 0x014B);
}

void tftNeoThinPanel(int x, int y, int w, int h, uint16_t fill = 0x0000)
{
  gfx.tftFillRoundRect(x, y, w, h, 5, fill);
  gfx.tftDrawRoundRect(x, y, w, h, 5, EVO_TFT_NATIVE_CYAN);
}

void tftNeoSignalBars(int x, int y, uint16_t color)
{
  // APMS FIX: stary wskaznik WiFi/sygnalu nie moze pojawiac sie w gornej belce.
  // Jesli jakis stary panel wywola te funkcje przy Y < 60, czyscimy obszar i wychodzimy.
  if (y < 60)
  {
    gfx.tftFillRect(max(0, x - 3), max(0, y - 16), 42, 24, 0x0000);
    return;
  }

  // APMS: stara funkcja zostaje dla zgodnosci, ale nie rysuje juz
  // stalej symulacji. Poziom pochodzi z prawdziwego WiFi.RSSI().
  uint8_t level = evoWifiRealLevel();
  uint16_t active = evoWifiLevelColor(level);
  uint16_t dim = 0x18C3;
  for (int i = 0; i < 6; i++) {
    int bh = 3 + i * 2;
    uint16_t c = (WiFi.status() == WL_CONNECTED && i < level) ? active : dim;
    gfx.tftFillRoundRect(x + i * 4, y + 12 - bh, 3, bh, 1, c);
  }
}

void tftNeoTechText(int x, int y, const String &txt, uint16_t color)
{
  // Mały techniczny napis: cień + tekst.
  gfx.tftText(x + 1, y + 1, txt.c_str(), 1, 0x0000);
  gfx.tftText(x, y, txt.c_str(), 1, color);
}

void tftNeoTextCenter(int x, int y, int w, const String &txt, uint16_t color)
{
  tftTextCenter(x + 1, y + 1, w, txt, 1, 0x0000);
  tftTextCenter(x, y, w, txt, 1, color);
}

void tftNeoAntennaIcon(int x, int y, uint16_t color)
{
  // Bez tftDrawCircle(), rysowane samymi liniami.
  gfx.tftDrawLine(x, y + 4, x, y + 30, color);
  gfx.tftDrawLine(x, y + 30, x - 13, y + 46, color);
  gfx.tftDrawLine(x, y + 30, x + 13, y + 46, color);
  gfx.tftDrawFastHLine(x - 16, y + 46, 33, color);
  gfx.tftFillRoundRect(x - 3, y, 6, 6, 3, color);

  gfx.tftDrawLine(x - 8, y + 7, x - 15, y + 15, color);
  gfx.tftDrawLine(x - 15, y + 15, x - 15, y + 27, color);
  gfx.tftDrawLine(x - 15, y + 27, x - 8, y + 35, color);

  gfx.tftDrawLine(x - 15, y + 2, x - 25, y + 13, color);
  gfx.tftDrawLine(x - 25, y + 13, x - 25, y + 29, color);
  gfx.tftDrawLine(x - 25, y + 29, x - 15, y + 40, color);

  gfx.tftDrawLine(x + 8, y + 7, x + 15, y + 15, color);
  gfx.tftDrawLine(x + 15, y + 15, x + 15, y + 27, color);
  gfx.tftDrawLine(x + 15, y + 27, x + 8, y + 35, color);

  gfx.tftDrawLine(x + 15, y + 2, x + 25, y + 13, color);
  gfx.tftDrawLine(x + 25, y + 13, x + 25, y + 29, color);
  gfx.tftDrawLine(x + 25, y + 29, x + 15, y + 40, color);
}


void tftNeoSegH(int x, int y, int len, int th, uint16_t color)
{
  // Segment poziomy bez tftFillTriangle().
  // Używamy tylko metod dostępnych w EvoDisplayLovyanGFX.
  if (len < th) len = th;
  gfx.tftFillRoundRect(x, y, len, th, max(1, th / 2), color);
  if (len > th * 2) {
    gfx.tftFillRect(x + th / 2, y, len - th, th, color);
  }
}



void tftNeoSegV(int x, int y, int len, int th, uint16_t color)
{
  // Segment pionowy bez tftFillTriangle().
  // Używamy tylko metod dostępnych w EvoDisplayLovyanGFX.
  if (len < th) len = th;
  gfx.tftFillRoundRect(x, y, th, len, max(1, th / 2), color);
  if (len > th * 2) {
    gfx.tftFillRect(x, y + th / 2, th, len - th, color);
  }
}


void tftNeoDigit(int x, int y, int s, char ch, uint16_t on, uint16_t off)
{
  int w = 10 * s;
  int h = 18 * s;
  int th = max(2, 2 * s);
  int a=0,b=0,c=0,d=0,e=0,f=0,g=0;

  switch (ch) {
    case '0': a=b=c=d=e=f=1; break;
    case '1': b=c=1; break;
    case '2': a=b=g=e=d=1; break;
    case '3': a=b=c=d=g=1; break;
    case '4': f=g=b=c=1; break;
    case '5': a=f=g=c=d=1; break;
    case '6': a=f=e=d=c=g=1; break;
    case '7': a=b=c=1; break;
    case '8': a=b=c=d=e=f=g=1; break;
    case '9': a=b=c=d=f=g=1; break;
    default: break;
  }

  uint16_t dim = off;
  tftNeoSegH(x + 1*s, y,         w - 2*s, th, a ? on : dim);
  tftNeoSegV(x + w - th, y + 1*s, h/2 - 1*s, th, b ? on : dim);
  tftNeoSegV(x + w - th, y + h/2, h/2 - 1*s, th, c ? on : dim);
  tftNeoSegH(x + 1*s, y + h - th, w - 2*s, th, d ? on : dim);
  tftNeoSegV(x, y + h/2, h/2 - 1*s, th, e ? on : dim);
  tftNeoSegV(x, y + 1*s, h/2 - 1*s, th, f ? on : dim);
  tftNeoSegH(x + 1*s, y + h/2 - th/2, w - 2*s, th, g ? on : dim);
}

int tftNeoSegCharW(int s) { return 12 * s; }

void tftNeoSegmentText(int x, int y, const String &txt, int s, uint16_t color)
{
  uint16_t off = 0x0841;
  int cx = x;
  for (uint16_t i = 0; i < txt.length(); i++) {
    char ch = txt[i];
    if (ch >= '0' && ch <= '9') {
      tftNeoDigit(cx, y, s, ch, color, off);
      cx += tftNeoSegCharW(s);
    } else if (ch == ':') {
      int th = max(2, 2 * s);
      gfx.tftFillRoundRect(cx + 2*s, y + 5*s, th, th, th/2, color);
      gfx.tftFillRoundRect(cx + 2*s, y + 12*s, th, th, th/2, color);
      cx += 5 * s;
    } else if (ch == '.') {
      int th = max(2, 2 * s);
      gfx.tftFillRoundRect(cx + 2*s, y + 16*s, th, th, th/2, color);
      cx += 5 * s;
    } else if (ch == '-') {
      tftNeoSegH(cx + 1*s, y + 9*s, 9*s, max(2,2*s), color);
      cx += 10 * s;
    } else {
      cx += 5 * s;
    }
  }
}

void tftNeoMiniBadge(int x, int y, int w, const String &txt, uint16_t frame, uint16_t textColor)
{
  gfx.tftFillRoundRect(x, y, w, 17, 4, 0x0000);
  gfx.tftDrawRoundRect(x, y, w, 17, 4, frame);
  tftTextCenter(x, y + 4, w, txt, 1, textColor);
}


void tftDrawOriginalFrame()
{
  gfx.tftFillScreen(0x0000);
  gfx.tftDrawRect(0, 0, 320, 240, 0x10A2);
  gfx.tftDrawRect(1, 1, 318, 238, 0x0841);
}




void tftDrawOriginalHeader(const String &station)
{
  // ================================================================
  // APMS HEADER COMMON - globalna gorna ramka dla paneli podstawowych.
  // Poprawka: bez gornego WiFi, czyste tlo i stabilne pole stacji/zegara.
  // Prawdziwy wskaznik WiFi zostaje tylko w dolnej stopce.
  // ================================================================

  gfx.tftFillRoundRect(5, 5, 310, 28, 8, 0x0000);
  gfx.tftDrawRoundRect(5, 5, 310, 28, 8, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(7, 7, 306, 24, 6, 0x03EF);

  // Czyszczenie calego wnetrza belki. Usuwa resztki starych ikonek i tekstow.
  gfx.tftFillRect(10, 8, 300, 22, 0x0000);

  // Nazwa stacji bez ikonki WiFi po lewej.
  tftNeoMiniBadge(10, 9, 232, tftClipText(station, 31), EVO_TFT_NATIVE_CYAN, EVO_TFT_NATIVE_CYAN);

  // Zegar w prawym gornym rogu.
  gfx.tftFillRect(245, 8, 62, 20, 0x0000);
  tftTextRight(305, 11, tftClockText(false), 2, 0xFFFF);
}





void tftDrawOriginalFooter()
{
  String sr = String(SampleRate) + "." + String(SampleRateRest) + "kHz";
  String bits = bitsPerSampleString.length() ? bitsPerSampleString + "bit" : String("--bit");
  String br = bitrateString.length() ? bitrateString + "kbps" : String("--kbps");
  String codec = streamCodec.length() ? streamCodec : String("MP3");

  gfx.tftDrawFastHLine(10, 201, 300, 0x028F);
  gfx.tftText(12, 211, sr.c_str(), 1, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(66, 211, bits.c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(111, 211, br.c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(166, 211, codec.c_str(), 1, EVO_TFT_NATIVE_TEXT);

  char bankBuf[8];
  snprintf(bankBuf, sizeof(bankBuf), "B-%02d", bank_nr);
  tftNeoMiniBadge(222, 207, 39, String(bankBuf), EVO_TFT_NATIVE_CYAN, 0xFFFF);

  // APMS: antena + prawdziwe slupki WiFi z RSSI.
  tftDrawRealWifiIndicator(266, 205, 49, 29, false);
}




void tftDrawOriginalProgress(int x, int y, int w, int h, int value, int maxValue, uint16_t color)
{
  value = constrain(value, 0, max(1, maxValue));
  gfx.tftDrawRoundRect(x, y, w, h, 4, EVO_TFT_NATIVE_CYAN);
  gfx.tftFillRoundRect(x + 1, y + 1, w - 2, h - 2, 3, 0x0000);
  int fillW = ((int32_t)value * (w - 4)) / max(1, maxValue);
  if (fillW > 0) gfx.tftFillRoundRect(x + 2, y + 2, fillW, h - 4, 3, color);
}




void tftDrawOriginalBarVu(int x, int y, int w, const char *label, int value, int peakValue)
{
  int v = constrain(value, 0, 255);
  int pk = constrain(peakValue, 0, 255);
  gfx.tftText(x, y - 2, label, 1, EVO_TFT_NATIVE_MUTED);

  const int segs = 24;
  int segW = max(3, (w - 38) / segs);
  int baseX = x + 22;
  int pct = map(v, 0, 255, 0, 100);

  for (int i = 0; i < segs; i++) {
    int segPct = ((i + 1) * 100) / segs;
    int bh = 8 + (i % 4) * 2;
    int yy = y + 13 - bh;
    uint16_t col = (segPct <= pct) ? tftVuScaleBandColor(segPct) : 0x18C3;
    gfx.tftFillRoundRect(baseX + i * segW, yy, max(2, segW - 2), bh, 2, col);
  }

  if (vuPeakHoldOn && pk > 0) {
    int px = baseX + ((int32_t)pk * (w - 38)) / 255;
    gfx.tftDrawFastVLine(px, y - 4, 22, EVO_TFT_NATIVE_RED);
  }
}


void tftDrawPeakMarker(int x, int y, uint16_t color)
{
  gfx.tftDrawFastVLine(x, y - 7, 14, color);
  gfx.tftDrawLine(x - 4, y - 7, x, y - 12, color);
  gfx.tftDrawLine(x + 4, y - 7, x, y - 12, color);
}

void tftDrawAnalogVuOne(int cx, int cy, int value, int peakValue, const char *label)
{
  int pct = tftVuPct(value);
  int peakPct = tftVuPct(peakValue);
  const int frameW = 150;
  const int frameH = 96;
  const int scaleW = 132;
  const int leftX = cx - scaleW / 2;
  const int top = cy - frameH / 2;
  const int railY = top + 46;
  const int pivotY = top + 86;

  gfx.tftFillRoundRect(cx - frameW / 2, top, frameW, frameH, 6, 0x0000); // APMS FIX: czarne tlo wskaznika
  gfx.tftDrawRoundRect(cx - frameW / 2, top, frameW, frameH, 6, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(cx - frameW / 2 + 2, top + 2, frameW - 4, frameH - 4, 5, 0x39E7);
  gfx.tftText(cx - 58, top + 7, label, 2, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(cx + 35, top + 9, "VU", 1, EVO_TFT_NATIVE_MUTED);

  struct ScaleLabel { uint8_t pos; const char *txt; };
  const ScaleLabel labels[] = {{0,"-20"},{18,"-10"},{35,"-5"},{50,"-3"},{62,"0"},{74,"+3"},{87,"+6"},{100,"+9"}};

  gfx.tftDrawFastHLine(leftX, railY, scaleW, 0xBDF7);
  for (int p = 0; p <= 100; p += 4) {
    int x = leftX + ((int32_t)p * scaleW) / 100;
    bool major = (p % 20 == 0) || p == 62 || p == 74 || p == 100;
    int h = major ? 13 : 7;
    int dx = (x < cx) ? -h / 2 : (x > cx ? h / 2 : 0);
    uint16_t col = tftVuLitScaleColor(p, pct, false);
    gfx.tftDrawLine(x, railY, x + dx, railY - h, col);
    if (major) gfx.tftDrawLine(x + 1, railY, x + dx + 1, railY - h, col);
  }

  for (uint8_t i = 0; i < sizeof(labels) / sizeof(labels[0]); i++) {
    int x = leftX + ((int32_t)labels[i].pos * scaleW) / 100;
    uint16_t col = tftVuLitScaleColor(labels[i].pos, pct, true);
    gfx.tftText(x - 9, railY + 8, labels[i].txt, 1, col);
  }

  if (vuPeakHoldOn && peakPct > 0) {
    int px = leftX + ((int32_t)peakPct * scaleW) / 100;
    tftDrawPeakMarker(px, railY - 1, EVO_TFT_NATIVE_RED);
  }

  float angle = radians(-84 + 168.0f * pct / 100.0f);
  int xNeedle = cx + sin(angle) * 66;
  int yNeedle = pivotY - cos(angle) * 66;
  uint16_t needleColor = tftVuScaleBandColor(pct);
  gfx.tftDrawLine(cx, pivotY, xNeedle, yNeedle, needleColor);
  gfx.tftDrawLine(cx + 1, pivotY, xNeedle + 1, yNeedle, needleColor);
  gfx.tftDrawLine(cx - 1, pivotY, xNeedle - 1, yNeedle, needleColor);
  gfx.tftFillRoundRect(cx - 5, pivotY - 4, 10, 8, 3, 0xFFFF);
}

void tftDrawCrystalVuOne(int x, int y, int w, int h, int value, int peakValue, const char *label)
{
  int pct = tftVuPct(value);
  int peakPct = tftVuPct(peakValue);
  int cx = x + w / 2;
  int cy = y + h / 2;

  gfx.tftDrawLine(x + 20, y, x + w - 20, y, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawLine(x + w - 20, y, x + w, cy, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawLine(x + w, cy, x + w - 20, y + h, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawLine(x + w - 20, y + h, x + 20, y + h, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawLine(x + 20, y + h, x, cy, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawLine(x, cy, x + 20, y, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(x + 12, y + 8, label, 2, EVO_TFT_NATIVE_TEXT);

  const int segs = 22;
  const int sx0 = x + 42;
  const int usable = w - 84;
  const int sw = max(5, usable / segs);
  for (int i = 0; i < segs; i++) {
    int segPct = ((i + 1) * 100) / segs;
    int bh = 10 + abs(i - segs / 2) * 2;
    int bx = sx0 + i * sw;
    int by = cy - bh / 2;
    uint16_t col = (segPct <= pct) ? tftVuScaleBandColor(segPct) : 0x9CD3;
    gfx.tftFillRoundRect(bx + 1, by, max(2, sw - 3), bh, 2, col);
    if (segPct == 32 || segPct == 59 || segPct == 81 || segPct == 100) {
      gfx.tftText(bx - 4, y + h - 17, String(segPct).c_str(), 1, (segPct <= pct) ? col : 0xFFFF);
    }
  }

  if (vuPeakHoldOn && peakPct > 0) {
    int px = sx0 + ((int32_t)peakPct * usable) / 100;
    gfx.tftDrawFastVLine(px, y + 7, h - 14, EVO_TFT_NATIVE_RED);
    gfx.tftDrawFastVLine(px + 1, y + 7, h - 14, EVO_TFT_NATIVE_RED);
  }

  int nx = sx0 + ((int32_t)pct * usable) / 100;
  uint16_t col = tftVuScaleBandColor(pct);
  gfx.tftDrawLine(cx, y + h - 12, nx, cy, col);
  gfx.tftDrawLine(cx + 1, y + h - 12, nx + 1, cy, col);
}

void tftDrawSideSpreadVu(int x, int y, int w, int h, int valueL, int valueR, int peakValueL, int peakValueR)
{
  int center = x + w / 2;
  int pctL = tftVuPct(valueL);
  int pctR = tftVuPct(valueR);
  int peakLpc = tftVuPct(peakValueL);
  int peakRpc = tftVuPct(peakValueR);
  int half = w / 2 - 18;
  int rowH = 23;

  gfx.tftDrawRoundRect(x, y, w, h, 7, EVO_TFT_NATIVE_CYAN);
  gfx.tftFillRoundRect(x + 2, y + 2, w - 4, h - 4, 6, 0x0000);
  gfx.tftDrawFastVLine(center, y + 13, h - 26, EVO_TFT_NATIVE_MUTED);
  tftTextCenter(x, y + 7, w, "CENTER SPREAD VU", 1, EVO_TFT_NATIVE_YELLOW);

  for (int row = 0; row < 2; row++) {
    int yy = y + 39 + row * 47;
    int pct = row == 0 ? pctL : pctR;
    int peakPct = row == 0 ? peakLpc : peakRpc;
    const char *lab = row == 0 ? "L" : "R";
    gfx.tftText(x + 8, yy + 3, lab, 2, EVO_TFT_NATIVE_TEXT);
    gfx.tftText(x + w - 22, yy + 3, lab, 2, EVO_TFT_NATIVE_TEXT);
    for (int i = 0; i < 24; i++) {
      int segPct = ((i + 1) * 100) / 24;
      int dist = ((i + 1) * half) / 24;
      int segW = (i % 4 == 3) ? 6 : 4;
      int segH = rowH + (i % 4 == 3 ? 5 : 0);
      uint16_t col = (segPct <= pct) ? tftVuScaleBandColor(segPct) : 0x632C;
      gfx.tftFillRoundRect(center - dist - segW, yy, segW, segH, 2, col);
      gfx.tftFillRoundRect(center + dist, yy, segW, segH, 2, col);
    }
    if (vuPeakHoldOn && peakPct > 0) {
      int dist = ((int32_t)peakPct * half) / 100;
      gfx.tftDrawFastVLine(center - dist, yy - 4, rowH + 13, EVO_TFT_NATIVE_RED);
      gfx.tftDrawFastVLine(center + dist, yy - 4, rowH + 13, EVO_TFT_NATIVE_RED);
    }
  }

  for (int p = 0; p <= 100; p += 25) {
    int dist = ((int32_t)p * half) / 100;
    uint16_t col = tftVuScaleBandColor(p);
    gfx.tftText(center - dist - 7, y + h - 18, String(p).c_str(), 1, col);
    gfx.tftText(center + dist - 7, y + h - 18, String(p).c_str(), 1, col);
  }
}

void tftDrawPulseWingVu(int x, int y, int w, int h, int valueL, int valueR, int peakValueL, int peakValueR)
{
  // Styl 6: wachlarze / skrzydla. Dziala bez bitmap, tylko linie i segmenty.
  int pctL = tftVuPct(valueL);
  int pctR = tftVuPct(valueR);
  int peakLpc = tftVuPct(peakValueL);
  int peakRpc = tftVuPct(peakValueR);
  int cx = x + w / 2;
  int baseY = y + h - 20;
  int arcY = y + 24;
  int radius = w / 2 - 20;

  gfx.tftDrawRoundRect(x, y, w, h, 8, EVO_TFT_NATIVE_CYAN);
  tftTextCenter(x, y + 7, w, "WING V-METER", 2, EVO_TFT_NATIVE_YELLOW);
  gfx.tftDrawFastVLine(cx, y + 35, h - 47, EVO_TFT_NATIVE_MUTED);

  for (int side = 0; side < 2; side++) {
    int pct = side == 0 ? pctL : pctR;
    int peakPct = side == 0 ? peakLpc : peakRpc;
    const char *lab = side == 0 ? "L" : "R";
    int dir = side == 0 ? -1 : 1;
    gfx.tftText(side == 0 ? x + 12 : x + w - 24, y + 38, lab, 2, EVO_TFT_NATIVE_TEXT);
    for (int i = 0; i < 20; i++) {
      int segPct = ((i + 1) * 100) / 20;
      float a = radians(15 + i * 3.5f);
      int ex = cx + dir * (int)(cos(a) * (24 + (i + 1) * radius / 22));
      int ey = baseY - (int)(sin(a) * (46 + (i % 5) * 3));
      uint16_t col = (segPct <= pct) ? tftVuScaleBandColor(segPct) : 0x632C;
      gfx.tftDrawLine(cx, baseY, ex, ey, col);
      if (segPct <= pct) gfx.tftDrawLine(cx + dir, baseY, ex + dir, ey, col);
      if (i % 4 == 3) gfx.tftText(ex - 7, ey - 12, String(segPct).c_str(), 1, (segPct <= pct) ? col : 0xFFFF);
    }
    if (vuPeakHoldOn && peakPct > 0) {
      float a = radians(15 + (peakPct * 3.5f * 20.0f / 100.0f));
      int ex = cx + dir * (int)(cos(a) * (24 + peakPct * radius / 100));
      int ey = baseY - (int)(sin(a) * 58);
      tftDrawPeakMarker(ex, ey, EVO_TFT_NATIVE_RED);
    }
  }

  uint16_t colL = tftVuScaleBandColor(pctL);
  uint16_t colR = tftVuScaleBandColor(pctR);
  int nxL = cx - ((int32_t)pctL * radius) / 100;
  int nxR = cx + ((int32_t)pctR * radius) / 100;
  gfx.tftDrawLine(cx, baseY, nxL, arcY + 72 - pctL / 2, colL);
  gfx.tftDrawLine(cx, baseY, nxR, arcY + 72 - pctR / 2, colR);
  gfx.tftFillRoundRect(cx - 5, baseY - 4, 10, 8, 3, 0xFFFF);
}








void tftDrawRadioMain()
{
  String station = tftStationName();
  String title = tftNowPlaying();

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(station);

  tftNeoPanel(6, 37, 308, 70, 0x0000);
  //tftNeoTechText(15, 47, "CURRENT STATION", EVO_TFT_NATIVE_CYAN);
  gfx.tftText(15, 52, tftClipText(station, 24).c_str(), 2, 0xFFFF);
  
  //tftNeoSegmentText(15, 78, "98.4", 2, EVO_TFT_NATIVE_CYAN);
  tftNeoMiniBadge(102, 83, 38, streamCodec.length() ? streamCodec : String("MP3"), EVO_TFT_NATIVE_CYAN, EVO_TFT_NATIVE_CYAN);
  tftNeoMiniBadge(146, 83, 70, bitrateString.length() ? bitrateString + " kbps" : String("128 kbps"), EVO_TFT_NATIVE_YELLOW, EVO_TFT_NATIVE_YELLOW);
  //gfx.tftText(272, 49, "SIG", 1, EVO_TFT_NATIVE_MUTED);
  //tftNeoSignalBars(281, 79, EVO_TFT_NATIVE_CYAN);

  tftNeoPanel(6, 111, 308, 60, 0x0000);
  tftDrawOriginalBarVu(16, 120, 248, "L", displayVuL, peakL);
  tftDrawOriginalBarVu(16, 145, 248, "R", displayVuR, peakR);

  tftNeoThinPanel(8, 174, 306, 27, 0x0000);
  tftNeoTechText(14, 186, "TRACK:", EVO_TFT_NATIVE_CYAN);
  gfx.tftText(90, 181, tftScrollWindow(title, 17, 320).c_str(), 2, 0xFFFF);

  tftDrawOriginalFooter();
}






String tftWeekdayText()
{
  time_t now = time(nullptr);
  struct tm timeinfo;

  localtime_r(&now, &timeinfo);

  const char* dniTygodnia[] = {
    "NIEDZIELA",
    "PONIEDZIALEK",
    "WTOREK",
    "SRODA",
    "CZWARTEK",
    "PIATEK",
    "SOBOTA"
  };

  return String(dniTygodnia[timeinfo.tm_wday]);
}





void tftDrawClockScreen()
{
  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(6, 38, 308, 139, 0x0000);

  // Godzina
  tftNeoSegmentText(55, 63, tftClockText(true), 3, EVO_TFT_NATIVE_CYAN);

  // Dzień tygodnia + data w jednej linii
  String dateLine = tftWeekdayText() + "  " + tftDateText();

  // Większa czcionka daty i dnia tygodnia
  tftTextCenter(6, 124, 308, dateLine, 2, EVO_TFT_NATIVE_YELLOW);

  gfx.tftDrawFastHLine(24, 151, 272, 0x028F);

  tftTextCenter(6, 160, 308, tftClipText(tftStationName(), 24), 2, EVO_TFT_NATIVE_TEXT);

  tftDrawOriginalFooter();
}




// ======================================================
// APMS MOVIE CLOCK / FULL SCREEN CLOCK INTRO
// Migawka aparatu + efekt starej kliszy + przejscie do zegara.
// Tryb 20 ma byc osobnym zegarem: bez stacji, bez metadanych,
// tylko duze cyfry rolowane z dolu do gory i data.
// ======================================================
bool evoMovieClockIntroPending = true;
uint32_t evoMovieClockIntroStartMs = 0;

void evoDrawCameraShutterFrame(int step, bool closing);

void evoMovieClockResetIntro()
{
  evoMovieClockIntroPending = true;
  evoMovieClockIntroStartMs = 0;
}

// ======================================================
// APMS MOVIE CLOCK - panel zegara jak na filmie
// Tryb 20: gorne male "lampy" + dolny wyswietlacz punktowy.
// Cyfry nie przeskakuja od razu: przy zmianie rolkuja sie pionowo,
// stara cyfra ucieka do gory, nowa wchodzi od dolu.
// ======================================================
uint8_t evoMovieClockDigitRow(char ch, uint8_t row)
{
  static const uint8_t pat[10][7] = {
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}, // 0
    {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E}, // 1
    {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}, // 2
    {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E}, // 3
    {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}, // 4
    {0x1F,0x10,0x10,0x1E,0x01,0x01,0x1E}, // 5
    {0x0E,0x10,0x10,0x1E,0x11,0x11,0x0E}, // 6
    {0x1F,0x01,0x02,0x04,0x08,0x08,0x08}, // 7
    {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}, // 8
    {0x0E,0x11,0x11,0x0F,0x01,0x01,0x0E}  // 9
  };
  if (ch < '0' || ch > '9' || row > 6) return 0;
  return pat[ch - '0'][row];
}

void evoMovieClockDrawGhostGrid(int x, int y, int pitch, int r, uint16_t dim, int clipY, int clipH)
{
  for (uint8_t row = 0; row < 7; row++) {
    for (uint8_t col = 0; col < 5; col++) {
      int cx = x + col * pitch;
      int cy = y + row * pitch;
      if (cy < clipY + r || cy > clipY + clipH - r) continue;
      gfx.tftFillCircle(cx, cy, r, dim);
    }
  }
}

void evoMovieClockDrawDigitDots(int x, int y, char ch, int yOffset, int pitch, int r, uint16_t glow, uint16_t on, int clipY, int clipH)
{
  for (uint8_t row = 0; row < 7; row++) {
    uint8_t bits = evoMovieClockDigitRow(ch, row);
    for (uint8_t col = 0; col < 5; col++) {
      if ((bits & (1 << (4 - col))) == 0) continue;
      int cx = x + col * pitch;
      int cy = y + yOffset + row * pitch;
      if (cy < clipY + r + 1 || cy > clipY + clipH - r - 1) continue;
      gfx.tftFillCircle(cx, cy, r + 2, glow);
      gfx.tftFillCircle(cx, cy, r, on);
    }
  }
}

void evoMovieClockDrawColon(int x, int y, int pitch, int r, bool on, uint16_t glow, uint16_t color, uint16_t dim)
{
  int cy1 = y + 2 * pitch;
  int cy2 = y + 4 * pitch;
  uint16_t c = on ? color : dim;
  if (on) {
    gfx.tftFillCircle(x, cy1, r + 2, glow);
    gfx.tftFillCircle(x, cy2, r + 2, glow);
  }
  gfx.tftFillCircle(x, cy1, r, c);
  gfx.tftFillCircle(x, cy2, r, c);
}

void evoMovieClockDrawRollingTime(int x, int y, const String &timeTxt)
{
  const int pitch = 8;
  const int r = 3;
  const int digitAdvance = 44;
  const int colonAdvance = 16;
  const int digitH = 7 * pitch;
  const int slotY = y - 5;
  const int slotH = digitH + 10;
  const uint16_t dim = 0x1800;
  const uint16_t glow = 0x5800;
  const uint16_t on = 0xFBE0;

  static bool init = false;
  static char target[9] = "        ";
  static char oldc[9]   = "        ";
  static uint32_t changedAt[8] = {0,0,0,0,0,0,0,0};

  String txt = timeTxt;
  if (txt.length() != 8) txt = "--:--:--";

  uint32_t now = millis();
  if (!init) {
    for (uint8_t i = 0; i < 8; i++) { target[i] = txt[i]; oldc[i] = txt[i]; changedAt[i] = 0; }
    target[8] = 0; oldc[8] = 0;
    init = true;
  }

  for (uint8_t i = 0; i < 8; i++) {
    if (target[i] != txt[i]) {
      oldc[i] = target[i];
      target[i] = txt[i];
      changedAt[i] = now;
    }
  }

  int cx = x;
  bool colonOn = ((now / 500) % 2) == 0;
  for (uint8_t i = 0; i < 8; i++) {
    char ch = target[i];
    if (ch == ':') {
      evoMovieClockDrawColon(cx + 5, y, pitch, r, colonOn, glow, on, dim);
      cx += colonAdvance;
      continue;
    }

    evoMovieClockDrawGhostGrid(cx, y, pitch, 2, dim, slotY, slotH);

    uint32_t age = changedAt[i] ? (now - changedAt[i]) : 999;
    if (age >= 460 || oldc[i] == target[i]) {
      evoMovieClockDrawDigitDots(cx, y, target[i], 0, pitch, r, glow, on, slotY, slotH);
      changedAt[i] = 0;
    } else {
      int prog = (int)((age * 255UL) / 460UL);
      prog = constrain(prog, 0, 255);
      int oldOff = -((digitH + 10) * prog) / 255;
      int newOff =  (digitH + 10) - ((digitH + 10) * prog) / 255;
      evoMovieClockDrawDigitDots(cx, y, oldc[i], oldOff, pitch, r, glow, on, slotY, slotH);
      evoMovieClockDrawDigitDots(cx, y, target[i], newOff, pitch, r, glow, on, slotY, slotH);
    }
    cx += digitAdvance;
  }
}

void evoMovieClockDrawTubeDigit(int x, int y, char ch)
{
  const uint16_t glass = 0x0841;
  const uint16_t frame = 0x39E7;
  const uint16_t glow = 0x7800;
  const uint16_t on = 0xF81F;
  const uint16_t dim = 0x1008;

  gfx.tftFillRoundRect(x, y, 28, 54, 12, glass);
  gfx.tftDrawRoundRect(x, y, 28, 54, 12, frame);
  gfx.tftDrawFastHLine(x + 7, y + 3, 14, 0xBDF7);
  gfx.tftFillCircle(x + 14, y + 29, 12, 0x1800);

  int dx = x + 6;
  int dy = y + 13;
  int pitch = 4;
  for (uint8_t row = 0; row < 7; row++) {
    uint8_t bits = evoMovieClockDigitRow(ch, row);
    for (uint8_t col = 0; col < 5; col++) {
      int cx = dx + col * pitch;
      int cy = dy + row * pitch;
      if (bits & (1 << (4 - col))) {
        gfx.tftFillCircle(cx, cy, 2, glow);
        gfx.tftFillCircle(cx, cy, 1, on);
      } else {
        gfx.tftFillCircle(cx, cy, 1, dim);
      }
    }
  }
}

void evoMovieClockDrawTubes(const String &timeTxt)
{
  String compact = timeTxt;
  compact.replace(":", "");
  while (compact.length() < 6) compact += "0";

  int x0 = 34;
  for (uint8_t i = 0; i < 6; i++) {
    evoMovieClockDrawTubeDigit(x0 + i * 42, 13, compact[i]);
  }
}

void evoMovieClockDrawRollingTimeFull(int x, int y, const String &timeTxt)
{
  const int pitch = 9;
  const int r = 4;
  const int digitAdvance = 43;
  const int colonAdvance = 17;
  const int digitH = 7 * pitch;
  const int slotY = y - 8;
  const int slotH = digitH + 16;
  const uint16_t dim = 0x1000;
  const uint16_t glow = 0x7000;
  const uint16_t on = 0xFBE0;

  static bool init = false;
  static char target[9] = "        ";
  static char oldc[9]   = "        ";
  static uint32_t changedAt[8] = {0,0,0,0,0,0,0,0};

  String txt = timeTxt;
  if (txt.length() != 8) txt = "--:--:--";

  uint32_t now = millis();
  if (!init) {
    for (uint8_t i = 0; i < 8; i++) { target[i] = txt[i]; oldc[i] = txt[i]; changedAt[i] = 0; }
    target[8] = 0; oldc[8] = 0;
    init = true;
  }

  for (uint8_t i = 0; i < 8; i++) {
    if (target[i] != txt[i]) {
      oldc[i] = target[i];
      target[i] = txt[i];
      changedAt[i] = now;
    }
  }

  int cx = x;
  bool colonOn = ((now / 500) % 2) == 0;
  for (uint8_t i = 0; i < 8; i++) {
    char ch = target[i];
    if (ch == ':') {
      evoMovieClockDrawColon(cx + 5, y, pitch, r, colonOn, glow, on, dim);
      cx += colonAdvance;
      continue;
    }

    evoMovieClockDrawGhostGrid(cx, y, pitch, 2, dim, slotY, slotH);

    uint32_t age = changedAt[i] ? (now - changedAt[i]) : 999;
    if (age >= 520 || oldc[i] == target[i]) {
      evoMovieClockDrawDigitDots(cx, y, target[i], 0, pitch, r, glow, on, slotY, slotH);
      changedAt[i] = 0;
    } else {
      int prog = (int)((age * 255UL) / 520UL);
      prog = constrain(prog, 0, 255);
      int travel = digitH + 16;
      int oldOff = -(travel * prog) / 255;
      int newOff = travel - (travel * prog) / 255;
      evoMovieClockDrawDigitDots(cx, y, oldc[i], oldOff, pitch, r, glow, on, slotY, slotH);
      evoMovieClockDrawDigitDots(cx, y, target[i], newOff, pitch, r, glow, on, slotY, slotH);
    }
    cx += digitAdvance;
  }
}

void evoMovieClockDrawFilmIntro(uint32_t age)
{
  // 0..450 ms: otwieranie migawki, 450..1250 ms: stara klisza,
  // 1250..1900 ms: przejscie do zegara.
  if (age < 450) {
    int step = map(age, 0, 449, 0, 18);
    evoDrawCameraShutterFrame(step, false);
    tftTextCenter(0, 104, 320, "APMS", 3, 0xFFFF);
    tftTextCenter(0, 135, 320, "CLOCK", 2, 0xD69A);
    return;
  }

  if (age < 1250) {
    int frame = (age - 450) / 70;
    uint16_t bg = (frame & 1) ? 0x0800 : 0x0000;
    gfx.tftFillScreen(bg);

    // Perforacja filmu po bokach.
    for (int y = 8; y < 235; y += 24) {
      gfx.tftDrawRect(5, y, 9, 13, 0x8410);
      gfx.tftDrawRect(306, y, 9, 13, 0x8410);
    }

    // Rysy i kurz starej tasmy.
    for (uint8_t i = 0; i < 22; i++) {
      int x = (i * 29 + frame * 13) % 320;
      uint16_t c = (i % 3 == 0) ? 0xBDF7 : 0x3186;
      gfx.tftDrawFastVLine(x, 0, 240, c);
    }
    for (uint8_t i = 0; i < 28; i++) {
      int x = (i * 47 + frame * 17) % 310 + 5;
      int y = (i * 23 + frame * 11) % 220 + 8;
      gfx.tftFillCircle(x, y, (i & 1) ? 1 : 2, 0x8410);
    }

    tftTextCenter(0, 76, 320, "STARA KLISZA", 2, 0xD69A);
    tftTextCenter(0, 108, 320, "URUCHAMIANIE ZEGARA", 1, 0x8410);
    return;
  }

  int fade = constrain((int)map(age, 1250, 1900, 0, 120), 0, 120);
  gfx.tftFillScreen(0x0000);
  gfx.tftDrawRoundRect(fade / 2, fade / 3, 320 - fade, 240 - (fade * 2 / 3), 12, 0x528A);
  gfx.tftDrawRoundRect(8 + fade / 3, 8 + fade / 4, 304 - (fade * 2 / 3), 224 - fade / 2, 10, 0x2104);
  tftTextCenter(0, 107, 320, "PRZEJSCIE DO ZEGARA", 1, 0x8410);
}



// ======================================================
// APMS RESTORE: STYL 20 - poprzedni panel zegara z filmu
// Gorne male lampy + dolny punktowy zegar + data + stacja/metadane.
// Nowy panel informacyjny z WiFi zostal przeniesiony na styl 21.
// ======================================================
void tftDrawMovieClockScreen()
{
  String tim = tftClockText(true);
  String dateLine = tftWeekdayText() + "  " + tftDateText();

  gfx.tftFillScreen(0x0000);

  // Gorna linia z malymi lampami jak na filmie.
  evoMovieClockDrawTubes(tim);
  tftTextCenter(4, 70, 312, "APMS DIGITAL NIXIE CLOCK", 1, 0x8410);

  // Dolny, szeroki, punktowy wyswietlacz.
  gfx.tftFillRoundRect(8, 86, 304, 78, 5, 0x0000);
  gfx.tftDrawRoundRect(8, 86, 304, 78, 5, 0x2104);
  gfx.tftDrawRoundRect(10, 88, 300, 74, 4, 0x0800);
  evoMovieClockDrawRollingTime(14, 99, tim);

  // Opis i radio na dole.
  tftTextCenter(8, 172, 304, dateLine, 2, EVO_TFT_NATIVE_YELLOW);
  gfx.tftDrawFastHLine(24, 197, 272, 0x2104);
  tftTextCenter(8, 205, 304, tftClipText(tftStationName(), 28), 1, EVO_TFT_NATIVE_TEXT);
  tftTextCenter(8, 221, 304, tftScrollWindow(tftNowPlaying(), 34, 360), 1, EVO_TFT_NATIVE_ORANGE);
}

void tftDrawWifiInfoPanelScreen()
{
  // ================================================================
  // MODE 21 - PANEL INFORMACYJNY / WIFI / ZEGAR / METADANE
  // APMS FIX 2026-05-10:
  // - mniejszy zegar na srodku, zeby nie zachodzil na date i dzien
  // - data oraz dzien tygodnia sa w osobnych polach
  // - prawdziwy wskaznik WiFi zostaje z WiFi.RSSI()
  // - sekcje dostaly kolory: cyan / zolty / zielony
  // ================================================================

  const uint16_t COL_BG       = 0x0000;
  const uint16_t COL_PANEL    = 0x0000;
  const uint16_t COL_PANEL2   = 0x0841;
  const uint16_t COL_FRAME    = EVO_TFT_NATIVE_CYAN;
  const uint16_t COL_CYAN     = EVO_TFT_NATIVE_CYAN;
  const uint16_t COL_WHITE    = EVO_TFT_NATIVE_TEXT;
  const uint16_t COL_MUTED    = EVO_TFT_NATIVE_MUTED;
  const uint16_t COL_YELLOW   = EVO_TFT_NATIVE_YELLOW;
  const uint16_t COL_GREEN    = EVO_TFT_NATIVE_GREEN;
  const uint16_t COL_RED      = EVO_TFT_NATIVE_RED;
  const uint16_t COL_BLUE     = 0x039F;

  String station = tftStationName();
  if (station.length() == 0) station = "RADIO INTERNETOWE";

  String artist = tftNowPlayingArtistText();
  String songTitle = tftNowPlayingTitleText();
  String nowText = tftNowPlaying();

  artist.replace("\r", " "); artist.replace("\n", " "); artist.trim();
  songTitle.replace("\r", " "); songTitle.replace("\n", " "); songTitle.trim();
  nowText.replace("\r", " "); nowText.replace("\n", " "); nowText.trim();
  while (nowText.indexOf("  ") >= 0) nowText.replace("  ", " ");

  if (songTitle.length() == 0 && nowText.length() > 0) songTitle = nowText;
  if (songTitle.length() == 0) songTitle = "Oczekiwanie na tytul...";

  String timeMain = tftClockText(false);
  String seconds = tftSecondText();
  String dateOnly = tftDateText();
  String dayOnly = tftWeekdayText();

  String codec = streamCodec.length() ? streamCodec : String("MP3");
  String br = bitrateString.length() ? bitrateString + " kbps" : String("--- kbps");
  String sr = String(SampleRate) + "." + String(SampleRateRest) + " kHz";
  String ip = WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : String("brak IP");

  gfx.tftFillScreen(COL_BG);
  gfx.tftDrawRect(0, 0, 320, 240, 0x0841);
  gfx.tftDrawRect(1, 1, 318, 238, 0x10A2);

  // ------------------------------------------------
  // Naglowek stacji - zostawiony duzy, ale tekst jest krocony,
  // zeby nie wychodzil poza ekran.
  // ------------------------------------------------
  tftTextCenter(0, 7, 320, tftClipText(station, 18), 3, COL_CYAN);
  gfx.tftDrawFastHLine(42, 38, 236, COL_CYAN);
  gfx.tftDrawFastHLine(43, 39, 234, 0x028F);

  // ------------------------------------------------
  // Metadane - dwie osobne linie, bez wchodzenia na zegar.
  // ------------------------------------------------
  if (artist.length() > 0)
  {
    tftTextCenter(10, 48, 300, tftClipText(artist, 24), 2, COL_WHITE);
    tftTextCenter(10, 70, 300, tftClipText(songTitle, 24), 2, COL_WHITE);
  }
  else
  {
    tftTextCenter(10, 59, 300, tftScrollWindow(songTitle, 24, 420), 2, COL_WHITE);
  }

  // Linia audio - mniejsza i kolorowa.
  tftTextCenter(0, 92, 320, codec + "   " + br + "   " + sr, 1, COL_YELLOW);

  // ------------------------------------------------
  // ZEGAR SRODKOWY - POPRAWIONE
  // Wczesniej size 4 zaczynal sie za nisko i nachodzil na date.
  // Teraz zegar jest size 3, lekko wyzej, a sekundy sa po prawej.
  // ------------------------------------------------
  gfx.tftFillRect(34, 106, 250, 82, COL_BG);

  // delikatne linie dekoracyjne nad zegarem
  gfx.tftDrawFastHLine(118, 107, 32, 0x2104);
  gfx.tftDrawFastHLine(171, 107, 32, 0x2104);
  gfx.tftDrawFastVLine(160, 106, 62, 0x2104);

  // Godzina i minuty - mniejsze cyfry.
  tftNeoSegmentText(52, 113, timeMain, 3, 0xDFFF);

  // Sekundy - osobny prawy licznik.
  gfx.tftDrawFastVLine(258, 109, 54, COL_CYAN);
  gfx.tftText(268, 120, seconds.c_str(), 2, COL_CYAN);
  gfx.tftDrawFastHLine(267, 146, 38, COL_CYAN);

  // ------------------------------------------------
  // Data i dzien tygodnia - osobno, bez nachodzenia na zegar.
  // ------------------------------------------------
  gfx.tftFillRect(34, 171, 252, 26, COL_BG);
  tftTextCenter(36, 173, 112, tftClipText(dateOnly, 14), 1, COL_YELLOW);
  tftTextCenter(150, 173, 134, tftClipText(dayOnly, 15), 1, COL_WHITE);

  // Kolorowa linia pod data.
  gfx.tftDrawFastHLine(54, 192, 62, COL_CYAN);
  gfx.tftDrawFastHLine(129, 192, 62, COL_GREEN);
  gfx.tftDrawFastHLine(204, 192, 62, COL_YELLOW);

  // ------------------------------------------------
  // Dolne panele informacyjne.
  // ------------------------------------------------
  tftNeoThinPanel(7, 204, 86, 28, COL_PANEL);
  tftTextCenter(7, 207, 86, "IP", 1, COL_CYAN);
  tftTextCenter(7, 220, 86, tftClipText(ip, 14), 1, COL_WHITE);

  tftNeoThinPanel(98, 204, 73, 28, COL_PANEL);
  tftDrawSmallSpeaker(105, 209, COL_CYAN);
  tftDrawOriginalProgress(130, 211, 35, 9, volumeValue, maxVolume, COL_GREEN);

  tftNeoThinPanel(176, 204, 61, 28, COL_PANEL);
  tftTextCenter(176, 207, 61, "KANAL", 1, COL_CYAN);
  tftTextCenter(176, 220, 61, String("Ch:") + String(station_nr), 1, COL_WHITE);

  // Prawdziwy wskaznik WiFi: antena + slupki + rzeczywiste RSSI.
  tftDrawRealWifiIndicator(242, 203, 74, 31, true);
}






void tftDrawInfoScreen()
{
  String title = tftNowPlaying();

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(8, 43, 74, 133, 0x0000);
  tftNeoAntennaIcon(45, 66, EVO_TFT_NATIVE_CYAN);
  tftNeoTextCenter(8, 132, 74, "RADIO", EVO_TFT_NATIVE_CYAN);
  tftTextCenter(8, 146, 74, "INFO", 2, EVO_TFT_NATIVE_CYAN);

  tftNeoPanel(88, 43, 224, 133, 0x0000);

  // Nazwa stacji
  gfx.tftText(99, 52, tftClipText(tftStationName(), 19).c_str(), 2, EVO_TFT_NATIVE_CYAN);

  // Tytuł audycji / utworu
  // Przeniesione na prawy panel, bo wcześniej było x = 14 i nachodziło na lewy panel RADIO
  gfx.tftText(99, 74, tftScrollWindow(title, 24, 300).c_str(), 1, EVO_TFT_NATIVE_YELLOW);

  // APMS WEATHER:
  // Miejscowosc jest pokazywana z duzej litery, np. "Golotczyzna".
  // Pogoda idzie wolnym przewijaniem w jednej linii: temp/opis/wiatr/wilg/cisn.
  evoWeatherMaybeUpdate(false);

  String weatherCity = evoWeatherCityDisplayName(evoWeatherCity);
  String weatherLine = evoWeatherLineDataOnly();

  gfx.tftFillRect(96, 92, 208, 34, 0x0000);
  gfx.tftText(99, 94, "Pogoda:", 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(162, 94, tftClipText(weatherCity, 18).c_str(), 1, EVO_TFT_NATIVE_CYAN);

  // W "Dane" nie dublujemy juz miejscowosci.
  // Stopnie pokazujemy jako +17C zamiast znaku stopnia, bo font TFT go przeklamywal.
  gfx.tftText(99, 110, "Dane:", 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(162, 110, tftScrollWindow(weatherLine, 23, 1050).c_str(), 1, EVO_TFT_NATIVE_YELLOW);

  gfx.tftText(99, 126, "Jezyk:", 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(162, 126, "Polski", 1, 0xFFFF);

  gfx.tftText(99, 142, "Strona:", 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(162, 142, tftClipText(tftStationName(), 24).c_str(), 1, 0x07E0);

  tftDrawOriginalFooter();
}





void tftDrawMode3SpreadScreen()
{
  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(6, 38, 308, 161, 0x0000);
  tftNeoTextCenter(6, 46, 308, "VU BOOMERANG", EVO_TFT_NATIVE_CYAN);
  tftDrawSideSpreadVu(12, 70, 296, 116, displayVuL, displayVuR, peakL, peakR);

  tftDrawOriginalFooter();
}





void tftDrawVuScreen()
{
  String title = tftNowPlaying();

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(6, 38, 308, 161, 0x0000);

  // Tytuł audycji / utworu zamiast napisu VU ANALOG
  gfx.tftText(14, 46, tftScrollWindow(title,24, 350).c_str(), 2, 0x07E0);

  tftDrawAnalogVuOne(82, 124, displayVuL, peakL, "L");
  tftDrawAnalogVuOne(238, 124, displayVuR, peakR, "R");

  tftDrawOriginalFooter();
}





void tftDrawVuCrystalScreen()
{
  String title = tftNowPlaying();

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(6, 38, 308, 161, 0x0000);

  // Tytuł audycji / utworu
  // 24 = liczba znaków w oknie przewijania
  // 350 = szybkość przewijania, większa wartość zwykle oznacza wolniej
  // 0x07E0 = zielony kolor
  gfx.tftText(14, 46, tftScrollWindow(title, 24, 350).c_str(), 2, 0x001F);

  tftDrawCrystalVuOne(14, 76, 292, 48, displayVuL, peakL, "L");
  tftDrawCrystalVuOne(14, 130, 292, 48, displayVuR, peakR, "R");

  tftDrawOriginalFooter();
}





void tftDrawVuSideSpreadScreen()
{
  String title = tftNowPlaying();

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  tftNeoPanel(6, 38, 308, 161, 0x0000);

  // Tytuł audycji / utworu zamiast napisu "VU WING"
  // 24  = liczba znaków widocznych w oknie przewijania
  // 300 = szybkość przewijania, większa wartość zwykle oznacza wolniej
  // 0x07E0 = zielony kolor
  gfx.tftText(14, 46, tftScrollWindow(title, 24, 300).c_str(), 2, 0x07E0);

  tftDrawPulseWingVu(12, 70, 296, 118, displayVuL, displayVuR, peakL, peakR);

  tftDrawOriginalFooter();
}




#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS



void tftDrawTitleBar(const String &title, const String &right = "")
{
  // ================================================================
  // APMS TITLE BAR - globalna gorna ramka paneli Analyzer/VU/System/SD/BT.
  // Poprawka: bez gornego WiFi, tytul miesci sie w jednej belce,
  // prawa informacja ma wlasne czyszczone pole.
  // ================================================================
  tftDrawOriginalFrame();

  gfx.tftFillRoundRect(5, 5, 310, 28, 8, 0x0000);
  gfx.tftDrawRoundRect(5, 5, 310, 28, 8, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(7, 7, 306, 24, 6, 0x03EF);
  gfx.tftFillRect(10, 8, 300, 22, 0x0000);

  // Mniej znakow w tytule, zeby nie wchodzil na prawy opis.
  tftTextCenter(10, 11, 260, tftClipText(title, 21), 2, EVO_TFT_NATIVE_CYAN);

  if (right.length())
  {
    gfx.tftFillRect(250, 9, 56, 18, 0x0000);
    tftTextRight(305, 12, tftClipText(right, 8), 1, 0xFFFF);
  }
}




void tftDrawSoftFooter(const String &left, const String &center, const String &right)
{
  tftNeoPanel(6, 202, 308, 31, 0x0000);
  gfx.tftText(14, 212, tftClipText(left, 11).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  tftTextCenter(6, 212, 308, tftClipText(center, 20), 1, EVO_TFT_NATIVE_CYAN);
  tftTextRight(306, 212, tftClipText(right, 11), 1, EVO_TFT_NATIVE_MUTED);
}



void tftDrawProgressBar(int x, int y, int w, int h, int value, int maxValue, uint16_t color)
{
  value = constrain(value, 0, max(1, maxValue));
  tftNeoPanel(x, y, w, h, 0x0000);
  int fillW = ((int32_t)value * (w - 4)) / max(1, maxValue);
  if (fillW > 0) gfx.tftFillRoundRect(x + 2, y + 2, fillW, h - 4, 4, color);
}


String tftStationFromPsram(int idx)
{
  if (idx < 0 || idx >= stationsCount || psramData == nullptr) return String("---");
  char station[STATION_NAME_LENGTH + 1];
  memset(station, 0, sizeof(station));
  int length = psramData[idx * (STATION_NAME_LENGTH + 1)];
  length = constrain(length, 0, STATION_NAME_LENGTH);
  for (int j = 0; j < length; j++) station[j] = psramData[idx * (STATION_NAME_LENGTH + 1) + 1 + j];
  String s = String(station);
  int http = s.indexOf("http");
  if (http > 1) s = s.substring(0, http);
  return tftCleanText(s);
}

void tftNativeCenterMessage(const String &text, const String &sub = "")
{
  gfx.tftStartWrite();
  tftDrawOriginalFrame();
  gfx.tftDrawRoundRect(16, 62, 288, 108, 6, EVO_TFT_NATIVE_CYAN);
  gfx.tftFillRect(17, 63, 286, 106, 0x0000);
  uint8_t sz = text.length() > 14 ? 2 : 3;
  tftTextCenter(18, 88, 284, text, sz, EVO_TFT_NATIVE_TEXT);
  if (sub.length()) tftTextCenter(18, 134, 284, sub, 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftEndWrite();
}

void tftNativeEncoderOrder()
{
  gfx.tftStartWrite();
  tftDrawTitleBar("ENCODER", tftClockText(false));
  gfx.tftText(28, 70, "ZMIANA FUNKCJI", 2, EVO_TFT_NATIVE_YELLOW);
  if (!encoderFunctionOrder) {
    gfx.tftText(28, 112, "Obrot: glosnosc", 2, EVO_TFT_NATIVE_TEXT);
    gfx.tftText(28, 144, "Klik: lista stacji", 1, EVO_TFT_NATIVE_MUTED);
  } else {
    gfx.tftText(28, 112, "Obrot: lista stacji", 2, EVO_TFT_NATIVE_TEXT);
    gfx.tftText(28, 144, "Klik: glosnosc", 1, EVO_TFT_NATIVE_MUTED);
  }
  tftDrawSoftFooter("BACK", "ENCODER", "OK");
  gfx.tftEndWrite();
}



void tftNativeBankMenu()
{
  if (bank_nr < 1) bank_nr = 1;
  gfx.tftStartWrite();
  tftDrawTitleBar("WYBOR BANKU", tftClockText(false));
  tftNeoPanel(10, 47, 300, 119, 0x0000);
  gfx.tftText(34, 61, "AKTUALNY BANK", 1, EVO_TFT_NATIVE_CYAN);
  tftNeoSegmentText(80, 82, String(bank_nr), 3, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(168, 93, "(01-20)", 2, 0xFFFF);
  tftDrawProgressBar(28, 128, 264, 20, bank_nr, bank_nr_max, EVO_TFT_NATIVE_CYAN);
  if (bankNetworkUpdate) gfx.tftText(36, 154, "Aktualizacja z sieci", 1, EVO_TFT_NATIVE_ORANGE);
  if (storageTextName == "EEPROM") gfx.tftText(180, 154, "Brak karty", 1, EVO_TFT_NATIVE_RED);
  tftDrawSoftFooter("OBROT", "WYBIERZ BANK", "OK");
  gfx.tftEndWrite();
}





void tftNativeStationList()
{
  gfx.tftStartWrite();
  tftDrawTitleBar("LISTA STACJI", String(bank_nr) + "/" + String(station_nr));
  int rows = 6;
  int y0 = 49;
  int rowH = 24;
  int start = firstVisibleLine;
  if (start < 0) start = 0;
  if (currentSelection < start) start = currentSelection;
  if (currentSelection >= start + rows) start = currentSelection - rows + 1;
  if (start < 0) start = 0;

  tftNeoPanel(8, 42, 304, 154, 0x0000);
  for (int r = 0; r < rows; r++) {
    int idx = start + r;
    if (idx >= stationsCount) break;
    int y = y0 + r * rowH;
    bool sel = idx == currentSelection;
    if (sel) {
      gfx.tftFillRoundRect(13, y - 1, 294, 20, 4, 0x0210);
      gfx.tftDrawRoundRect(13, y - 1, 294, 20, 4, EVO_TFT_NATIVE_CYAN);
      gfx.tftText(18, y + 4, String(idx + 1).c_str(), 1, EVO_TFT_NATIVE_YELLOW);
      gfx.tftText(46, y + 4, tftClipText(tftStationFromPsram(idx), 31).c_str(), 1, 0xFFFF);
      gfx.tftText(294, y + 4, "*", 1, EVO_TFT_NATIVE_YELLOW);
    } else {
      gfx.tftDrawFastHLine(16, y + 19, 286, 0x1082);
      gfx.tftText(18, y + 4, String(idx + 1).c_str(), 1, EVO_TFT_NATIVE_MUTED);
      gfx.tftText(46, y + 4, tftClipText(tftStationFromPsram(idx), 31).c_str(), 1, EVO_TFT_NATIVE_TEXT);
    }
  }
  tftDrawSoftFooter("BANK " + String(bank_nr), "STACJE", String(station_nr) + "/" + String(stationsCount));
  gfx.tftEndWrite();
}





void tftNativeVolume()
{
  int maxV = max(1, (int)maxVolume);
  int v = constrain((int)volumeValue, 0, maxV);
  gfx.tftStartWrite();
  int x = 45;
  int y = 154;
  int w = 230;
  int h = 62;
  tftNeoPanel(x, y, w, h, 0x0000);
  tftDrawSmallSpeaker(x + 16, y + 21, EVO_TFT_NATIVE_TEXT);
  tftTextCenter(x, y + 10, w, "GLOSNOSC", 2, 0xFFFF);
  tftNeoSegmentText(x + w - 48, y + 21, String(v), 1, 0xFFFF);
  tftDrawOriginalProgress(x + 52, y + 34, w - 82, 12, v, maxV, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(x + 54, y + 49, "MIN", 1, EVO_TFT_NATIVE_MUTED);
  tftTextRight(x + w - 12, y + 49, "MAX", 1, EVO_TFT_NATIVE_MUTED);
  if (volumeMute) tftTextCenter(x, y + 45, w, "MUTE", 1, EVO_TFT_NATIVE_RED);
  gfx.tftEndWrite();
}



int tftToneX(int value, int minVal, int maxVal, int x, int w)
{
  value = constrain(value, minVal, maxVal);
  return x + ((int32_t)(value - minVal) * w) / max(1, (maxVal - minVal));
}

void tftEqRow(int y, const char *label, int value, int minVal, int maxVal, bool selected, bool balance = false)
{
  uint16_t labelColor = selected ? EVO_TFT_NATIVE_YELLOW : EVO_TFT_NATIVE_TEXT;
  if (selected) gfx.tftFillRect(8, y - 5, 304, 25, 0x2104);
  gfx.tftText(18, y, label, 1, labelColor);
  char val[18];
  snprintf(val, sizeof(val), "%+ddB", value);
  gfx.tftText(82, y, val, 1, EVO_TFT_NATIVE_MUTED);
  int x = 130, w = 160;
  gfx.tftDrawFastHLine(x, y + 8, w, EVO_TFT_NATIVE_MUTED);
  int zero = tftToneX(0, minVal, maxVal, x, w);
  gfx.tftDrawFastVLine(zero, y + 3, 11, EVO_TFT_NATIVE_CYAN);
  int px = tftToneX(value, minVal, maxVal, x, w);
  gfx.tftFillRect(px - 4, y + 2, 8, 13, selected ? EVO_TFT_NATIVE_YELLOW : EVO_TFT_NATIVE_CYAN);
}

void tftNativeEqualizer()
{
  gfx.tftStartWrite();
  tftDrawTitleBar("EQUALIZER", tftClockText(false));
  tftEqRow(62,  "HIGH", toneHiValue,  -40, 6, toneSelect == 1);
  tftEqRow(98,  "MID",  toneMidValue, -40, 6, toneSelect == 2);
  tftEqRow(134, "LOW",  toneLowValue, -40, 6, toneSelect == 3);
  tftEqRow(170, "BAL",  balanceValue, -16, 16, toneSelect == 4, true);
  tftDrawSoftFooter("ROTATE", "TONE CONTROL", "PRESS");
  gfx.tftEndWrite();
}

void tftNativeInfo(const String &chipSN)
{
  gfx.tftStartWrite();
  tftDrawTitleBar("INFO", tftClockText(false));
  gfx.tftText(18, 58, "EVO RADIO MOD", 2, EVO_TFT_NATIVE_YELLOW);
  gfx.tftText(18, 90, tftClipText(chipSN, 38).c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(18, 112, (String("HOST: ") + hostname).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(18, 134, (String("SSID: ") + wifiManager.getWiFiSSID()).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(18, 156, (String("IP: ") + currentIP).c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(18, 178, (String("RSSI: ") + String(WiFi.RSSI()) + " dBm").c_str(), 1, EVO_TFT_NATIVE_YELLOW);
  tftDrawSoftFooter("MAC", WiFi.macAddress(), "FW");
  gfx.tftEndWrite();
}

void tftNativeSleepTimer()
{
  String text;
  if (sleepTimerValueCounter != 0) text = SLEEP_STRING + String(sleepTimerValueCounter) + SLEEP_STRING_VAL;
  else text = String(SLEEP_STRING) + SLEEP_STRING_OFF;
  tftNativeCenterMessage(text, "SLEEP TIMER");
}

void tftNativeLoadingBankProgress(int count, int bank)
{
  gfx.tftStartWrite();
  tftDrawTitleBar("WCZYTYWANIE", "B" + String(bank));
  gfx.tftText(30, 72, "Ladowanie stacji", 2, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(30, 108, (String("Zapisano: ") + String(count)).c_str(), 2, EVO_TFT_NATIVE_CYAN);
  tftDrawProgressBar(30, 154, 260, 24, count, MAX_STATIONS, EVO_TFT_NATIVE_GREEN);
  tftDrawSoftFooter(storageTextName, "BANK " + String(bank), "WAIT");
  gfx.tftEndWrite();
}

void tftNativeOTA(uint32_t progress, uint32_t total)
{
  int pct = 0;
  if (total > 0) pct = (int)((uint64_t)progress * 100 / total);
  gfx.tftStartWrite();
  tftDrawTitleBar("OTA UPDATE", String(pct) + "%");
  gfx.tftText(32, 82, "Aktualizacja firmware", 2, EVO_TFT_NATIVE_TEXT);
  tftDrawProgressBar(30, 136, 260, 28, pct, 100, EVO_TFT_NATIVE_ORANGE);
  gfx.tftText(52, 178, (String(progress) + "/" + String(total)).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftEndWrite();
}


bool evoStandbyClockAnimating = false;

void evoDrawOldFilmColorFrame(uint8_t frame, const char *caption)
{
  // Kolorowa klisza/stary film: uzywane przy przejsciu do zegara standby.
  static const uint16_t filmBg[4] = {0x0800, 0x0008, 0x1000, 0x0200};
  static const uint16_t accent[4] = {0x07E0, 0xFFE0, 0x001F, 0xF800};
  uint16_t bg = filmBg[frame & 3];
  uint16_t a0 = accent[frame & 3];
  uint16_t a1 = accent[(frame + 1) & 3];

  gfx.tftFillScreen(bg);

  // Perforacja kolorowej kliszy po bokach.
  for (int y = 6; y < 236; y += 22) {
    uint16_t c = accent[((y / 22) + frame) & 3];
    gfx.tftFillRoundRect(4, y, 10, 14, 2, c);
    gfx.tftFillRoundRect(306, y, 10, 14, 2, c);
    gfx.tftDrawRoundRect(18, y + 1, 284, 12, 2, 0x3186);
  }

  // Rysy, kurz i przesuw tasmowy.
  for (uint8_t i = 0; i < 26; i++) {
    int x = (i * 29 + frame * 17) % 320;
    uint16_t c = (i % 4 == 0) ? a0 : ((i % 3 == 0) ? a1 : 0x2104);
    gfx.tftDrawFastVLine(x, 0, 240, c);
  }
  for (uint8_t i = 0; i < 34; i++) {
    int x = (i * 47 + frame * 13) % 310 + 5;
    int y = (i * 23 + frame * 19) % 225 + 5;
    gfx.tftFillCircle(x, y, (i & 1) ? 1 : 2, (i % 5 == 0) ? a1 : 0x8410);
  }

  // Kolorowe ramki jak klatki filmu.
  gfx.tftDrawRoundRect(24, 24, 272, 192, 12, a0);
  gfx.tftDrawRoundRect(30, 30, 260, 180, 10, a1);
  gfx.tftDrawFastHLine(36, 116 + ((frame & 1) ? 2 : -2), 248, 0xBDF7);

  if (caption && caption[0]) {
    tftTextCenter(0, 93, 320, caption, 2, 0xFFFF);
    tftTextCenter(0, 122, 320, "STANDBY CLOCK", 1, 0xFFE0);
  }
}

void evoMovieClockDrawStandbyTime(int x, int y, const String &timeTxt)
{
  // Standby: mniejsze cyfry niz panel 20, ale animacja ma byc plynna.
  // Ta funkcja musi byc wywolywana kilkanascie razy na sekunde podczas rolowania.
  // APMS FIX: standby ma byc czytelny, ale nie za duzy.
  // Mniejszy pitch daje wiecej marginesu, a cyfry przewijaja sie plynnie co sekunde.
  const int pitch = 7;
  const int r = 3;
  const int digitAdvance = 40;
  const int colonAdvance = 15;
  const int digitH = 7 * pitch;
  const int slotY = y - 6;
  const int slotH = digitH + 12;
  const uint16_t dim = 0x1000;
  const uint16_t glow = 0x5800;
  const uint16_t on = 0xFBE0;
  const uint16_t alt = 0xFD20;

  static bool init = false;
  static char target[9] = "        ";
  static char oldc[9]   = "        ";
  static uint32_t changedAt[8] = {0,0,0,0,0,0,0,0};

  String txt = timeTxt;
  if (txt.length() != 8) txt = "--:--:--";

  uint32_t now = millis();
  if (!init) {
    for (uint8_t i = 0; i < 8; i++) { target[i] = txt[i]; oldc[i] = txt[i]; changedAt[i] = 0; }
    target[8] = 0; oldc[8] = 0;
    init = true;
  }

  for (uint8_t i = 0; i < 8; i++) {
    if (target[i] != txt[i]) {
      oldc[i] = target[i];
      target[i] = txt[i];
      changedAt[i] = now;
    }
  }

  bool animatingNow = false;
  int cx = x;
  bool colonOn = ((now / 500) % 2) == 0;
  for (uint8_t i = 0; i < 8; i++) {
    char ch = target[i];
    if (ch == ':') {
      evoMovieClockDrawColon(cx + 5, y, pitch, r, colonOn, glow, alt, dim);
      cx += colonAdvance;
      continue;
    }

    evoMovieClockDrawGhostGrid(cx, y, pitch, 2, dim, slotY, slotH);

    uint32_t age = changedAt[i] ? (now - changedAt[i]) : 9999;
    if (age >= EVO_TFT_STANDBY_CLOCK_ROLL_MS || oldc[i] == target[i]) {
      evoMovieClockDrawDigitDots(cx, y, target[i], 0, pitch, r, glow, on, slotY, slotH);
      changedAt[i] = 0;
    } else {
      animatingNow = true;
      int prog = (int)((age * 255UL) / EVO_TFT_STANDBY_CLOCK_ROLL_MS);
      prog = constrain(prog, 0, 255);
      // Lagodne wejscie i wyjscie: bez skokowego startu/stopu cyfry.
      int eased = (int)(((long)prog * prog * (765L - 2L * prog)) / 65025L);
      int travel = digitH + 14;
      int oldOff = -(travel * eased) / 255;
      int newOff = travel - (travel * eased) / 255;
      evoMovieClockDrawDigitDots(cx, y, oldc[i], oldOff, pitch, r, glow, on, slotY, slotH);
      evoMovieClockDrawDigitDots(cx, y, target[i], newOff, pitch, r, glow, on, slotY, slotH);
    }
    cx += digitAdvance;
  }

  evoStandbyClockAnimating = animatingNow;
}

void tftNativeStandbyClock()
{
  // Zegar standby po wylaczeniu radia z pilota.
  // APMS FIX 2026-05-10:
  // - usuniete boczne klisze/perforacje, bo przepychaly duzo pikseli po SPI,
  // - sekundy zmieniaja sie co 1 sekunde,
  // - sama cyfra sekund roluje z dolu do gory w czasie EVO_TFT_STANDBY_CLOCK_ROLL_MS.
  // Nie zmienia stylu 20 - to jest osobny ekran trybu czuwania.
  gfx.setPowerSave(0);
  uint8_t standbyBrightness = dimmerSleepDisplayBrightness;
  if (standbyBrightness < EVO_TFT_STANDBY_CLOCK_BRIGHTNESS_MIN) standbyBrightness = EVO_TFT_STANDBY_CLOCK_BRIGHTNESS_MIN;
  gfx.setContrast(standbyBrightness);

  String tim = tftClockText(true);                  // HH:MM:SS - sekundy musza byc zawsze obecne
  String dateLine = tftWeekdayText() + "  " + tftDateText();

  gfx.tftStartWrite();
  gfx.tftFillScreen(0x0000);

  // Lekkie statyczne ramki bez kliszy po bokach.
  // Mniej rysowania = mniej opoznien podczas animacji sekund.
  gfx.tftDrawRoundRect(18, 18, 284, 204, 12, 0x2104);
  gfx.tftDrawRoundRect(23, 23, 274, 194, 10, 0x0841);
  gfx.tftDrawFastHLine(38, 57, 244, 0x39E7);
  gfx.tftDrawFastHLine(38, 58, 244, 0x0800);
  tftTextCenter(0, 34, 320, "STANDBY", 1, 0x8410);

  // Okno zegara.
  gfx.tftFillRoundRect(14, 69, 292, 86, 8, 0x0000);
  gfx.tftDrawRoundRect(14, 69, 292, 86, 8, 0x4208);
  gfx.tftDrawRoundRect(17, 72, 286, 80, 6, 0x1800);
  evoMovieClockDrawStandbyTime(25, 90, tim);

  // Data bez animowanego tla.
  gfx.tftFillRoundRect(25, 172, 270, 38, 8, 0x0000);
  gfx.tftDrawRoundRect(25, 172, 270, 38, 8, 0x4208);
  tftTextCenter(25, 184, 270, dateLine, 2, EVO_TFT_NATIVE_YELLOW);

  gfx.tftEndWrite();
}

void evoDrawCameraShutterFrame(int step, bool closing)
{
  step = constrain(step, 0, 18);
  int m = closing ? map(step, 0, 18, 0, 126) : map(step, 0, 18, 126, 0);
  static const uint16_t accent[4] = {0x07E0, 0xFFE0, 0x001F, 0xF800};
  uint16_t blade = 0x0000;
  uint16_t edge = accent[step & 3];
  uint16_t edge2 = accent[(step + 1) & 3];
  uint16_t film = (step & 1) ? 0x0800 : 0x0008;

  gfx.tftFillScreen(film);

  // Kolorowe perforacje i rysy kliszy.
  for (int y = 6; y < 236; y += 22) {
    uint16_t c = accent[((y / 22) + step) & 3];
    gfx.tftFillRoundRect(4, y, 10, 14, 2, c);
    gfx.tftFillRoundRect(306, y, 10, 14, 2, c);
  }
  for (uint8_t i = 0; i < 18; i++) {
    int x = (i * 37 + step * 11) % 320;
    uint16_t c = (i & 1) ? 0x3186 : edge2;
    gfx.tftDrawFastVLine(x, 0, 240, c);
  }
  for (uint8_t i = 0; i < 8; i++) {
    int y = (i * 31 + step * 7) % 240;
    gfx.tftDrawFastHLine(0, y, 320, (i & 1) ? 0x2104 : edge);
  }

  // Migawka aparatu: lopatki zamykaja obraz do srodka.
  gfx.tftFillRect(0, 0, 320, m, blade);
  gfx.tftFillRect(0, 240 - m, 320, m, blade);
  gfx.tftFillRect(0, 0, m, 240, blade);
  gfx.tftFillRect(320 - m, 0, m, 240, blade);

  gfx.tftFillRect(0, 0, m + 18, m + 18, blade);
  gfx.tftFillRect(320 - m - 18, 0, m + 18, m + 18, blade);
  gfx.tftFillRect(0, 240 - m - 18, m + 18, m + 18, blade);
  gfx.tftFillRect(320 - m - 18, 240 - m - 18, m + 18, m + 18, blade);

  int openW = max(2, 320 - 2 * m);
  int openH = max(2, 240 - 2 * m);
  gfx.tftDrawRoundRect(160 - openW / 2, 120 - openH / 2, openW, openH, 10, edge);
  gfx.tftDrawRoundRect(163 - openW / 2, 123 - openH / 2, max(2, openW - 6), max(2, openH - 6), 8, edge2);
  gfx.tftDrawCircle(160, 120, max(3, 118 - m), edge);
}

void tftNativePowerOffAnimation()
{
  gfx.tftStartWrite();

  // Najpierw kolorowa klisza/stary film - wolniej, z widocznym efektem tasmy.
  for (uint8_t f = 0; f < 10; f++) {
    evoDrawOldFilmColorFrame(f, (f < 5) ? "POWER OFF" : "PRZEJSCIE");
    gfx.tftEndWrite();
    delay(85);
    gfx.tftStartWrite();
  }

  // Krotki blysk jak klatka filmu/aparat.
  gfx.tftFillScreen(0xFFFF);
  gfx.tftEndWrite();
  delay(80);
  gfx.tftStartWrite();

  // Zamkniecie migawki aparatu - wolniejsze niz poprzednio.
  for (int i = 0; i <= 18; i++) {
    evoDrawCameraShutterFrame(i, true);
    gfx.tftEndWrite();
    delay(42);
    gfx.tftStartWrite();
  }

  // Zanik cienkiej linii jak w starym kineskopie/filmie.
  for (int h = 24; h >= 2; h -= 3) {
    gfx.tftFillScreen(0x0000);
    gfx.tftFillRect(0, 120 - h / 2, 320, h, 0x39E7);
    gfx.tftDrawFastHLine(0, 120, 320, 0xFFE0);
    gfx.tftEndWrite();
    delay(35);
    gfx.tftStartWrite();
  }

  gfx.tftFillScreen(0x0000);
  gfx.tftEndWrite();
}


void tftNativeStartupSplash(bool loadedLogo, const char *rev)
{
  int target = constrain((int)displayBrightness, 20, 255);
  if (f_logoSlowBrightness) gfx.setContrast(0);

  for (int step = 0; step <= 16; step++) {
    int br = map(step, 0, 16, 8, target);
    if (f_logoSlowBrightness) gfx.setContrast(br);

    gfx.tftStartWrite();
    gfx.tftFillScreen(0x0000);
    gfx.tftDrawRect(0, 0, 320, 240, EVO_TFT_NATIVE_CYAN);
    gfx.tftDrawFastHLine(0, 39, 320, EVO_TFT_NATIVE_CYAN);
    // APMS FIX 2026-05-10:
    // Usuniete zolte napisy wersji/trybu z gornej czesci ekranu startowego.
    // Wczesniej bylo tutaj tftTextRight(... String(rev) ...), przez co nazwa
    // oprogramowania nachodzila na tytul i wygladala jak blad wyswietlania.
    gfx.tftText(24, 10, "Evo Internet Radio", 2, EVO_TFT_NATIVE_TEXT);
    // tftTextRight(310, 12, String(rev), 1, EVO_TFT_NATIVE_YELLOW);

    if (loadedLogo) {
      gfx.tftDrawXBitmap(32, 58, SCREEN_WIDTH, SCREEN_HEIGHT, logo_bits, EVO_TFT_NATIVE_CYAN);
    } else {
      // Oryginalne nutki XBM z softu OLED, wysrodkowane na panelu TFT.
      gfx.tftDrawXBitmap(32, 62, notes_width, notes_height, notes, EVO_TFT_NATIVE_CYAN);
      gfx.tftText(74, 122, "EVO WEB RADIO", 2, EVO_TFT_NATIVE_TEXT);
    }

    int w = map(step, 0, 16, 0, 260);
    gfx.tftDrawRoundRect(30, 184, 260, 16, 4, EVO_TFT_NATIVE_CYAN);
    if (w > 4) gfx.tftFillRoundRect(32, 186, w - 4, 12, 3, EVO_TFT_NATIVE_YELLOW);
    gfx.tftText(46, 210, "booting audio / wifi / storage", 1, EVO_TFT_NATIVE_MUTED);
    gfx.tftEndWrite();
    delay(18);
  }

  gfx.setContrast(target);
}

void tftNativeConnectingMessage(const String &msg)
{
  gfx.tftStartWrite();
  gfx.tftFillRect(0, 202, 320, 38, 0x0000);
  gfx.tftDrawFastHLine(0, 201, 320, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(8, 214, tftClipText(msg, 42).c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftEndWrite();
}

void tftNativeNoStorageScreen()
{
  gfx.tftStartWrite();
  tftDrawTitleBar("STORAGE ERROR", "SD");
  gfx.tftText(28, 82, "Please check SD card", 2, EVO_TFT_NATIVE_RED);
  gfx.tftDrawRect(246, 66, 42, 58, EVO_TFT_NATIVE_TEXT);
  gfx.tftFillRect(252, 72, 30, 10, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(254, 96, "SD", 2, EVO_TFT_NATIVE_YELLOW);
  tftDrawSoftFooter("ERROR", storageTextName, "CHECK");
  gfx.tftEndWrite();
}



// =================================================================================================
// V43 - EVO3 MOD KOLOR FULL na bazie V7
// Rdzen radia, audio, WiFi, WebServer i LovyanGFX zostaje z V7.
// Tutaj sa funkcje wykonawcze i nowe panele dla elementow z EVO3 MOD OST:
// SD Player, SD Recorder, DLNA, Bluetooth, EQ16, Analyzer FFT/Scope, System Monitor.
// Panele sa rysowane natywnie w 320x240, potem skalowane przez warstwe V7 na ILI9488.
// =================================================================================================

#ifndef EVO43_MAX_TRACKS
  #define EVO43_MAX_TRACKS 96
#endif
#ifndef EVO43_REC_BUFFER_SIZE
  #define EVO43_REC_BUFFER_SIZE 1024
#endif

struct Evo43TrackItem
{
  String path;
  String name;
  bool isDir;
};

static Evo43TrackItem evo43Tracks[EVO43_MAX_TRACKS];
static uint16_t evo43TrackCount = 0;
static uint16_t evo43SelectedTrack = 0;
static String evo43CurrentDir = "/";
static bool evo43FilesDirty = true;
static bool evo43SdPlaying = false;
static bool evo43SdPaused = false;
static String evo43CurrentTrack = "";
static String evo43LastAction = "READY";

static bool evo43RecActive = false;
static bool evo43RecHeadersDone = false;
static WiFiClient evo43RecClient;
static File evo43RecFile;
static String evo43RecFileName = "";
static String evo43RecStation = "";
static uint32_t evo43RecStartMs = 0;
static uint32_t evo43RecLastByteMs = 0;
static uint32_t evo43RecBytes = 0;
static String evo43RecHeaderBuffer = "";
static uint8_t evo43RecBuffer[EVO43_REC_BUFFER_SIZE];

static bool evo43Eq16Enabled = false;
static int8_t evo43Eq16[16] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
static uint8_t evo43Eq16SelectedBand = 0;
static bool evo43Eq16EditGain = false;  // OK wlacza regulacje wybranego pasma EQ16
static bool eq16MenuActive = false;     // aktywne menu EQ16 z pilota / WWW
static bool evoAudioEqReturnModeValid = false;
static uint8_t evoAudioEqReturnDisplayMode = 0;  // tryb ekranu, do ktorego wracamy po EQ16
static uint8_t evo43AnalyzerStyle = 5;
static bool evo43AnalyzerTest = false;
static String evo43DlnaHost = "";
static String evo43DlnaIdx = "0";
static String evo43DlnaDescUrl = "";

static String evo43BtMode = "OFF";
static String evo43BtLastCmd = "";

// =================================================================================================
// V46 - pelniejsze przeniesienie ustawien EVO3 MOD OST na kolorowy LovyanGFX / ILI9488
// =================================================================================================

#define EVO46_MAX_WIFI_NETWORKS 5

struct Evo46WifiNetwork
{
  String ssid;
  String pass;
};

static Evo46WifiNetwork evo46WifiNetworks[EVO46_MAX_WIFI_NETWORKS];
static uint8_t evo46WifiCount = 0;
static bool evo46AnalyzerEnabled = true;
static uint8_t evo46AnalyzerStyles = 2;   // 0=Classic cycle, 1=Reduced, 2=All
static uint8_t evo46AnalyzerPreset = 4;   // 0..4, 4=Custom
static uint8_t evo46BtVolume = 15;
static bool evo46SdPlayerStyleEnabled[15] = {true,true,true,true,true,true,true,true,true,true,true,true,true,true,true};

struct Evo46AnalyzerConfig
{
  uint16_t peakHoldTimeMs = 40;
  uint8_t palette = 0;
  uint8_t bg = 0;
  uint8_t grid = 1;
  uint8_t scale = 100;

  uint8_t s5_barWidth = 8;
  uint8_t s5_gap = 3;
  uint8_t s5_segments = 18;
  uint8_t s5_segmentHeight = 3;
  uint8_t s5_fill = 80;
  bool s5_showPeaks = true;
  uint8_t s5_smoothness = 50;
  uint8_t s5_barBrightness = 255;
  uint8_t s5_peakBrightness = 255;

  uint8_t s8_barWidth = 14;
  uint8_t s8_gap = 3;
  uint8_t s8_segments = 32;
  uint8_t s8_segmentHeight = 2;
  uint8_t s8_fill = 60;
  bool s8_showPeaks = true;
  uint8_t s8_smoothness = 50;
  uint8_t s8_barBrightness = 255;
  uint8_t s8_peakBrightness = 255;

  uint8_t s6_width = 7;
  uint8_t s6_gap = 5;
  uint8_t s6_lines = 22;
  bool s6_showPeaks = true;
  uint8_t s6_smoothness = 55;
  uint8_t s6_barBrightness = 230;
  uint8_t s6_peakBrightness = 255;

  uint8_t s10_barWidth = 10;
  uint8_t s10_gap = 4;
  uint8_t s10_maxPeaks = 3;
  uint8_t s10_peakHoldTime = 35;
  uint8_t s10_peakFloatSpeed = 7;
  uint8_t s10_peakFadeSteps = 12;
  uint8_t s10_peakBrightness = 255;
  uint8_t s10_barBrightness = 245;
  uint8_t s10_minHeight = 2;
};

static Evo46AnalyzerConfig evo46AnalyzerCfg;
static uint8_t evo46BandSmooth[32] = {0};
static uint8_t evo46BandPeak[32] = {0};
static uint32_t evo46BandPeakMs[32] = {0};

static uint8_t evo46ClampU8(int v, int lo, int hi)
{
  if (v < lo) v = lo;
  if (v > hi) v = hi;
  return (uint8_t)v;
}

static uint16_t evo46PaletteColor(uint8_t pal, int pct)
{
  pct = constrain(pct, 0, 100);
  pal = constrain((int)pal, 0, 5);
  if (pal == 1) { // niebiesko-cyan
    if (pct < 35) return 0x03FF;
    if (pct < 65) return EVO_TFT_NATIVE_CYAN;
    if (pct < 85) return EVO_TFT_NATIVE_YELLOW;
    return EVO_TFT_NATIVE_RED;
  }
  if (pal == 2) { // retro bursztyn
    if (pct < 35) return 0xFD20;
    if (pct < 65) return EVO_TFT_NATIVE_ORANGE;
    if (pct < 85) return EVO_TFT_NATIVE_YELLOW;
    return EVO_TFT_NATIVE_RED;
  }
  if (pal == 3) { // fiolet / magenta
    if (pct < 35) return 0x781F;
    if (pct < 65) return 0xF81F;
    if (pct < 85) return EVO_TFT_NATIVE_CYAN;
    return EVO_TFT_NATIVE_YELLOW;
  }
  if (pal == 4) { // klasyczne VU cztery kolory
    if (pct < 35) return EVO_TFT_NATIVE_GREEN;
    if (pct < 62) return EVO_TFT_NATIVE_YELLOW;
    if (pct < 82) return 0x001F; // niebieski
    return EVO_TFT_NATIVE_RED;
  }
  if (pal == 5) { // zimny neon
    if (pct < 35) return 0x07FF;
    if (pct < 62) return 0x05FF;
    if (pct < 82) return 0xA81F;
    return 0xF81F;
  }
  // domyslny EVO3 KOLOR
  if (pct < 35) return EVO_TFT_NATIVE_GREEN;
  if (pct < 62) return EVO_TFT_NATIVE_YELLOW;
  if (pct < 82) return EVO_TFT_NATIVE_ORANGE;
  return EVO_TFT_NATIVE_RED;
}

static uint16_t evo46Dim(uint16_t c)
{
  uint16_t r = (c >> 11) & 0x1F;
  uint16_t g = (c >> 5) & 0x3F;
  uint16_t b = c & 0x1F;
  r >>= 2; g >>= 2; b >>= 2;
  return (r << 11) | (g << 5) | b;
}

static uint16_t evo46BgColor()
{
  switch (evo46AnalyzerCfg.bg) {
    case 1: return 0x0000;
    case 2: return 0x0841;
    case 3: return 0x1008;
    case 4: return 0x2000;
    default: return 0x0005;
  }
}

static uint16_t evo46GridColor()
{
  switch (evo46AnalyzerCfg.grid) {
    case 0: return 0x0841;
    case 2: return 0x39E7;
    case 3: return EVO_TFT_NATIVE_CYAN;
    case 4: return EVO_TFT_NATIVE_GREEN;
    default: return 0x18E3;
  }
}

static String evo46CfgLine(const String &k, const String &v)
{
  return k + "=" + v + "\n";
}

static String evo46AnalyzerCfgToString()
{
  String s;
  s.reserve(1200);
  s += evo46CfgLine("peakHoldMs", String(evo46AnalyzerCfg.peakHoldTimeMs));
  s += evo46CfgLine("palette", String(evo46AnalyzerCfg.palette));
  s += evo46CfgLine("bg", String(evo46AnalyzerCfg.bg));
  s += evo46CfgLine("grid", String(evo46AnalyzerCfg.grid));
  s += evo46CfgLine("scale", String(evo46AnalyzerCfg.scale));
  s += evo46CfgLine("s5w", String(evo46AnalyzerCfg.s5_barWidth));
  s += evo46CfgLine("s5gap", String(evo46AnalyzerCfg.s5_gap));
  s += evo46CfgLine("s5seg", String(evo46AnalyzerCfg.s5_segments));
  s += evo46CfgLine("s5segh", String(evo46AnalyzerCfg.s5_segmentHeight));
  s += evo46CfgLine("s5fill", String(evo46AnalyzerCfg.s5_fill));
  s += evo46CfgLine("s5peaks", String(evo46AnalyzerCfg.s5_showPeaks ? 1 : 0));
  s += evo46CfgLine("s5smooth", String(evo46AnalyzerCfg.s5_smoothness));
  s += evo46CfgLine("s5barBrightness", String(evo46AnalyzerCfg.s5_barBrightness));
  s += evo46CfgLine("s5peakBrightness", String(evo46AnalyzerCfg.s5_peakBrightness));
  s += evo46CfgLine("s8w", String(evo46AnalyzerCfg.s8_barWidth));
  s += evo46CfgLine("s8gap", String(evo46AnalyzerCfg.s8_gap));
  s += evo46CfgLine("s8seg", String(evo46AnalyzerCfg.s8_segments));
  s += evo46CfgLine("s8segh", String(evo46AnalyzerCfg.s8_segmentHeight));
  s += evo46CfgLine("s8fill", String(evo46AnalyzerCfg.s8_fill));
  s += evo46CfgLine("s8peaks", String(evo46AnalyzerCfg.s8_showPeaks ? 1 : 0));
  s += evo46CfgLine("s8smooth", String(evo46AnalyzerCfg.s8_smoothness));
  s += evo46CfgLine("s8barBrightness", String(evo46AnalyzerCfg.s8_barBrightness));
  s += evo46CfgLine("s8peakBrightness", String(evo46AnalyzerCfg.s8_peakBrightness));
  s += evo46CfgLine("s6w", String(evo46AnalyzerCfg.s6_width));
  s += evo46CfgLine("s6gap", String(evo46AnalyzerCfg.s6_gap));
  s += evo46CfgLine("s6lines", String(evo46AnalyzerCfg.s6_lines));
  s += evo46CfgLine("s6peaks", String(evo46AnalyzerCfg.s6_showPeaks ? 1 : 0));
  s += evo46CfgLine("s6smooth", String(evo46AnalyzerCfg.s6_smoothness));
  s += evo46CfgLine("s6barBrightness", String(evo46AnalyzerCfg.s6_barBrightness));
  s += evo46CfgLine("s6peakBrightness", String(evo46AnalyzerCfg.s6_peakBrightness));
  s += evo46CfgLine("s10barw", String(evo46AnalyzerCfg.s10_barWidth));
  s += evo46CfgLine("s10gap", String(evo46AnalyzerCfg.s10_gap));
  s += evo46CfgLine("s10maxp", String(evo46AnalyzerCfg.s10_maxPeaks));
  s += evo46CfgLine("s10hold", String(evo46AnalyzerCfg.s10_peakHoldTime));
  s += evo46CfgLine("s10speed", String(evo46AnalyzerCfg.s10_peakFloatSpeed));
  s += evo46CfgLine("s10fade", String(evo46AnalyzerCfg.s10_peakFadeSteps));
  s += evo46CfgLine("s10peakbr", String(evo46AnalyzerCfg.s10_peakBrightness));
  s += evo46CfgLine("s10barbr", String(evo46AnalyzerCfg.s10_barBrightness));
  s += evo46CfgLine("s10minh", String(evo46AnalyzerCfg.s10_minHeight));
  return s;
}

static void evo46AnalyzerClamp()
{
  evo46AnalyzerCfg.peakHoldTimeMs = constrain((int)evo46AnalyzerCfg.peakHoldTimeMs, 10, 2000);
  evo46AnalyzerCfg.palette = evo46ClampU8(evo46AnalyzerCfg.palette, 0, 5);
  evo46AnalyzerCfg.bg = evo46ClampU8(evo46AnalyzerCfg.bg, 0, 4);
  evo46AnalyzerCfg.grid = evo46ClampU8(evo46AnalyzerCfg.grid, 0, 4);
  evo46AnalyzerCfg.scale = evo46ClampU8(evo46AnalyzerCfg.scale, 30, 200);
  evo46AnalyzerCfg.s5_barWidth = evo46ClampU8(evo46AnalyzerCfg.s5_barWidth, 2, 24);
  evo46AnalyzerCfg.s5_gap = evo46ClampU8(evo46AnalyzerCfg.s5_gap, 0, 10);
  evo46AnalyzerCfg.s5_segments = evo46ClampU8(evo46AnalyzerCfg.s5_segments, 4, 40);
  evo46AnalyzerCfg.s5_segmentHeight = evo46ClampU8(evo46AnalyzerCfg.s5_segmentHeight, 1, 10);
  evo46AnalyzerCfg.s5_fill = evo46ClampU8(evo46AnalyzerCfg.s5_fill, 10, 100);
  evo46AnalyzerCfg.s5_smoothness = evo46ClampU8(evo46AnalyzerCfg.s5_smoothness, 0, 95);
  evo46AnalyzerCfg.s8_barWidth = evo46ClampU8(evo46AnalyzerCfg.s8_barWidth, 2, 30);
  evo46AnalyzerCfg.s8_gap = evo46ClampU8(evo46AnalyzerCfg.s8_gap, 0, 12);
  evo46AnalyzerCfg.s8_segments = evo46ClampU8(evo46AnalyzerCfg.s8_segments, 4, 40);
  evo46AnalyzerCfg.s8_segmentHeight = evo46ClampU8(evo46AnalyzerCfg.s8_segmentHeight, 1, 10);
  evo46AnalyzerCfg.s8_fill = evo46ClampU8(evo46AnalyzerCfg.s8_fill, 10, 100);
  evo46AnalyzerCfg.s8_smoothness = evo46ClampU8(evo46AnalyzerCfg.s8_smoothness, 0, 95);
  evo46AnalyzerCfg.s6_width = evo46ClampU8(evo46AnalyzerCfg.s6_width, 2, 20);
  evo46AnalyzerCfg.s6_gap = evo46ClampU8(evo46AnalyzerCfg.s6_gap, 0, 12);
  evo46AnalyzerCfg.s6_lines = evo46ClampU8(evo46AnalyzerCfg.s6_lines, 4, 40);
  evo46AnalyzerCfg.s6_smoothness = evo46ClampU8(evo46AnalyzerCfg.s6_smoothness, 0, 95);
  evo46AnalyzerCfg.s10_barWidth = evo46ClampU8(evo46AnalyzerCfg.s10_barWidth, 4, 22);
  evo46AnalyzerCfg.s10_gap = evo46ClampU8(evo46AnalyzerCfg.s10_gap, 0, 12);
  evo46AnalyzerCfg.s10_maxPeaks = evo46ClampU8(evo46AnalyzerCfg.s10_maxPeaks, 1, 5);
  evo46AnalyzerCfg.s10_peakHoldTime = evo46ClampU8(evo46AnalyzerCfg.s10_peakHoldTime, 0, 100);
  evo46AnalyzerCfg.s10_peakFloatSpeed = evo46ClampU8(evo46AnalyzerCfg.s10_peakFloatSpeed, 3, 15);
  evo46AnalyzerCfg.s10_peakFadeSteps = evo46ClampU8(evo46AnalyzerCfg.s10_peakFadeSteps, 5, 20);
  evo46AnalyzerCfg.s10_minHeight = evo46ClampU8(evo46AnalyzerCfg.s10_minHeight, 1, 8);
}

static void evo46AnalyzerApplyKV(String k, String v)
{
  k.trim(); v.trim();
  if (k.length() == 0) return;
  if (k == "peakHoldMs") evo46AnalyzerCfg.peakHoldTimeMs = (uint16_t)v.toInt();
  else if (k == "palette") evo46AnalyzerCfg.palette = (uint8_t)v.toInt();
  else if (k == "bg") evo46AnalyzerCfg.bg = (uint8_t)v.toInt();
  else if (k == "grid") evo46AnalyzerCfg.grid = (uint8_t)v.toInt();
  else if (k == "scale") evo46AnalyzerCfg.scale = (uint8_t)v.toInt();
  else if (k == "s5w") evo46AnalyzerCfg.s5_barWidth = (uint8_t)v.toInt();
  else if (k == "s5gap") evo46AnalyzerCfg.s5_gap = (uint8_t)v.toInt();
  else if (k == "s5seg") evo46AnalyzerCfg.s5_segments = (uint8_t)v.toInt();
  else if (k == "s5segh") evo46AnalyzerCfg.s5_segmentHeight = (uint8_t)v.toInt();
  else if (k == "s5fill") evo46AnalyzerCfg.s5_fill = (uint8_t)v.toInt();
  else if (k == "s5peaks") evo46AnalyzerCfg.s5_showPeaks = v.toInt() != 0;
  else if (k == "s5smooth") evo46AnalyzerCfg.s5_smoothness = (uint8_t)v.toInt();
  else if (k == "s5barBrightness") evo46AnalyzerCfg.s5_barBrightness = (uint8_t)v.toInt();
  else if (k == "s5peakBrightness") evo46AnalyzerCfg.s5_peakBrightness = (uint8_t)v.toInt();
  else if (k == "s8w") evo46AnalyzerCfg.s8_barWidth = (uint8_t)v.toInt();
  else if (k == "s8gap") evo46AnalyzerCfg.s8_gap = (uint8_t)v.toInt();
  else if (k == "s8seg") evo46AnalyzerCfg.s8_segments = (uint8_t)v.toInt();
  else if (k == "s8segh") evo46AnalyzerCfg.s8_segmentHeight = (uint8_t)v.toInt();
  else if (k == "s8fill") evo46AnalyzerCfg.s8_fill = (uint8_t)v.toInt();
  else if (k == "s8peaks") evo46AnalyzerCfg.s8_showPeaks = v.toInt() != 0;
  else if (k == "s8smooth") evo46AnalyzerCfg.s8_smoothness = (uint8_t)v.toInt();
  else if (k == "s8barBrightness") evo46AnalyzerCfg.s8_barBrightness = (uint8_t)v.toInt();
  else if (k == "s8peakBrightness") evo46AnalyzerCfg.s8_peakBrightness = (uint8_t)v.toInt();
  else if (k == "s6w") evo46AnalyzerCfg.s6_width = (uint8_t)v.toInt();
  else if (k == "s6gap") evo46AnalyzerCfg.s6_gap = (uint8_t)v.toInt();
  else if (k == "s6lines") evo46AnalyzerCfg.s6_lines = (uint8_t)v.toInt();
  else if (k == "s6peaks") evo46AnalyzerCfg.s6_showPeaks = v.toInt() != 0;
  else if (k == "s6smooth") evo46AnalyzerCfg.s6_smoothness = (uint8_t)v.toInt();
  else if (k == "s6barBrightness") evo46AnalyzerCfg.s6_barBrightness = (uint8_t)v.toInt();
  else if (k == "s6peakBrightness") evo46AnalyzerCfg.s6_peakBrightness = (uint8_t)v.toInt();
  else if (k == "s10barw") evo46AnalyzerCfg.s10_barWidth = (uint8_t)v.toInt();
  else if (k == "s10gap") evo46AnalyzerCfg.s10_gap = (uint8_t)v.toInt();
  else if (k == "s10maxp") evo46AnalyzerCfg.s10_maxPeaks = (uint8_t)v.toInt();
  else if (k == "s10hold") evo46AnalyzerCfg.s10_peakHoldTime = (uint8_t)v.toInt();
  else if (k == "s10speed") evo46AnalyzerCfg.s10_peakFloatSpeed = (uint8_t)v.toInt();
  else if (k == "s10fade") evo46AnalyzerCfg.s10_peakFadeSteps = (uint8_t)v.toInt();
  else if (k == "s10peakbr") evo46AnalyzerCfg.s10_peakBrightness = (uint8_t)v.toInt();
  else if (k == "s10barbr") evo46AnalyzerCfg.s10_barBrightness = (uint8_t)v.toInt();
  else if (k == "s10minh") evo46AnalyzerCfg.s10_minHeight = (uint8_t)v.toInt();
  evo46AnalyzerClamp();
}

static void evo46AnalyzerStyleLoadFromString(const String &content)
{
  int pos = 0;
  while (pos < (int)content.length()) {
    int nl = content.indexOf('\n', pos);
    if (nl < 0) nl = content.length();
    String line = content.substring(pos, nl);
    int eq = line.indexOf('=');
    if (eq > 0) evo46AnalyzerApplyKV(line.substring(0, eq), line.substring(eq + 1));
    pos = nl + 1;
  }
  evo46AnalyzerClamp();
}

static void evo46AnalyzerStyleSave()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  STORAGE.remove("/analyzer.cfg");
  File f = STORAGE.open("/analyzer.cfg", FILE_WRITE);
  if (!f) return;
  f.print(evo46AnalyzerCfgToString());
  f.close();
#endif
}

static void evo46AnalyzerStyleLoad()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File f = STORAGE.open("/analyzer.cfg", FILE_READ);
  if (!f) { evo46AnalyzerStyleSave(); return; }
  String txt = f.readString();
  f.close();
  evo46AnalyzerStyleLoadFromString(txt);
#endif
}

static void evo46SystemSave()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  STORAGE.remove("/evo46.cfg");
  File f = STORAGE.open("/evo46.cfg", FILE_WRITE);
  if (!f) return;
  f.println(String("vuDrive=") + String(evo46VuDrive));
  f.println(String("analyzerEnabled=") + String(evo46AnalyzerEnabled ? 1 : 0));
  f.println(String("analyzerStyles=") + String(evo46AnalyzerStyles));
  f.println(String("analyzerPreset=") + String(evo46AnalyzerPreset));
  f.println(String("btVolume=") + String(evo46BtVolume));
  for (int i = 1; i <= 14; i++) f.println(String("sdStyle") + String(i) + "=" + String(evo46SdPlayerStyleEnabled[i] ? 1 : 0));
  f.close();
#endif
}

static void evo46SystemLoad()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File f = STORAGE.open("/evo46.cfg", FILE_READ);
  if (!f) { evo46SystemSave(); return; }
  while (f.available()) {
    String line = f.readStringUntil('\n');
    line.trim();
    int eq = line.indexOf('=');
    if (eq < 0) continue;
    String k = line.substring(0, eq);
    String v = line.substring(eq + 1);
    if (k == "vuDrive") evo46VuDrive = evo46ClampU8(v.toInt(), 10, 200);
    else if (k == "analyzerEnabled") evo46AnalyzerEnabled = v.toInt() != 0;
    else if (k == "analyzerStyles") evo46AnalyzerStyles = evo46ClampU8(v.toInt(), 0, 2);
    else if (k == "analyzerPreset") evo46AnalyzerPreset = evo46ClampU8(v.toInt(), 0, 4);
    else if (k == "btVolume") evo46BtVolume = evo46ClampU8(v.toInt(), 0, 42);
    else if (k.startsWith("sdStyle")) {
      int idx = k.substring(7).toInt();
      if (idx >= 1 && idx <= 14) evo46SdPlayerStyleEnabled[idx] = v.toInt() != 0;
    }
  }
  f.close();
#endif
}

static void evo46WifiSave()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  STORAGE.remove("/wifi_multi.cfg");
  File f = STORAGE.open("/wifi_multi.cfg", FILE_WRITE);
  if (!f) return;
  for (uint8_t i = 0; i < evo46WifiCount; i++) {
    f.print(evo46WifiNetworks[i].ssid); f.print('\t'); f.println(evo46WifiNetworks[i].pass);
  }
  f.close();
#endif
}

static void evo46WifiLoad()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  evo46WifiCount = 0;
  File f = STORAGE.open("/wifi_multi.cfg", FILE_READ);
  if (!f) return;
  while (f.available() && evo46WifiCount < EVO46_MAX_WIFI_NETWORKS) {
    String line = f.readStringUntil('\n'); line.trim();
    if (line.length() == 0) continue;
    int tab = line.indexOf('\t');
    evo46WifiNetworks[evo46WifiCount].ssid = tab >= 0 ? line.substring(0, tab) : line;
    evo46WifiNetworks[evo46WifiCount].pass = tab >= 0 ? line.substring(tab + 1) : "";
    evo46WifiCount++;
  }
  f.close();
#endif
}

static void evo46AnalyzerApplyPreset(uint8_t preset)
{
  preset = constrain((int)preset, 0, 4);
  evo46AnalyzerPreset = preset;
  if (preset == 0) { // Klasyczny
    evo46AnalyzerCfg.palette = 4; evo46AnalyzerCfg.bg = 1; evo46AnalyzerCfg.grid = 1; evo46AnalyzerCfg.scale = 85;
    evo46AnalyzerCfg.s8_barWidth = 14; evo46AnalyzerCfg.s8_gap = 2; evo46AnalyzerCfg.s8_segments = 32; evo46AnalyzerCfg.s8_fill = 60;
  } else if (preset == 1) { // Nowoczesny
    evo46AnalyzerCfg.palette = 1; evo46AnalyzerCfg.bg = 0; evo46AnalyzerCfg.grid = 3; evo46AnalyzerCfg.scale = 75;
    evo46AnalyzerCfg.s5_barWidth = 8; evo46AnalyzerCfg.s5_gap = 3; evo46AnalyzerCfg.s8_barWidth = 14; evo46AnalyzerCfg.s8_gap = 4;
  } else if (preset == 2) { // Kompaktowy
    evo46AnalyzerCfg.palette = 0; evo46AnalyzerCfg.bg = 2; evo46AnalyzerCfg.grid = 0; evo46AnalyzerCfg.scale = 65;
    evo46AnalyzerCfg.s5_barWidth = 6; evo46AnalyzerCfg.s5_gap = 2; evo46AnalyzerCfg.s8_barWidth = 11; evo46AnalyzerCfg.s8_gap = 2;
  } else if (preset == 3) { // Retro
    evo46AnalyzerCfg.palette = 2; evo46AnalyzerCfg.bg = 4; evo46AnalyzerCfg.grid = 2; evo46AnalyzerCfg.scale = 70;
    evo46AnalyzerCfg.s6_width = 6; evo46AnalyzerCfg.s6_gap = 5; evo46AnalyzerCfg.s10_barWidth = 9;
  } else { // Floating Peaks / Custom
    evo46AnalyzerCfg.palette = 5; evo46AnalyzerCfg.bg = 0; evo46AnalyzerCfg.grid = 3; evo46AnalyzerCfg.scale = 70;
    evo46AnalyzerCfg.s10_barWidth = 10; evo46AnalyzerCfg.s10_gap = 4; evo46AnalyzerCfg.s10_maxPeaks = 3;
  }
  evo46AnalyzerClamp();
}

static String evo46HtmlInput(const String &label, const String &name, int value, int minv, int maxv)
{
  String s = "<div class='row'><label>" + label + "</label><input name='" + name + "' type='number' min='" + String(minv) + "' max='" + String(maxv) + "' value='" + String(value) + "'></div>";
  return s;
}

static String evo46HtmlCheck(const String &label, const String &name, bool checked)
{
  return String("<div class='row'><label>") + label + "</label><input name='" + name + "' type='checkbox' value='1' " + (checked ? "checked" : "") + "></div>";
}

static String evo46AnalyzerBuildHtmlPage()
{
  String s;
  s.reserve(12000);
  s += F("<!doctype html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Analyzer</title><style>body{font-family:Arial;margin:0;background:#f6f6f6;color:#111}main{max-width:980px;margin:auto;padding:18px}h2{margin-top:0}.card{background:white;border:1px solid #ddd;border-radius:12px;padding:14px;margin:12px 0;box-shadow:0 2px 8px #0001}.row{display:grid;grid-template-columns:230px 140px;gap:10px;align-items:center;margin:7px 0}.row input,.row select{padding:7px;border:1px solid #999;border-radius:4px}.btn{border:0;border-radius:8px;padding:10px 14px;margin:4px;background:#222;color:white;font-weight:bold}.green{background:#45ad4f}.blue{background:#2384df}.orange{background:#ff9800}.red{background:#d33}.preview{display:flex;gap:5px;margin-top:8px}.bar{width:30px;border-radius:5px}.small{font-size:.86rem;color:#333}@media(max-width:650px){.row{grid-template-columns:1fr}.btn{width:100%;}}</style></head><body><main>");
  s += F("<h2>Analizator – ustawienia stylów 5, 6, 8, 10</h2><p>Tu regulujesz wyglad slupkow, segmentow, peak hold, kolory i poziom sygnalu. To jest przeniesienie edycji z EVO3 MOD OST na kolorowe panele LovyanGFX / ILI9488.</p>");
  s += F("<div class='card'><h3>Ustawienia globalne</h3><form method='POST' action='/analyzerSave'>");
  s += evo46HtmlInput("Peak hold time (ms)", "peakHoldMs", evo46AnalyzerCfg.peakHoldTimeMs, 10, 2000);
  s += evo46HtmlInput("Poziom analizatora (%)", "scale", evo46AnalyzerCfg.scale, 30, 200);
  s += "<div class='row'><label>Paleta kolorow</label><select name='palette'>";
  const char* pals[] = {"EVO3 green/yellow/orange/red", "Blue/Cyan", "Retro amber", "Violet", "Classic VU 4 colors", "Neon"};
  for (int i=0;i<6;i++){ s += "<option value='"+String(i)+"'" + (evo46AnalyzerCfg.palette==i?" selected":"") + ">" + pals[i] + "</option>"; }
  s += "</select></div>";
  s += evo46HtmlInput("Tlo panelu 0-4", "bg", evo46AnalyzerCfg.bg, 0, 4);
  s += evo46HtmlInput("Siatka 0-4", "grid", evo46AnalyzerCfg.grid, 0, 4);
  s += F("<div class='preview'><div class='bar' style='height:25px;background:#20b050'></div><div class='bar' style='height:35px;background:#ffd21f'></div><div class='bar' style='height:45px;background:#ff8a00'></div><div class='bar' style='height:55px;background:#f03030'></div></div>");
  s += F("<h3>Presety</h3><button class='btn' formaction='/analyzerPreset?p=0'>Klasyczny</button><button class='btn blue' formaction='/analyzerPreset?p=1'>Nowoczesny</button><button class='btn green' formaction='/analyzerPreset?p=2'>Kompaktowy</button><button class='btn orange' formaction='/analyzerPreset?p=3'>Retro</button><button class='btn red' formaction='/analyzerPreset?p=4'>Floating Peaks</button></div>");

  s += F("<div class='card'><h3>Styl 5 - slupkowy FFT / VU</h3>");
  s += evo46HtmlInput("bar width", "s5w", evo46AnalyzerCfg.s5_barWidth, 2, 24);
  s += evo46HtmlInput("bar gap", "s5gap", evo46AnalyzerCfg.s5_gap, 0, 10);
  s += evo46HtmlInput("segments", "s5seg", evo46AnalyzerCfg.s5_segments, 4, 40);
  s += evo46HtmlInput("segment height", "s5segh", evo46AnalyzerCfg.s5_segmentHeight, 1, 10);
  s += evo46HtmlInput("fill (0..100)", "s5fill", evo46AnalyzerCfg.s5_fill, 10, 100);
  s += evo46HtmlCheck("show peaks", "s5peaks", evo46AnalyzerCfg.s5_showPeaks);
  s += evo46HtmlInput("smoothness", "s5smooth", evo46AnalyzerCfg.s5_smoothness, 0, 95);
  s += evo46HtmlInput("bar brightness", "s5barBrightness", evo46AnalyzerCfg.s5_barBrightness, 0, 255);
  s += evo46HtmlInput("peak brightness", "s5peakBrightness", evo46AnalyzerCfg.s5_peakBrightness, 0, 255);
  s += F("</div><div class='card'><h3>Styl 8 - slupkowy z segmentami</h3>");
  s += evo46HtmlInput("bar width", "s8w", evo46AnalyzerCfg.s8_barWidth, 2, 30);
  s += evo46HtmlInput("bar gap", "s8gap", evo46AnalyzerCfg.s8_gap, 0, 12);
  s += evo46HtmlInput("segments", "s8seg", evo46AnalyzerCfg.s8_segments, 4, 40);
  s += evo46HtmlInput("segment height", "s8segh", evo46AnalyzerCfg.s8_segmentHeight, 1, 10);
  s += evo46HtmlInput("fill (0..100)", "s8fill", evo46AnalyzerCfg.s8_fill, 10, 100);
  s += evo46HtmlCheck("show peaks", "s8peaks", evo46AnalyzerCfg.s8_showPeaks);
  s += evo46HtmlInput("smoothness", "s8smooth", evo46AnalyzerCfg.s8_smoothness, 0, 95);
  s += evo46HtmlInput("bar brightness", "s8barBrightness", evo46AnalyzerCfg.s8_barBrightness, 0, 255);
  s += evo46HtmlInput("peak brightness", "s8peakBrightness", evo46AnalyzerCfg.s8_peakBrightness, 0, 255);
  s += F("</div><div class='card'><h3>Styl 6 - cienkie kreski + peak</h3>");
  s += evo46HtmlInput("line/bar width", "s6w", evo46AnalyzerCfg.s6_width, 2, 20);
  s += evo46HtmlInput("gap", "s6gap", evo46AnalyzerCfg.s6_gap, 0, 12);
  s += evo46HtmlInput("lines", "s6lines", evo46AnalyzerCfg.s6_lines, 4, 40);
  s += evo46HtmlCheck("show peaks", "s6peaks", evo46AnalyzerCfg.s6_showPeaks);
  s += evo46HtmlInput("smoothness", "s6smooth", evo46AnalyzerCfg.s6_smoothness, 0, 95);
  s += evo46HtmlInput("bar brightness", "s6barBrightness", evo46AnalyzerCfg.s6_barBrightness, 0, 255);
  s += evo46HtmlInput("peak brightness", "s6peakBrightness", evo46AnalyzerCfg.s6_peakBrightness, 0, 255);
  s += F("</div><div class='card'><h3>Styl 10 - Floating Peaks</h3>");
  s += evo46HtmlInput("bar width (px)", "s10barw", evo46AnalyzerCfg.s10_barWidth, 4, 22);
  s += evo46HtmlInput("bar gap", "s10gap", evo46AnalyzerCfg.s10_gap, 0, 12);
  s += evo46HtmlInput("max flying peaks", "s10maxp", evo46AnalyzerCfg.s10_maxPeaks, 1, 5);
  s += evo46HtmlInput("peak hold time (frames)", "s10hold", evo46AnalyzerCfg.s10_peakHoldTime, 0, 100);
  s += evo46HtmlInput("float speed (px/frame)", "s10speed", evo46AnalyzerCfg.s10_peakFloatSpeed, 3, 15);
  s += evo46HtmlInput("fade steps", "s10fade", evo46AnalyzerCfg.s10_peakFadeSteps, 5, 20);
  s += evo46HtmlInput("min height (px)", "s10minh", evo46AnalyzerCfg.s10_minHeight, 1, 8);
  s += evo46HtmlInput("bar brightness", "s10barbr", evo46AnalyzerCfg.s10_barBrightness, 0, 255);
  s += evo46HtmlInput("peak brightness", "s10peakbr", evo46AnalyzerCfg.s10_peakBrightness, 100, 255);
  s += F("</div><div class='card'><button class='btn green' type='submit'>Zapisz ustawienia</button><button class='btn blue' formaction='/analyzerApply'>Zastosuj bez zapisu</button><button class='btn' formaction='/mode?m=5'>Podglad Style 5</button><button class='btn' formaction='/mode?m=8'>Podglad Style 8</button><p><a href='/analyzerCfg'>Pobierz analyzer.cfg</a> | <a href='/menu'>Wroc do menu</a></p></div></form>");
  s += F("</main></body></html>");
  return s;
}

static void evo46AnalyzerParseRequest(AsyncWebServerRequest *request)
{
  const char* keys[] = {"peakHoldMs","palette","bg","grid","scale","s5w","s5gap","s5seg","s5segh","s5fill","s5smooth","s5barBrightness","s5peakBrightness","s8w","s8gap","s8seg","s8segh","s8fill","s8smooth","s8barBrightness","s8peakBrightness","s6w","s6gap","s6lines","s6smooth","s6barBrightness","s6peakBrightness","s10barw","s10gap","s10maxp","s10hold","s10speed","s10fade","s10minh","s10barbr","s10peakbr"};
  for (uint8_t i = 0; i < sizeof(keys)/sizeof(keys[0]); i++) {
    if (request->hasParam(keys[i], true)) evo46AnalyzerApplyKV(keys[i], request->getParam(keys[i], true)->value());
  }
  evo46AnalyzerCfg.s5_showPeaks = request->hasParam("s5peaks", true);
  evo46AnalyzerCfg.s8_showPeaks = request->hasParam("s8peaks", true);
  evo46AnalyzerCfg.s6_showPeaks = request->hasParam("s6peaks", true);
  evo46AnalyzerPreset = 4;
  evo46AnalyzerClamp();
}

static String evo43JsonEscape(const String &in)
{
  String out;
  out.reserve(in.length() + 8);
  for (uint16_t i = 0; i < in.length(); i++)
  {
    char c = in[i];
    if (c == '\\') out += "\\\\";
    else if (c == '"') out += "\\\"";
    else if (c == '\n' || c == '\r') out += ' ';
    else out += c;
  }
  return out;
}

static String evo43HumanSize(uint32_t bytes)
{
  if (bytes < 1024) return String(bytes) + " B";
  if (bytes < 1024UL * 1024UL) return String(bytes / 1024.0f, 1) + " KB";
  return String(bytes / 1048576.0f, 2) + " MB";
}

static String evo43CleanFileName(String s)
{
  s = tftCleanText(s);
  if (s.length() == 0) s = "EVO_RADIO";
  for (uint16_t i = 0; i < s.length(); i++)
  {
    char c = s[i];
    bool ok = (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_' || c == '-';
    if (!ok) s.setCharAt(i, '_');
  }
  if (s.length() > 30) s = s.substring(0, 30);
  return s;
}

static bool evo43IsAudioFile(const String &n)
{
  String s = n;
  s.toLowerCase();
  return s.endsWith(".mp3") || s.endsWith(".aac") || s.endsWith(".m4a") || s.endsWith(".wav") || s.endsWith(".flac") || s.endsWith(".ogg") || s.endsWith(".opus");
}

static String evo43BaseName(String path)
{
  path.replace("\\", "/");
  int slash = path.lastIndexOf('/');
  if (slash >= 0 && slash < (int)path.length() - 1) return path.substring(slash + 1);
  if (path == "/") return "/";
  return path;
}

static String evo43NormalizePath(String path)
{
  path.trim();
  path.replace("\\", "/");
  if (!path.startsWith("/")) path = "/" + path;
  while (path.indexOf("//") >= 0) path.replace("//", "/");
  if (path.length() > 1 && path.endsWith("/")) path.remove(path.length() - 1);
  return path;
}

static void evo43MarkFilesDirty()
{
  evo43FilesDirty = true;
}

static void evo43ScanCurrentDir()
{
  if (!evo43FilesDirty) return;
  evo43FilesDirty = false;
  evo43TrackCount = 0;
  evo43SelectedTrack = 0;
  evo43CurrentDir = evo43NormalizePath(evo43CurrentDir);
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File dir = STORAGE.open(evo43CurrentDir);
  if (!dir || !dir.isDirectory())
  {
    evo43CurrentDir = "/";
    dir = STORAGE.open("/");
  }
  if (!dir || !dir.isDirectory())
  {
    evo43LastAction = "STORAGE OPEN ERROR";
    return;
  }
  File f = dir.openNextFile();
  while (f && evo43TrackCount < EVO43_MAX_TRACKS)
  {
    String p = String(f.name());
    p = evo43NormalizePath(p);
    String n = evo43BaseName(p);
    bool isDir = f.isDirectory();
    if (isDir || evo43IsAudioFile(n))
    {
      evo43Tracks[evo43TrackCount].path = p;
      evo43Tracks[evo43TrackCount].name = n;
      evo43Tracks[evo43TrackCount].isDir = isDir;
      evo43TrackCount++;
    }
    f.close();
    f = dir.openNextFile();
  }
  dir.close();
  evo43LastAction = String("FILES ") + String(evo43TrackCount);
#else
  evo43LastAction = "STORAGE DISABLED";
#endif
}

static void evo43GoParentDir()
{
  if (evo43CurrentDir == "/") return;
  int slash = evo43CurrentDir.lastIndexOf('/');
  if (slash <= 0) evo43CurrentDir = "/";
  else evo43CurrentDir = evo43CurrentDir.substring(0, slash);
  evo43MarkFilesDirty();
}

static void evo43SelectNextTrack()
{
  evo43ScanCurrentDir();
  if (evo43TrackCount == 0) return;
  evo43SelectedTrack++;
  if (evo43SelectedTrack >= evo43TrackCount) evo43SelectedTrack = 0;
}

static void evo43SelectPrevTrack()
{
  evo43ScanCurrentDir();
  if (evo43TrackCount == 0) return;
  if (evo43SelectedTrack == 0) evo43SelectedTrack = evo43TrackCount - 1;
  else evo43SelectedTrack--;
}

static bool evo43PlaySelectedTrack()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  evo43ScanCurrentDir();
  if (evo43TrackCount == 0)
  {
    evo43LastAction = "NO AUDIO FILES";
    return false;
  }
  if (evo43SelectedTrack >= evo43TrackCount) evo43SelectedTrack = 0;
  Evo43TrackItem &it = evo43Tracks[evo43SelectedTrack];
  if (it.isDir)
  {
    evo43CurrentDir = evo43NormalizePath(it.path);
    evo43MarkFilesDirty();
    evo43LastAction = "DIR " + evo43BaseName(evo43CurrentDir);
    return true;
  }
  audio.stopSong();
  delay(20);
  bool ok = audio.connecttoFS(STORAGE, it.path.c_str());
  evo43SdPlaying = ok;
  evo43SdPaused = false;
  evo43CurrentTrack = it.name;
  stationStringWeb = it.name;
  stationStringScroll = it.name + "    ";
  evo43LastAction = ok ? String("PLAY ") + it.name : String("PLAY ERROR");
  return ok;
#else
  evo43LastAction = "STORAGE DISABLED";
  return false;
#endif
}

static void evo43SdStop(bool backToRadio)
{
  audio.stopSong();
  evo43SdPlaying = false;
  evo43SdPaused = false;
  evo43LastAction = backToRadio ? "BACK RADIO" : "STOP";
  if (backToRadio) changeStation();
}

static void evo43SdPauseResume()
{
  if (!evo43SdPlaying)
  {
    evo43PlaySelectedTrack();
    return;
  }
  bool ok = audio.pauseResume();
  evo43SdPaused = !evo43SdPaused;
  evo43LastAction = ok ? (evo43SdPaused ? "PAUSE" : "RESUME") : "PAUSE TOGGLE";
}

static String evo43CurrentStationUrl()
{
  if (urlPlaying && url2play.length() > 0) return url2play;
  if (station_nr < 1 || station_nr > stationsCount || psramData == nullptr) return "";
  char station[STATION_NAME_LENGTH + 1];
  memset(station, 0, sizeof(station));
  int length = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1)];
  length = constrain(length, 0, STATION_NAME_LENGTH);
  for (int j = 0; j < length; j++) station[j] = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1) + 1 + j];
  String line = String(station);
  int urlStart = line.indexOf("http");
  if (urlStart < 0) return "";
  String u = line.substring(urlStart);
  u.trim();
  return u;
}

static bool evo43SplitHttpUrl(const String &url, String &host, uint16_t &port, String &path)
{
  String u = url;
  u.trim();
  if (u.startsWith("https://"))
  {
    evo43LastAction = "REC HTTPS NOT SUPPORTED";
    return false;
  }
  if (!u.startsWith("http://")) return false;
  u.remove(0, 7);
  int slash = u.indexOf('/');
  String hp = slash >= 0 ? u.substring(0, slash) : u;
  path = slash >= 0 ? u.substring(slash) : "/";
  int colon = hp.indexOf(':');
  if (colon >= 0)
  {
    host = hp.substring(0, colon);
    port = (uint16_t)hp.substring(colon + 1).toInt();
    if (port == 0) port = 80;
  }
  else
  {
    host = hp;
    port = 80;
  }
  return host.length() > 0;
}

static String evo43MakeRecordFileName(const String &station)
{
  struct tm ti;
  char tbuf[24];
  if (getLocalTime(&ti, 0)) snprintf(tbuf, sizeof(tbuf), "%04d%02d%02d_%02d%02d%02d", ti.tm_year + 1900, ti.tm_mon + 1, ti.tm_mday, ti.tm_hour, ti.tm_min, ti.tm_sec);
  else snprintf(tbuf, sizeof(tbuf), "%lu", (unsigned long)(millis() / 1000));
  return String("/RECORDINGS/REC_") + String(tbuf) + "_" + evo43CleanFileName(station) + ".mp3";
}

static bool evo43RecorderStart()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  if (evo43RecActive) return true;
  String url = evo43CurrentStationUrl();
  if (url.length() == 0)
  {
    evo43LastAction = "NO STATION URL";
    return false;
  }
  String host, path;
  uint16_t port = 80;
  if (!evo43SplitHttpUrl(url, host, port, path))
  {
    evo43LastAction = "REC URL ERROR";
    return false;
  }
  if (!STORAGE.exists("/RECORDINGS")) STORAGE.mkdir("/RECORDINGS");
  evo43RecStation = tftCleanText(stationName.length() ? stationName : tftStationName());
  evo43RecFileName = evo43MakeRecordFileName(evo43RecStation);
  evo43RecFile = STORAGE.open(evo43RecFileName, FILE_WRITE);
  if (!evo43RecFile)
  {
    evo43LastAction = "REC FILE ERROR";
    return false;
  }
  if (!evo43RecClient.connect(host.c_str(), port))
  {
    evo43RecFile.close();
    evo43LastAction = "REC CONNECT ERROR";
    return false;
  }
  evo43RecClient.print(String("GET ") + path + " HTTP/1.1\r\nHost: " + host + "\r\nUser-Agent: EVO3-MOD-KOLOR\r\nIcy-MetaData: 0\r\nConnection: close\r\n\r\n");
  evo43RecActive = true;
  evo43RecHeadersDone = false;
  evo43RecHeaderBuffer = "";
  evo43RecStartMs = millis();
  evo43RecLastByteMs = millis();
  evo43RecBytes = 0;
  evo43LastAction = "REC START";
  return true;
#else
  evo43LastAction = "STORAGE DISABLED";
  return false;
#endif
}

static void evo43RecorderStop()
{
  if (evo43RecClient.connected()) evo43RecClient.stop();
  if (evo43RecFile) evo43RecFile.close();
  evo43RecActive = false;
  evo43RecHeadersDone = false;
  evo43LastAction = "REC STOP " + evo43HumanSize(evo43RecBytes);
}

static void evo43RecorderLoop()
{
  if (!evo43RecActive) return;
  if (!evo43RecClient.connected() && evo43RecClient.available() == 0)
  {
    evo43RecorderStop();
    evo43LastAction = "REC END " + evo43HumanSize(evo43RecBytes);
    return;
  }
  while (evo43RecClient.available() > 0)
  {
    if (!evo43RecHeadersDone)
    {
      char c = (char)evo43RecClient.read();
      evo43RecHeaderBuffer += c;
      if (evo43RecHeaderBuffer.endsWith("\r\n\r\n"))
      {
        evo43RecHeadersDone = true;
        evo43RecHeaderBuffer = "";
      }
      if (evo43RecHeaderBuffer.length() > 4096)
      {
        evo43RecorderStop();
        evo43LastAction = "REC HEADER ERROR";
        return;
      }
    }
    else
    {
      int n = evo43RecClient.read(evo43RecBuffer, min((int)sizeof(evo43RecBuffer), evo43RecClient.available()));
      if (n > 0 && evo43RecFile)
      {
        evo43RecFile.write(evo43RecBuffer, n);
        evo43RecBytes += n;
        evo43RecLastByteMs = millis();
      }
    }
    audio.loop();
  }
  if ((uint32_t)(millis() - evo43RecLastByteMs) > 20000UL)
  {
    evo43RecorderStop();
    evo43LastAction = "REC TIMEOUT";
  }
}

static void evo43ApplyEq16ToTone()
{
  int low = 0, mid = 0, high = 0;
  for (int i = 0; i < 5; i++) low += evo43Eq16[i];
  for (int i = 5; i < 11; i++) mid += evo43Eq16[i];
  for (int i = 11; i < 16; i++) high += evo43Eq16[i];
  toneLowValue = constrain(low / 5, -40, 6);
  toneMidValue = constrain(mid / 6, -40, 6);
  toneHiValue = constrain(high / 5, -40, 6);
  audio.setTone(toneLowValue, toneMidValue, toneHiValue);
  evo43LastAction = "EQ16 APPLY -> 3BAND";
}

static void evo43Eq16Reset()
{
  for (int i = 0; i < 16; i++) evo43Eq16[i] = 0;
  evo43ApplyEq16ToTone();
}

static void evo43Eq16SetBand(uint8_t band, int8_t value)
{
  if (band >= 16) return;
  evo43Eq16[band] = constrain(value, -12, 12);
  evo43ApplyEq16ToTone();
}


// -------------------------------------------------------------------------------------------------
// V46 - KOLOROWE PANELE EVO3 MOD OST PRZEPISANE NA LovyanGFX
// Wszystkie panele rysuja w bazowej siatce 320x240, a warstwa V7 skaluje obraz na ILI9488.
// -------------------------------------------------------------------------------------------------

static uint16_t evo43ColorByPct(int pct)
{
  return evo46PaletteColor(evo46AnalyzerCfg.palette, pct);
}

static uint16_t evo43DimColorByPct(int pct)
{
  pct = constrain(pct, 0, 100);
  if (pct < 35) return 0x0320;
  if (pct < 62) return 0x4200;
  if (pct < 82) return 0x3200;
  return 0x3000;
}

static uint8_t evo43VuL8()
{
  return (uint8_t)constrain(displayVuL, 0, 255);
}

static uint8_t evo43VuR8()
{
  return (uint8_t)constrain(displayVuR, 0, 255);
}

static int evo43VuPctL()
{
  return constrain(tftVuPct(evo43VuL8()), 0, 100);
}

static int evo43VuPctR()
{
  return constrain(tftVuPct(evo43VuR8()), 0, 100);
}

static int evo43VuPctMix()
{
  return max(evo43VuPctL(), evo43VuPctR());
}

static void evo43DrawCard(int x, int y, int w, int h, const String &title)
{
  gfx.tftFillRoundRect(x, y, w, h, 10, 0x0005);
  gfx.tftDrawRoundRect(x, y, w, h, 10, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(x + 2, y + 2, w - 4, h - 4, 8, 0x01CF);
  gfx.tftFillRoundRect(x + 4, y + 4, w - 8, 25, 7, 0x0011);
  gfx.tftText(x + 10, y + 9, tftClipText(title, 34).c_str(), 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftDrawFastHLine(x + 8, y + 34, w - 16, EVO_TFT_NATIVE_CYAN);
}

static void evo43DrawBadge(int x, int y, const String &txt, uint16_t color)
{
  int w = gfx.tftTextWidth(txt.c_str(), 1) + 14;
  gfx.tftFillRoundRect(x, y, w, 18, 5, 0x0000);
  gfx.tftDrawRoundRect(x, y, w, 18, 5, color);
  gfx.tftText(x + 7, y + 5, txt.c_str(), 1, color);
}

static void evo43DrawGlowLine(int x, int y, int w, uint16_t color)
{
  gfx.tftDrawFastHLine(x, y - 1, w, evo43DimColorByPct(50));
  gfx.tftDrawFastHLine(x, y, w, color);
  gfx.tftDrawFastHLine(x, y + 1, w, evo43DimColorByPct(70));
}

static void evo43DrawMiniVU(int x, int y, int w, int h)
{
  int l = evo43VuPctL();
  int r = evo43VuPctR();
  gfx.tftDrawRoundRect(x, y, w, h, 5, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(x + 5, y + 5, "L", 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(x + 5, y + 20, "R", 1, EVO_TFT_NATIVE_MUTED);
  int maxW = w - 28;
  for (int i = 0; i < 10; i++)
  {
    int px = x + 18 + i * (maxW / 10);
    uint16_t lc = (i * 10 <= l) ? evo43ColorByPct(i * 10) : 0x2104;
    uint16_t rc = (i * 10 <= r) ? evo43ColorByPct(i * 10) : 0x2104;
    gfx.tftFillRoundRect(px, y + 6, max(2, maxW / 10 - 2), 7, 2, lc);
    gfx.tftFillRoundRect(px, y + 21, max(2, maxW / 10 - 2), 7, 2, rc);
  }
}

static uint8_t evo43LevelForBand(uint8_t band)
{
  int base = evo43VuPctMix();
  int phase = (int)(millis() / 37 + band * 31);
  int wave = (int)((sin(phase * 0.07f) + 1.0f) * 38.0f);
  int side = (band % 2) ? evo43VuPctL() : evo43VuPctR();
  int shaped = (base * 45 + side * 35 + wave * 20) / 100;
  shaped += (band % 5) * 3;
  return (uint8_t)constrain(shaped, 2, 100);
}


static uint8_t evo46SmoothBandValue(uint8_t band, uint8_t raw, uint8_t smoothness)
{
  band &= 31;
  raw = constrain(raw, 0, 100);
  smoothness = constrain(smoothness, 0, 95);
  uint8_t cur = evo46BandSmooth[band];
  int next = ((int)cur * smoothness + (int)raw * (100 - smoothness)) / 100;
  if (raw > cur && next < cur + 1) next = cur + 1;
  evo46BandSmooth[band] = (uint8_t)constrain(next, 0, 100);
  return evo46BandSmooth[band];
}

static void evo46UpdatePeak(uint8_t band, uint8_t level, bool show)
{
  band &= 31;
  uint32_t now = millis();
  if (!show) { evo46BandPeak[band] = 0; return; }
  if (level >= evo46BandPeak[band]) {
    evo46BandPeak[band] = level;
    evo46BandPeakMs[band] = now;
  } else if ((uint32_t)(now - evo46BandPeakMs[band]) > evo46AnalyzerCfg.peakHoldTimeMs) {
    if (evo46BandPeak[band] > 1) evo46BandPeak[band]--;
    else evo46BandPeak[band] = 0;
  }
}

static void evo46DrawAnalyzerGrid(int x0, int topY, int w, int h)
{
  uint16_t gc = evo46GridColor();
  for (int y = topY; y <= topY + h; y += h / 4) gfx.tftDrawFastHLine(x0, y, w, gc);
  for (int x = x0; x <= x0 + w; x += max(16, w / 8)) gfx.tftDrawFastVLine(x, topY, h, gc);
}

static void evo43DrawSpectrumBars(int x0, int baseY, int count, int bw, int gap, int maxH)
{
  int totalW = count * bw + (count - 1) * gap;
  gfx.tftFillRoundRect(x0 - 4, baseY - maxH - 6, totalW + 8, maxH + 12, 6, evo46BgColor());
  evo46DrawAnalyzerGrid(x0 - 2, baseY - maxH, totalW + 4, maxH);
  for (int i = 0; i < count; i++)
  {
    uint8_t raw = evo43LevelForBand(i);
    raw = constrain(((int)raw * (int)evo46AnalyzerCfg.scale) / 100, 0, 100);
    uint8_t lvl = evo46SmoothBandValue(i, raw, evo46AnalyzerCfg.s5_smoothness);
    evo46UpdatePeak(i, lvl, evo46AnalyzerCfg.s5_showPeaks);
    int h = map(lvl, 0, 100, 2, maxH);
    int x = x0 + i * (bw + gap);
    gfx.tftFillRoundRect(x, baseY - maxH, bw, maxH, 2, 0x0000);
    int segments = max(1, (int)evo46AnalyzerCfg.s5_segments);
    int step = max(2, maxH / segments);
    int segH = max(1, min((int)evo46AnalyzerCfg.s5_segmentHeight, step));
    for (int sy = 0; sy < h; sy += step)
    {
      int pct = map(sy, 0, maxH, 0, 100);
      uint16_t c = evo46PaletteColor(evo46AnalyzerCfg.palette, pct);
      if (evo46AnalyzerCfg.s5_barBrightness < 180) c = evo46Dim(c);
      int filledW = max(1, (bw * (int)evo46AnalyzerCfg.s5_fill) / 100);
      gfx.tftFillRoundRect(x, baseY - sy - segH, filledW, segH, 1, c);
    }
    if (evo46AnalyzerCfg.s5_showPeaks && evo46AnalyzerCfg.s5_peakBrightness > 0) {
      int peakY = baseY - map(evo46BandPeak[i & 31], 0, 100, 0, maxH) - 4;
      if (peakY < baseY - maxH) peakY = baseY - maxH;
      gfx.tftDrawFastHLine(x, peakY, bw, EVO_TFT_NATIVE_RED);
    }
  }
}

static void evo43DrawSpectrumSegments(int x0, int baseY, int count, int bw, int gap, int maxH)
{
  int totalW = count * bw + (count - 1) * gap;
  gfx.tftFillRoundRect(x0 - 4, baseY - maxH - 6, totalW + 8, maxH + 12, 6, evo46BgColor());
  evo46DrawAnalyzerGrid(x0 - 2, baseY - maxH, totalW + 4, maxH);
  for (int i = 0; i < count; i++)
  {
    uint8_t raw = evo43LevelForBand(i);
    raw = constrain(((int)raw * (int)evo46AnalyzerCfg.scale) / 100, 0, 100);
    uint8_t lvl = evo46SmoothBandValue(i, raw, evo46AnalyzerCfg.s6_smoothness);
    evo46UpdatePeak(i, lvl, evo46AnalyzerCfg.s6_showPeaks);
    int h = map(lvl, 0, 100, 2, maxH);
    int x = x0 + i * (bw + gap);
    int lines = max(4, (int)evo46AnalyzerCfg.s6_lines);
    int step = max(2, maxH / lines);
    for (int s = 0; s < lines; s++)
    {
      int y = baseY - s * step - 3;
      int pct = map(s * step, 0, maxH, 0, 100);
      uint16_t c = ((s * step) <= h) ? evo46PaletteColor(evo46AnalyzerCfg.palette, pct) : 0x1082;
      gfx.tftFillRoundRect(x, y, bw, 2, 1, c);
    }
    if (evo46AnalyzerCfg.s6_showPeaks && evo46AnalyzerCfg.s6_peakBrightness > 0) {
      int peakY = baseY - map(evo46BandPeak[i & 31], 0, 100, 0, maxH) - 4;
      if (peakY < baseY - maxH) peakY = baseY - maxH;
      gfx.tftDrawFastHLine(x, peakY, bw, EVO_TFT_NATIVE_RED);
    }
  }
}

static void evo46DrawSpectrumWideStyle8(int x0, int baseY, int count, int bw, int gap, int maxH)
{
  int totalW = count * bw + (count - 1) * gap;
  gfx.tftFillRoundRect(x0 - 4, baseY - maxH - 6, totalW + 8, maxH + 12, 6, evo46BgColor());
  evo46DrawAnalyzerGrid(x0 - 2, baseY - maxH, totalW + 4, maxH);
  for (int i = 0; i < count; i++)
  {
    uint8_t raw = evo43LevelForBand(i);
    raw = constrain(((int)raw * (int)evo46AnalyzerCfg.scale) / 100, 0, 100);
    uint8_t lvl = evo46SmoothBandValue(i, raw, evo46AnalyzerCfg.s8_smoothness);
    evo46UpdatePeak(i, lvl, evo46AnalyzerCfg.s8_showPeaks);
    int h = map(lvl, 0, 100, 2, maxH);
    int x = x0 + i * (bw + gap);
    int segments = max(4, (int)evo46AnalyzerCfg.s8_segments);
    int step = max(2, maxH / segments);
    int segH = max(1, min((int)evo46AnalyzerCfg.s8_segmentHeight, step));
    for (int sy = 0; sy < maxH; sy += step)
    {
      int pct = map(sy, 0, maxH, 0, 100);
      uint16_t c = (sy <= h) ? evo46PaletteColor(evo46AnalyzerCfg.palette, pct) : 0x1082;
      if (sy > h) c = evo46Dim(c);
      int filledW = max(1, (bw * (int)evo46AnalyzerCfg.s8_fill) / 100);
      gfx.tftFillRoundRect(x, baseY - sy - segH, filledW, segH, 1, c);
    }
    if (evo46AnalyzerCfg.s8_showPeaks && evo46AnalyzerCfg.s8_peakBrightness > 0) {
      int peakY = baseY - map(evo46BandPeak[i & 31], 0, 100, 0, maxH) - 4;
      if (peakY < baseY - maxH) peakY = baseY - maxH;
      gfx.tftDrawFastHLine(x, peakY, bw, EVO_TFT_NATIVE_RED);
    }
  }
}

static void evo43DrawFloatingPeaks(int x0, int baseY, int count, int bw, int gap, int maxH)
{
  int totalW = count * bw + (count - 1) * gap;
  gfx.tftFillRoundRect(x0 - 4, baseY - maxH - 6, totalW + 8, maxH + 12, 6, evo46BgColor());
  evo46DrawAnalyzerGrid(x0 - 2, baseY - maxH, totalW + 4, maxH);
  for (int i = 0; i < count; i++)
  {
    uint8_t raw = evo43LevelForBand(i);
    raw = constrain(((int)raw * (int)evo46AnalyzerCfg.scale) / 100, 0, 100);
    uint8_t lvl = evo46SmoothBandValue(i, raw, 35);
    int h = map(lvl, 0, 100, evo46AnalyzerCfg.s10_minHeight, maxH - 8);
    int x = x0 + i * (bw + gap);
    for (int sy = 0; sy < h; sy += 6)
    {
      uint16_t c = evo46PaletteColor(evo46AnalyzerCfg.palette, map(sy, 0, maxH, 0, 100));
      if (evo46AnalyzerCfg.s10_barBrightness < 180) c = evo46Dim(c);
      gfx.tftFillRoundRect(x, baseY - sy - 4, bw, 4, 2, c);
    }
    for (int k = 0; k < evo46AnalyzerCfg.s10_maxPeaks; k++) {
      int floatOffset = ((millis() / max(1, (int)evo46AnalyzerCfg.s10_peakFloatSpeed * 8)) + i * 7 + k * 13) % maxH;
      int peakY = baseY - h - 4 - floatOffset / (k + 1);
      if (peakY < baseY - maxH) peakY = baseY - maxH + (k * 4);
      gfx.tftFillRoundRect(x - 1, peakY, bw + 2, 3, 1, EVO_TFT_NATIVE_RED);
    }
  }
}

static void evo43DrawFourColorAnalogVu(int cx, int cy, int value, int peakValue, const char *label)
{
  int pct = constrain(tftVuPct(value), 0, 100);
  int ppct = constrain(tftVuPct(peakValue), 0, 100);
  int top = cy - 90;
  int frameW = 134;
  int frameH = 104;
  gfx.tftFillRoundRect(cx - frameW / 2, top, frameW, frameH, 8, 0x0841);
  gfx.tftDrawRoundRect(cx - frameW / 2, top, frameW, frameH, 8, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawRoundRect(cx - frameW / 2 + 2, top + 2, frameW - 4, frameH - 4, 7, 0xBDF7);
  gfx.tftText(cx - 7, top + 10, label, 1, EVO_TFT_NATIVE_YELLOW);
  int pivotY = top + 82;
  int radius = 72;
  for (int t = 0; t <= 100; t += 5)
  {
    float a = (-145.0f + t * 1.10f) * 0.0174533f;
    int x1 = cx + cos(a) * (radius - 12);
    int y1 = pivotY + sin(a) * (radius - 12);
    int x2 = cx + cos(a) * radius;
    int y2 = pivotY + sin(a) * radius;
    uint16_t c = (t <= pct) ? evo43ColorByPct(t) : 0x9CF3;
    gfx.tftDrawLine(x1, y1, x2, y2, c);
    if ((t % 20) == 0) gfx.tftDrawLine(x1 + 1, y1, x2 + 1, y2, c);
  }
  float na = (-145.0f + pct * 1.10f) * 0.0174533f;
  int nx = cx + cos(na) * (radius - 18);
  int ny = pivotY + sin(na) * (radius - 18);
  gfx.tftDrawLine(cx, pivotY, nx, ny, EVO_TFT_NATIVE_RED);
  gfx.tftDrawLine(cx + 1, pivotY, nx + 1, ny, EVO_TFT_NATIVE_RED);
  gfx.tftFillRoundRect(cx - 5, pivotY - 4, 10, 8, 3, EVO_TFT_NATIVE_TEXT);
  int px = cx - frameW / 2 + 12 + map(ppct, 0, 100, 0, frameW - 24);
  gfx.tftDrawFastVLine(px, top + 22, 16, EVO_TFT_NATIVE_RED);
  tftTextCenter(cx - frameW / 2, top + 88, frameW, String(pct) + "%", 1, EVO_TFT_NATIVE_TEXT);
}

static void evo43DrawModeRibbon(const String &left, const String &mid, const String &right)
{
  gfx.tftFillRoundRect(12, 203, 296, 25, 7, 0x0008);
  gfx.tftDrawRoundRect(12, 203, 296, 25, 7, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(22, 211, tftClipText(left, 13).c_str(), 1, EVO_TFT_NATIVE_GREEN);
  tftTextCenter(92, 211, 136, tftClipText(mid, 17), 1, EVO_TFT_NATIVE_YELLOW);
  tftTextRight(298, 211, tftClipText(right, 13), 1, EVO_TFT_NATIVE_ORANGE);
}

static void evo43DrawTopMiniStatus(const String &modeName)
{
  // ================================================================
  // APMS TOP MINI STATUS
  // Linia stacji i IP jest obnizona pod gorna ramke, zeby nie nachodzila
  // na tytul. Czyscimy caly pasek przy kazdym rysowaniu panelu.
  // ================================================================
  tftDrawTitleBar(modeName, String("V") + String(volumeValue));

  const int infoY = 38;
  gfx.tftFillRect(10, 34, 300, 12, 0x0000);

  String stationLine = tftClipText(tftStationName(), 26);
  String ipLine = (WiFi.status() == WL_CONNECTED) ? WiFi.localIP().toString() : String("brak IP");

  gfx.tftText(18, infoY, stationLine.c_str(), 1, EVO_TFT_NATIVE_TEXT);
  tftTextRight(304, infoY, ipLine, 1, EVO_TFT_NATIVE_MUTED);
}

static void evo43Eq16Save()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  STORAGE.remove("/eq16.cfg");
  File f = STORAGE.open("/eq16.cfg", FILE_WRITE);
  if (!f) return;
  for (int i = 0; i < 16; i++) { f.print(evo43Eq16[i]); f.print(i == 15 ? '\n' : ','); }
  f.close();
#endif
}

static void evo43Eq16Load()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File f = STORAGE.open("/eq16.cfg", FILE_READ);
  if (!f) return;
  String line = f.readStringUntil('\n');
  f.close();
  int pos = 0;
  for (int i = 0; i < 16; i++)
  {
    int comma = line.indexOf(',', pos);
    String part = comma >= 0 ? line.substring(pos, comma) : line.substring(pos);
    part.trim();
    if (part.length()) evo43Eq16[i] = constrain(part.toInt(), -12, 12);
    if (comma < 0) break;
    pos = comma + 1;
  }
  evo43ApplyEq16ToTone();
#endif
}

static void evo43Eq16Preset(uint8_t preset)
{
  static const int8_t presets[7][16] = {
    {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
    {6,6,5,4,2,0,0,0,-1,-1,0,1,2,3,3,3},
    {-2,-2,-1,0,1,3,4,4,3,2,1,0,0,-1,-1,-2},
    {4,3,2,1,0,-1,-2,-2,-1,0,2,3,4,4,3,2},
    {6,5,4,2,0,-2,-3,-3,-2,0,2,4,5,6,6,5},
    {5,4,3,1,0,1,2,3,3,2,1,2,3,4,4,3},
    {3,2,1,0,1,2,3,3,2,1,0,1,2,3,2,1}
  };
  if (preset > 6) preset = 0;
  for (int i = 0; i < 16; i++) evo43Eq16[i] = presets[preset][i];
  evo43Eq16Enabled = true;
  evo43ApplyEq16ToTone();
  evo43Eq16Save();
  evo43LastAction = String("EQ PRESET ") + String(preset);
}

static void evo43DlnaSave()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  STORAGE.remove("/dlna_config.txt");
  File f = STORAGE.open("/dlna_config.txt", FILE_WRITE);
  if (!f) return;
  f.println(evo43DlnaHost);
  f.println(evo43DlnaIdx);
  f.println(evo43DlnaDescUrl);
  f.close();
#endif
}

static void evo43DlnaLoad()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File f = STORAGE.open("/dlna_config.txt", FILE_READ);
  if (!f) return;
  evo43DlnaHost = f.readStringUntil('\n'); evo43DlnaHost.trim();
  evo43DlnaIdx = f.readStringUntil('\n'); evo43DlnaIdx.trim();
  evo43DlnaDescUrl = f.readStringUntil('\n'); evo43DlnaDescUrl.trim();
  f.close();
#endif
}

static bool evo43BtUartEnabled = false;
static bool evo43BtUartStarted = false;
static String evo43BtLog = "";

static void evo43BtEnsureUart()
{
  if (!evo43BtUartEnabled || evo43BtUartStarted) return;
  Serial2.begin(115200, SERIAL_8N1, 19, 20);
  evo43BtUartStarted = true;
  evo43BtLog += "UART start RX19/TX20\n";
}

static void evo43BtSend(const String &cmd)
{
  evo43BtLastCmd = cmd;
  evo43BtEnsureUart();
  if (evo43BtUartEnabled && evo43BtUartStarted) Serial2.println(cmd);
  evo43BtLog += String("> ") + cmd + "\n";
  if (evo43BtLog.length() > 1200) evo43BtLog.remove(0, evo43BtLog.length() - 1200);
}

void evo43FullModLoop()
{
  static bool once = false;
  if (!once)
  {
    once = true;
    evo46SystemLoad();
    evo46AnalyzerStyleLoad();
    evo46WifiLoad();
    evo43Eq16Load();
    evo43DlnaLoad();
  }
  evo43RecorderLoop();
  if (evo43BtUartEnabled)
  {
    evo43BtEnsureUart();
    while (Serial2.available())
    {
      String line = Serial2.readStringUntil('\n');
      line.trim();
      if (line.length()) evo43BtLog += String("< ") + line + "\n";
      if (evo43BtLog.length() > 1200) evo43BtLog.remove(0, evo43BtLog.length() - 1200);
    }
  }
}

void v39PanelSDPlayer()
{
  evo43ScanCurrentDir();
  evo43DrawTopMiniStatus("SD PLAYER");
  evo43DrawCard(12, 44, 296, 150, evo43CurrentDir);
  if (evo43TrackCount == 0)
  {
    gfx.tftText(28, 94, "Brak plikow audio w katalogu", 1, EVO_TFT_NATIVE_RED);
    gfx.tftText(28, 116, "MP3 AAC M4A WAV FLAC OGG OPUS", 1, EVO_TFT_NATIVE_MUTED);
  }
  uint8_t rows = 5;
  uint16_t start = 0;
  if (evo43SelectedTrack >= rows) start = evo43SelectedTrack - rows + 1;
  for (uint8_t r = 0; r < rows && (start + r) < evo43TrackCount; r++)
  {
    uint16_t idx = start + r;
    int y = 78 + r * 22;
    bool sel = idx == evo43SelectedTrack;
    if (sel) gfx.tftFillRoundRect(22, y - 4, 190, 19, 4, 0x2104);
    String prefix = evo43Tracks[idx].isDir ? String("[") : String(" ");
    String suffix = evo43Tracks[idx].isDir ? String("]") : String("");
    gfx.tftText(28, y, tftClipText(prefix + evo43Tracks[idx].name + suffix, 30).c_str(), 1, sel ? EVO_TFT_NATIVE_YELLOW : EVO_TFT_NATIVE_TEXT);
  }
  evo43DrawMiniVU(218, 78, 76, 36);
  evo43DrawBadge(218, 124, evo43SdPlaying ? (evo43SdPaused ? "PAUSE" : "PLAY") : "STOP", evo43SdPlaying ? EVO_TFT_NATIVE_GREEN : EVO_TFT_NATIVE_MUTED);
  gfx.tftText(218, 152, tftClipText(evo43CurrentTrack, 12).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("/sdplayer", evo43LastAction, "PLAY");
}

void v39PanelSDRecorder()
{
  evo43DrawTopMiniStatus("SD RECORDER");

  // APMS FIX 2026-05-10:
  // Panel nagrywania SD byl za wysoko i napisy wchodzily blisko gornej ramki.
  // Obnizamy zawartosc w karcie oraz zamiast duzego kola REC rysujemy ikonke
  // karty SD: karta jest zielona, a napis REC na karcie jest czerwony.
  evo43DrawCard(12, 50, 296, 144, "stream recorder");

  auto drawSdRecIcon = [&](int x, int y)
  {
    const int w = 58;
    const int h = 72;
    const uint16_t sdGreen  = EVO_TFT_NATIVE_GREEN;
    const uint16_t sdDark   = 0x0200;
    const uint16_t sdFrame  = EVO_TFT_NATIVE_CYAN;
    const uint16_t recRed   = EVO_TFT_NATIVE_RED;
    const uint16_t sdText   = EVO_TFT_NATIVE_TEXT;

    // Korpus karty SD.
    gfx.tftFillRoundRect(x, y + 6, w, h - 6, 6, sdDark);
    gfx.tftDrawRoundRect(x, y + 6, w, h - 6, 6, sdFrame);
    gfx.tftDrawRoundRect(x + 2, y + 8, w - 4, h - 10, 5, sdGreen);

    // Gorne sciecie / ksztalt karty SD.
    gfx.tftFillRect(x + w - 15, y + 6, 13, 16, 0x0000);
    gfx.tftDrawFastHLine(x + w - 28, y + 8, 14, sdGreen);
    gfx.tftDrawFastVLine(x + w - 15, y + 8, 13, sdGreen);
    gfx.tftDrawFastHLine(x + w - 15, y + 21, 12, sdGreen);

    // Styki karty.
    for (int i = 0; i < 5; i++)
    {
      int px = x + 8 + i * 9;
      gfx.tftFillRoundRect(px, y + 14, 5, 12, 1, EVO_TFT_NATIVE_YELLOW);
    }

    // Napis REC czerwony na zielonej karcie.
    gfx.tftText(x + 12, y + 37, "REC", 1, recRed);
    gfx.tftText(x + 10, y + 54, "SD",  1, sdText);

    // Mala kropka aktywnosci. Przy nagrywaniu miga na czerwono.
    uint16_t dotCol = evo43RecActive && ((millis() / 350) % 2 == 0) ? recRed : sdGreen;
    gfx.tftFillCircle(x + w - 11, y + h - 11, 4, dotCol);
  };

  drawSdRecIcon(36, 82);

  uint32_t sec = evo43RecActive ? (millis() - evo43RecStartMs) / 1000 : 0;

  // Napisy w ramce obnizone i rozdzielone, zeby nie dotykaly naglowka karty.
  gfx.tftText(108, 86,  evo43RecActive ? "NAGRYWANIE" : "GOTOWY DO", evo43RecActive ? 2 : 1, evo43RecActive ? EVO_TFT_NATIVE_RED : EVO_TFT_NATIVE_TEXT);
  if (!evo43RecActive) gfx.tftText(108, 104, "NAGRYWANIA", 1, EVO_TFT_NATIVE_TEXT);

  String timeTxt = String("czas: ") + String(sec / 60) + ":" + (sec % 60 < 10 ? "0" : "") + String(sec % 60);
  gfx.tftText(108, 126, timeTxt.c_str(), 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftText(108, 150, (String("plik: ") + evo43HumanSize(evo43RecBytes)).c_str(), 1, EVO_TFT_NATIVE_CYAN);

  String fileName = evo43BaseName(evo43RecFileName);
  if (fileName.length() == 0) fileName = "brak pliku nagrania";
  gfx.tftText(28, 176, tftClipText(fileName, 42).c_str(), 1, EVO_TFT_NATIVE_MUTED);

  evo43DrawModeRibbon("/rec/start", evo43LastAction, "/rec/stop");
}

void v39PanelDLNA()
{
  // MODE 11 - DLNA / UPNP
  // APMS FIX: napisy w panelu obnizone, aby nie wchodzily w gorna belke ramki.
  evo43DrawTopMiniStatus("DLNA / UPNP");
  evo43DrawCard(12, 48, 296, 146, "media browser / playlist");

  // Celownik DLNA przesuniety lekko nizej, zeby zostawic wiecej miejsca na tytul karty.
  const int cx = 238;
  const int cy = 116;
  gfx.tftDrawCircle(cx, cy, 30, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawCircle(cx, cy, 18, EVO_TFT_NATIVE_GREEN);
  gfx.tftDrawCircle(cx, cy, 6, EVO_TFT_NATIVE_YELLOW);
  gfx.tftDrawFastHLine(cx - 30, cy, 60, EVO_TFT_NATIVE_CYAN);
  gfx.tftDrawFastVLine(cx, cy - 30, 60, EVO_TFT_NATIVE_CYAN);

  gfx.tftText(28, 88, "DLNA host:", 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(28, 106, tftClipText(evo43DlnaHost.length() ? evo43DlnaHost : String("ustaw w /dlna"), 30).c_str(), 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(28, 132, (String("ObjectID: ") + evo43DlnaIdx).c_str(), 1, EVO_TFT_NATIVE_YELLOW);
  gfx.tftText(28, 158, "Playlist: /playlist_dlna.txt", 1, EVO_TFT_NATIVE_CYAN);

  evo43DrawModeRibbon("/dlna", WiFi.SSID(), "UPNP");
}


static void evo43DrawBluetoothStatusIcon(int x, int y, bool connected)
{
  // ================================================================
  // APMS BLUETOOTH ICON FIX 2
  // Ikona jest teraz mniejsza i miesci sie w calosci w prawym polu panelu.
  // Brak polaczenia = niebieska ikona, polaczenie aktywne = zielona.
  // ================================================================
  uint16_t frameColor = connected ? EVO_TFT_NATIVE_GREEN : 0x041F;
  uint16_t coreColor  = connected ? 0x07E0 : 0x03BF;

  gfx.tftFillRect(x, y, 66, 104, 0x0000);

  // Mniejsza obwodka z zaokragleniem, podobna do pokazanej ikonki wzorcowej.
  const int bx = x + 14;
  const int by = y + 10;
  const int bw = 36;
  const int bh = 76;
  gfx.tftDrawRoundRect(bx, by, bw, bh, 12, frameColor);
  gfx.tftDrawRoundRect(bx + 1, by + 1, bw - 2, bh - 2, 11, coreColor);

  const int cx = bx + bw / 2;
  const int cy = by + bh / 2;

  // Pion symbolu BT.
  gfx.tftDrawLine(cx, cy - 20, cx, cy + 20, coreColor);
  gfx.tftDrawLine(cx + 1, cy - 20, cx + 1, cy + 20, coreColor);

  // Gorne skrzydla.
  gfx.tftDrawLine(cx,     cy - 20, cx + 12, cy - 4, coreColor);
  gfx.tftDrawLine(cx + 1, cy - 20, cx + 13, cy - 4, coreColor);
  gfx.tftDrawLine(cx + 12, cy - 4, cx - 1, cy + 8, coreColor);
  gfx.tftDrawLine(cx + 13, cy - 4, cx,     cy + 8, coreColor);

  // Dolne skrzydla.
  gfx.tftDrawLine(cx - 1, cy + 8, cx + 12, cy + 20, coreColor);
  gfx.tftDrawLine(cx,     cy + 8, cx + 13, cy + 20, coreColor);
  gfx.tftDrawLine(cx,     cy + 20, cx + 12, cy + 6, coreColor);
  gfx.tftDrawLine(cx + 1, cy + 20, cx + 13, cy + 6, coreColor);

  // Drobne lewe przeciecie, zeby symbol byl blizszy klasycznemu BT.
  gfx.tftDrawLine(cx - 6, cy + 2, cx, cy + 8, coreColor);
  gfx.tftDrawLine(cx - 6, cy + 1, cx, cy + 7, coreColor);
}

void v39PanelBluetooth()
{
  // MODE 12 - BLUETOOTH
  // APMS FIX: nowa poprawna ikona BT, stara grafika usunieta.
  // Niebieska = brak polaczenia, zielona = tryb/polaczenie aktywne.
  evo43DrawTopMiniStatus("BLUETOOTH");
  evo43DrawCard(12, 48, 296, 146, "BT RX/TX UART panel");

  gfx.tftText(38, 88, "Tryb:", 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(94, 84, evo43BtMode.c_str(), 2, EVO_TFT_NATIVE_CYAN);

  gfx.tftText(38, 124, "UART:", 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(94, 124, evo43BtUartEnabled ? "ON RX19/TX20" : "OFF", 1,
              evo43BtUartEnabled ? EVO_TFT_NATIVE_GREEN : EVO_TFT_NATIVE_RED);

  gfx.tftText(38, 150, "CMD:", 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(94, 150, tftClipText(evo43BtLastCmd, 22).c_str(), 1, EVO_TFT_NATIVE_TEXT);

  bool btConnected = evo43BtUartEnabled && (evo43BtMode != "OFF");
  evo43DrawBluetoothStatusIcon(226, 76, btConnected);

  evo43DrawModeRibbon("/bt", "OFF RX TX AUTO", "UART");
}


// APMS FIX: nazwy 16 pasm EQ - potrzebne dla panelu EQ16 i komunikatow pilota.
// Funkcja musi byc zdefiniowana przed v39PanelEQ16(), bo Arduino IDE nie zawsze
// poprawnie tworzy prototypy dla funkcji wstawionych w srodku duzego pliku .ino.
static const char* evo43Eq16BandName(uint8_t band)
{
  static const char* names[16] = {
    "32Hz", "45Hz", "63Hz", "90Hz",
    "125Hz", "180Hz", "250Hz", "355Hz",
    "500Hz", "710Hz", "1kHz", "1.4kHz",
    "2kHz", "4kHz", "8kHz", "16kHz"
  };
  if (band > 15) band = 15;
  return names[band];
}

void v39PanelEQ16()
{
  // ================================================================
  // MODE 13 - GRAPHIC EQ16
  // APMS FIX 2026-05-10:
  // Dopasowanie grafiki do opisow na TFT 320x240.
  // Wczesniej pelna linia "32 45 63 ... 16k" wychodzila poza ramke.
  // Teraz opisy sa skrocone, rysowane tylko w punktach orientacyjnych,
  // a aktualne pasmo i wartosc dB sa pokazane w dolnym pasku.
  // ================================================================

  evo43DrawTopMiniStatus("GRAPHIC EQ16");

  String eqHelp = evo43Eq16EditGain
                    ? "EDIT: GORA/DOL dB   OK=zapis"
                    : "WYBOR: L/R pasmo   OK=edit";

  evo43DrawCard(12, 44, 296, 150, eqHelp);

  const int base = 130;
  const int topY = 78;
  const int gridBottom = 166;
  const int firstX = 28;
  const int stepX = 17;

  // Linia 0 dB.
  gfx.tftDrawFastHLine(23, base, 274, EVO_TFT_NATIVE_CYAN);

  // Pomocnicza siatka pozioma, delikatna, zeby EQ byl czytelny.
  gfx.tftDrawFastHLine(23, base - 24, 274, 0x18C3);
  gfx.tftDrawFastHLine(23, base + 24, 274, 0x18C3);

  for (int i = 0; i < 16; i++)
  {
    int x = firstX + i * stepX;
    int val = constrain(evo43Eq16[i], -12, 12);
    int y = base - val * 4;

    uint16_t c = (i == evo43Eq16SelectedBand)
                   ? (evo43Eq16EditGain ? EVO_TFT_NATIVE_RED : EVO_TFT_NATIVE_YELLOW)
                   : (val >= 0 ? EVO_TFT_NATIVE_CYAN : EVO_TFT_NATIVE_ORANGE);

    // Slupki i pionowe linie siatki zostaja w obrysie panelu.
    gfx.tftDrawFastVLine(x, topY, gridBottom - topY, 0x39E7);

    if (val >= 0)
      gfx.tftFillRoundRect(x - 5, y, 10, base - y + 1, 3, c);
    else
      gfx.tftFillRoundRect(x - 5, base, 10, y - base + 1, 3, c);

    if (i == evo43Eq16SelectedBand)
    {
      // Ramka wyboru byla ucinana od dolu przy etykietach pasma.
      // Skracamy ja minimalnie i przesuwamy tak, by cala byla widoczna.
      gfx.tftDrawRoundRect(x - 7, topY - 3, 14, gridBottom - topY + 6, 3,
                           evo43Eq16EditGain ? EVO_TFT_NATIVE_RED : EVO_TFT_NATIVE_YELLOW);
    }
  }

  // Opisy osi: nie wypisujemy wszystkich 16 nazw w jednym dlugim stringu,
  // bo na malej czcionce i tak wychodzilo poza ramke.
  // Zostawione sa punkty orientacyjne, ktore mieszcza sie w jednej linii.
  struct EqAxisLabel { uint8_t band; const char* txt; };
  const EqAxisLabel axisLabels[] = {
    { 0,  "32"  },
    { 2,  "63"  },
    { 4,  "125" },
    { 6,  "250" },
    { 8,  "500" },
    { 10, "1k"  },
    { 12, "2k"  },
    { 14, "8k"  },
    { 15, "16k" }
  };

  gfx.tftFillRect(20, 171, 280, 14, 0x0000);
  for (uint8_t i = 0; i < sizeof(axisLabels) / sizeof(axisLabels[0]); i++)
  {
    int lx = firstX + axisLabels[i].band * stepX;
    uint16_t lc = (axisLabels[i].band == evo43Eq16SelectedBand)
                    ? EVO_TFT_NATIVE_YELLOW
                    : EVO_TFT_NATIVE_MUTED;
    tftTextCenter(lx - 12, 175, 24, String(axisLabels[i].txt), 1, lc);
  }

  // Aktualne pasmo jako osobny opis, zawsze miesci sie w dolnym pasku.
  String mid = String(evo43Eq16BandName(evo43Eq16SelectedBand)) + " " + String(evo43Eq16[evo43Eq16SelectedBand]) + "dB";
  evo43DrawModeRibbon(evo43Eq16EditGain ? "EDIT" : "SELECT", mid, evo43Eq16EditGain ? "UP/DN OK" : "L/R OK");
}

static void evo43Eq16OpenPanel()
{
  displayMode = 13;
  eq16MenuActive = true;
  equalizerMenuEnable = true;
  evo43Eq16Enabled = true;
  timeDisplay = false;
  displayActive = true;
  displayStartTime = millis();
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  gfx.tftStartWrite();
  v39PanelEQ16();
  gfx.tftEndWrite();
#else
  displayRadio();
  gfx.sendBuffer();
#endif
}

static void evo43Eq16SelectBand(int8_t dir)
{
  if (dir > 0) evo43Eq16SelectedBand = (evo43Eq16SelectedBand + 1) & 0x0F;
  else evo43Eq16SelectedBand = (evo43Eq16SelectedBand == 0) ? 15 : evo43Eq16SelectedBand - 1;
  evo43Eq16EditGain = false;
  evo43LastAction = String("EQ16 PASMO ") + String(evo43Eq16SelectedBand + 1) + " " + evo43Eq16BandName(evo43Eq16SelectedBand);
  evo43Eq16OpenPanel();
}

static void evo43Eq16ToggleEdit()
{
  evo43Eq16EditGain = !evo43Eq16EditGain;
  if (!evo43Eq16EditGain) evo43Eq16Save();
  evo43LastAction = evo43Eq16EditGain ? "EQ16 REGULACJA" : "EQ16 ZAPIS";
  evo43Eq16OpenPanel();
}

static void evo43Eq16AdjustGain(int8_t delta)
{
  if (!evo43Eq16EditGain)
  {
    evo43LastAction = "EQ16: nacisnij OK";
    evo43Eq16OpenPanel();
    return;
  }
  int8_t value = evo43Eq16[evo43Eq16SelectedBand] + delta;
  evo43Eq16SetBand(evo43Eq16SelectedBand, value);
  evo43Eq16Save();
  evo43LastAction = String("EQ16 ") + evo43Eq16BandName(evo43Eq16SelectedBand) + " " + String(evo43Eq16[evo43Eq16SelectedBand]) + "dB";
  evo43Eq16OpenPanel();
}

void v39PanelAnalyzerFFT()
{
  evo43DrawTopMiniStatus("ANALYZER STYLE 5");
  evo43DrawCard(12, 44, 296, 150, "original EVO3 bars / 4-color VU");
  evo43DrawSpectrumBars(25, 166, 24, evo46AnalyzerCfg.s5_barWidth, evo46AnalyzerCfg.s5_gap, 84);
  evo43DrawMiniVU(222, 54, 72, 34);
  gfx.tftText(25, 176, "Style 5: 16/24 bars + peak hold", 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("MODE 5", String("drv ") + String(evo46VuDrive) + "% scale " + String(evo46AnalyzerCfg.scale) + "%", "LIVE");
}

void v44PanelAnalyzerSegments()
{
  evo43DrawTopMiniStatus("ANALYZER STYLE 6");
  evo43DrawCard(12, 44, 296, 150, "original EVO3 segment analyzer");
  evo43DrawSpectrumSegments(25, 166, 24, evo46AnalyzerCfg.s6_width, evo46AnalyzerCfg.s6_gap, 84);
  gfx.tftText(25, 176, "Style 6: segmenty, peak, plynne skale", 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("MODE 6", String("seg ") + String(evo46AnalyzerCfg.s6_lines), "LIVE");
}

void v44PanelAnalyzerWide()
{
  evo43DrawTopMiniStatus("ANALYZER STYLE 8");
  evo43DrawCard(12, 44, 296, 150, "wide bars like EVO3 mode 8");
  evo46DrawSpectrumWideStyle8(18, 174, 16, evo46AnalyzerCfg.s8_barWidth, evo46AnalyzerCfg.s8_gap, 96);
  gfx.tftText(25, 184, "Style 8: szerokie slupki VU/FFT", 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("MODE 8", String("w") + String(evo46AnalyzerCfg.s8_barWidth) + " gap" + String(evo46AnalyzerCfg.s8_gap), "PEAK");
}

void v44PanelAnalyzerFloating()
{
  evo43DrawTopMiniStatus("ANALYZER STYLE 10");
  evo43DrawCard(12, 44, 296, 150, "floating peaks / ulatujace szczyty");
  evo43DrawFloatingPeaks(22, 174, 20, evo46AnalyzerCfg.s10_barWidth, evo46AnalyzerCfg.s10_gap, 96);
  gfx.tftText(25, 184, "Style 10: floating peaks", 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("MODE 10", String("peaks ") + String(evo46AnalyzerCfg.s10_maxPeaks), "LIVE");
}

void v39PanelAnalyzerScope()
{
  evo43DrawTopMiniStatus("ANALYZER SCOPE");
  evo43DrawCard(12, 44, 296, 150, "oscilloscope L/R");
  for (int x = 24; x <= 296; x += 24) gfx.tftDrawFastVLine(x, 78, 86, 0x0841);
  for (int y = 78; y <= 164; y += 21) gfx.tftDrawFastHLine(24, y, 272, 0x0841);
  int lastY1 = 121, lastY2 = 121;
  int ampL = 10 + evo43VuPctL() / 5;
  int ampR = 10 + evo43VuPctR() / 5;
  for (int x = 0; x < 272; x += 4)
  {
    int y1 = 121 + sin((x + millis() / 9) * 0.075f) * ampL;
    int y2 = 121 + cos((x + millis() / 11) * 0.068f) * ampR;
    if (x > 0)
    {
      gfx.tftDrawLine(24 + x - 4, lastY1, 24 + x, y1, EVO_TFT_NATIVE_CYAN);
      gfx.tftDrawLine(24 + x - 4, lastY2, 24 + x, y2, EVO_TFT_NATIVE_ORANGE);
    }
    lastY1 = y1;
    lastY2 = y2;
  }
  evo43DrawModeRibbon("SCOPE", "audio L/R", "LIVE");
}

void v44PanelSquareVuMode4()
{
  // MODE 18 - VU KWADRATOWY / PROSTOKATNY TFT
  // Poprawka: ciemne tlo jak na zdjeciu, bez bialej tarczy.
  // Cyfry, kreski i igla zmieniaja kolor wedlug wychylu: zielony, zolty, niebieski, czerwony.

  String title = tftNowPlaying();

  uint16_t raw = audio.getVUlevel();
  uint8_t rawL = raw >> 8;
  uint8_t rawR = raw & 0xFF;

  // APMS FIX 2026-05-10:
  // Styl 18 musi korzystac z tego samego parametru co menu serwisowe:
  // "Poziom wysterowania VU / Analyzer" = evo46VuDrive 10-200%.
  // Wczesniej bylo zwykle map(raw, 0..255 -> 0..100), dlatego zmiana w menu
  // nie miala zadnego wplywu na czarny prostokatny VU.
  int vuL = tftVuPct(rawL);
  int vuR = tftVuPct(rawR);
  if (volumeMute) { vuL = 0; vuR = 0; }
  if (rawL > 0 && vuL < 1) vuL = 1;
  if (rawR > 0 && vuR < 1) vuR = 1;

  static uint8_t squareVuL = 0;
  static uint8_t squareVuR = 0;

  if (vuSmooth)
  {
    if (vuL > squareVuL) {
      int step = max(1, (vuL - (int)squareVuL) / max(1, (int)vuRiseNeedleSpeed));
      squareVuL = (uint8_t)constrain((int)squareVuL + step, 0, 100);
    } else if (vuL < squareVuL) {
      int step = max(1, ((int)squareVuL - vuL) / max(1, (int)vuFallNeedleSpeed));
      squareVuL = (uint8_t)constrain((int)squareVuL - step, 0, 100);
    }

    if (vuR > squareVuR) {
      int step = max(1, (vuR - (int)squareVuR) / max(1, (int)vuRiseNeedleSpeed));
      squareVuR = (uint8_t)constrain((int)squareVuR + step, 0, 100);
    } else if (vuR < squareVuR) {
      int step = max(1, ((int)squareVuR - vuR) / max(1, (int)vuFallNeedleSpeed));
      squareVuR = (uint8_t)constrain((int)squareVuR - step, 0, 100);
    }
  }
  else
  {
    squareVuL = (uint8_t)vuL;
    squareVuR = (uint8_t)vuR;
  }

  auto vuColor4 = [](int pct) -> uint16_t
  {
    pct = constrain(pct, 0, 100);
    if (pct < 35) return EVO_TFT_NATIVE_GREEN;
    if (pct < 62) return EVO_TFT_NATIVE_YELLOW;
    if (pct < 82) return 0x001F; // niebieski
    return EVO_TFT_NATIVE_RED;
  };

  auto vuDimColor = [](uint16_t c) -> uint16_t
  {
    uint16_t r = (c >> 11) & 0x1F;
    uint16_t g = (c >> 5) & 0x3F;
    uint16_t b = c & 0x1F;
    r >>= 2;
    g >>= 2;
    b >>= 2;
    return (r << 11) | (g << 5) | b;
  };

  tftDrawOriginalFrame();
  tftDrawOriginalHeader(tftStationName());

  // Panel glowny - czarny / ciemny granat.
  tftNeoPanel(6, 38, 308, 161, 0x0000);

  // Pasek informacji co teraz nadaje stacja.
  // APMS FIX: metadane zawsze w jednej linii. Dlugie tytuly sa przewijane
  // mniejsza czcionka, zeby nie wchodzily na wskazniki VU.
  title.replace("\r", " ");
  title.replace("\n", " ");
  title.trim();
  while (title.indexOf("  ") >= 0) title.replace("  ", " ");
  if (title.length() == 0) title = "Oczekiwanie na tytul...";

  gfx.tftFillRect(10, 40, 300, 28, 0x0000);
  gfx.tftText(16, 47, "NOW:", 1, EVO_TFT_NATIVE_CYAN);

  if (title.length() > 22)
  {
    gfx.tftText(52, 47, tftScrollWindow(title, 38, 520).c_str(), 1, EVO_TFT_NATIVE_YELLOW);
  }
  else
  {
    gfx.tftText(52, 43, tftScrollWindow(title, 18, 420).c_str(), 2, EVO_TFT_NATIVE_YELLOW);
  }

  gfx.tftDrawFastHLine(14, 68, 292, 0x028F);

  struct Label {
    uint8_t pos;
    const char* txt;
  };

  const uint8_t majorPos[] = { 0, 18, 35, 50, 62, 74, 87, 100 };
  const uint8_t MAJOR_COUNT = sizeof(majorPos) / sizeof(majorPos[0]);

  const Label scaleLabels[] = {
    { 0,   "-20" },
    { 18,  "-10" },
    { 35,  "-5"  },
    { 62,  "0"   },
    { 74,  "+3"  },
    { 87,  "+6"  },
    { 100, "+9"  }
  };
  const uint8_t LABEL_COUNT = sizeof(scaleLabels) / sizeof(scaleLabels[0]);

  auto drawSquareVu = [&](int x, int y, int w, int h, uint8_t value, const char *channel)
  {
    const uint16_t gaugeBg     = 0x0000; // czarna tarcza
    const uint16_t gaugeBg2    = 0x0000; // czarne tlo
    const uint16_t frameColor  = EVO_TFT_NATIVE_CYAN;
    const uint16_t innerFrame  = 0x039F;
    const uint16_t mutedLine   = 0x18C3;
    const uint16_t mutedText   = 0x6B6D;

    const int frameRadius = 5;
    const int scaleWidth = w - 28;
    const int leftX = x + 14;
    const int centerX = x + w / 2;
    const int railY1 = y + 36;
    const int railY2 = railY1 - 4;
    const int pivotY = y + h - 9;
    const int majorTickHeight = 12;
    const int minorTickHeight = 7;

    // Tarcza: ciemne tlo, zadnego bialego wypelnienia.
    gfx.tftFillRoundRect(x, y, w, h, frameRadius, gaugeBg);
    gfx.tftFillRoundRect(x + 2, y + 2, w - 4, h - 4, frameRadius, gaugeBg2);
    gfx.tftDrawRoundRect(x, y, w, h, frameRadius, frameColor);
    gfx.tftDrawRoundRect(x + 2, y + 2, w - 4, h - 4, frameRadius, innerFrame);

    // Kanal L/R i napis VU.
    gfx.tftText(x + 8, y + 7, channel, 2, EVO_TFT_NATIVE_TEXT);
    gfx.tftText(centerX + 30, y + 9, "VU", 1, mutedText);

    // Szyny skali.
    gfx.tftDrawFastHLine(leftX, railY2, scaleWidth, mutedLine);
    gfx.tftDrawFastHLine(leftX + (62 * scaleWidth) / 100, railY2 + 2, scaleWidth - (62 * scaleWidth) / 100, EVO_TFT_NATIVE_RED);
    gfx.tftDrawFastHLine(leftX, railY1, scaleWidth, 0xBDF7);
    gfx.tftDrawFastHLine(leftX, railY1 + 1, scaleWidth, 0x528A);

    auto tickColor = [&](int pct, bool number) -> uint16_t
    {
      pct = constrain(pct, 0, 100);
      if (pct <= value) return vuColor4(pct);
      uint16_t dim = vuDimColor(vuColor4(pct));
      return number ? (pct >= 82 ? 0x7800 : 0x632C) : dim;
    };

    auto drawTick = [&](int tx, int th, bool major)
    {
      int midX = leftX + scaleWidth / 2;
      int dx = 0;
      if (tx < midX - 1)      dx = -th / 2;
      else if (tx > midX + 1) dx =  th / 2;

      int pct = ((tx - leftX) * 100) / max(1, scaleWidth);
      uint16_t col = tickColor(pct, false);
      gfx.tftDrawLine(tx, railY1, tx + dx, railY1 - th, col);
      if (major) gfx.tftDrawLine(tx + 1, railY1, tx + dx + 1, railY1 - th, col);
    };

    // Duze kreski.
    for (uint8_t i = 0; i < MAJOR_COUNT; i++)
    {
      int tx = leftX + (majorPos[i] * scaleWidth) / 100;
      drawTick(tx, majorTickHeight, true);
    }

    // Male kreski - dwie pomiedzy kazda para duzych.
    for (uint8_t i = 0; i < MAJOR_COUNT - 1; i++)
    {
      int x1 = leftX + (majorPos[i] * scaleWidth) / 100;
      int x2 = leftX + (majorPos[i + 1] * scaleWidth) / 100;
      int step = (x2 - x1) / 3;
      drawTick(x1 + step, minorTickHeight, false);
      drawTick(x1 + 2 * step, minorTickHeight, false);
    }

    // Cyfry skali - kolor zalezy od wychylu.
    for (uint8_t i = 0; i < LABEL_COUNT; i++)
    {
      int tx = leftX + (scaleLabels[i].pos * scaleWidth) / 100;
      uint16_t col = tickColor(scaleLabels[i].pos, true);
      gfx.tftText(tx - 7, railY1 + 10, scaleLabels[i].txt, 1, col);
    }

    // Igla - cienka, wydluzona o kolejne ok. 3 mm.
    // Nadal trzymamy ograniczenie, zeby koncowka nie wyszla poza ramke.
    int needleLen = min(h - 10, scaleWidth / 2 + 34);
    if (needleLen < 54) needleLen = 54;
    float angle = radians(-70 + 140.0f * value / 100.0f);
    int xNeedle = centerX + (int)(sin(angle) * needleLen);
    int yNeedle = pivotY - (int)(cos(angle) * needleLen);
    xNeedle = constrain(xNeedle, x + 4, x + w - 4);
    yNeedle = constrain(yNeedle, y + 4, y + h - 10);
    uint16_t needleColor = vuColor4(value);

    gfx.tftDrawLine(centerX, pivotY, xNeedle, yNeedle, needleColor); // cienka igla 1 px
    gfx.tftFillRoundRect(centerX - 3, pivotY - 3, 6, 6, 2, needleColor);

    // Mala kontrolka koloru poziomu w rogu.
    gfx.tftFillRoundRect(x + w - 18, y + h - 17, 10, 10, 3, needleColor);
  };

  drawSquareVu(14, 76, 140, 94, squareVuL, "L");
  drawSquareVu(166, 76, 140, 94, squareVuR, "R");

  // Dolny opis panelu plus aktualna stacja, zeby nie tracic informacji co gra.
  gfx.tftText(14, 181, tftScrollWindow(tftStationName(), 29, 480).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  gfx.tftText(244, 181, "MODE 18", 1, EVO_TFT_NATIVE_CYAN);

  tftDrawOriginalFooter();
}

void v44PanelFileBrowser()
{
  evo43ScanCurrentDir();
  evo43DrawTopMiniStatus("FILES / STORAGE");
  evo43DrawCard(12, 44, 296, 150, evo43CurrentDir);
  uint8_t rows = 6;
  uint16_t start = 0;
  if (evo43SelectedTrack >= rows) start = evo43SelectedTrack - rows + 1;
  for (uint8_t r = 0; r < rows && (start + r) < evo43TrackCount; r++)
  {
    uint16_t idx = start + r;
    int y = 74 + r * 19;
    bool sel = idx == evo43SelectedTrack;
    if (sel) gfx.tftFillRoundRect(22, y - 3, 260, 17, 4, 0x2104);
    gfx.tftText(28, y, tftClipText((evo43Tracks[idx].isDir ? String("[DIR] ") : String("[AUD] ")) + evo43Tracks[idx].name, 40).c_str(), 1, sel ? EVO_TFT_NATIVE_YELLOW : EVO_TFT_NATIVE_TEXT);
  }
  evo43DrawModeRibbon("FILES", String(evo43TrackCount) + " items", storageTextName);
}

void v44PanelAnalogVu4Color()
{
  gfx.tftFillScreen(0x0000);
  evo43DrawTopMiniStatus("VU METER 4 COLOR");
  evo43DrawFourColorAnalogVu(86, 146, displayVuL, peakL, "L");
  evo43DrawFourColorAnalogVu(234, 146, displayVuR, peakR, "R");
  evo43DrawModeRibbon("MODE 4", tftClipText(tftStationName(), 18), "VU 4C");
}

void v39PanelSystemMonitor()
{
  evo43DrawTopMiniStatus("SYSTEM MONITOR");
  evo43DrawCard(12, 44, 296, 150, "diagnostics");
  int heapPct = constrain((int)(100 - (ESP.getFreeHeap() / 3000)), 0, 100);
  int wifiPct = constrain(map(WiFi.RSSI(), -95, -35, 0, 100), 0, 100);
  tftDrawProgressBar(34, 82, 220, 16, heapPct, 100, EVO_TFT_NATIVE_ORANGE);
  gfx.tftText(262, 84, "RAM", 1, EVO_TFT_NATIVE_TEXT);
  tftDrawProgressBar(34, 112, 220, 16, wifiPct, 100, EVO_TFT_NATIVE_GREEN);
  gfx.tftText(262, 114, "WiFi", 1, EVO_TFT_NATIVE_TEXT);
  tftDrawProgressBar(34, 142, 220, 16, evo43VuPctMix(), 100, EVO_TFT_NATIVE_CYAN);
  gfx.tftText(262, 144, "AUD", 1, EVO_TFT_NATIVE_TEXT);
  gfx.tftText(34, 172, (String("Heap: ") + String(ESP.getFreeHeap()) + "  IP: " + WiFi.localIP().toString()).c_str(), 1, EVO_TFT_NATIVE_MUTED);
  evo43DrawModeRibbon("/sys", softwareRev, storageTextName);
}

static String evo43BuildSdPlayerHtml()
{
  String html = F("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>SD Player</title><style>body{font-family:Arial;background:#111;color:#eee;max-width:760px;margin:auto;padding:18px}.b{padding:10px 14px;margin:4px;border:0;border-radius:8px;background:#04a;color:#fff}.r{background:#b22}.g{background:#286}.card{background:#1d1d1d;border:1px solid #099;border-radius:12px;padding:14px;margin:10px 0}a{color:#0ff}</style></head><body><h2>EVO3 MOD KOLOR V46 - SD Player</h2><div class='card'>Katalog: ");
  html += evo43CurrentDir;
  html += F("<br>Aktualny: ");
  html += evo43CurrentTrack;
  html += F("<br>Status: ");
  html += evo43LastAction;
  html += F("</div><button class='b' onclick=location.href='/sdplayer/api/prev'>PREV</button><button class='b g' onclick=location.href='/sdplayer/api/play'>PLAY/OPEN</button><button class='b' onclick=location.href='/sdplayer/api/pause'>PAUSE</button><button class='b r' onclick=location.href='/sdplayer/api/stop'>STOP</button><button class='b' onclick=location.href='/sdplayer/api/next'>NEXT</button><button class='b' onclick=location.href='/sdplayer/api/up'>UP</button><button class='b' onclick=location.href='/sdplayer/api/back'>RADIO</button><div class='card'><pre id='list'>loading...</pre></div><p><a href='/menu'>Menu</a></p><script>fetch('/sdplayer/api/list').then(r=>r.json()).then(j=>{let s='';j.items.forEach((x,i)=>s+=(i==j.selected?'> ':'  ')+(x.dir?'[D] ':'    ')+x.name+'\\n');document.getElementById('list').textContent=s;});</script></body></html>");
  return html;
}


static String evo43BuildBtHtml()
{
  String html = F("<!doctype html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>Bluetooth</title><style>body{font-family:Arial;background:#f3f3f3;color:#111;max-width:760px;margin:auto;padding:18px;text-align:center}.card{background:#fff;border-radius:12px;padding:16px;margin:12px 0;box-shadow:0 2px 10px #0002}.b{padding:10px 14px;margin:4px;border:0;border-radius:6px;background:#1e88e5;color:#fff;font-weight:bold}.g{background:#43a047}.r{background:#e53935}.gray{background:#999}input{padding:9px;border:1px solid #ccc;border-radius:5px}pre{background:#111;color:#0f0;text-align:left;padding:12px;border-radius:8px;white-space:pre-wrap;max-height:240px;overflow:auto}.hint{font-size:.85rem;color:#555}.warn{font-size:.85rem;color:red}</style></head><body><h2>📶 Ustawienia Bluetooth</h2>");
  html += F("<div class='card'><h3>Status</h3><div style='background:#aaa;color:white;border-radius:4px;padding:10px;font-weight:bold'>Bluetooth ");
  html += evo43BtMode;
  html += F("</div><p>Mode: "); html += evo43BtMode; html += F("</p><p>Device: "); html += evo43BtUartEnabled ? "UART RX19/TX20" : "Brak polaczenia"; html += F("</p></div>");
  html += F("<div class='card'><h3>⚡ Komunikacja UART</h3><label><input type='checkbox' onchange=\"location.href='/bt/api/uart?en='+(this.checked?1:0)\" ");
  if (evo43BtUartEnabled) html += "checked";
  html += F("> Wlacz komunikacje UART z modulem BT (RX19/TX20)</label><p class='warn'>Zaznacz aby wysylac komendy do modulu BT. Odznacz gdy modul jest odlaczony.</p></div>");
  html += F("<div class='card'><h3>Mode Selection</h3><button class='b g' onclick=location.href='/bt/api/mode?m=OFF'>OFF</button><button class='b' onclick=location.href='/bt/api/mode?m=RX'>RX (Receiver)</button><button class='b' onclick=location.href='/bt/api/mode?m=TX'>TX (Transmitter)</button><button class='b' onclick=location.href='/bt/api/mode?m=AUTO'>AUTO</button><p class='hint'>RX - telefon wysyla audio do radia | TX - radio wysyla audio do sluchawek BT</p></div>");
  html += F("<div class='card'><h3>Volume (BT RX Mode)</h3><form action='/bt/api/volume'><input name='v' type='number' min='0' max='42' value='");
  html += String(evo46BtVolume);
  html += F("'><button class='b'>Set</button></form><p>Wzmocnienie:</p><button class='b' onclick=location.href='/bt/api/cmd?c=GAIN%20100'>100</button><button class='b' onclick=location.href='/bt/api/cmd?c=GAIN%20200'>200</button><button class='b' onclick=location.href='/bt/api/cmd?c=GAIN%20300'>300</button><button class='b' onclick=location.href='/bt/api/cmd?c=GAIN%20400'>400</button></div>");
  html += F("<div class='card'><h3>Actions</h3><button class='b' onclick=location.href='/bt/api/cmd?c=SCAN'>🔍 Scan Devices</button><button class='b' onclick=location.href='/bt/api/cmd?c=DISCONNECT'>Disconnect</button><button class='b r' onclick=location.href='/bt/api/cmd?c=DELETE_ALL'>Delete All Paired</button></div>");
  html += F("<div class='card'><form action='/bt/api/cmd'><h3>Terminal diagnostyczny BT UART</h3><input name='c' style='width:75%' placeholder='AT / komenda UART'><button class='b'>Send</button></form><pre>");
  html += evo43JsonEscape(evo43BtLog);
  html += F("</pre></div><p><a href='/menu'>Powrot do Menu</a></p></body></html>");
  return html;
}

static String evo43BuildEqHtml()
{
  String html = F("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>EQ16</title><style>body{font-family:Arial;background:#101010;color:#eee;max-width:900px;margin:auto;padding:18px}.card{background:#1d1d1d;border:1px solid #099;border-radius:12px;padding:14px;margin:10px 0}input{width:42px}.b{padding:9px 12px;margin:4px;border:0;border-radius:8px;background:#047;color:#fff}a{color:#0ff}</style></head><body><h2>EVO3 MOD KOLOR V46 - Graphic EQ16</h2><div class='card'><b>Presety:</b><br><button class='b' onclick=location.href='/eq16/api/preset?p=0'>Flat</button><button class='b' onclick=location.href='/eq16/api/preset?p=1'>Bass</button><button class='b' onclick=location.href='/eq16/api/preset?p=2'>Vocal</button><button class='b' onclick=location.href='/eq16/api/preset?p=3'>Radio</button><button class='b' onclick=location.href='/eq16/api/preset?p=4'>V-Shape</button><button class='b' onclick=location.href='/eq16/api/preset?p=5'>Rock</button><button class='b' onclick=location.href='/eq16/api/preset?p=6'>Jazz</button></div><form action='/eq16/api/set'><div class='card'>");
  for (int i = 0; i < 16; i++)
  {
    html += String("B") + String(i + 1) + ": <input name='b" + String(i) + "' type='number' min='-12' max='12' value='" + String(evo43Eq16[i]) + "'> ";
    if (i == 7) html += "<br><br>";
  }
  html += F("<br><br><button class='b' type='submit'>Zapisz i zastosuj</button></div></form><p><a href='/eq16/api/reset'>Reset</a> | <a href='/mode?m=13'>Panel EQ</a> | <a href='/menu'>Menu</a></p></body></html>");
  return html;
}


static String evo46BuildSdRecorderHtml()
{
  String html = F("<!doctype html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>SD Recorder</title><style>body{font-family:Arial;background:#101828;color:#eee;max-width:760px;margin:auto;padding:18px}.card{background:#15233a;border:1px solid #255a99;border-radius:12px;padding:15px;margin:12px 0}.b{padding:11px 16px;margin:5px;border:0;border-radius:8px;background:#1680e8;color:white;font-weight:bold}.r{background:#e53935}.g{background:#43a047}.mut{color:#9fb3ce}a{color:#70c8ff}</style></head><body><h2>SD Recorder</h2><div class='card'><h3>Status: ");
  html += evo43RecActive ? "NAGRYWANIE" : "STOP";
  html += F("</h3><p>Plik: "); html += evo43RecFileName.length() ? evo43RecFileName : "-";
  html += F("</p><p>Bajty: "); html += String(evo43RecBytes); html += F(" ("); html += evo43HumanSize(evo43RecBytes); html += F(")</p><p>Komunikat: "); html += evo43LastAction; html += F("</p></div>");
  html += F("<div class='card'><button class='b g' onclick=location.href='/rec/start'>START RECORD</button><button class='b r' onclick=location.href='/rec/stop'>STOP RECORD</button><button class='b' onclick=location.href='/rec/status'>JSON STATUS</button><button class='b' onclick=location.href='/mode?m=9'>Panel TFT</button></div>");
  html += F("<div class='card'><p class='mut'>Nagrania sa zapisywane w katalogu <b>/RECORDINGS</b> na aktywnym nosniku SD/SPIFFS. Recorder obsluguje strumienie HTTP; HTTPS nie jest nagrywany bezposrednio.</p></div><p><a href='/menu'>Powrot do Menu</a></p></body></html>");
  return html;
}

static String evo46WifiJsonEscape(const String &in)
{
  String out;
  for (uint16_t i = 0; i < in.length(); i++) {
    char c = in[i];
    if (c == '"' || c == '\\') out += '\\';
    out += c;
  }
  return out;
}

void evo43RegisterFullModHandlers()
{
  server.on("/sdplayer", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/html", evo43BuildSdPlayerHtml()); });
  server.on("/sdrecorder", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/html", evo46BuildSdRecorderHtml()); });
  server.on("/sdplayer/api/list", HTTP_GET, [](AsyncWebServerRequest *request){
    evo43ScanCurrentDir();
    String json = String("{\"dir\":\"") + evo43JsonEscape(evo43CurrentDir) + "\",\"selected\":" + String(evo43SelectedTrack) + ",\"playing\":" + String(evo43SdPlaying ? "true" : "false") + ",\"items\":[";
    for (uint16_t i = 0; i < evo43TrackCount; i++)
    {
      if (i) json += ',';
      json += String("{\"name\":\"") + evo43JsonEscape(evo43Tracks[i].name) + "\",\"path\":\"" + evo43JsonEscape(evo43Tracks[i].path) + "\",\"dir\":" + String(evo43Tracks[i].isDir ? "true" : "false") + "}";
    }
    json += "]}";
    request->send(200, "application/json", json);
  });
  server.on("/sdplayer/api/next", HTTP_GET, [](AsyncWebServerRequest *request){ evo43SelectNextTrack(); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/prev", HTTP_GET, [](AsyncWebServerRequest *request){ evo43SelectPrevTrack(); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/play", HTTP_GET, [](AsyncWebServerRequest *request){ evo43PlaySelectedTrack(); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/pause", HTTP_GET, [](AsyncWebServerRequest *request){ evo43SdPauseResume(); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/stop", HTTP_GET, [](AsyncWebServerRequest *request){ evo43SdStop(false); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/up", HTTP_GET, [](AsyncWebServerRequest *request){ evo43GoParentDir(); request->redirect("/sdplayer"); });
  server.on("/sdplayer/api/back", HTTP_GET, [](AsyncWebServerRequest *request){ evo43SdStop(true); request->redirect("/menu"); });

  server.on("/rec/start", HTTP_GET, [](AsyncWebServerRequest *request){ evo43RecorderStart(); request->redirect("/menu"); });
  server.on("/rec/stop", HTTP_GET, [](AsyncWebServerRequest *request){ evo43RecorderStop(); request->redirect("/menu"); });
  server.on("/rec/status", HTTP_GET, [](AsyncWebServerRequest *request){
    String json = String("{\"active\":") + String(evo43RecActive ? "true" : "false") + ",\"bytes\":" + String(evo43RecBytes) + ",\"file\":\"" + evo43JsonEscape(evo43RecFileName) + "\",\"msg\":\"" + evo43JsonEscape(evo43LastAction) + "\"}";
    request->send(200, "application/json", json);
  });

  server.on("/dlna", HTTP_GET, [](AsyncWebServerRequest *request){
    String html = F("<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'><title>DLNA</title><style>body{font-family:Arial;background:#101010;color:#eee;max-width:760px;margin:auto;padding:18px}.card{background:#1d1d1d;border:1px solid #099;border-radius:12px;padding:14px;margin:10px 0}input{width:90%;padding:8px}a{color:#0ff}</style></head><body><h2>DLNA / UPNP</h2><form action='/dlna/api/save'><div class='card'>Host/IP:<br><input name='host' value='");
    html += evo43DlnaHost;
    html += F("'><br>ObjectID:<br><input name='idx' value='");
    html += evo43DlnaIdx;
    html += F("'><br>Desc URL:<br><input name='desc' value='");
    html += evo43DlnaDescUrl;
    html += F("'><br><br><button>Zapisz</button></div></form><p>Playlist DLNA: /playlist_dlna.txt</p><p><a href='/menu'>Menu</a></p></body></html>");
    request->send(200, "text/html", html);
  });
  server.on("/dlna/api/save", HTTP_GET, [](AsyncWebServerRequest *request){
    if (request->hasParam("host")) evo43DlnaHost = request->getParam("host")->value();
    if (request->hasParam("idx")) evo43DlnaIdx = request->getParam("idx")->value();
    if (request->hasParam("desc")) evo43DlnaDescUrl = request->getParam("desc")->value();
    evo43DlnaSave();
    evo43LastAction = "DLNA CONFIG SAVED";
    request->redirect("/dlna");
  });

  server.on("/bt", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/html", evo43BuildBtHtml()); });
  server.on("/bt/api/mode", HTTP_GET, [](AsyncWebServerRequest *request){ if (request->hasParam("m")) evo43BtMode = request->getParam("m")->value(); evo43BtSend("MODE " + evo43BtMode); request->redirect("/bt"); });
  server.on("/bt/api/cmd", HTTP_GET, [](AsyncWebServerRequest *request){ if (request->hasParam("c")) evo43BtSend(request->getParam("c")->value()); request->redirect("/bt"); });
  server.on("/bt/api/volume", HTTP_GET, [](AsyncWebServerRequest *request){ if (request->hasParam("v")) { evo46BtVolume = evo46ClampU8(request->getParam("v")->value().toInt(), 0, 42); evo43BtSend(String("VOL ") + String(evo46BtVolume)); evo46SystemSave(); } request->redirect("/bt"); });
  server.on("/bt/api/uart", HTTP_GET, [](AsyncWebServerRequest *request){ evo43BtUartEnabled = request->hasParam("en") && request->getParam("en")->value().toInt() != 0; evo43BtLastCmd = evo43BtUartEnabled ? "UART ON" : "UART OFF"; request->redirect("/bt"); });
  server.on("/bt/api/log", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/plain", evo43BtLog); });

  server.on("/eq16", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/html", evo43BuildEqHtml()); });
  server.on("/eq16/api/set", HTTP_GET, [](AsyncWebServerRequest *request){
    for (int i = 0; i < 16; i++)
    {
      String k = String("b") + String(i);
      if (request->hasParam(k)) evo43Eq16[i] = constrain(request->getParam(k)->value().toInt(), -12, 12);
    }
    evo43Eq16Enabled = true;
    evo43ApplyEq16ToTone();
    evo43Eq16Save();
    request->redirect("/eq16");
  });
  server.on("/eq16/api/reset", HTTP_GET, [](AsyncWebServerRequest *request){ evo43Eq16Reset(); evo43Eq16Save(); request->redirect("/eq16"); });
  server.on("/eq16/api/preset", HTTP_GET, [](AsyncWebServerRequest *request){ uint8_t p = request->hasParam("p") ? request->getParam("p")->value().toInt() : 0; evo43Eq16Preset(p); request->redirect("/eq16"); });
  server.on("/eq16/api/band", HTTP_GET, [](AsyncWebServerRequest *request){ if (request->hasParam("b")) evo43Eq16SelectedBand = constrain(request->getParam("b")->value().toInt(), 0, 15); if (request->hasParam("v")) evo43Eq16SetBand(evo43Eq16SelectedBand, request->getParam("v")->value().toInt()); evo43Eq16Save(); request->redirect("/eq16"); });

  server.on("/analyzer", HTTP_GET, [](AsyncWebServerRequest *request){
    if (request->hasParam("style")) evo43AnalyzerStyle = constrain(request->getParam("style")->value().toInt(), 5, 10);
    request->send(200, "text/html", evo46AnalyzerBuildHtmlPage());
  });

  server.on("/analyzerApply", HTTP_POST, [](AsyncWebServerRequest *request){
    evo46AnalyzerParseRequest(request);
    request->send(200, "text/html", "<!doctype html><html><head><meta http-equiv='refresh' content='1;url=/analyzer'></head><body><h2>Analyzer applied</h2></body></html>");
  });

  server.on("/analyzerSave", HTTP_POST, [](AsyncWebServerRequest *request){
    evo46AnalyzerParseRequest(request);
    evo46AnalyzerStyleSave();
    evo46SystemSave();
    request->send(200, "text/html", "<!doctype html><html><head><meta http-equiv='refresh' content='1;url=/analyzer'></head><body><h2>Analyzer saved</h2></body></html>");
  });

  server.on("/analyzerPreset", HTTP_POST, [](AsyncWebServerRequest *request){
    uint8_t p = request->hasParam("p") ? request->getParam("p")->value().toInt() : 0;
    evo46AnalyzerApplyPreset(p);
    evo46AnalyzerStyleSave();
    evo46SystemSave();
    request->redirect("/analyzer");
  });

  server.on("/analyzerCfg", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/plain", evo46AnalyzerCfgToString());
  });

  server.on("/mode", HTTP_GET, [](AsyncWebServerRequest *request){ if (request->hasParam("m")) { displayMode = constrain(request->getParam("m")->value().toInt(), 0, displayModeMax); displayRadio(); } request->redirect("/menu"); });


  server.on("/wifi", HTTP_GET, [](AsyncWebServerRequest *request){ request->send(200, "text/html", FPSTR(wifi_html)); });
  server.on("/wifi-list", HTTP_GET, [](AsyncWebServerRequest *request){
    String json = "[";
    for (uint8_t i = 0; i < evo46WifiCount; i++) {
      if (i) json += ",";
      json += String("{\"ssid\":\"") + evo46WifiJsonEscape(evo46WifiNetworks[i].ssid) + "\",\"pass\":" + String(evo46WifiNetworks[i].pass.length() ? "true" : "false") + "}";
    }
    json += "]";
    request->send(200, "application/json", json);
  });
  server.on("/wifi-scan", HTTP_GET, [](AsyncWebServerRequest *request){
    int n = WiFi.scanNetworks(false, false, false, 300);
    String json = "[";
    if (n > 0) {
      for (int i = 0; i < n; i++) {
        if (i) json += ",";
        json += "\"" + evo46WifiJsonEscape(WiFi.SSID(i)) + "\"";
      }
    }
    json += "]";
    WiFi.scanDelete();
    request->send(200, "application/json", json);
  });
  server.on("/wifi-add", HTTP_POST, [](AsyncWebServerRequest *request){
    if (!request->hasParam("ssid", true)) { request->send(400, "text/plain", "Brak parametru ssid"); return; }
    String ssid = request->getParam("ssid", true)->value(); ssid.trim();
    String pass = request->hasParam("pass", true) ? request->getParam("pass", true)->value() : "";
    if (ssid.length() == 0) { request->send(400, "text/plain", "SSID nie moze byc pusty"); return; }
    for (uint8_t i = 0; i < evo46WifiCount; i++) {
      if (evo46WifiNetworks[i].ssid == ssid) { evo46WifiNetworks[i].pass = pass; evo46WifiSave(); request->send(200, "text/plain", "Siec zaktualizowana"); return; }
    }
    if (evo46WifiCount >= EVO46_MAX_WIFI_NETWORKS) { request->send(400, "text/plain", "Limit sieci osiagniety"); return; }
    evo46WifiNetworks[evo46WifiCount].ssid = ssid;
    evo46WifiNetworks[evo46WifiCount].pass = pass;
    evo46WifiCount++;
    evo46WifiSave();
    request->send(200, "text/plain", "Siec dodana");
  });
  server.on("/wifi-remove", HTTP_POST, [](AsyncWebServerRequest *request){
    if (!request->hasParam("idx", true)) { request->send(400, "text/plain", "Brak idx"); return; }
    int idx = request->getParam("idx", true)->value().toInt();
    if (idx < 0 || idx >= (int)evo46WifiCount) { request->send(400, "text/plain", "Zly indeks"); return; }
    for (uint8_t i = idx; i + 1 < evo46WifiCount; i++) evo46WifiNetworks[i] = evo46WifiNetworks[i + 1];
    evo46WifiCount--;
    evo46WifiSave();
    request->send(200, "text/plain", "Siec usunieta");
  });

  server.on("/modes", HTTP_GET, [](AsyncWebServerRequest *request){
    String json = F("{\"modes\":[\"0 Radio\",\"1 Clock\",\"2 Info\",\"3 Center\",\"4 VU Analog 4C\",\"5 Analyzer Bars\",\"6 Analyzer Segments\",\"7 SD Player\",\"8 Analyzer Wide\",\"9 SD Recorder\",\"10 Floating Peaks\",\"11 DLNA\",\"12 Bluetooth\",\"13 EQ16\",\"14 Scope\",\"15 System\",\"16 V7 Crystal\",\"17 V7 Side\",\"18 VU Square\",\"19 Files\",\"20 Movie Clock\",\"21 Info WiFi\"]}");
    request->send(200, "application/json", json);
  });

  server.on("/sys", HTTP_GET, [](AsyncWebServerRequest *request){
    String json = String("{\"heap\":") + String(ESP.getFreeHeap()) + ",\"rssi\":" + String(WiFi.RSSI()) + ",\"ip\":\"" + WiFi.localIP().toString() + "\",\"rev\":\"" + String(softwareRev) + "\"}";
    request->send(200, "application/json", json);
  });
}

#endif // NATIVE ALL SCREENS


// ========================================================================
// APMS MAPA PANELI TFT / DISPLAY MODE
// ------------------------------------------------------------------------
// 0  tftDrawRadioMain()             - glowny ekran radia
// 1  tftDrawClockScreen()           - zegar klasyczny
// 2  tftDrawInfoScreen()            - informacje systemowe
// 3  tftDrawMode3SpreadScreen()     - ekran rozkladu informacji
// 4  v44PanelAnalogVu4Color()       - analogowy VU 4 kolory
// 5  v39PanelAnalyzerFFT()          - analizator FFT
// 6  v44PanelAnalyzerSegments()     - analizator segmentowy
// 7  v39PanelSDPlayer()             - odtwarzacz SD
// 8  v44PanelAnalyzerWide()         - szeroki analizator
// 9  v39PanelSDRecorder()           - nagrywanie SD
// 10 v44PanelAnalyzerFloating()     - analizator z plywajacymi peakami
// 11 v39PanelDLNA()                 - panel DLNA
// 12 v39PanelBluetooth()            - panel Bluetooth
// 13 v39PanelEQ16()                 - equalizer 16 pasm
// 14 v39PanelAnalyzerScope()        - oscyloskop / scope
// 15 v39PanelSystemMonitor()        - monitor systemu
// 16 tftDrawVuCrystalScreen()       - VU crystal
// 17 tftDrawVuSideSpreadScreen()    - VU boczny
// 18 v44PanelSquareVuMode4()        - czarny prostokatny VU z V7, 4 kolory
// 19 v44PanelFileBrowser()          - przegladarka plikow
// 20 tftDrawMovieClockScreen()      - przywrocony zegar filmowy/lampowy
// 21 tftDrawWifiInfoPanelScreen()   - nowy panel informacyjny z prawdziwym WiFi
// UWAGA: gorny wskaznik WiFi jest usuniety globalnie z naglowka, WiFi zostaje na dole
// ========================================================================
void displayRadioTFT()
{
  static uint32_t lastFrame = 0;
  static uint8_t lastMode = 255;
  uint32_t now = millis();

  uint16_t frameMs = EVO_TFT_NATIVE_FRAME_MS;
#if EVO_AUDIO_PRIORITY_MODE
  if (displayMode == 1) frameMs = EVO_AUDIO_SAFE_CLOCK_FRAME_MS;
  else if (displayMode == 20) frameMs = EVO_TFT_CLOCK_MOVIE_FRAME_MS;
  else if (displayMode == 16 || displayMode == 17 || displayMode == 18) frameMs = EVO_TFT_VU_DYNAMIC_FRAME_MS; // APMS: VU ma byc dynamiczne
  else if (displayMode == 2 || displayMode >= 7) frameMs = EVO_AUDIO_SAFE_MENU_FRAME_MS;
  else frameMs = EVO_AUDIO_SAFE_FRAME_MS;
#endif

  if (displayMode != lastMode)
  {
    lastMode = displayMode;
    lastFrame = 0;
    if (displayMode == 20) evoMovieClockResetIntro();
  }

  if ((uint32_t)(now - lastFrame) < frameMs) return;
  lastFrame = now;

#if EVO_AUDIO_PRIORITY_MODE
  audio.loop();   // dopelnij bufor przed dluzszym rysowaniem TFT
#endif

  tftNativeUpdateVuValues();
  gfx.tftStartWrite();
  if (displayMode == 1) tftDrawClockScreen();
  else if (displayMode == 2) tftDrawInfoScreen();
  else if (displayMode == 3) tftDrawMode3SpreadScreen();
  else if (displayMode == 4) v44PanelAnalogVu4Color();
  else if (displayMode == 5) v39PanelAnalyzerFFT();
  else if (displayMode == 6) v44PanelAnalyzerSegments();
  else if (displayMode == 7) v39PanelSDPlayer();
  else if (displayMode == 8) v44PanelAnalyzerWide();
  else if (displayMode == 9) v39PanelSDRecorder();
  else if (displayMode == 10) v44PanelAnalyzerFloating();
  else if (displayMode == 11) v39PanelDLNA();
  else if (displayMode == 12) v39PanelBluetooth();
  else if (displayMode == 13) v39PanelEQ16();
  else if (displayMode == 14) v39PanelAnalyzerScope();
  else if (displayMode == 15) v39PanelSystemMonitor();
  else if (displayMode == 16) tftDrawVuCrystalScreen();
  else if (displayMode == 17) tftDrawVuSideSpreadScreen();
  else if (displayMode == 18) v44PanelSquareVuMode4(); // APMS FIX: styl 18 = czarny prostokatny VU z V7, 4 kolory
  else if (displayMode == 19) v44PanelFileBrowser();
  else if (displayMode == 20) tftDrawMovieClockScreen();
  else if (displayMode == 21) tftDrawWifiInfoPanelScreen();
  else tftDrawRadioMain();
  gfx.tftEndWrite();

#if EVO_AUDIO_PRIORITY_MODE
  audio.loop();   // natychmiast po SPI wracamy do dekodera audio
#endif
}
#endif

// ----------- GLOWNA OBSLUGA WYSWIETLACZA W FUNKCJI RADIA INTERNETOWEGO ----------- //
void displayRadio() 
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  displayRadioTFT();
  return;
#endif
  int StationNameEnd = stationName.indexOf("  "); // Wycinamy nazwe stacji tylko do miejsca podwojnej spacji 
  stationName = stationName.substring(0, StationNameEnd);

  if (displayMode == 0)
  {
    gfx.clearBuffer();
    gfx.setFont(u8g2_font_helvB14_tr);
    gfx.drawStr(24, 16, stationName.substring(0, stationNameLenghtCut - 1).c_str());
    gfx.drawRBox(1, 1, 21, 16, 4);  // Biały kwadrat (tło) pod numerem stacji
        
    // Funkcja wyswietlania numeru Banku na dole ekranu
    gfx.setFont(spleen6x12PL);
    char BankStr[8];  
    snprintf(BankStr, sizeof(BankStr), "B-%02d", bank_nr); // Formatujemy numer banku do postacji 00

    // Wyswietlamy numer Banku w dolnej linijce
    
    if (!urlPlaying) 
    {
      gfx.drawBox(161, 54, 1, 12);  // dorysowujemy 1px pasek przed napisem "Bank" dla symetrii
      gfx.setDrawColor(0);
      gfx.setCursor(162, 63);  // Pozycja napisu Bank0x na dole ekranu
      gfx.print(BankStr);
    }
    
    gfx.setDrawColor(0);
    char StationNrStr[3];
    snprintf(StationNrStr, sizeof(StationNrStr), "%02d", station_nr);  //Formatowanie informacji o stacji i banku do postaci 00
    // Pozycja numeru stacji na gorze po lewej ekranu
    
    // Rozroznienie czy wypisujemy numer stacji czy napis URL jesli gramy z linka ze strony www
    if (!urlPlaying) 
    {
      gfx.setCursor(4, 14);
      gfx.setFont(u8g2_font_spleen8x16_mr); 
      gfx.print(StationNrStr);} 
    else 
    {
      gfx.setCursor(3, 13);
      gfx.setFont(spleen6x12PL);
      gfx.print("URL");
    }
    
    gfx.setDrawColor(1);
      
    // Logo 3xZZZ w trybie dla timera SLEEP
    if (f_sleepTimerOn) 
    {
      gfx.setFont(u8g2_font_04b_03_tr); 
      gfx.drawStr(189,63, "z");
      gfx.drawStr(192,61, "z");
      gfx.drawStr(195,59, "z");
    }
    
    stationStringFormatting(); //Formatujemy stationString wyswietlany przez funkcję Scrollera
    gfx.drawLine(0, 52, 255, 52); // Dolna linia rozdzielajaca
    
    gfx.setFont(spleen6x12PL); 
    gfx.drawStr(135, 63, streamCodec.c_str()); // dopisujemy kodek minimalnie przesuniety o 1px aby zmiescil sie napis numeru banku
    String displayString = String(SampleRate) + "." + String(SampleRateRest) + "kHz " + bitsPerSampleString + "bit " + bitrateString + "kbps";
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(0, 63, displayString.c_str());
  }
  
  else if (displayMode == 1) // ZEGAR - Tryb wświetlania zegara z 1 linijką radia na dole
  {
    gfx.clearBuffer();
    gfx.setDrawColor(1);
    gfx.setFont(spleen6x12PL);
    gfx.drawLine(0, 50, 255, 50); // Linia separacyjna zegar, dolna linijka radia

    // Logo 3xZZZ w trybie dla timera SLEEP
    if (f_sleepTimerOn) 
    {
      gfx.setFont(u8g2_font_04b_03_tr); 
      gfx.drawStr(200,47, "z");
      gfx.drawStr(203,45, "z");
      gfx.drawStr(206,43, "z");
      
    }
    
    // --- GŁOSNIKCZEK I POZIOM GŁOSOSCI ---
    gfx.setFont(spleen6x12PL);
    gfx.drawGlyph(215,47, 0x9E); // 0x9E w czionce Spleen to zakodowany symbol głosniczka
    gfx.drawStr(223,47, String(volumeValue).c_str());

    stationStringFormatting(); //Formatujemy stationString wyswietlany przez funkcję Scrollera  
  }
  
  else if (displayMode == 2) // 3 LINIE - Tryb wświetlania mode 2 - 3 linijki tekstu, bez przewijania-scroll
  {
    gfx.clearBuffer();
    gfx.setFont(spleen6x12PL);
        
    if (!urlPlaying) 
    {
      gfx.drawStr(23, 11, stationName.substring(0, stationNameLenghtCut).c_str()); // Przyciecie i wyswietlenie dzieki temu nie zmieniamy zawartosci zmiennej stationName
      gfx.drawRBox(1, 1, 18, 13, 4);  // Rbox pod numerem stacji
    }
    else // gramy z URL powiekszamy pole od numer stacji aby zmiescil sie napis URL
    {
      gfx.drawStr(29, 11, stationName.substring(0, stationNameLenghtCut).c_str()); // Przyciecie i wyswietlenie dzieki temu nie zmieniamy zawartosci zmiennej stationName
      gfx.drawRBox(1, 1, 24, 13, 4);  // Rbox pod numerem stacji
    }

    // Funkcja wyswietlania numeru Banku na dole ekranu
    char BankStr[8];  
    snprintf(BankStr, sizeof(BankStr), "B-%02d", bank_nr); // Formatujemy numer banku do postacji 00

    // Wyswietlamy numer Banku w dolnej linijce
    if (!urlPlaying) 
    {
      gfx.drawBox(161, 54, 1, 12);  // dorysowujemy 1px pasek przed napisem "Bank" dla symetrii
      gfx.setDrawColor(0);
      gfx.setCursor(162, 63);  // Pozycja napisu Bank0x na dole ekranu
      gfx.print(BankStr);
    } //else {gfx.print("URL");}
   
    gfx.setDrawColor(0);
    char StationNrStr[3];
    snprintf(StationNrStr, sizeof(StationNrStr), "%02d", station_nr);  //Formatowanie informacji o stacji i banku do postaci 00
                                                // Pozycja numeru stacji na gorze po lewej ekranu
    if (!urlPlaying) { gfx.setCursor(4, 11); gfx.print(StationNrStr);} else { gfx.setCursor(5, 12); gfx.print("URL");}
    gfx.setDrawColor(1);

    // Logo 3xZZZ w trybie dla timera SLEEP
    if (f_sleepTimerOn) 
    {
      gfx.setFont(u8g2_font_04b_03_tr); 
      gfx.drawStr(189,63, "z");
      gfx.drawStr(192,61, "z");
      gfx.drawStr(195,59, "z");
    }

    stationStringFormatting(); //Formatujemy stationString wyswietlany przez funkcję Scrollera

    gfx.drawLine(0, 52, 255, 52);
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(135, 63, streamCodec.c_str()); // dopisujemy kodek minimalnie przesuniety o 1px aby zmiescil sie napis numeru banku
    String displayString = String(SampleRate) + "." + String(SampleRateRest) + "kHz " + bitsPerSampleString + "bit " + bitrateString + "kbps";
    gfx.drawStr(0, 63, displayString.c_str());  
  }
  
  else if (displayMode == 3) // Tryb wświetlania mode 3 - Wyjustowany do srodka, linijka statusu (stacja, bank godzina) na gorze i na dole (format stream, wifi zasieg)
  {
    gfx.clearBuffer();
        
    //-- "IKONA" SLEEP TIMER -- 
    if (f_sleepTimerOn)
    {
      gfx.setFont(u8g2_font_04b_03_tr); 
      gfx.drawStr(165,10, "z");
      gfx.drawStr(168,8, "z");
      gfx.drawStr(171,6, "z");
    }
    
    // -- IKONA VOLUME I WARTOSC --    
    gfx.setFont(spleen6x12PL);
    gfx.drawGlyph(180,10, 0x9E); // 0x9E w czionce Spleen to zakodowany symbol głosniczka
    gfx.drawStr(189,10, String(volumeValue).c_str());        
    
    
    // -- LOGO FLAC/MP3/AACi BITRATE --
    gfx.setFont(mono04b03b); // szerokosc 5, wysokosc 6
    uint8_t x_codec = 103;  // Koordynata X dla informacji o kodeku
    
    if (!f_simpleMode3) {x_codec = 47;}
    
    if (flac == true || opus == true) 
    {
      if (gfx.getStrWidth(bitrateString.c_str()) > 19) {gfx.drawFrame(x_codec,2,45,9);}  // 128 ->18px, regulujemy ranke w zaleznosci czy bitrate ma 4 czy 3 cyfry
      else { gfx.drawFrame(x_codec,2,39,9);}
      
      gfx.drawBox(x_codec+1,2,21,9);
      gfx.setDrawColor(0);
      gfx.drawStr(x_codec+2,9, streamCodec.c_str());
      gfx.setDrawColor(1);
      gfx.drawStr(x_codec+23,9, bitrateString.c_str());
    } else 
    {
      gfx.drawFrame(x_codec+6,2,38,9);
      gfx.drawBox(x_codec+6,2,19,9);
      gfx.setDrawColor(0);
      gfx.drawStr(x_codec+8,9, streamCodec.c_str());
      gfx.setDrawColor(1);
      gfx.drawStr(x_codec+27,9, bitrateString.c_str());
    }

    // -- WYSWIETL NUMER BANKU i STACJI --
    gfx.setFont(spleen6x12PL);
    gfx.setCursor(1, 10);
    
    if (!urlPlaying) // Jesli nie gramy z adresu URL wyslanego ze strony www
    {       
      char StationNrStr[3]; snprintf(StationNrStr, sizeof(StationNrStr), "%02d", station_nr);  //Formatowanie informacji o stacji i banku do postaci 00
      
      if (f_simpleMode3)
      {
        char BankStr[8]; snprintf(BankStr, sizeof(BankStr), "%1d", bank_nr); // Formatujemy numer banku
        gfx.print("CH.");   
        gfx.print(BankStr);
        //gfx.print(".");
        gfx.setFont(spleen6x12PL);
        gfx.print(StationNrStr);
      }
      else
      {
        char BankStr[8]; snprintf(BankStr, sizeof(BankStr), "%02d", bank_nr); // Formatujemy numer banku do postacji 00
        gfx.print("BANK:");
        gfx.print(BankStr);     
        gfx.setCursor(99, 10);
        gfx.print("STATION:");
        gfx.print(StationNrStr);
      }
    }
    else
    { 
      if (f_simpleMode3) {gfx.print("URL");} else {gfx.setCursor(119, 10); gfx.print("URL");}
    }
   
    //gfx.setFont(u8g2_font_helvB14_tr);
    //gfx.setFont(u8g2_font_fub14_tr);
    //gfx.setFont(u8g2_font_smart_patrol_nbp_tf);
    gfx.setFont(u8g2_font_UnnamedDOSFontIV_tr);
    int stationNameWidth = gfx.getStrWidth(stationName.substring(0, stationNameLenghtCut).c_str()); // Liczy pozycje aby wyswietlic stationName na wycentrowane środku
    int stationNamePositionX = (256 - stationNameWidth) / 2;
    
    gfx.drawStr(stationNamePositionX, stationNamePositionYmode3, stationName.substring(0, stationNameLenghtCut).c_str()); // Przyciecie i wyswietlenie dzieki temu nie zmieniamy zawartosci zmiennej stationName

    stationStringFormatting(); //Formatujemy stationString wyswietlany przez funkcję Scrollera
    gfx.setFont(spleen6x12PL);
  }

  else if (displayMode == 4) // Duze wskazniki VU - nie wyswietlamy zadnych informacji o stacji radiowej tylko wskazniki VU i odsweizenie dla www
  {
    gfx.clearBuffer();
    gfx.setFont(spleen6x12PL);
  }
  
  else if (displayMode == 5) // Duze paski VU
  {
   gfx.clearBuffer();
   stationStringFormatting(); 
  }
  
  else if(displayMode == 6)  // Radio info
  {
    gfx.clearBuffer();
    stationStringFormatting(); 
    displayInfo();
  }

  else if (displayMode == 7) // Tryb testowy dla wysweitlacza 128x64
  {
    gfx.clearBuffer();
    
    gfx.drawLine(128,0,128,64); // Lnia testowa wyznaczajaca wirtualnie rozmiar ekranu
    
    gfx.drawLine(13,5,46,5); 
    gfx.drawLine(82,5,115,5);
    
    gfx.setFont(spleen6x12PL);
    int stationNameWidth = gfx.getStrWidth(stationName.substring(0, stationNameLenghtCut - 2).c_str()); // Liczy pozycje aby wyswietlic stationName na wycentrowane środku
    int stationNamePositionX = (127 - stationNameWidth) / 2;
    gfx.drawStr(stationNamePositionX, 22, stationName.substring(0, stationNameLenghtCut - 2).c_str());
        
    gfx.setFont(u8g2_font_04b_03_tr);
    char BankStr[8];  
    char StationNrStr[3];
    snprintf(BankStr, sizeof(BankStr), "%02d", bank_nr); // Formatujemy numer banku do postacji 00
    snprintf(StationNrStr, sizeof(StationNrStr), "%02d", station_nr);  //Formatowanie informacji o stacji i banku do postaci 00
        
    gfx.drawRBox(0, 0, 13, 10, 3);  // Biały kwadrat (tło) pod numerem stacji
    gfx.drawRBox(115, 0, 13, 10, 3);  // Biały kwadrat (tło) pod numerem stacji
    if (!urlPlaying) 
    {
      //gfx.drawBox(87, 58, 1, 5);  // dorysowujemy 1px pasek przed napisem "Bank" dla symetrii
      gfx.setDrawColor(0);
      //gfx.setCursor(88,63);  // Pozycja napisu Bank0x na dole ekranu
      gfx.setCursor(117,8);  // Pozycja napisu Bank0x na dole ekranu
      gfx.print(BankStr);
    }
   
       
    // Pozycja numeru stacji na gorze po lewej ekranu
    if (!urlPlaying) 
    {
      //gfx.setFont(spleen6x12PL);
      gfx.setCursor(2, 8);
      //gfx.print("Station:");  
      gfx.print(StationNrStr);
    } 
    else 
    {
      gfx.setCursor(1, 10);
      gfx.setFont(spleen6x12PL);
      gfx.print("URL");
    }
    gfx.setDrawColor(1);
      
    // Logo 3xZZZ w trybie dla timera SLEEP
    if (f_sleepTimerOn) 
    {
      gfx.setFont(u8g2_font_04b_03_tr); 
      gfx.drawStr(189,63, "z");
      gfx.drawStr(192,61, "z");
      gfx.drawStr(195,59, "z");
    }
    
    stationStringFormatting(); //Formatujemy stationString wyswietlany przez funkcję Scrollera
    gfx.drawLine(0, 54, 127, 54); // Dolna linia rozdzielajaca
    
    
    
    gfx.setFont(u8g2_font_04b_03_tr); 
    //gfx.drawStr(42, 63, String(bitrateString + "k").c_str());
    //gfx.drawStr(65, 63, streamCodec.c_str()); // dopisujemy kodek minimalnie przesuniety o 1px aby zmiescil sie napis numeru banku
       

    String displayString = String(SampleRate) + "." + String(SampleRateRest) + "kHz " + bitsPerSampleString +"bit " + bitrateString + "kbps  ";
    //gfx.setFont(u8g2_font_04b_03_tr);
    gfx.setCursor(0, 63);
    //gfx.drawStr(0, 63, displayString.c_str());
    gfx.print(displayString);

    gfx.setFont(mono04b03b);
    gfx.print(String(streamCodec));

  }  

 

}


String evoMetaAsciiQuotes(String s)
{
  // Zamiana typograficznych cudzyslowow/apostrofow na zwykle ASCII.
  // Bez tej funkcji kompilator zatrzymywal sie w evoMetaClean().
  s.replace("’", "'");
  s.replace("‘", "'");
  s.replace("´", "'");
  s.replace("`", "'");
  s.replace("“", "\"");
  s.replace("”", "\"");
  s.replace("„", "\"");
  s.replace("«", "\"");
  s.replace("»", "\"");
  return s;
}

String evoMetaClean(String s)
{
  s = evoMetaAsciiQuotes(s);
  s.replace("\r", " ");
  s.replace("\n", " ");
  s.replace("\\'", "'");
  s.replace("&apos;", "'");
  s.replace("&quot;", "'");
  s.replace("&#39;", "'");
  s.replace("&#039;", "'");
  s.replace("&amp;", "&");
  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  s.trim();
  return s;
}

String evoMetaExtractValue(String src, const char *key)
{
  String s = evoMetaClean(src);
  String low = s;
  low.toLowerCase();
  String k = String(key);
  k.toLowerCase();

  int p = low.indexOf(k);
  if (p < 0) return "";
  p += k.length();

  while (p < s.length())
  {
    char c = s.charAt(p);
    if (c == ':' || c == '=' || c == ' ' || c == '\t') p++;
    else break;
  }

  if (p >= s.length()) return "";

  if (s.charAt(p) == '\'')
  {
    int end = s.indexOf("'", p + 1);
    if (end < 0) end = s.length();
    return evoMetaClean(s.substring(p + 1, end));
  }

  int end = s.indexOf(';', p);
  if (end < 0) end = s.indexOf('|', p);
  if (end < 0) end = s.length();
  return evoMetaClean(s.substring(p, end));
}

String evoMetaValueAfterPrefix(String src, const char *prefix)
{
  String s = evoMetaClean(src);
  String low = s;
  low.toLowerCase();
  String pfx = String(prefix);
  pfx.toLowerCase();
  if (!low.startsWith(pfx)) return "";

  int p = pfx.length();
  while (p < s.length())
  {
    char c = s.charAt(p);
    if (c == ':' || c == '=' || c == ' ' || c == '\t') p++;
    else break;
  }
  return evoMetaClean(s.substring(p));
}

bool evoMetaSameText(String a, String b)
{
  a = evoMetaClean(a);
  b = evoMetaClean(b);
  a.toLowerCase();
  b.toLowerCase();
  return (a.length() > 0 && a == b);
}

bool evoMetaLooksLikeStationOnly(String s)
{
  String clean = evoMetaClean(s);
  if (clean.length() == 0) return true;
  if (evoMetaSameText(clean, stationNameStream)) return true;
  if (evoMetaSameText(clean, tftStationName())) return true;
  if (evoMetaSameText(clean, stationName)) return true;
  return false;
}

String evoMetaNormalizeNowPlaying(String raw)
{
  String s = evoMetaClean(raw);
  if (s.length() == 0) return "";

  String streamTitle = evoMetaExtractValue(s, "StreamTitle");
  if (streamTitle.length()) s = streamTitle;

  String titleFromKey = evoMetaExtractValue(s, "Title");
  if (!titleFromKey.length()) titleFromKey = evoMetaExtractValue(s, "TIT2");
  if (!titleFromKey.length()) titleFromKey = evoMetaValueAfterPrefix(s, "TIT2");

  String artistFromKey = evoMetaExtractValue(s, "Artist");
  if (!artistFromKey.length()) artistFromKey = evoMetaExtractValue(s, "TPE1");
  if (!artistFromKey.length()) artistFromKey = evoMetaValueAfterPrefix(s, "TPE1");

  if (titleFromKey.length() && artistFromKey.length()) s = artistFromKey + " - " + titleFromKey;
  else if (titleFromKey.length()) s = titleFromKey;

  s.replace("StreamTitle=", "");
  s.replace("StreamTitle:", "");
  s.replace("StreamTitle", "");
  s.replace("Title=", "");
  s.replace("Title:", "");
  s.replace("TIT2=", "");
  s.replace("TIT2:", "");
  s.replace("TPE1=", "");
  s.replace("TPE1:", "");
  s.replace(";", "");
  s.replace("'", "");
  s = evoMetaClean(s);
  return s;
}

void evoMetaSplitArtistTitle(String meta)
{
  evoNowPlayingArtist = "";
  evoNowPlayingTitle = meta;

  int sep = meta.indexOf(" - ");
  int skip = 3;
  if (sep < 0) { sep = meta.indexOf(" – "); skip = 5; }
  if (sep < 0) { sep = meta.indexOf(" — "); skip = 5; }

  if (sep > 0)
  {
    evoNowPlayingArtist = evoMetaClean(meta.substring(0, sep));
    evoNowPlayingTitle = evoMetaClean(meta.substring(sep + skip));
  }
}

void evoAudioClearNowPlaying()
{
  evoNowPlayingRaw = "";
  evoNowPlayingArtist = "";
  evoNowPlayingTitle = "";
  evoNowPlayingText = "";
  evoNowPlayingValid = false;
  evoNowPlayingMs = 0;
  stationString.remove(0);
  stationStringWeb.remove(0);
  stationStringScroll.remove(0);
  stationStringScrollWidth = 0;
  f_audioInfoRefreshStationString = true;
  f_audioInfoRefreshDisplayRadio = true;
  wsAudioRefresh = true;
}

void evoAudioSetNowPlaying(const String &raw)
{
  String meta = evoMetaNormalizeNowPlaying(raw);
  if (tftIsEmptyNowPlayingText(meta)) return;

  // Nie zapisujemy nazwy stacji jako tytulu utworu.
  if (evoMetaLooksLikeStationOnly(meta))
  {
    Serial.printf("audio meta ignored station-only: %s\n", meta.c_str());
    return;
  }

  evoNowPlayingRaw = evoMetaClean(raw);
  evoNowPlayingText = meta;
  evoMetaSplitArtistTitle(meta);
  evoNowPlayingValid = true;
  evoNowPlayingMs = millis();

  // Zostawiamy stare zmienne, bo duza czesc programu i scroller ich uzywa.
  stationString = evoNowPlayingText;
  stationStringWeb = evoNowPlayingText;
  stationStringScroll = evoNowPlayingText + "    ";
  stationStringScrollWidth = stationStringScroll.length() * 6;

  f_audioInfoRefreshStationString = true;
  f_audioInfoRefreshDisplayRadio = true;
  wsAudioRefresh = true;

  Serial.printf("audio nowplaying: %s\n", evoNowPlayingText.c_str());
}

// Obsługa callbacków audio dla ESP32-audioI2S od schreibfaul1.
// Aktualna wersja z GitHuba używa Audio::audio_info_callback + Audio::msg_t.
// Zostawiamy też stare globalne funkcje audio_xxx, bo część starszych wersji biblioteki nadal je wywołuje.
static void evoAudioParseInfoLine(const char *info)
{
  if (!info) return;
  String msg = String(info);
  msg.trim();

  int bitrateIndex = msg.indexOf("Bitrate (b/s):");
  if (bitrateIndex != -1)
  {
    int endIndex = msg.indexOf('\n', bitrateIndex);
    if (endIndex == -1) endIndex = msg.length();
    bitrateString = msg.substring(bitrateIndex + 14, endIndex);
    bitrateString.trim();
    bitrateStringInt = bitrateString.toInt() / 1000;
    bitrateString = String(bitrateStringInt);
    f_audioInfoRefreshDisplayRadio = true;
    wsAudioRefresh = true;
  }

  int sampleRateIndex = msg.indexOf("SampleRate (Hz):");
  if (sampleRateIndex != -1)
  {
    int endIndex = msg.indexOf('\n', sampleRateIndex);
    if (endIndex == -1) endIndex = msg.length();
    sampleRateString = msg.substring(sampleRateIndex + 17, endIndex);
    sampleRateString.trim();
    SampleRate = sampleRateString.toInt();
    SampleRateRest = (SampleRate % 1000) / 100;
    SampleRate = SampleRate / 1000;
    f_audioInfoRefreshDisplayRadio = true;
    wsAudioRefresh = true;
  }

  int bitsPerSampleIndex = msg.indexOf("BitsPerSample:");
  if (bitsPerSampleIndex != -1)
  {
    int endIndex = msg.indexOf('\n', bitsPerSampleIndex);
    if (endIndex == -1) endIndex = msg.length();
    bitsPerSampleString = msg.substring(bitsPerSampleIndex + 15, endIndex);
    bitsPerSampleString.trim();
    f_audioInfoRefreshDisplayRadio = true;
    wsAudioRefresh = true;
  }

  if (msg.indexOf("MP3Decoder") != -1)   { mp3 = true;  flac = false; aac = false; vorbis = false; opus = false; streamCodec = "MP3";  f_audioInfoRefreshDisplayRadio = true; wsAudioRefresh = true; }
  if (msg.indexOf("FLACDecoder") != -1)  { flac = true; mp3 = false;  aac = false; vorbis = false; opus = false; streamCodec = "FLAC"; f_audioInfoRefreshDisplayRadio = true; wsAudioRefresh = true; }
  if (msg.indexOf("AACDecoder") != -1)   { aac = true;  flac = false; mp3 = false;  vorbis = false; opus = false; streamCodec = "AAC";  f_audioInfoRefreshDisplayRadio = true; wsAudioRefresh = true; }
  if (msg.indexOf("VORBISDecoder") != -1){ vorbis=true; aac = false;  flac = false; mp3 = false;  opus = false; streamCodec = "VRB";  f_audioInfoRefreshDisplayRadio = true; wsAudioRefresh = true; }
  if (msg.indexOf("OPUSDecoder") != -1)  { opus = true; vorbis=false; aac = false;  flac = false; mp3 = false;  streamCodec = "OPUS"; f_audioInfoRefreshDisplayRadio = true; wsAudioRefresh = true; }

  String low = msg;
  low.toLowerCase();
  if (low.indexOf("streamtitle") >= 0 || low.indexOf("artist") >= 0 || low.indexOf("title") >= 0 || low.indexOf("tit2") >= 0 || low.indexOf("tpe1") >= 0)
  {
    evoAudioSetNowPlaying(msg);
  }

  Serial.printf("audio info: %s\n", info);
}

void audio_info(const char *info)
{
  evoAudioParseInfoLine(info);
}

void audio_bitrate(const char *info)
{
  if (!info) return;
  bitrateString = String(info);
  bitrateString.trim();
  bitrateStringInt = bitrateString.toInt();
  if (bitrateStringInt > 1000) bitrateStringInt = bitrateStringInt / 1000;
  if (bitrateStringInt > 0) bitrateString = String(bitrateStringInt);
  f_audioInfoRefreshDisplayRadio = true;
  wsAudioRefresh = true;
  Serial.printf("audio bitrate: %s\n", info);
}

void audio_showstation(const char *info)
{
  if (!info) return;
  stationNameStream = String(info);
  stationNameStream.trim();
  if ((urlPlaying) || (stationNameFromStream)) stationName = stationNameStream;
  f_audioInfoRefreshStationString = true;
  wsAudioRefresh = true;
  Serial.printf("audio station: %s\n", info);
}

void audio_showstreamtitle(const char *info)
{
  if (!info) return;
  evoAudioSetNowPlaying(String(info));
  Serial.printf("audio title: %s\n", info);
}

void audio_eof_mp3(const char *info)
{
  Serial.printf("audio eof: %s\n", info ? info : "");
  if (resumePlay == true)
  {
    ir_code = rcCmdOk;
    bit_count = 32;
    calcNec();
    resumePlay = false;
  }
}

void audio_id3data(const char *info)
{
  static String id3Title;
  static String id3Artist;
  if (!info) return;

  String s = evoMetaClean(String(info));
  String low = s;
  low.toLowerCase();

  String val;
  val = evoMetaValueAfterPrefix(s, "title");
  if (val.length()) id3Title = val;
  val = evoMetaValueAfterPrefix(s, "tit2");
  if (val.length()) id3Title = val;
  val = evoMetaValueAfterPrefix(s, "artist");
  if (val.length()) id3Artist = val;
  val = evoMetaValueAfterPrefix(s, "tpe1");
  if (val.length()) id3Artist = val;

  if (low.indexOf("streamtitle") >= 0)
  {
    evoAudioSetNowPlaying(s);
  }
  else if (id3Artist.length() || id3Title.length())
  {
    String meta;
    if (id3Artist.length() && id3Title.length()) meta = id3Artist + " - " + id3Title;
    else meta = id3Title.length() ? id3Title : id3Artist;
    evoAudioSetNowPlaying(meta);
  }

  Serial.printf("audio id3: %s\n", info);
}

void audio_showstreaminfo(const char *info)
{
  if (!info) return;
  evoAudioParseInfoLine(info);
  String s = String(info);
  String low = s;
  low.toLowerCase();
  if (low.indexOf("streamtitle") >= 0 || low.indexOf("title") >= 0 || low.indexOf("artist") >= 0 || low.indexOf("tit2") >= 0 || low.indexOf("tpe1") >= 0)
  {
    evoAudioSetNowPlaying(s);
  }
  Serial.printf("audio streaminfo: %s\n", info);
}
void audio_lasthost(const char *info)      { Serial.printf("audio lasthost: %s\n", info ? info : ""); }
void audio_icyurl(const char *info)        { Serial.printf("audio icyurl: %s\n", info ? info : ""); }
void audio_icydescription(const char *info){ Serial.printf("audio desc: %s\n", info ? info : ""); }



void evoAudioRefreshRuntimeParams()
{
  uint32_t br = audio.getBitRate();
  if (br > 0)
  {
    bitrateStringInt = br / 1000;
    if (bitrateStringInt > 0) bitrateString = String(bitrateStringInt);
  }

  uint32_t sr = audio.getSampleRate();
  if (sr > 0)
  {
    sampleRateString = String(sr);
    SampleRate = sr / 1000;
    SampleRateRest = (sr % 1000) / 100;
  }

  uint8_t bps = audio.getBitsPerSample();
  if (bps > 0) bitsPerSampleString = String(bps);

  const char *codec = audio.getCodecname();
  if (codec && strlen(codec) > 0 && strcmp(codec, "unknown") != 0)
  {
    streamCodec = String(codec);
    mp3 = (streamCodec == "MP3");
    aac = (streamCodec == "AAC" || streamCodec == "M4A");
    flac = (streamCodec == "FLAC");
    vorbis = (streamCodec == "VORBIS" || streamCodec == "OGG");
    opus = (streamCodec == "OPUS");
  }

  f_audioInfoRefreshDisplayRadio = true;
  wsAudioRefresh = true;
}

void evoAudioInfoCallback(Audio::msg_t m)
{
  const char *msg = m.msg ? m.msg : "";

  switch (m.e)
  {
    case Audio::evt_info:
      audio_info(msg);
      break;

    case Audio::evt_bitrate:
      audio_bitrate(msg);
      break;

    case Audio::evt_name:
      audio_showstation(msg);
      break;

    case Audio::evt_streamtitle:
      audio_showstreamtitle(msg);
      break;

    case Audio::evt_id3data:
      audio_id3data(msg);
      break;

    case Audio::evt_eof:
      audio_eof_mp3(msg);
      break;

    case Audio::evt_lasthost:
      audio_lasthost(msg);
      break;

    case Audio::evt_icyurl:
      audio_icyurl(msg);
      break;

    case Audio::evt_icydescription:
      audio_icydescription(msg);
      break;

    case Audio::evt_icylogo:
      Serial.printf("audio logo: %s\n", msg);
      break;

    case Audio::evt_image:
      Serial.printf("audio image: %s\n", msg);
      break;

    case Audio::evt_lyrics:
      evoAudioSetNowPlaying(String(msg));
      Serial.printf("audio lyrics: %s\n", msg);
      break;

    case Audio::evt_log:
      Serial.printf("audio log: %s\n", msg);
      break;

    default:
      Serial.printf("audio cb %s: %s\n", m.s ? m.s : "event", msg);
      break;
  }

  evoAudioRefreshRuntimeParams();
}

void encoderFunctionOrderChange()
{
  displayActive = true;
  displayStartTime = millis();
  volumeSet = false;
  timeDisplay = false;
  bankMenuEnable = false;
  encoderFunctionOrder = !encoderFunctionOrder;
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeEncoderOrder();
  return;
#endif
  gfx.clearBuffer();
  gfx.setFont(spleen6x12PL);
  gfx.drawStr(1,14,"Encoder function order change:");
  if (encoderFunctionOrder == false) {gfx.drawStr(1,28,"Rotate for volume, press for station list");}
  if (encoderFunctionOrder == true ) {gfx.drawStr(1,28,"Rotate for station list, press for volume");}
  gfx.sendBuffer();
}

void bankMenuDisplay()
{
  if (bank_nr < 1) {bank_nr = 1;}
  const uint8_t cornerRadius = 3;
  float segmentWidth = (float)212 / bank_nr_max;

  displayStartTime = millis();
  Serial.println("debug -> BankMenuDisplay");
  volumeSet = false;
  bankMenuEnable = true;
  timeDisplay = false;
  displayActive = true;
  //currentOption = BANK_LIST;  // Ustawienie listy banków do przewijania i wyboru
  String bankNrStr = String(bank_nr);
  Serial.println("debug -> Wyświetlenie listy banków");
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeBankMenu();
  return;
#endif
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf);
  gfx.drawStr(80, 33, "BANK ");
  gfx.drawStr(145, 33, String(bank_nr).c_str());  // numer banku
  //if ((bankNetworkUpdate == true) || (noSDcard == true))
  if ((bankNetworkUpdate == true) || (storageTextName == "EEPROM"))
  {
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(185, 24, "NETWORK ");
    gfx.drawStr(188, 34, "UPDATE  ");
    
    //if (noSDcard == true)
    if (storageTextName == "EEPROM")
    {
      //gfx.drawStr(24, 24, "NO SD");
      gfx.drawStr(24, 34, "NO CARD");
    }
  
  }
  
  gfx.drawRFrame(21, 42, 214, 14, cornerRadius);                // Ramka do slidera bankow
    
  uint16_t sliderX = 23 + (uint16_t)round((bank_nr - 1)* segmentWidth); // Przeliczenie zmiennej X z zaokragleniemw  gore dla położenia slidera
  uint16_t sliderWidth = (uint16_t)round(segmentWidth - 2); // Przliczenie szwerokości slidera w zaleznosci od ilosi banków
  gfx.drawRBox(sliderX, 44, sliderWidth, 10, 2);

  //gfx.drawRBox((bank_nr * 13) + 10, 44, 15, 10, 2);  // wypełnienie slidera Rbox dla stałej wartosci max_bank = 16, stara wersja
  gfx.sendBuffer();
  
}

// =========== Funkcja do obsługi przycisków enkoderów, debouncing i długiego naciśnięcia ==============//
void handleButtons() 
{
  static unsigned long buttonPressTime2 = 0;  // Zmienna do przechowywania czasu naciśnięcia przycisku enkodera 2
  static bool isButton2Pressed = false;       // Flaga do śledzenia, czy przycisk enkodera 2 jest wciśnięty
  static bool action2Taken = false;           // Flaga do śledzenia, czy akcja dla enkodera 2 została wykonana

  static unsigned long lastPressTime2 = 0;  // Zmienna do kontrolowania debouncingu (ostatni czas naciśnięcia)
  const unsigned long debounceDelay2 = 50;  // Opóźnienie debouncingu

  // ===== Obsługa przycisku enkodera 2 =====
  int reading2 = digitalRead(SW_PIN2);

  // Debouncing dla przycisku enkodera 2
  if (reading2 == LOW)  // Przycisk jest wciśnięty (stan niski)
  {
    if (millis() - lastPressTime2 > debounceDelay2) 
    {
      lastPressTime2 = millis();  // Aktualizujemy czas ostatniego naciśnięcia
      // Sprawdzamy, czy przycisk był wciśnięty przez 3 sekundy
      if (!isButton2Pressed) 
      {
        buttonPressTime2 = millis();  // Ustawiamy czas naciśnięcia
        isButton2Pressed = true;      // Ustawiamy flagę, że przycisk jest wciśnięty
        action2Taken = false;         // Resetujemy flagę akcji dla enkodera 2
        action3Taken = false;         // Resetujmy flage akcji Super długiego wcisniecia enkodera 2
        volumeSet = false;
      }

      if (millis() - buttonPressTime2 >= buttonLongPressTime2 && millis() - buttonPressTime2 >= buttonSuperLongPressTime2 && action3Taken == false) 
      {
        ir_code = rcCmdPower; // Udajemy kod pilota Back
        bit_count = 32;
        calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC
        action3Taken = true;
      }


      // Jeśli przycisk jest wciśnięty przez co najmniej 3 sekundy i akcja jeszcze nie była wykonana
      if (millis() - buttonPressTime2 >= buttonLongPressTime2 && !action2Taken && millis() - buttonPressTime2 < buttonSuperLongPressTime2) {
        Serial.println("debug--Bank Menu");
        bankMenuDisplay();
        
        // Ustawiamy flagę akcji, aby wykonała się tylko raz
        action2Taken = true;
      }
    }
  } 
  else 
  {
    isButton2Pressed = false;  // Resetujemy flagę naciśnięcia przycisku enkodera 2
    action2Taken = false;      // Resetujemy flagę akcji dla enkodera 2
    action3Taken = false;
  }

    
  #ifdef twoEncoders

    static unsigned long buttonPressTime1 = 0;  // Zmienna do przechowywania czasu naciśnięcia przycisku enkodera 2
    static bool isButton1Pressed = false;       // Flaga do śledzenia, czy przycisk enkodera 2 jest wciśnięty
    
    static unsigned long lastPressTime1 = 0;  // Zmienna do kontrolowania debouncingu (ostatni czas naciśnięcia)
    const unsigned long debounceDelay1 = 50;  // Opóźnienie debouncingu

    // ===== Obsługa przycisku enkodera 1 =====
    int reading1 = digitalRead(SW_PIN1);
    // Debouncing dla przycisku enkodera 1

    if (reading1 == LOW)  // Przycisk jest wciśnięty (stan niski)
    {
      if (millis() - lastPressTime1 > debounceDelay1) 
      {
        lastPressTime1 = millis();  // Aktualizujemy czas ostatniego naciśnięcia

        // Sprawdzamy, czy przycisk był wciśnięty przez 3 sekundy
        if (!isButton1Pressed) 
        {
          buttonPressTime1 = millis();  // Ustawiamy czas naciśnięcia
          isButton1Pressed = true;      // Ustawiamy flagę, że przycisk jest wciśnięty
          action4Taken = false;         // Resetujemy flagę akcji dla enkodera 2
        }
        
        
        if (millis() - buttonPressTime1 >= buttonLongPressTime1 && millis() - buttonPressTime1 >= buttonSuperLongPressTime1 && action4Taken == false) 
        {
          ir_code = rcCmdPower; // Udajemy kod pilota Back
          bit_count = 32;
          calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC      
          action4Taken = true;
        }
        /*
        if (millis() - buttonPressTime1 >= buttonLongPressTime1 && !action5Taken && millis() - buttonPressTime1 < buttonSuperLongPressTime1) 
        {
          bankMenuDisplay();
          // Ustawiamy flagę akcji, aby wykonała się tylko raz
          action5Taken = true;
        }
        */
      }
    }  
    else
    {
      isButton1Pressed = false;  // Resetujemy flagę naciśnięcia przycisku enkodera 1
      action4Taken = false;
      action5Taken = false;
    }     
  #endif
  



}

int maxSelection() 
{
  //if (currentOption == INTERNET_RADIO) 
  //{
    return stationsCount - 1;
  //} 
  //return 0;  // Zwraca 0, jeśli żaden warunek nie jest spełniony
}

// Funkcja do przewijania w dół
void scrollDown() 
{
  if (currentSelection < maxSelection()) 
  {
    currentSelection++;
    if (currentSelection >= firstVisibleLine + maxVisibleLines) 
    {
      firstVisibleLine++;
    }
  }
    else
  {
    // Jeśli osiągnięto maksymalną wartość, przejdź do najmniejszej (0)
    currentSelection = 0;
    firstVisibleLine = 0; // Przywróć do pierwszej widocznej linii
  }
    
  Serial.print("Scroll Down: CurrentSelection = ");
  Serial.println(currentSelection);
}

// Funkcja do przewijania w górę
void scrollUp() 
{
  if (currentSelection > 0) 
  {
    currentSelection--;
    if (currentSelection < firstVisibleLine) 
    {
      firstVisibleLine = currentSelection;
    }
  }
  else
  {
    // Jeśli osiągnięto wartość 0, przejdź do najwyższej wartości
    currentSelection = maxSelection(); 
    firstVisibleLine = currentSelection - maxVisibleLines + 1; // Ustaw pierwszą widoczną linię na najwyższą
  }
  
  Serial.print("Scroll Up: CurrentSelection = ");
  Serial.println(currentSelection);
}

void readVolumeFromSD() 
{
  // Sprawdź, czy karta SD jest dostępna
  //if (!STORAGE.begin(SD_CS)) 
  if (!STORAGE_BEGIN())
  {
    Serial.println("debug SD -> Nie można znaleźć karty SD, ustawiam wartość Volume z EEPROMu.");
    Serial.print("debug vol -> Wartość Volume: ");
    EEPROM.get(2, volumeValue);
    if (volumeValue > maxVolume) {volumeValue = 10;} // zabezpiczenie przed pusta komorka EEPROM o wartosci FF (255)
    
    if (f_volumeFadeOn == false) {audio.setVolume(volumeValue);}  // zakres 0...21...42
    volumeBufferValue = volumeValue; 
    
    Serial.println(volumeValue);
    return;
  }
  // Sprawdź, czy plik volume.txt istnieje
  if (STORAGE.exists("/volume.txt")) 
  {
    myFile = STORAGE.open("/volume.txt");
    if (myFile) 
    {
      volumeValue = myFile.parseInt();
	    myFile.close();
      
      Serial.print("debug SD -> Wczytano volume.txt z karty SD, wartość odczytana: ");
      Serial.println(volumeValue);    
    } 
	  else 
	  {
      Serial.println("debug SD -> Błąd podczas otwierania pliku volume.txt");
    }
  } 
  else 
  {
    Serial.print("debug SD -> Plik volume.txt nie istnieje, wartość Volume domyślna: ");
	  Serial.println(volumeValue);    
  }
  if (volumeValue > maxVolume) {volumeValue = 10;}  // Ustawiamy bezpieczną wartość
  //audio.setVolume(volumeValue);  // zakres 0...21...42
  volumeBufferValue = volumeValue;
}

void saveVolumeOnSD() 
{
  volumeBufferValue = volumeValue; // Wyrownanie wartosci bufora Volume i Volume przy zapisie
  
  // Sprawdź, czy plik volume.txt istnieje
  Serial.print("debug SD -> Zaspis do pliku wartosci Volume: ");
  Serial.println(volumeValue); 
  
  // Sprawdź, czy plik istnieje
  if (STORAGE.exists("/volume.txt")) 
  {
    Serial.println("debug SD -> Plik volume.txt już istnieje.");

    // Otwórz plik do zapisu i nadpisz aktualną wartość flitrów equalizera
    myFile = STORAGE.open("/volume.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println(volumeValue);
      myFile.close();
      Serial.println("debug SD -> Aktualizacja volume.txt na karcie SD");
    } 
	  else 
	  {
      Serial.println("debug SD -> Błąd podczas otwierania pliku volume.txt.");
    }
  } 
  else 
  {
    Serial.println("debug SD -> Plik volume.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualną wartość głośności
    myFile = STORAGE.open("/volume.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println(volumeValue);
      myFile.close();
      Serial.println("debug SD -> Utworzono i zapisano volume.txt na karcie SD");
    } 
    else 
    {
      Serial.println("debug SD -> Błąd podczas tworzenia pliku volume.txt.");
    }
  }
  if (noSDcard == true) {EEPROM.write(2,volumeValue); EEPROM.commit(); Serial.println("debug eeprom -> Zapis volume do EEPROM");}
}

void drawSignalPower(uint8_t xpwr, uint8_t ypwr, bool print, bool mode)
{
  // Wartosci na podstawie ->  https://www.intuitibits.com/2016/03/23/dbm-to-percent-conversion/
  int signal_dBM[] = { -100, -99, -98, -97, -96, -95, -94, -93, -92, -91, -90, -89, -88, -87, -86, -85, -84, -83, -82, -81, -80, -79, -78, -77, -76, -75, -74, -73, -72, -71, -70, -69, -68, -67, -66, -65, -64, -63, -62, -61, -60, -59, -58, -57, -56, -55, -54, -53, -52, -51, -50, -49, -48, -47, -46, -45, -44, -43, -42, -41, -40, -39, -38, -37, -36, -35, -34, -33, -32, -31, -30, -29, -28, -27, -26, -25, -24, -23, -22, -21, -20, -19, -18, -17, -16, -15, -14, -13, -12, -11, -10, -9, -8, -7, -6, -5, -4, -3, -2, -1};
  int signal_percent[] = {0, 0, 0, 0, 0, 0, 4, 6, 8, 11, 13, 15, 17, 19, 21, 23, 26, 28, 30, 32, 34, 35, 37, 39, 41, 43, 45, 46, 48, 50, 52, 53, 55, 56, 58, 59, 61, 62, 64, 65, 67, 68, 69, 71, 72, 73, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 90, 91, 92, 93, 93, 94, 95, 95, 96, 96, 97, 97, 98, 98, 99, 99, 99, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100, 100};

  int signalpwr = WiFi.RSSI();
  //uint8_t wifiSignalLevel = 0;
    
  
  // Pionowe kreseczki, szerokosc 11px
  
  // Czyscimy obszar pod kreseczkami
  gfx.setDrawColor(0);
  gfx.drawBox(xpwr,ypwr-10,11,11);
  gfx.setDrawColor(1);

  
  // Rysowanie antenki
  int x = xpwr - 3; 
  int y = ypwr - 8;
  gfx.drawLine(x,y,x,y+7); // kreska srodkowa
  gfx.drawLine(x,y+4,x-3,y); // lewe ramie
  gfx.drawLine(x,y+4,x+3,y); // prawe ramie


  // Rysujemy podstawy 1x1px pod kazdą kreseczką
  gfx.drawBox(xpwr,ypwr - 1, 1, 1);
  gfx.drawBox(xpwr + 2, ypwr - 1, 1, 1);
  gfx.drawBox(xpwr + 4, ypwr - 1, 1, 1);
  gfx.drawBox(xpwr + 6, ypwr - 1, 1, 1);
  gfx.drawBox(xpwr + 8, ypwr - 1, 1, 1);
  gfx.drawBox(xpwr + 10, ypwr - 1, 1, 1);

 if ((WiFi.status() == WL_CONNECTED) && (mode == 0))
 {
      // Rysujemy kreseczki
    if (signalpwr > -88) { wifiSignalLevel = 1; gfx.drawBox(xpwr, ypwr - 2, 1, 1); }     // 0-14
    if (signalpwr > -81) { wifiSignalLevel = 2; gfx.drawBox(xpwr + 2, ypwr - 3, 1, 2); } // > 28
    if (signalpwr > -74) { wifiSignalLevel = 3; gfx.drawBox(xpwr + 4, ypwr - 4, 1, 3); } // > 42
    if (signalpwr > -66) { wifiSignalLevel = 4; gfx.drawBox(xpwr + 6, ypwr - 5, 1, 4); } // > 56
    if (signalpwr > -57) { wifiSignalLevel = 5; gfx.drawBox(xpwr + 8, ypwr - 6, 1, 5); } // > 70
    if (signalpwr > -50) { wifiSignalLevel = 6; gfx.drawBox(xpwr + 10, ypwr - 8, 1, 7);} // > 84
  }

  if ((WiFi.status() == WL_CONNECTED) && (mode == 1))
  {
      // Rysujemy kreseczki
    if (signalpwr > -88) { wifiSignalLevel = 1; gfx.drawBox(xpwr, ypwr - 2, 1, 1); }     // 0-14
    if (signalpwr > -81) { wifiSignalLevel = 2; gfx.drawBox(xpwr + 2, ypwr - 3, 1, 2); } // > 28
    if (signalpwr > -74) { wifiSignalLevel = 3; gfx.drawBox(xpwr + 4, ypwr - 4, 1, 3); } // > 42
    if (signalpwr > -66) { wifiSignalLevel = 4; gfx.drawBox(xpwr + 6, ypwr - 5, 1, 4); } // > 56
    if (signalpwr > -57) { wifiSignalLevel = 5; gfx.drawBox(xpwr + 8, ypwr - 6, 1, 5); } // > 70
    if (signalpwr > -50) { wifiSignalLevel = 6; gfx.drawBox(xpwr + 10, ypwr - 7, 1, 6);} // > 84
  }


  if (print == true) // Jesli flaga print =1 to wypisujemy na serialu sile sygnału w % i w skali 1-6
  {
    for (int j = 0; j < 100; j++) 
    {
      if (signal_dBM[j] == signalpwr) 
      {
        Serial.print("debug WiFi -> Sygnału WiFi: ");
        Serial.print(signal_percent[j]);
        Serial.print("%  Poziom: ");
        Serial.print(wifiSignalLevel);
        Serial.print("   dBm: ");
        Serial.println(signalpwr);
        
        break;
      }
    }
  }
}


void rcInputKey(uint8_t i)
{
  rcInputDigitsMenuEnable = true;
  if (bankMenuEnable == true)
  {
    
    if (i == 0) {i = 10;}
    bank_nr = i;
    bankMenuDisplay();
  }
  else
  {
    timeDisplay = false;
    displayActive = true;
    displayStartTime = millis(); 
    
    if (rcInputDigit1 == 0xFF)
    {
      rcInputDigit1 = i;
    }
    else 
    {
      rcInputDigit2 = i;
    }

    int y = 35;
    gfx.clearBuffer();
    gfx.setFont(u8g2_font_fub14_tf); // cziocnka 14x11
    gfx.drawStr(65, y, "Station:"); 
    if (rcInputDigit1 != 0xFF)
    {gfx.drawStr(153, y, String(rcInputDigit1).c_str());} 
    //else {gfx.drawStr(153, x,"_" ); }
    else {gfx.drawStr(153, y,"_" ); }
    
    if (rcInputDigit2 != 0xFF)
    {gfx.drawStr(164, y, String(rcInputDigit2).c_str());} 
    else {gfx.drawStr(164, y,"_" ); }



    if ((rcInputDigit1 != 0xFF) && (rcInputDigit2 != 0xFF)) // jezeli obie wartosci nie są puste
    {
      station_nr = (rcInputDigit1 *10) + rcInputDigit2;
    }
    else if ((rcInputDigit1 != 0xFF) && (rcInputDigit2 == 0xFF))  // jezeli tylko podalismy jedna cyfrę
    { 
      station_nr = rcInputDigit1;
    }

    if (station_nr > stationsCount)  // sprawdzamy czy wprowadzona wartość nie wykracza poza licze stacji w danym banku
    {
      station_nr = stationsCount;  // jesli wpisana wartość jest wieksza niz ilosc stacji to ustawiamy war
    }
    
    if (station_nr < 1)
    {
      station_nr = stationFromBuffer;
    }

    // Odczyt stacji pod daną komórka pamieci PSRAM:
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych
    int length = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1)];   // Odczytaj długość nazwy stacji z PSRAM dla bieżącego indeksu stacji
    
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) { // Odczytaj nazwę stacji z PSRAM jako ciąg bajtów, maksymalnie do STATION_NAME_LENGTH
      station[j] = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }
    gfx.setFont(spleen6x12PL);
    String stationNameText = String(station);
    stationNameText = stationNameText.substring(0, 25); // Przycinamy do 23 znakow

    gfx.drawLine(0,48,256,48);
    gfx.setFont(spleen6x12PL);
    gfx.setCursor(0, 60);
    gfx.print("Bank:" + String(bank_nr) + ", 1-" + String(stationsCount) + "     " + stationNameText);
    gfx.sendBuffer();

    if ((rcInputDigit1 !=0xFF) && (rcInputDigit2 !=0xFF)) // jezeli wpisalismy obie cyfry to czyscimy pola aby mozna bylo je wpisac ponownie
    {
      rcInputDigit1 = 0xFF; // czyscimy cyfre 1, flaga pustej zmiennej F aby naciskajac kolejny raz mozna bylo wypisac cyfre bez czekania 6 sek
      rcInputDigit2 = 0xFF; // czyscimy cyfre 2, flaga pustej zmiennej F
    }
  }
  #ifdef IR_LED
    irLedBlink(); 
  #endif 
}

// Funkcja do zapisywania numeru stacji i numeru banku na karcie SD
void saveStationOnSD() 
{
  if ((station_nr !=0) && (bank_nr != 0))
  {
    // Sprawdź, czy plik station_nr.txt istnieje

    Serial.print("debug SD -> Zapisujemy bank: ");
    Serial.println(bank_nr);
    Serial.print("debug SD -> Zapisujemy stacje: ");
    Serial.println(station_nr);

    // Sprawdź, czy plik station_nr.txt istnieje
    if (STORAGE.exists("/station_nr.txt")) {
      Serial.println("debug SD -> Plik station_nr.txt już istnieje.");

      // Otwórz plik do zapisu i nadpisz aktualną wartość station_nr
      myFile = STORAGE.open("/station_nr.txt", FILE_WRITE);
      if (myFile) {
        myFile.println(station_nr);
        myFile.close();
        Serial.println("debug SD -> Aktualizacja station_nr.txt na karcie SD");
      } else {
        Serial.println("debug SD -> Błąd podczas otwierania pliku station_nr.txt.");
      }
    } else {
      Serial.println("debug SD -> Plik station_nr.txt nie istnieje. Tworzenie...");

      // Utwórz plik i zapisz w nim aktualną wartość station_nr
      myFile = STORAGE.open("/station_nr.txt", FILE_WRITE);
      if (myFile) {
        myFile.println(station_nr);
        myFile.close();
        Serial.println("debug SD -> Utworzono i zapisano station_nr.txt na karcie SD");
      } else {
        Serial.println("debug SD -> Błąd podczas tworzenia pliku station_nr.txt.");
      }
    }

    // Sprawdź, czy plik bank_nr.txt istnieje
    if (STORAGE.exists("/bank_nr.txt")) 
    {
      Serial.println("debug SD -> Plik bank_nr.txt już istnieje.");

      // Otwórz plik do zapisu i nadpisz aktualną wartość bank_nr
      myFile = STORAGE.open("/bank_nr.txt", FILE_WRITE);
      if (myFile) {
        myFile.println(bank_nr);
        myFile.close();
        Serial.println("debug SD -> Aktualizacja bank_nr.txt na karcie STORAGE.");
      } else {
        Serial.println("debug SD -> Błąd podczas otwierania pliku bank_nr.txt.");
      }
    } 
    else 
    {
      Serial.println("debug SD -> Plik bank_nr.txt nie istnieje. Tworzenie...");

      // Utwórz plik i zapisz w nim aktualną wartość bank_nr
      myFile = STORAGE.open("/bank_nr.txt", FILE_WRITE);
      if (myFile) {
        myFile.println(bank_nr);
        myFile.close();
        Serial.println("debug SD -> Utworzono i zapisano bank_nr.txt na karcie SD");
      } else {
        Serial.println("debug SD -> Błąd podczas tworzenia pliku bank_nr.txt.");
      }
    }
    
    if (noSDcard == true)
    {
      Serial.println("debug SD -> Brak karty SD zapisujemy do EEPROM");
      EEPROM.write(0, station_nr);
      EEPROM.write(1, bank_nr);
      EEPROM.commit();
    }
  }
  else
  {
    Serial.println("debug ChangeStation -> Gramy z adresu URL, nie zapisujemy stacji i banku");  
  }
}


void startFadeIn(uint8_t target)
{
  targetVolume = target;
  currentVolume = 0;
  audio.setVolume(0);
  fadingIn = true;
  lastFadeTime = millis();
}

void handleFadeIn()
{
  if (!fadingIn) return;  // jeśli fade-in nieaktywny, nic nie rób

  if (millis() - lastFadeTime >= fadeStepDelay)
  {
    lastFadeTime = millis();

    if (currentVolume < targetVolume)
    {
      audio.setVolume(currentVolume);
      currentVolume++;
    }
    else
    {
      fadingIn = false; // zakończ fade-in
      audio.setVolume(targetVolume);
    }
  }
}

void volumeFadeOut(uint8_t time_ms)
{
  for (uint8_t i = volumeValue; i > 0; i--)
  {
    audio.setVolume(i);
    delay(time_ms);
  } 
}


void changeStation() 
{
  //audio.setVolume(0);
  fwupd = false;
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf); // cziocnka 14x11
  gfx.drawStr(34, 33, "Loading stream..."); // 8 znakow  x 11 szer
  //gfx.drawStr(51, 33, "Loading stream"); // 8 znakow  x 11 szer
  gfx.sendBuffer();

  mp3 = flac = aac = vorbis = opus = false;
  streamCodec = "-";
  //stationLogoUrl = "";
  
  if (urlPlaying) {bank_nr = previous_bank_nr;}  // Przywracamy ostatni numer banku po graniu z ULR gdzie ustawilismy bank na 0
    
  // Usunięcie wszystkich znaków z obiektów 
  evoAudioClearNowPlaying();
  stationNameStream.remove(0);
  stationLogoUrl.remove(0);

  bitrateString.remove(0);
  sampleRateString.remove(0);
  bitsPerSampleString.remove(0); 
  SampleRate = 0;
  SampleRateRest = 0;

  sampleRateString = "--.-";
  bitsPerSampleString = "--";
  bitrateString = "---";

  Serial.println("debug changeStation -> Read station from PSRAM");
  String stationUrl = "";

  // Odczyt stacji pod daną komórka pamieci PSRAM:
  char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
  memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych
  int length = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1)];   // Odczytaj długość nazwy stacji z PSRAM dla bieżącego indeksu stacji
      
  for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
  { // Odczytaj nazwę stacji z PSRAM jako ciąg bajtów, maksymalnie do STATION_NAME_LENGTH
    station[j] = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
  }
  
  //Serial.println("-------- GRAMY OBECNIE ---------- ");
  //Serial.print(station_nr - 1);
  //Serial.print(" ");
  //Serial.println(String(station));

  String line = String(station); // Przypisujemy dane odczytane z PSRAM do zmiennej line
  
  // Wyciągnij pierwsze 42 znaki i przypisz do stationName
  stationName = line.substring(0, 41);  //42 Skopiuj pierwsze 42 znaki z linii
  Serial.print("debug changeStation -> Nazwa stacji: ");
  Serial.println(stationName);

  // Znajdź część URL w linii, np. po numerze stacji
  int urlStart = line.indexOf("http");  // Szukamy miejsca, gdzie zaczyna się URL
  if (urlStart != -1) 
  {
    stationUrl = line.substring(urlStart);  // Wyciągamy URL od "http"
    stationUrl.trim();                      // Usuwamy białe znaki na początku i końcu
  }
  else
  {
	return;
  }
  
  if (stationUrl.isEmpty()) // jezeli link URL jest pusty
  {
    Serial.println("debug changeStation -> Błąd: Nie znaleziono stacji dla podanego numeru.");
    return;
  }
  
  //Serial.print("URL: ");
  //Serial.println(stationUrl);

  // Weryfikacja, czy w linku znajduje się "http" lub "https"
  if (stationUrl.startsWith("http://") || stationUrl.startsWith("https://")) 
  {
    // Wydrukuj nazwę stacji i link na serialu
    Serial.print("debug changeStation -> Aktualnie wybrana stacja: ");
    Serial.println(station_nr);
    Serial.print("debug changeStation -> Link do stacji: ");
    Serial.println(stationUrl);
    
    gfx.setFont(spleen6x12PL);  // wypisujemy jaki stream jakie stacji jest ładowany
    
    int StationNameEnd = stationName.indexOf("  "); // Wycinamy nazwe stacji tylko do miejsca podwojnej spacji 
    stationName = stationName.substring(0, StationNameEnd);
    
    int stationNameWidth = gfx.getStrWidth(stationName.substring(0, stationNameLenghtCut).c_str()); // Liczy pozycje aby wyswietlic stationName na środku
    int stationNamePositionX = (SCREEN_WIDTH - stationNameWidth) / 2;
    
    gfx.drawStr(stationNamePositionX, 55, String(stationName.substring(0, stationNameLenghtCut)).c_str());
    gfx.sendBuffer();
    
    // Płynne wyciszenie przed zmiana stacji jesli włączone
    if (f_volumeFadeOn && !volumeMute) {volumeFadeOut(volumeFadeOutTime);}
    
    // Połącz z daną stacją
    audio.connecttohost(stationUrl.c_str());
    
    // Właczamy sciszanie tylko jesli MUTE jest wyłaczone. Jesli MUTE jest wyłączone i sciszanie równiez to ustawiamy głośnośc zgodnie z volumeValue 
    if (f_volumeFadeOn && !volumeMute) {startFadeIn(volumeValue);} else if (!volumeMute) {audio.setVolume(volumeValue);}   
    
    // Zapisujemy jaki numer stacji i który bank gramy tylko jesli sie zmieniły
    //if ((station_nr != stationFromBuffer || bank_nr != previous_bank_nr) && f_saveVolumeStationAlways) {saveStationOnSD();}
    
    
    if (station_nr != 0 ) {stationFromBuffer = station_nr;} 
    if (f_saveVolumeStationAlways) {saveStationOnSD();} 
    //saveStationOnSD(); // Zapisujemy jaki numer stacji i który bank gramy

    urlPlaying = false; // Kasujemy flage odtwarzania z adresu przesłanego ze strony WWW
       
  } 
  else 
  {
    Serial.println("debug changeStation -> Błąd: link stacji nie zawiera 'http' lub 'https'");
    Serial.println("debug changeStation -> Odczytany URL: " + stationUrl);
  }
  
  currentSelection = station_nr - 1; // ustawiamy stacje na liscie na obecnie odtwarzaczną po zmianie stacji
  firstVisibleLine = currentSelection + 1; // pierwsza widoczna lina to grająca stacja przy starcie
  if (currentSelection + 1 >= stationsCount - 1) 
  {
   firstVisibleLine = currentSelection - 3;
  }
  ActionNeedUpdateTime = true;
   
  wsStationChange(station_nr, bank_nr); // Od teraz Event Audio odpowiada za info o stacji
  wsAudioRefresh = true;
  
  //audio.setVolume(volumeValue); // Przywracamy ustawienie glosności
}

// Funkcja do wyświetlania listy stacji radiowych z opcją wyboru poprzez zaznaczanie w negatywie
void displayStations() 
{
  listedStations = true;
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeStationList();
  Serial.print("CurrentSelection = " ); Serial.println(currentSelection);
  Serial.print("firstVisibleLine = " ); Serial.println(firstVisibleLine);
  return;
#endif
  gfx.clearBuffer();  // Wyczyść bufor przed rysowaniem, aby przygotować ekran do nowej zawartości
  gfx.setFont(spleen6x12PL);
  gfx.setCursor(20, 10);                                          // Ustaw pozycję kursora (x=60, y=10) dla nagłówka
  gfx.print("BANK: " + String(bank_nr));                                          // Wyświetl nagłówek "BANK:"
  gfx.setCursor(68, 10);                                          // Ustaw pozycję kursora (x=60, y=10) dla nagłówka
  gfx.print(" - RADIO STATIONS: ");                                // Wyświetl nagłówek "Radio Stations:"
  gfx.print(String(station_nr) + " / " + String(stationsCount));  // Dodaj numer aktualnej stacji i licznik wszystkich stacji
  gfx.drawLine(0,11,256,11);
  // "BANK: 16 - RADIO STATIONS: 99 / 99


  int displayRow = 1;  // Zmienna dla numeru wiersza, zaczynając od drugiego (pierwszy to nagłówek)
  
  //erial.print("FirstVisibleLine:");
  //Serial.print(firstVisibleLine);

  // Wyświetlanie stacji, zaczynając od drugiej linii (y=21)
  for (int i = firstVisibleLine; i < min(firstVisibleLine + maxVisibleLines, stationsCount); i++) 
  {
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych

    // Odczytaj długość nazwy stacji z PSRAM dla bieżącego indeksu stacji
    int length = psramData[i * (STATION_NAME_LENGTH + 1)];  //----------------------------------------------

    // Odczytaj nazwę stacji z PSRAM jako ciąg bajtów, maksymalnie do STATION_NAME_LENGTH
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
    {
      station[j] = psramData[i * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }

    // Sprawdź, czy bieżąca stacja to ta, która jest aktualnie zaznaczona
    if (i == currentSelection) 
    {
      gfx.setDrawColor(1);                           // Ustaw biały kolor rysowania
      //gfx.drawBox(0, displayRow * 13 - 2, 256, 13);  // Narysuj prostokąt jako tło dla zaznaczonej stacji (x=0, szerokość 256, wysokość 10)
      gfx.drawBox(0, displayRow * 13, 256, 13);  // Narysuj prostokąt jako tło dla zaznaczonej stacji (x=0, szerokość 256, wysokość 10)
      gfx.setDrawColor(0);                           // Zmień kolor rysowania na czarny dla tekstu zaznaczonej stacji
    } else {
      gfx.setDrawColor(1);  // Dla niezaznaczonych stacji ustaw zwykły biały kolor tekstu
    }
    // Wyświetl nazwę stacji, ustawiając kursor na odpowiedniej pozycji
    //         gfx.drawStr(0, displayRow * 13 + 8, String(station).c_str());
    gfx.drawStr(0, displayRow * 13 + 10, String(station).c_str());
    //gfx.print(station);  // Wyświetl nazwę stacji

    // Przejdź do następnej linii (następny wiersz na ekranie)
    displayRow++;
  }
  // Przywróć domyślne ustawienia koloru rysowania (biały tekst na czarnym tle)
  gfx.setDrawColor(1);  // Biały kolor rysowania
  gfx.sendBuffer();     // Wyślij zawartość bufora do ekranu OLED, aby wyświetlić zmiany
  Serial.print("CurrentSelection = "); Serial.println(currentSelection);
  Serial.print("firstVisibleLine = "); Serial.println(firstVisibleLine);
}

void updateTimerFlag() 
{
  ActionNeedUpdateTime = true;
}

void displayPowerSave(bool saveON)
{
  if ((saveON == 1) && (displayActive == false) && (fwupd == false) && (audio.isRunning() == true)) {gfx.setPowerSave(1);}
  if (saveON == 0) {gfx.setPowerSave(0);}
}



// Funkcja wywoływana co sekundę przez timer do aktualizacji czasu na wyświetlaczu
void updateTime() 
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  displayRadioTFT();
  return;
#endif
  gfx.setDrawColor(1);  // Ustaw kolor na biały
  bool showDots;

  if (timeDisplay == true) 
  {

    if ((timeDisplay == true) && (audio.isRunning() == true))
    {
      // Struktura przechowująca informacje o czasie
      struct tm timeinfo;
      
      // Sprawdź, czy udało się pobrać czas z lokalnego zegara czasu rzeczywistego
      if (!getLocalTime(&timeinfo, 3000)) 
      {
        // Wyświetl komunikat o niepowodzeniu w pobieraniu czasu
        Serial.println("debug time -> Nie udało się uzyskać czasu");
        return;  // Zakończ funkcję, gdy nie udało się uzyskać czasu
      }
      
      showDots = (timeinfo.tm_sec % 2 == 0); // Parzysta sekunda = pokazuj dwukropek

      // Konwertuj godzinę, minutę i sekundę na stringi w formacie "HH:MM:SS"
      char timeString[9];  // Bufor przechowujący czas w formie tekstowej
      if ((timeinfo.tm_min == 0) && (timeinfo.tm_sec == 0) && (timeVoiceInfoEveryHour == true) && (f_voiceTimeBlocked == false)) {f_requestVoiceTimePlay = true; f_voiceTimeBlocked = true;} // Sprawdzamy czy wybiła pełna godzina, jesli włączony informacja głosowa co godzine to odtwarzamy
      
      if ((displayMode == 0) || (displayMode == 2)) // Tryb podstawowy i 3 linijki tesktu
      { 
        //snprintf(timeString, sizeof(timeString), "%2d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
        if (showDots) snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
        else snprintf(timeString, sizeof(timeString), "%2d %02d", timeinfo.tm_hour, timeinfo.tm_min);
        gfx.setFont(spleen6x12PL);
        //gfx.drawStr(208, 63, timeString);
        gfx.drawStr(226, 63, timeString);
      }
      else if (displayMode == 1) // Tryb - Duzy zegar
      {
        int xtime = 0;
        gfx.setFont(u8g2_font_7Segments_26x42_mn);
        
        //snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);

        //Miganie kropek
        if (showDots) snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
        else snprintf(timeString, sizeof(timeString), "%2d %02d", timeinfo.tm_hour, timeinfo.tm_min);
        gfx.drawStr(xtime+7, 45, timeString); 
        
        gfx.setFont(u8g2_font_fub14_tf); // 14x11
        snprintf(timeString, sizeof(timeString), "%02d", timeinfo.tm_mday);
        gfx.drawStr(203,17, timeString);

        String month = "";
        switch (timeinfo.tm_mon) {
        case 0: month = "JAN"; break;     
        case 1: month = "FEB"; break;     
        case 2: month = "MAR"; break;
        case 3: month = "APR"; break;
        case 4: month = "MAY"; break;
        case 5: month = "JUN"; break;
        case 6: month = "JUL"; break;
        case 7: month = "AUG"; break;
        case 8: month = "SEP"; break;
        case 9: month = "OCT"; break;
        case 10: month = "NOV"; break;
        case 11: month = "DEC"; break;                                
        }
        gfx.setFont(spleen6x12PL);
        gfx.drawStr(232,14, month.c_str());

        String dayOfWeek = "";
        switch (timeinfo.tm_wday) {
        case 0: dayOfWeek = " Sunday  "; break;     
        case 1: dayOfWeek = " Monday  "; break;     
        case 2: dayOfWeek = " Tuesday "; break;
        case 3: dayOfWeek = "Wednesday"; break;
        case 4: dayOfWeek = "Thursday "; break;
        case 5: dayOfWeek = " Friday  "; break;
        case 6: dayOfWeek = "Saturday "; break;
        }
        
        gfx.drawRBox(198,20,58,15,3);  // Box z zaokraglonymi rogami, biały pod dniem tygodnia
        gfx.drawLine(198,20,256,20); // Linia separacyjna dzien miesiac / dzien tygodnia
        gfx.setDrawColor(0);
        gfx.drawStr(201,31, dayOfWeek.c_str());
        gfx.setDrawColor(1);
        gfx.drawRFrame(198,0,58,35,3); // Ramka na całosci kalendarza

        snprintf(timeString, sizeof(timeString), ":%02d", timeinfo.tm_sec);
        gfx.drawStr(xtime+163, 45, timeString);
      }
      else if (displayMode == 3)
      { 
        if (showDots) snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
        else snprintf(timeString, sizeof(timeString), "%2d %02d", timeinfo.tm_hour, timeinfo.tm_min);
        gfx.setFont(spleen6x12PL);
        //gfx.drawStr(113, 11, timeString);
        gfx.drawStr(226, 10, timeString);
      }
      else if (displayMode == 7)
      { 
        if (showDots) snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
        else snprintf(timeString, sizeof(timeString), "%2d %02d", timeinfo.tm_hour, timeinfo.tm_min);
        gfx.setFont(spleen6x12PL);
        gfx.drawStr(50, 8, timeString);
      }
    
    }
    else if ((timeDisplay == true) && (audio.isRunning() == false))
    {
      displayPowerSave(0); 
      // Struktura przechowująca informacje o czasie
      struct tm timeinfo;
      
      if (!getLocalTime(&timeinfo,3000)) 
      {
        Serial.println("debug time -> Nie udało się uzyskać czasu");
        return;  // Zakończ funkcję, gdy nie udało się uzyskać czasu
      }
      showDots = (timeinfo.tm_sec % 2 == 0); // Parzysta sekunda = pokazuj dwukropek
      char timeString[9];  // Bufor przechowujący czas w formie tekstowej
      
      //snprintf(timeString, sizeof(timeString), "%02d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
      if (showDots) snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
      else snprintf(timeString, sizeof(timeString), "%2d %02d", timeinfo.tm_hour, timeinfo.tm_min);
      gfx.setFont(spleen6x12PL);
      
      if ((displayMode == 0) || (displayMode == 2)) { gfx.drawStr(0, 63, "                         ");}
      if (displayMode == 1) { gfx.drawStr(0, 33, "                         ");}
      if (displayMode == 3) { gfx.drawStr(53, 62, "                         ");}

      if (millis() - lastCheckTime >= 1000)
      {
        if ((displayMode == 0) || (displayMode == 2)) { gfx.drawStr(0, 63, "Brak tytulu audycji");}
        if (displayMode == 1) { gfx.drawStr(0, 33, "Brak tytulu audycji");}
        if (displayMode == 3) { gfx.drawStr(53, 62 , "Brak tytulu audycji");}
        lastCheckTime = millis(); // Zaktualizuj czas ostatniego sprawdzenia
      }       
      if ((displayMode == 0) || (displayMode == 1) || (displayMode == 2)) { gfx.drawStr(226, 63, timeString);}
      if (displayMode == 3) { gfx.drawStr(226, 10, timeString);}
    }
  }
}

void saveEqualizerOnSD() 
{
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf); // cziocnka 14x11
  gfx.drawStr(1, 33, "Saving equalizer settings"); // 8 znakow  x 11 szer
  gfx.sendBuffer();
  
  
  // Sprawdź, czy plik equalizer.txt istnieje

  Serial.print("Filtr High: ");
  Serial.println(toneHiValue);
  
  Serial.print("Filtr Mid: ");
  Serial.println(toneMidValue);
  
  Serial.print("Filtr Low: ");
  Serial.println(toneLowValue);
  
  Serial.print("Balance: "); 
  Serial.println(balanceValue);
  
  // Sprawdź, czy plik istnieje
  if (STORAGE.exists("/equalizer.txt")) 
  {
    Serial.println("debug SD -> Plik equalizer.txt już istnieje.");

    // Otwórz plik do zapisu i nadpisz aktualną wartość flitrów equalizera
    myFile = STORAGE.open("/equalizer.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println(toneHiValue);
	    myFile.println(toneMidValue);
	    myFile.println(toneLowValue);
      myFile.println(balanceValue);
      myFile.close();
      Serial.println("debug SD -> Aktualizacja equalizer.txt na karcie SD");
    } 
	  else 
	  {
      Serial.println("debug SD -> Błąd podczas otwierania pliku equalizer.txt.");
    }
  } 
  else 
  {
    Serial.println("debug SD -> Plik equalizer.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualną wartość filtrów equalizera
    myFile = STORAGE.open("/equalizer.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println(toneHiValue);
	    myFile.println(toneMidValue);
	    myFile.println(toneLowValue);
      myFile.println(balanceValue);
      myFile.close();
      Serial.println("debug SD -> Utworzono i zapisano equalizer.txt na karcie SD");
    } 
	  else 
	  {
      Serial.println("debug SD -> Błąd podczas tworzenia pliku equalizer.txt.");
    }
  }
}

void readEqualizerFromSD() 
{
  // Sprawdź, czy karta SD jest dostępna
  //if (!STORAGE.begin(SD_CS))
  if (!STORAGE_BEGIN()) 
  {
    Serial.println("debug SD -> Nie można znaleźć karty SD, ustawiam domyślne wartości filtrow Equalziera.");
    toneHiValue = 0;  // Domyślna wartość filtra gdy brak karty SD
	  toneMidValue = 0; // Domyślna wartość filtra gdy brak karty SD
	  toneLowValue = 0; // Domyślna wartość filtra gdy brak karty SD
    balanceValue = 0;
    return;
  }

  // Sprawdź, czy plik equalizer.txt istnieje
  if (STORAGE.exists("/equalizer.txt")) 
  {
    myFile = STORAGE.open("/equalizer.txt");
    if (myFile) 
    {
      toneHiValue = myFile.parseInt();
	    toneMidValue = myFile.parseInt();
	    toneLowValue = myFile.parseInt();
      balanceValue = myFile.parseInt();
      myFile.close();
      
      Serial.println("debug SD -> Wczytano equalizer.txt z karty SD: ");
	  
      Serial.print("debug SD -> Filtr High equalizera odczytany z SD: ");
      Serial.println(toneHiValue);
    
      Serial.print("debug SD -> Filtr Mid equalizera odczytany z SD: ");
      Serial.println(toneMidValue);
    
      Serial.print("debug SD -> Filtr Low equalizera odczytany z SD: ");
      Serial.println(toneLowValue);

      Serial.print("debug SD -> Wartosc Balansu odczytana z SD: ");
      Serial.println(balanceValue);
        
    } 
	  else 
	  {
      Serial.println("debug SD -> Błąd podczas otwierania pliku equalizer.txt.");
    }
  } 
  else 
  {
    Serial.println("debug SD -> Plik equalizer.txt nie istnieje.");
    toneHiValue = 0;  // Domyślna wartość filtra gdy brak karty SD
	  toneMidValue = 0; // Domyślna wartość filtra gdy brak karty SD
	  toneLowValue = 0; // Domyślna wartość filtra gdy brak karty SD
    balanceValue = 0;
  }
  audio.setTone(toneLowValue, toneMidValue, toneHiValue); // Ustawiamy filtry - zakres regulacji -40 + 6dB jako int8_t ze znakiem
  audio.setBalance(balanceValue);
}

// Funkcja do odczytu danych stacji radiowej z karty SD
void readStationFromSD() 
{
  // Sprawdź, czy karta SD jest dostępna
  //if (!STORAGE.begin(SD_CS)) 
  if (!STORAGE_BEGIN())
  {
    //Serial.println("Nie można znaleźć karty STORAGE. Ustawiam domyślne wartości: Station=1, Bank=1.");
    Serial.println("debug SD -> Nie można znaleźć karty SD, ustawiam wartości z EEPROMu");
    //station_nr = 1;  // Domyślny numer stacji gdy brak karty SD
    //bank_nr = 1;     // Domyślny numer banku gdy brak karty SD
    EEPROM.get(0, station_nr);
    EEPROM.get(1, bank_nr);
    
    Serial.print("debug EEPROM -> Odczyt EEPROM Stacja: ");
    Serial.println(station_nr);
    Serial.print("debug EEPROM -> Odczyt EEPROM Bank: ");
    Serial.println(bank_nr);

    if ((station_nr > 99) || (station_nr == 0)) { station_nr = 1;} // zabezpiecznie na wypadek błędnego odczytu EEPROMu lub wartości
    if ((bank_nr > bank_nr_max) || (bank_nr == 0)) { bank_nr = 1;}
    
    return;
  }

  // Sprawdź, czy plik station_nr.txt istnieje
  if (STORAGE.exists("/station_nr.txt")) {
    myFile = STORAGE.open("/station_nr.txt");
    if (myFile) {
      station_nr = myFile.parseInt();
      myFile.close();
      Serial.print("debug SD -> Wczytano station_nr z karty SD: ");
      Serial.println(station_nr);
    } else {
      Serial.println("debug SD -> Błąd podczas otwierania pliku station_nr.txt.");
    }
  } else {
    Serial.println("debug SD -> Plik station_nr.txt nie istnieje.");
    station_nr = 9;  // ustawiamy stacje w przypadku braku pliku na karcie
  }

  // Sprawdź, czy plik bank_nr.txt istnieje
  if (STORAGE.exists("/bank_nr.txt")) {
    myFile = STORAGE.open("/bank_nr.txt");
    if (myFile) {
      bank_nr = myFile.parseInt();
      myFile.close();
      Serial.print("debug SD -> Wczytano bank_nr z karty SD: ");
      Serial.println(bank_nr);
    } else {
      Serial.println("debug SD -> Błąd podczas otwierania pliku bank_nr.txt.");
    }
  } else {
    Serial.println("debug SD -> Plik bank_nr.txt nie istnieje.");
    bank_nr = 1;  // // ustawiamy bank w przypadku braku pliku na karcie
  }
}

void vuMeterMode0() 
{
  uint16_t raw = audio.getVUlevel();
  vuMeterR = (raw >> 8) & 0xFF;
  vuMeterL = raw & 0xFF;

  //vuMeterL = constrain(vuMeterL, 0, 240);
  //vuMeterR = constrain(vuMeterR, 0, 240);

  // zapobiega nagłym spadkom przy bardzo silnym sygnale
  //if (vuMeterL < displayVuL - 8) vuMeterL = displayVuL - 8;
  //if (vuMeterR < displayVuR - 8) vuMeterR = displayVuR - 8;

  
  //vuMeterR = audio.getVUlevel() & 0xFF;  // wyciagamy ze zmiennej typu int16 kanał L
  //vuMeterL = audio.getVUlevel() >> 8;  // z wyzszej polowki wyciagamy kanal P

  //vuMeterL = constrain(vuMeterL, 0, 243);
  //vuMeterR = constrain(vuMeterR, 0, 243);

  //vuMeterR = map(vuMeterR, 0, 255, 0, 240);
  //vuMeterL = map(vuMeterL, 0, 255, 0, 240);  // 244 VU + start od x=10 +  peak hold 2px

  if (vuMeterR < 1) vuMeterR = 1;
  if (vuMeterL < 1) vuMeterL = 1;

  //if (vuMeterR > 230) vuMeterR = 230;
  //if (vuMeterL > 230) vuMeterL = 230;
  //vuMeterL = constrain(vuMeterL, 0, 230);
 // vuMeterR = constrain(vuMeterR, 0, 230);

  if (vuSmooth)
  {
    // LEFT
    /*
    if (vuMeterL > displayVuL) 
    {
      displayVuL += vuRiseSpeed;
      if (displayVuL > vuMeterL) 
      displayVuL = vuMeterL;
    } 
    */

    if (vuMeterL > displayVuL) 
    {
      if (displayVuL > 255 - vuRiseSpeed) displayVuL = 255;
      else
      displayVuL += vuRiseSpeed;

      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    }


    
    
    else if (vuMeterL < displayVuL) 
    {
      if (displayVuL > vuFallSpeed) 
      {
        displayVuL -= vuFallSpeed;
      } 
      else 
      {
        //displayVuL = 0;
        displayVuL = vuMeterL;
      }
    }

    // RIGHT
    /*
    if (vuMeterR > displayVuR) 
    {
      displayVuR += vuRiseSpeed;
      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    } 
    */

    if (vuMeterR > displayVuR) 
    {
      if (displayVuR > 255 - vuRiseSpeed) displayVuR = 255;
      else
      displayVuR += vuRiseSpeed;

      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    }  

    else if (vuMeterR < displayVuR) 
    {
      if (displayVuR > vuFallSpeed) 
      {
        displayVuR -= vuFallSpeed;
      } 
      else 
      {
        //displayVuR = 0;
        displayVuR = vuMeterR;
      }
    }
  }

  // Aktualizacja peak&hold dla Lewego kanału
  if (vuSmooth)
  {
    if (vuPeakHoldOn)
    {
      // --- Peak L ---
      if (displayVuL >= peakL) 
      {
        peakL = displayVuL;
        peakHoldTimeL = 0;
      } 
      else 
      {
        if (peakHoldTimeL < peakHoldThreshold) 
        {
          peakHoldTimeL++;
        } 
        else 
        {
          if (peakL > 0) peakL--;
        }
      }

      // --- Peak R ---
      if (displayVuR >= peakR) 
      {
        peakR = displayVuR;
        peakHoldTimeR = 0;
      } 
      else 
      {
        if (peakHoldTimeR < peakHoldThreshold) 
        {
          peakHoldTimeR++;
        } 
        else 
        {
          if (peakR > 0) peakR--;
        }
      }
    }    
  }
  else
  {
    if (vuPeakHoldOn)
    {
      if (vuMeterL >= peakL) 
      {
        peakL = vuMeterL;
        peakHoldTimeL = 0;
      } 
      else 
      {
        if (peakHoldTimeL < peakHoldThreshold) 
        {
          peakHoldTimeL++;
        } 
        else 
        {
          if (peakL > 0) peakL--;
        }
      }
      // Aktualizacja peak&hold dla Prawego kanału
      if (vuMeterR >= peakR) 
      {
        peakR = vuMeterR;
        peakHoldTimeR = 0;
      } 
      else 
      {
        if (peakHoldTimeR < peakHoldThreshold) 
        {
          peakHoldTimeR++;
        } 
        else 
        {
          if (peakR > 0) peakR--;
        }
      }
    }
  }


  if (volumeMute == false)  
  {
    if (vuSmooth)
    {
      gfx.setDrawColor(0);
      gfx.drawBox(7, vuLy, 249, 3);  //czyszczenie ekranu pod VU meter
      gfx.drawBox(7, vuRy, 249, 3);
      gfx.setDrawColor(1);

      // Biale pola pod literami L i R
      gfx.drawBox(0, vuLy - 3, 7, 7);  
      gfx.drawBox(0, vuRy - 3, 7, 7);  

      // Rysujemy litery L i R
      gfx.setDrawColor(0);
      gfx.setFont(u8g2_font_04b_03_tr);
      gfx.drawStr(2, vuLy + 3, "L");
      gfx.drawStr(2, vuRy + 3, "R");
      gfx.setDrawColor(1);  // Przywracamy białe rysowanie

      if (vuMeterMode == 1)  // tryb 1 ciagle paski
      {
        gfx.setDrawColor(1);
        //gfx.drawBox(10, vuLy, vuMeterL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        //gfx.drawBox(10, vuRy, vuMeterR, 2);

        gfx.drawBox(10, vuLy, displayVuL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        gfx.drawBox(10, vuRy, displayVuR, 2);


        // Rysowanie peaków jako cienka kreska
        gfx.drawBox(9 + peakL, vuLy, 1, 2);
        gfx.drawBox(9 + peakR, vuRy, 1, 2);
      } 
      else  // vuMeterMode == 0  tryb podstawowy, kreseczki z przerwami
      {      
        for (uint8_t vusize = 0; vusize < displayVuL; vusize++)
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuLy, 1, 2);//gfx.drawBox(9 + vusize, vuLy, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }  
        for (uint8_t vusize = 0; vusize < displayVuR; vusize++)
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuRy, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }    
        
        if (vuPeakHoldOn)
        {
          // Peak - kreski w trybie przerywanym
          gfx.drawBox(9 + peakL, vuLy, 1, 2);
          gfx.drawBox(9 + peakR, vuRy, 1, 2);
        }
      }
         
    }
    else
    {
      gfx.setDrawColor(0);
      gfx.drawBox(7, vuLy, 255, 3);  //czyszczenie ekranu pod VU meter
      gfx.drawBox(7, vuRy, 255, 3);
      gfx.setDrawColor(1);

      // Biale pola pod literami L i R
      gfx.drawBox(0, vuLy - 3, 7, 7);  
      gfx.drawBox(0, vuRy - 3, 7, 7);  

      // Rysujemy litery L i R
      gfx.setDrawColor(0);
      gfx.setFont(u8g2_font_04b_03_tr);
      gfx.drawStr(2, vuLy + 3, "L");
      gfx.drawStr(2, vuRy + 3, "R");
      gfx.setDrawColor(1);  // Przywracamy białe rysowanie

      if (vuMeterMode == 1)  // tryb 1 ciagle paski
      {
        gfx.setDrawColor(1);
        gfx.drawBox(10, vuLy, vuMeterL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        gfx.drawBox(10, vuRy, vuMeterR, 2);

        // Rysowanie peaków jako cienka kreska
        gfx.drawBox(9 + peakL, vuLy, 1, 2);
        gfx.drawBox(9 + peakR, vuRy, 1, 2);
      } 
      else  // vuMeterMode == 0  tryb podstawowy, kreseczki z przerwami
      {      
        for (uint8_t vusize = 0; vusize < vuMeterL; vusize++) 
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuLy, 1, 2);//gfx.drawBox(9 + vusize, vuLy, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }  
        for (uint8_t vusize = 0; vusize < vuMeterR; vusize++) 
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuRy, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        } 
       
        if (vuPeakHoldOn)
        {
          // Peak - kreski w trybie przerywanym
          gfx.drawBox(9 + peakL, vuLy, 1, 2);
          gfx.drawBox(9 + peakR, vuRy, 1, 2);
        }
      }  
    } // else smooth
  }  // moute off
}

void vuMeterMode3() 
{
  // Pobranie poziomu VU
  vuMeterR = min(audio.getVUlevel() & 0xFF, 255);
  vuMeterL = min(audio.getVUlevel() >> 8, 255);

  vuMeterR = map(vuMeterR, 0, 255, 0, 127);
  vuMeterL = map(vuMeterL, 0, 255, 0, 127);

  // Wygładzanie
  if (vuSmooth)
  {
    /*
    if (vuMeterL > displayVuL) 
    {
      displayVuL += vuRiseSpeed;
      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    }
    */

    if (vuMeterL > displayVuL) 
    {
      if (displayVuL > 127 - vuRiseSpeed) displayVuL = 127;
      else
      displayVuL += vuRiseSpeed;

      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    }
    else 
    {
      if (displayVuL > vuFallSpeed) {
        displayVuL -= vuFallSpeed;
      } else {
        displayVuL = 0;
      }
    }

    /*
    if (vuMeterR > displayVuR) {
      displayVuR += vuRiseSpeed;
      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    } 
    */

    if (vuMeterR > displayVuR) 
    {
      if (displayVuR > 127 - vuRiseSpeed) displayVuR = 127;
      else
      displayVuR += vuRiseSpeed;

      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    }
    else 
    {
      if (displayVuR > vuFallSpeed) {
        displayVuR -= vuFallSpeed;
      } else {
        displayVuR = 0;
      }
    }
  }

  // Peak & Hold
  if (vuPeakHoldOn)
  {
    // LEFT
    if ((vuSmooth ? displayVuL : vuMeterL) >= peakL) {
      peakL = vuSmooth ? displayVuL : vuMeterL;
      peakHoldTimeL = 0;
    } else {
      if (peakHoldTimeL < peakHoldThreshold) {
        peakHoldTimeL++;
      } else if (peakL > 0) {
        peakL--;
      }
    }

    // RIGHT
    if ((vuSmooth ? displayVuR : vuMeterR) >= peakR) {
      peakR = vuSmooth ? displayVuR : vuMeterR;
      peakHoldTimeR = 0;
    } else {
      if (peakHoldTimeR < peakHoldThreshold) {
        peakHoldTimeR++;
      } else if (peakR > 0) {
        peakR--;
      }
    }
  }

  if (!volumeMute)
  {
    // Czyszczenie linii VU
    gfx.setDrawColor(0);
    gfx.drawBox(0, vuYmode3, 240, vuThicknessMode3);
    gfx.setDrawColor(1);

    // Wybór wartości do rysowania: wygładzone lub surowe
    int leftLevel = vuSmooth ? displayVuL : vuMeterL;
    int rightLevel = vuSmooth ? displayVuR : vuMeterR;

    // Rysowanie LEWEGO kanału - od środka w lewo
    for (int i = 0; i < leftLevel; i++) {
      if ((i % 9) < 8) {  // 8px kreska + 1px przerwa
        int x = vuCenterXmode3 - 2 - i;  // -1 żeby nie nakładać się na środek
        if (x >= 0) gfx.drawBox(x, vuYmode3, 1, vuThicknessMode3);
      }
    }

    // Rysowanie PRAWEGO kanału - od środka w prawo
    for (int i = 0; i < rightLevel; i++) {
      if ((i % 9) < 8) {
        int x = vuCenterXmode3 + 2 + i;
        if (x < 240) gfx.drawBox(x, vuYmode3, 1, vuThicknessMode3);
      }
    }

    // Rysowanie PEAKÓW
    if (vuPeakHoldOn) {
      int peakLeftX = vuCenterXmode3 - 1 - peakL;
      int peakRightX = vuCenterXmode3 + peakR;
      if (peakLeftX >= 0) gfx.drawBox(peakLeftX, vuYmode3, 1, vuThicknessMode3);
      if (peakRightX < 240) gfx.drawBox(peakRightX, vuYmode3, 1, vuThicknessMode3);
    }
  }
}

/*
void vuMeterMode4() // Mode4 duze wskaznikami VU, połokragle
{
  // Pobranie poziomów VU (0–255)
  uint8_t rawL = audio.getVUlevel() >> 8;
  uint8_t rawR = audio.getVUlevel() & 0xFF;

  // Skalowanie do 0–100
  int vuL = map(rawL, 0, 255, 0, 100);
  int vuR = map(rawR, 0, 255, 0, 100);

  // Bezwładność analogowa
  if (vuSmooth) {
    // Lewy
    if (vuL > displayVuL) {
      displayVuL += max(1, (vuL - displayVuL) / vuRiseNeedleSpeed);  // szybciej w górę
    } else if (vuL < displayVuL) {
      displayVuL -= max(1, (displayVuL - vuL) / vuFallNeedleSpeed); // wolniej w dół
    }

    // Prawy
    if (vuR > displayVuR) {
      displayVuR += max(1, (vuR - displayVuR) / vuRiseNeedleSpeed);
    } else if (vuR < displayVuR) {
      displayVuR -= max(1, (displayVuR - vuR) / vuFallNeedleSpeed);
    }

    displayVuL = constrain(displayVuL, 0, 100);
    displayVuR = constrain(displayVuR, 0, 100);
  } else {
    displayVuL = vuL;
    displayVuR = vuR;
  }

  // Parametry wskaźników
  const int radius = 45;
  const int frameWidth = 120;
  const int frameHeight = 60;

  int centerXL = 65;
  int centerYL = 63;

  int centerXR = 195;
  int centerYR = 63;

  const int arcStartDeg = -60;
  const int arcEndDeg = 60;

  // Czyszczenie ekranu
  gfx.setDrawColor(0);
  gfx.drawBox(0, 0, 256, 64);
  gfx.setDrawColor(1);
  gfx.setFont(u8g2_font_6x10_tr);

  // Struktura opisów dB
  struct Mark {
    int angle;
    const char* label;
  };

  const Mark scaleMarks[] = {
    { -60, "-20" },
    { -40, "-10" },
    { -20, "-5"  },
    {   0,  "0"   },
    {  20, "+3"  },
    {  40, "+6"  },
    {  60, "+9"  },
  };

  // Funkcja rysująca łuk wskaźnika
  auto drawVUArc = [&](int cx, int cy, const char* label) 
  {
    // Ramka
    gfx.drawFrame((cx - frameWidth / 2), cy - radius - 18, frameWidth, frameHeight);

    // Skala łuku
    for (int a = arcStartDeg; a <= arcEndDeg; a += 6) 
    {
      float angle = radians(a);
      int x1 = cx + sin(angle) * (radius - 4);
      int y1 = cy - cos(angle) * (radius - 4);
      int x2 = cx + sin(angle) * radius;
      int y2 = cy - cos(angle) * radius;
      gfx.drawLine(x1, y1, x2, y2);
    }

    // Opisy dB
    for (const Mark& m : scaleMarks) 
    {
      float angle = radians(m.angle);
      int tx = cx + sin(angle) * (radius + 10);
      int ty = cy - cos(angle) * (radius + 10);
      gfx.setCursor(tx - 8, ty + 5);
      gfx.print(m.label);
    }

    // Opis kanału (L/R)
    gfx.setCursor(cx - 2, cy - 18);
    gfx.print(label);
  };

  // Rysowanie wskaźników L i R
  drawVUArc(centerXL, centerYL,"L"); //x,y,label (L)
  drawVUArc(centerXR, centerYR,"R"); //x,y,label (R)

  // Igła lewa
  float angleL = radians(arcStartDeg + (arcEndDeg - arcStartDeg) * displayVuL / 100.0);
  int xNeedleL = centerXL + sin(angleL) * (radius - 6);
  int yNeedleL = centerYL - cos(angleL) * (radius - 6);
  gfx.drawLine(centerXL, centerYL - 8, xNeedleL, yNeedleL);

  // Igła prawa
  float angleR = radians(arcStartDeg + (arcEndDeg - arcStartDeg) * displayVuR / 100.0);
  int xNeedleR = centerXR + sin(angleR) * (radius - 6);
  int yNeedleR = centerYR - cos(angleR) * (radius - 6);
  gfx.drawLine(centerXR, centerYR - 8, xNeedleR, yNeedleR);
}
*/

void vuMeterMode4() // Mode4 – VU analogowe z prostokatna skala
{
  // ===== Odczyt VU =====
  uint8_t rawL = audio.getVUlevel() >> 8;
  uint8_t rawR = audio.getVUlevel() & 0xFF;

  int vuL = map(rawL, 0, 255, 0, 100);
  int vuR = map(rawR, 0, 255, 0, 100);

  if (vuL < 1) vuL = 1;
  if (vuR < 1) vuR = 1;
  
  // ===== Bezwładność =====
  if (vuSmooth) {
    if (vuL > displayVuL)
      displayVuL += max(1, (vuL - displayVuL) / vuRiseNeedleSpeed);
    else
      displayVuL -= max(1, (displayVuL - vuL) / vuFallNeedleSpeed);

    if (vuR > displayVuR)
      displayVuR += max(1, (vuR - displayVuR) / vuRiseNeedleSpeed);
    else
      displayVuR -= max(1, (displayVuR - vuR) / vuFallNeedleSpeed);

    displayVuL = constrain(displayVuL, 0, 100);
    displayVuR = constrain(displayVuR, 0, 100);
  } else {
    displayVuL = vuL;
    displayVuR = vuR;
  }

  // ===== Parametry wskaźników =====
  const int frameWidth = 120;
  const int frameHeight = 60;
  const int scaleWidth = 100;
  const int scaleYTopOffset = 23;
  const int majorTickHeight = 9;
  const int minorTickHeight = 5;
  const int baseLineThick = 2;

  int centerXL = 65;
  int centerXR = 195;
  int centerY  = 30;

  // ===== Czyszczenie =====
  gfx.setDrawColor(0);
  gfx.drawBox(0, 0, 256, 64);
  gfx.setDrawColor(1);
  //gfx.setFont(u8g2_font_6x10_tr);
  gfx.setFont(mono04b03b); 
  
  // ===== Ramki wskaźników z wypełnieniem =====
  if (reversColorMode4) 
  {
    gfx.drawRBox(centerXL - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3); // Boxy z zaokragleniami
    gfx.drawRBox(centerXR - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);
    gfx.setDrawColor(0); // Rysujemy wszystko w negatywnie z białbym tlem VUmeterow
  }
  else
  {
    gfx.drawRFrame(centerXL - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3); // Ramki z zaokragleniami
    gfx.drawRFrame(centerXR - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);
  }
  
  struct Label {
    uint8_t pos;       // 0–100
    const char* txt;
  };
  
  
  // ===== Pozycje DUŻYCH kresek skali (0–100) =====
  const uint8_t majorPos[] = {
    0,   // -20
    18,  // -10
    35,  // -5
    50,  // środek
    62,  // 0 dB
    74,  // +3
    87,  // +6
    100  // +9
  };

  const uint8_t MAJOR_COUNT = sizeof(majorPos) / sizeof(majorPos[0]);


  const Label scaleLabels[] = {
    { 0,   "-20" },
    { 18,  "-10" },
    { 35,  "-5"  },
    { 62,  "0"   },
    { 72,  "+3"  },
    { 86,  "+6"  },
    { 100, "+9"  }
  };
  const uint8_t LABEL_COUNT = sizeof(scaleLabels) / sizeof(scaleLabels[0]);  
  
  auto drawLinearScale = [&](int centerX)
  {
    int leftX  = centerX - scaleWidth / 2;
    int railY1 = centerY - frameHeight / 2 + scaleYTopOffset;
    int railY2 = railY1 - 3;

    // === Helper: tick ===
    auto drawTick = [&](int x, int h)
    {
      int midX = leftX + scaleWidth / 2;
      int dx = 0;

      if (x < midX - 1)      dx = -h / 2;
      else if (x > midX + 1) dx =  h / 2;
      // else: środek = pionowo

      gfx.drawLine(x, railY1, x + dx, railY1 - h);
    };

    // === Rails ===
    gfx.drawLine(leftX, railY2+1, leftX + scaleWidth, railY2+1);
    gfx.drawLine(leftX + 62 , railY2 + 2, leftX + scaleWidth, railY2+2);

    // --- Linia dolna wskaznika ---
    gfx.drawLine(leftX, railY1, leftX + scaleWidth, railY1);
    gfx.drawLine(leftX, railY1 + 1, leftX + scaleWidth, railY1 + 1); // porgrubienie


    // === Major ticks ===
    for (uint8_t i = 0; i < MAJOR_COUNT; i++) {
      int x = leftX + (majorPos[i] * scaleWidth) / 100;
      drawTick(x, majorTickHeight);
    }
    
    // === Opisy skali ===
    for (uint8_t i = 0; i < LABEL_COUNT; i++) {
      int x = leftX + (scaleLabels[i].pos * scaleWidth) / 100;
      gfx.setCursor(x - 5, railY1 + 10);
      gfx.print(scaleLabels[i].txt);
    }

    // === Minor ticks: 2 pomiędzy KAŻDĄ parą major ===
    for (uint8_t i = 0; i < MAJOR_COUNT - 1; i++)
    {
      //if (majorPos[i] == 50) continue;
      int x1 = leftX + (majorPos[i]     * scaleWidth) / 100;
      int x2 = leftX + (majorPos[i + 1] * scaleWidth) / 100;

      int step = (x2 - x1) / 3;
      drawTick(x1 + step,     minorTickHeight);
      drawTick(x1 + 2 * step, minorTickHeight);
    }
  };


  // ===== Ramki wskaźników =====
  
  //gfx.drawRBox(centerXL - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);
  //gfx.drawRBox(centerXR - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);

  //gfx.drawRFrame(centerXL - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);
  //gfx.drawRFrame(centerXR - frameWidth / 2, centerY - frameHeight / 2, frameWidth, frameHeight,3);

  // ===== Rysowanie skal =====
  drawLinearScale(centerXL);
  drawLinearScale(centerXR);

  // ===== Opis kanałów =====
  //gfx.setCursor(centerXL - 3, centerY + 12); gfx.print("dB");
  //gfx.setCursor(centerXR - 3, centerY + 12); gfx.print("dB");

  
  gfx.setFont(u8g2_font_6x10_tr);
  //gfx.setCursor(centerXL - 2, centerY - frameHeight/2 + 5);
  //gfx.setCursor(centerXL - 2, centerY + 17); gfx.print("L");
  //gfx.setCursor(centerXL - 2, centerY + 18); gfx.print("L");
  gfx.setCursor(centerXL - 5, centerY + 18); gfx.print("VU");
  //gfx.setCursor(centerXR - 2, centerY - frameHeight/2 + 5);
  //gfx.setCursor(centerXR - 2, centerY + 17); gfx.print("R");
  gfx.setCursor(centerXR - 5, centerY + 18); gfx.print("VU");

  // ===== Igły =====
  const int radius = 45;
  //float angleL = radians(-60 + 120.0 * displayVuL / 100.0);
  //float angleR = radians(-60 + 120.0 * displayVuR / 100.0);
  float angleL = radians(-70 + 140.0 * displayVuL / 100.0);
  float angleR = radians(-70 + 140.0 * displayVuR / 100.0);

  int xNeedleL = centerXL + sin(angleL) * (radius - 6);
  int yNeedleL = centerY + 15 - cos(angleL) * (radius - 6);
  //int yNeedleL = centerY - cos(angleL) * (radius - 3);
  
  int xNeedleR = centerXR + sin(angleR) * (radius - 6);
  int yNeedleR = centerY + 15 - cos(angleR) * (radius - 6);
  //int yNeedleR = centerY - cos(angleR) * (radius - 3);

  
  gfx.drawLine(centerXL, centerY + 24, xNeedleL, yNeedleL);
  gfx.drawLine(centerXR, centerY + 24, xNeedleR, yNeedleR);
  gfx.setDrawColor(1);

}


void vuMeterMode5() // Duze paski VU na cały ekran
{
  uint16_t raw = audio.getVUlevel();
  vuMeterL = (raw >> 8) & 0xFF;
  vuMeterR = raw & 0xFF;

  //vuMeterR = map(vuMeterR, 0, 255, 0, 240);
  //vuMeterL = map(vuMeterL, 0, 255, 0, 240);  // 244 VU + start od x=10 +  peak hold 2px

  if (vuMeterR < 1) vuMeterR = 0;
  if (vuMeterL < 1) vuMeterL = 0;
    
  //if (vuMeterR > 255) vuMeterR = 255;
  //if (vuMeterL > 255) vuMeterL = 255;


  if (vuSmooth)
  {
    // LEFT
    /*
    if (vuMeterL > displayVuL) 
    {
      displayVuL += vuRiseSpeed;
      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    }
    */
    if (vuMeterL > displayVuL) 
    {
      if (displayVuL > 255 - vuRiseSpeed) displayVuL = 255;
      else
      displayVuL += vuRiseSpeed;

      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    }




    else if (vuMeterL < displayVuL) 
    {
      if (displayVuL > vuFallSpeed) 
      {
        displayVuL -= vuFallSpeed;
      } 
      else 
      {
        displayVuL = 0;
      }
    }

    // RIGHT
    /*
    if (vuMeterR > displayVuR) 
    {
      displayVuR += vuRiseSpeed;
      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    }
    */
    if (vuMeterR > displayVuR) 
    {
      if (displayVuR > 255 - vuRiseSpeed) displayVuR = 255;
      else
      displayVuR += vuRiseSpeed;

      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    }


    else if (vuMeterR < displayVuR) 
    {
      if (displayVuR > vuFallSpeed) 
      {
        displayVuR -= vuFallSpeed;
      } 
      else 
      {
        displayVuR = 0;
      }
    }
  }

  // Aktualizacja peak&hold dla Lewego kanału
  if (vuSmooth)
  {
    if (vuPeakHoldOn)
    {
      // --- Peak L ---
      if (displayVuL >= peakL) 
      {
        peakL = displayVuL;
        peakHoldTimeL = 0;
      } 
      else 
      {
        if (peakHoldTimeL < peakHoldThreshold) 
        {
          peakHoldTimeL++;
        } 
        else 
        {
          if (peakL > 0) peakL--;
        }
      }

      // --- Peak R ---
      if (displayVuR >= peakR) 
      {
        peakR = displayVuR;
        peakHoldTimeR = 0;
      } 
      else 
      {
        if (peakHoldTimeR < peakHoldThreshold) 
        {
          peakHoldTimeR++;
        } 
        else 
        {
          if (peakR > 0) peakR--;
        }
      }
    }    
  }

  if (volumeMute == false)  
  {
    if (vuSmooth)
    {
      gfx.setDrawColor(0);
      gfx.drawBox(0, 5, 257, 20);  //czyszczenie ekranu pod VU meter
      gfx.drawBox(0, 40, 257, 20);
      gfx.setDrawColor(1);

      // Biale pola pod literami L i R
      //gfx.drawBox(0, vuLy - 3, 7, 7);  
      //gfx.drawBox(0, vuRy - 3, 7, 7);  

      // Rysujemy litery L i R
      //gfx.setDrawColor(0);
      //gfx.setFont(u8g2_font_04b_03_tr);
      gfx.setFont(spleen6x12PL);
      gfx.drawStr(0, 5 + 14, "L");
      gfx.drawStr(0, 40 + 14, "R");
      gfx.setDrawColor(1);  // Przywracamy białe rysowanie

         
      for (uint8_t vusize = 0; vusize < displayVuL; vusize++)
      {       
        if ((vusize % 5) < 4) gfx.drawBox(9 + vusize, 5, 1, 20);//gfx.drawBox(9 + vusize, vuLy, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
      }
      
      for (uint8_t vusize = 0; vusize < displayVuR; vusize++)
      {
        if ((vusize % 5) < 4) gfx.drawBox(9 + vusize, 40, 1, 20); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
      }    
      
      if (vuPeakHoldOn)
      {
        // Peak - kreski w trybie przerywanym
        gfx.drawBox(9 + peakL, 5, 1, 20);
        gfx.drawBox(9 + peakR, 40, 1, 20);
      }
      
         
    }
  } 
}

void vuMeterMode7() // VU dla wyswietlacz 128x64, eksperyment z SSD1306 w displayMode5
{
  uint16_t raw = audio.getVUlevel();
  vuMeterL = (raw >> 8) & 0xFF;
  vuMeterR = raw & 0xFF;

  vuMeterR = map(vuMeterR, 0, 255, 0, 116);
  vuMeterL = map(vuMeterL, 0, 255, 0, 116);  // 244 VU + start od x=10 +  peak hold 2px


  if (vuSmooth)
  {
    // LEFT
    if (vuMeterL > displayVuL) 
    {
      displayVuL += vuRiseSpeed;
      if (displayVuL > vuMeterL) displayVuL = vuMeterL;
    } 
    else if (vuMeterL < displayVuL) 
    {
      if (displayVuL > vuFallSpeed) 
      {
        displayVuL -= vuFallSpeed;
      } 
      else 
      {
        displayVuL = 0;
      }
    }

    // RIGHT
    if (vuMeterR > displayVuR) 
    {
      displayVuR += vuRiseSpeed;
      if (displayVuR > vuMeterR) displayVuR = vuMeterR;
    } 
    else if (vuMeterR < displayVuR) 
    {
      if (displayVuR > vuFallSpeed) 
      {
        displayVuR -= vuFallSpeed;
      } 
      else 
      {
        displayVuR = 0;
      }
    }
  }

  // Aktualizacja peak&hold dla Lewego kanału
  if (vuSmooth)
  {
    if (vuPeakHoldOn)
    {
      // --- Peak L ---
      if (displayVuL >= peakL) 
      {
        peakL = displayVuL;
        peakHoldTimeL = 0;
      } 
      else 
      {
        if (peakHoldTimeL < peakHoldThreshold) 
        {
          peakHoldTimeL++;
        } 
        else 
        {
          if (peakL > 0) peakL--;
        }
      }

      // --- Peak R ---
      if (displayVuR >= peakR) 
      {
        peakR = displayVuR;
        peakHoldTimeR = 0;
      } 
      else 
      {
        if (peakHoldTimeR < peakHoldThreshold) 
        {
          peakHoldTimeR++;
        } 
        else 
        {
          if (peakR > 0) peakR--;
        }
      }
    }    
  }
  else
  {
    if (vuPeakHoldOn)
    {
      if (vuMeterL >= peakL) 
      {
        peakL = vuMeterL;
        peakHoldTimeL = 0;
      } 
      else 
      {
        if (peakHoldTimeL < peakHoldThreshold) 
        {
          peakHoldTimeL++;
        } 
        else 
        {
          if (peakL > 0) peakL--;
        }
      }
      // Aktualizacja peak&hold dla Prawego kanału
      if (vuMeterR >= peakR) 
      {
        peakR = vuMeterR;
        peakHoldTimeR = 0;
      } 
      else 
      {
        if (peakHoldTimeR < peakHoldThreshold) 
        {
          peakHoldTimeR++;
        } 
        else 
        {
          if (peakR > 0) peakR--;
        }
      }
    }
  }


  if (volumeMute == false)  
  {
    if (vuSmooth)
    {
      gfx.setDrawColor(0);
      gfx.drawBox(7, vuLyMode5, 121, 3);  //czyszczenie ekranu pod VU meter
      gfx.drawBox(7, vuRyMode5, 121, 3);
      gfx.setDrawColor(1);

      // Biale pola pod literami L i R
      gfx.drawBox(0, vuLyMode5 - 3, 7, 7);  
      gfx.drawBox(0, vuRyMode5 - 3, 7, 7);  

      // Rysujemy litery L i R
      gfx.setDrawColor(0);
      gfx.setFont(u8g2_font_04b_03_tr);
      gfx.drawStr(2, vuLyMode5 + 3, "L");
      gfx.drawStr(2, vuRyMode5 + 3, "R");
      gfx.setDrawColor(1);  // Przywracamy białe rysowanie

      if (vuMeterMode == 1)  // tryb 1 ciagle paski
      {
        gfx.setDrawColor(1);
        //gfx.drawBox(10, vuLyMode5, vuMeterL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        //gfx.drawBox(10, vuRyMode5, vuMeterR, 2);

        gfx.drawBox(10, vuLyMode5, displayVuL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        gfx.drawBox(10, vuRyMode5, displayVuR, 2);


        // Rysowanie peaków jako cienka kreska
        gfx.drawBox(9 + peakL, vuLyMode5, 1, 2);
        gfx.drawBox(9 + peakR, vuRyMode5, 1, 2);
      } 
      else  // vuMeterMode == 0  tryb podstawowy, kreseczki z przerwami
      {      
        for (uint8_t vusize = 0; vusize < displayVuL; vusize++)
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuLyMode5, 1, 2);//gfx.drawBox(9 + vusize, vuLyMode5, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }  
        for (uint8_t vusize = 0; vusize < displayVuR; vusize++)
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuRyMode5, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }    
        
        if (vuPeakHoldOn)
        {
          // Peak - kreski w trybie przerywanym
          gfx.drawBox(9 + peakL, vuLyMode5, 1, 2);
          gfx.drawBox(9 + peakR, vuRyMode5, 1, 2);
        }
      }
         
    }
    else
    {
      gfx.setDrawColor(0);
      gfx.drawBox(7, vuLyMode5, 121, 3);  //czyszczenie ekranu pod VU meter
      gfx.drawBox(7, vuRyMode5, 121, 3);
      gfx.setDrawColor(1);

      // Biale pola pod literami L i R
      gfx.drawBox(0, vuLyMode5 - 3, 7, 7);  
      gfx.drawBox(0, vuRyMode5 - 3, 7, 7);  

      // Rysujemy litery L i R
      gfx.setDrawColor(0);
      gfx.setFont(u8g2_font_04b_03_tr);
      gfx.drawStr(2, vuLyMode5 + 3, "L");
      gfx.drawStr(2, vuRyMode5 + 3, "R");
      gfx.setDrawColor(1);  // Przywracamy białe rysowanie

      if (vuMeterMode == 1)  // tryb 1 ciagle paski
      {
        gfx.setDrawColor(1);
        gfx.drawBox(10, vuLyMode5, vuMeterL, 2);  // rysujemy kreseczki o dlugosci odpowiadajacej wartosci VU
        gfx.drawBox(10, vuRyMode5, vuMeterR, 2);

        // Rysowanie peaków jako cienka kreska
        gfx.drawBox(9 + peakL, vuLyMode5, 1, 2);
        gfx.drawBox(9 + peakR, vuRyMode5, 1, 2);
      } 
      else  // vuMeterMode == 0  tryb podstawowy, kreseczki z przerwami
      {      
        for (uint8_t vusize = 0; vusize < vuMeterL; vusize++) 
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuLyMode5, 1, 2);//gfx.drawBox(9 + vusize, vuLyMode5, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        }  
        for (uint8_t vusize = 0; vusize < vuMeterR; vusize++) 
        {
          if ((vusize % 9) < 8) gfx.drawBox(9 + vusize, vuRyMode5, 1, 2); // rysuj tylko 8 pikseli, potem 1px przerwy, 9 w osi x to odstep na literke
        } 
       
        if (vuPeakHoldOn)
        {
          // Peak - kreski w trybie przerywanym
          gfx.drawBox(9 + peakL, vuLyMode5, 1, 2);
          gfx.drawBox(9 + peakR, vuRyMode5, 1, 2);
        }
      }  
    } // else smooth
  }  // moute off
}

void showIP(uint16_t xip, uint16_t yip)
{
  gfx.setFont(spleen6x12PL);
  gfx.setDrawColor(1);
  gfx.setCursor(xip,yip);
  gfx.print("IP: " + currentIP);
}

void displayClearUnderScroller() // Funkcja odpwoiedzialna za przewijanie informacji strem tittle lub stringstation
{
  if (displayMode == 0) // Tryb normalny Mode 0- radio
  {
    gfx.setDrawColor(1);
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(0,yPositionDisplayScrollerMode0, "                                           "); //43 spacje - czyszczenie ekranu   
   } 
  else if (displayMode == 1)  // Tryb zegara - Mode 1
  {
    gfx.drawStr(0,yPositionDisplayScrollerMode1, "                                           "); //43 znaki czyszczenie ekranu
  }
  else if (displayMode == 2)  // Tryb mały tekst - Mode 2
  {
    gfx.setDrawColor(1);
    gfx.setFont(spleen6x12PL);   
    gfx.drawStr(0,yPositionDisplayScrollerMode2, "                                           "); //43 znaki czyszczenie ekranu
    gfx.drawStr(0,yPositionDisplayScrollerMode2 + 12, "                                           "); //43 znaki czyszczenie ekranu
    gfx.drawStr(0,yPositionDisplayScrollerMode2 + 12 + 12, "                                           "); //43 znaki czyszczenie ekranu
  }
  else if (displayMode == 3)
  {
    gfx.setDrawColor(1);
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(0,yPositionDisplayScrollerMode3, "                                           "); //43 spacje - czyszczenie ekranu   
  }
  else if (displayMode == 7) 
  {
    gfx.setDrawColor(1);
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(0,yPositionDisplayScrollerMode5, "                        "); //43 spacje - czyszczenie ekranu   
  }
  
  gfx.sendBuffer();  // rysujemy całą zawartosc ekranu.  
}

void displayRadioScroller() // Funkcja odpwoiedzialna za przewijanie informacji strem tittle lub stringstation
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  displayRadioTFT();
  return;
#endif
  // Jesli zmieniła sie dlugosc wyswietlanego stationString to wyczysc ekran OLED w miescach Scrollera
  if (stationStringScroll.length() != stationStringScrollLength) 
  {
    //Serial.print("debug -- czyscimy obszar scrollera stationStringScrollLength - stara wartosc: ");
    //Serial.print(stationStringScrollLength);
    //Serial.print(" <-> nowa wartosc: ");
    //Serial.println(stationStringScroll.length());
    
    stationStringScrollLength = stationStringScroll.length();
    displayClearUnderScroller();
  }

  if (displayMode == 0) // Tryb normalny - Mode 0, radio + VUmeter
  {
    if (stationStringScroll.length() > maxStationVisibleStringScrollLength) //42 + 4 znaki spacji separatora. Realnie widzimy 42 znaki
    {    
      xPositionStationString = offset;
      gfx.setFont(spleen6x12PL);
      gfx.setDrawColor(1);
      do {
        gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode0, stationStringScroll.c_str());
        xPositionStationString = xPositionStationString + stationStringScrollWidth;
      } while (xPositionStationString < 256);
      
      offset = offset - 1;
      if (offset < (65535 - stationStringScrollWidth)) { 
        offset = 0;
      }

    } else {
      xPositionStationString = 0;
      gfx.setDrawColor(1);
      gfx.setFont(spleen6x12PL);    
      gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode0, stationStringScroll.c_str());
      
    }
  } 
  else if (displayMode == 1)  // Tryb zegara
  {
    
    if (stationStringScroll.length() > maxStationVisibleStringScrollLength) 
    {     
      xPositionStationString = offset;
      gfx.setFont(spleen6x12PL);
      gfx.setDrawColor(1);
      do {
        gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode1, stationStringScroll.c_str());

        xPositionStationString = xPositionStationString + stationStringScrollWidth;
      } while (xPositionStationString < 256);
      
      offset = offset - 1;
      if (offset < (65535 - stationStringScrollWidth)) {
        offset = 0;
      }

    } 
    else 
    {
      xPositionStationString = 0;
      gfx.setDrawColor(1);
      gfx.setFont(spleen6x12PL);       
      gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode1, stationStringScroll.c_str());
    }

  }
  else if (displayMode == 2)  // Tryb Mode 2, Radio, 3 linijki station tekst
  {

    // Parametry do obługi wyświetlania w 3 kolejnych wierszach z podzialem do pełnych wyrazów
    const int maxLineLength = 41;  // Maksymalna długość jednej linii w znakach
    String currentLine = "";       // Bieżąca linia
    int yPosition = yPositionDisplayScrollerMode2; // Początkowa pozycja Y


    // Podziel tekst na wyrazy
    String word;
    int wordStart = 0;

    for (int i = 0; i <= stationStringScroll.length(); i++)
    {
      // Sprawdź, czy dotarliśmy do końca słowa lub do końca tekstu
      if (i == stationStringScroll.length() || stationStringScroll.charAt(i) == ' ')
      {
        // Pobierz słowo
        String word = stationStringScroll.substring(wordStart, i);
        wordStart = i + 1;

        // Sprawdź, czy dodanie słowa do bieżącej linii nie przekroczy maxLineLength
        if (currentLine.length() + word.length() <= maxLineLength)
        {
          // Dodaj słowo do bieżącej linii
          if (currentLine.length() > 0)
          {
            currentLine += " ";  // Dodaj spację między słowami
          }
          currentLine += word;
        }
        else
        {
          // Jeśli słowo nie pasuje, wyświetl bieżącą linię i przejdź do nowej linii
          gfx.setFont(spleen6x12PL);
          gfx.drawStr(0, yPosition, currentLine.c_str());
          yPosition += 12;  // Przesunięcie w dół dla kolejnej linii
          // Zresetuj bieżącą linię i dodaj nowe słowo
          currentLine = word;
        }
      }
    }
    // Wyświetl ostatnią linię, jeśli coś zostało
    if (currentLine.length() > 0)
    {
      gfx.setFont(spleen6x12PL);
      gfx.drawStr(0, yPosition, currentLine.c_str());
    }
  }
  else if (displayMode == 3)
  {
   if (stationStringScroll.length() > maxStationVisibleStringScrollLength) //42 + 4 znaki spacji separatora. Realnie widzimy 42 znaki
    {    
      xPositionStationString = offset;
      gfx.setFont(spleen6x12PL);
      gfx.setDrawColor(1);
      do {
        gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode3, stationStringScroll.c_str());
        xPositionStationString = xPositionStationString + stationStringScrollWidth;
      } while (xPositionStationString < 256);
      
      offset = offset - 1;
      if (offset < (65535 - stationStringScrollWidth)) { 
        offset = 0;
      }
    } else {
      xPositionStationString = 0;
      //xPositionStationString = gfx.getStrWidth(stationStringScroll.c_str());
      xPositionStationString = (SCREEN_WIDTH - stationStringScrollWidth) / 2;
           
      gfx.setDrawColor(1);
      gfx.setFont(spleen6x12PL);    
      gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode3, stationStringScroll.c_str()); 
    } 
  }
  
  else if (displayMode == 7)
  {
   //if (stationStringScroll.length() > maxStationVisibleStringScrollLength) //42 + 4 znaki spacji separatora. Realnie widzimy 42 znaki
   if (stationStringScroll.length() > 24) //42 + 4 znaki spacji separatora. Realnie widzimy 42 znaki
    {    
      xPositionStationString = offset;
      gfx.setFont(spleen6x12PL);
      gfx.setDrawColor(1);
      do {
        gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode5, stationStringScroll.c_str());
        xPositionStationString = xPositionStationString + stationStringScrollWidth;
      } while (xPositionStationString < 128);
      
      offset = offset - 1;
      if (offset < (65535 - stationStringScrollWidth)) { 
        offset = 0;
      }
    } else {
      xPositionStationString = 0;
      //xPositionStationString = gfx.getStrWidth(stationStringScroll.c_str());
      //xPositionStationString = (SCREEN_WIDTH - stationStringScrollWidth) / 2;
      
      xPositionStationString = (128 - stationStringScrollWidth) / 2;
           
      gfx.setDrawColor(1);
      gfx.setFont(spleen6x12PL);    
      gfx.drawStr(xPositionStationString, yPositionDisplayScrollerMode5, stationStringScroll.c_str()); 
    } 
  }
  
}

void handleKeyboard()
{
  uint8_t key = 17;
  keyboardValue = 0;

  // --- Dummy read (dla stabilnosci ESP32 ADC)
  analogRead(keyboardPin);
  delayMicroseconds(5);

  for (int i = 0; i < 32; i++)
  {
    keyboardValue = keyboardValue + analogRead(keyboardPin);
  }
  //keyboardValue = keyboardValue / 32;  
  keyboardValue >>= 5;


  if (debugKeyboard == 1) 
  { 
    displayActive = true;
    displayStartTime = millis();
    gfx.clearBuffer();
    gfx.setCursor(10,10); gfx.print("ADC:   " + String(keyboardValue));
    gfx.setCursor(10,23); gfx.print("BUTTON:" + String(keyboardButtonPressed));
    gfx.sendBuffer(); 
    Serial.print("debug - ADC odczyt: ");
    Serial.print(keyboardValue);
    Serial.print(" flaga przycisk wcisniety:");
    Serial.println(keyboardButtonPressed);
  }
  // Kasujemy flage nacisnietego przycisku tylko jesli nic nie jest wcisnięte
  if (keyboardValue > keyboardButtonNeutral-keyboardButtonThresholdTolerance)
  {  
    keyboardButtonPressed = false;
  }
  // Jesli nic nie jest wcisniete i nic nie było nacisnięte analizujemy przycisk
  if (keyboardValue < keyboardButtonNeutral-keyboardButtonThresholdTolerance)
  {  
    if (keyboardButtonPressed == false)
    {
      // Sprawdzamy stan klawiatury
      if ((keyboardValue <= keyboardButtonThreshold_1 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_1 - keyboardButtonThresholdTolerance ))
      { key=1;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_2 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_2 - keyboardButtonThresholdTolerance ))
      { key=2;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_3 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_3 - keyboardButtonThresholdTolerance ))
      { key=3;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_4 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_4 - keyboardButtonThresholdTolerance ))
      { key=4;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_5 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_5 - keyboardButtonThresholdTolerance ))
      { key=5;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_6 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_6 - keyboardButtonThresholdTolerance ))
      { key=6;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_7 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_7 - keyboardButtonThresholdTolerance ))
      { key=7;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_8 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_8 - keyboardButtonThresholdTolerance ))
      { key=8;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_9 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_9 - keyboardButtonThresholdTolerance ))
      { key=9;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_0 + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_0 - keyboardButtonThresholdTolerance ))
      { key=0;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_BankMenu + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_BankMenu - keyboardButtonThresholdTolerance ))
      { key=11;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_Ok + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_Ok - keyboardButtonThresholdTolerance ))
      { key=12;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_DisplayMode + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_DisplayMode - keyboardButtonThresholdTolerance ))
      { key=13;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_Back + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_Back - keyboardButtonThresholdTolerance ))
      { key=14;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_Mute + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_Mute - keyboardButtonThresholdTolerance ))
      { key=15;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_Dimmer + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_Dimmer - keyboardButtonThresholdTolerance ))
      { key=16;keyboardButtonPressed = true;}

      // Strzalki nawigacyjne
      if ((keyboardValue <= keyboardButtonThreshold_ArrowLeft + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_ArrowLeft - keyboardButtonThresholdTolerance ))
      { key=17;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_ArrowRight + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_ArrowRight - keyboardButtonThresholdTolerance ))
      { key=18;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_ArrowUp + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_ArrowUp - keyboardButtonThresholdTolerance ))
      { key=19;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_ArrowDown + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_ArrowDown - keyboardButtonThresholdTolerance ))
      { key=20;keyboardButtonPressed = true;}

      if ((keyboardValue <= keyboardButtonThreshold_PresetsOn + keyboardButtonThresholdTolerance ) && (keyboardValue >= keyboardButtonThreshold_PresetsOn - keyboardButtonThresholdTolerance ))
      { key=21;keyboardButtonPressed = true;}

      

      if ((key < 22) && (keyboardButtonPressed == true))
      {
        Serial.print("ADC odczyt poprawny: ");
        Serial.print(keyboardValue);
        Serial.print(" przycisk: ");
        Serial.println(key);
        keyboardValue = 0;
     
        if ((debugKeyboard == false) && (key < 10)) // Dla przyciskoq 0-9 wykonujemy akcje jak na pilocie
        { 
          if (f_Presets && !bankMenuEnable) {setPreset(key); return;} else {rcInputKey(key);}      
          //rcInputKey(key);
        }
        else if ((debugKeyboard == false) && (key == 11)) {bankMenuDisplay();} // Przycisk Memory wywyłuje menu wyboru Banku
        else if ((debugKeyboard == false) && (key == 12)) // Przycisk Shift zatwierdza zmiane stacji, banku, działa jak "OK" na pilocie
        { 
         ir_code = rcCmdOk; // Przycisk Auto TUning udaje OK
          bit_count = 32;
          calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC
        }
        else if ((debugKeyboard == false) && (key == 13)) // Przycisk Auto - przełaczanie tryb Zegar/Radio
        { 
          ir_code = rcCmdSrc; // Przycisk Auto TUning udaje Src
          bit_count = 32;
          calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC
        }
        else if ((debugKeyboard == false) && (key == 14)) // Przycisk Band udaje Back
        {  
          ir_code = rcCmdBack; // Udajemy komendy pilota
          bit_count = 32;
          calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC
        }
        else if ((debugKeyboard == false) && (key == 15)) // Przycisk Mute
        { 
          ir_code = rcCmdMute; // Przypisujemy kod polecenia z pilota
          bit_count = 32; // ustawiamy informacje, ze mamy pelen kod NEC do analizy 
          calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC     
        }
        else if ((debugKeyboard == false) && (key == 16)) // Przycisk Memory Scan - zmiana janości wyswietlacza - funkcja "Dimmer"
        { 
          ir_code = rcCmdDirect; // Udajemy komendy pilota
          bit_count = 32;
          calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC
        }
        else if ((debugKeyboard == false) && (key == 17)) {ir_code = rcCmdArrowLeft; bit_count = 32; calcNec();}
        else if ((debugKeyboard == false) && (key == 18)) {ir_code = rcCmdArrowRight; bit_count = 32; calcNec();}
        else if ((debugKeyboard == false) && (key == 19)) {ir_code = rcCmdArrowUp; bit_count = 32; calcNec();}
        else if ((debugKeyboard == false) && (key == 20)) {ir_code = rcCmdArrowDown; bit_count = 32; calcNec();}
        else if ((debugKeyboard == false) && (key == 21)) {ir_code = rcCmdBankPlus; bit_count = 32; calcNec();}  
        
        key=22; // Reset "KEY" do pozycji poza zakresem klawiatury
      }
    }
  } 
  
}

// ---- WYSWIETLANIE VOLUME (bez zmiany wartości) ----
void volumeDisplay()
{
  displayStartTime = millis();
  timeDisplay = false;
  displayActive = true;
  volumeSet = true;
  //volumeMute = false;  

  Serial.print("debug volumeDisplay -> Wartość głośności: ");
  Serial.println(volumeValue);
  //audio.setVolume(volumeValue);  // zakres 0...21
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeVolume();
  wsVolumeChange();
  return;
#endif
  String volumeValueStr = String(volumeValue);  // Zamiana liczby VOLUME na ciąg znaków
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf);
  gfx.drawStr(65, 33, "VOLUME");
  gfx.drawStr(163, 33, volumeValueStr.c_str());

  gfx.drawRFrame(21, 42, 214, 14, 3);                                                   // Rysujmey ramke dla progress bara głosnosci
  if (maxVolume == 42 && volumeValue > 0) { gfx.drawRBox(23, 44, volumeValue * 5, 10, 2);}  // Progress bar głosnosci
  if (maxVolume == 21 && volumeValue > 0) { gfx.drawRBox(23, 44, volumeValue * 10, 10, 2);} // Progress bar głosnosci
  gfx.sendBuffer();
  
  //wsVolumeChange(volumeValue); // Wyślij aktualizację przez WebSocket na strone WWW
  wsVolumeChange(); // Wyślij aktualizację przez WebSocket na strone WWW
  }


// ---- GŁOSNIEJ +1 ----
void volumeUp()
{
  volumeSet = true;
  timeDisplay = false;
  displayActive = true;
  volumeMute = false;
  displayStartTime = millis();   
  volumeValue++;

  if (volumeValue > maxVolume) {volumeValue = maxVolume;}
  audio.setVolume(volumeValue);  // zakres 0...21 lub 0...42
  volumeDisplay();
}

// ---- CISZEJ -1 ----
void volumeDown()
{
  volumeSet = true;
  timeDisplay = false;
  displayActive = true;
  displayStartTime = millis();
  volumeMute = false;
 
  volumeValue--;
  if (volumeValue < 1) {volumeValue = 1;}
  audio.setVolume(volumeValue);  // zakres 0...21 lub 0...42
  volumeDisplay();
}

// ---- KASOWANIE WSZYSTKICH FLAG ---- 
//Kasuje wszystkie flagi przebywania w menu, funkcjach itd. Pozwala pwrócic do wyswietlania ekranu głownego radia
void clearFlags()  
{
  timeDisplay = true;

  debugKeyboard = false;
  displayActive = false;
  listedStations = false;
  volumeSet = false;
  bankMenuEnable = false;
  bankNetworkUpdate = false;
  equalizerMenuEnable = false;
  eq16MenuActive = false;
  evo43Eq16EditGain = false;
  rcInputDigitsMenuEnable = false;
  f_voiceTimeBlocked = false;
  if (f_displaySleepTime && f_sleepTimerOn) {f_displaySleepTimeSet = true;}
  f_displaySleepTime = false;

  rcInputDigit1 = 0xFF; // czyscimy cyfre 1, flaga pustej zmiennej to FF
  rcInputDigit2 = 0xFF; // czyscimy cyfre 2, flaga pustej zmiennej to FF
  station_nr = stationFromBuffer; // Przywracamy numer stacji z bufora
  bank_nr = previous_bank_nr;     // Przywracamy numer banku z bufora
}


void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, AwsEventType type, void *arg, uint8_t *data, size_t len) 
{
  if (type == WS_EVT_CONNECT) 
  {
    Serial.println("debug Web -> WebSocket klient podlaczony");

    client->text("station:" + String(station_nr));
    client->text("stationname:" + stationName.substring(0, stationNameLenghtCut));
    client->text("volume:" + String(volumeValue)); 
    client->text("mute:" + String(volumeMute));
    client->text("bank:" + String(bank_nr));

    if (audio.isRunning() == true)
    {
     String nowText = evoWebNowPlayingText();
     sanitizeUtf8(nowText);
     client->text("stationtext$" + nowText);
    }
    else
    {
     client->text("stationtext$Oczekiwanie na tytul utworu...");
    }
    
    client->text("bitrate:" + String(bitrateString)); 
    client->text("samplerate:" + String(sampleRateString)); 
    client->text("bitpersample:" + String(bitsPerSampleString)); 

  
  if (mp3 == true) {client->text("streamformat:MP3"); }
  if (flac == true) {client->text("streamformat:FLAC"); }
  if (aac == true) {client->text("streamformat:AAC"); }
  if (vorbis == true) {client->text("streamformat:VORBIS"); }
  if (opus == true) {client->text("streamformat:OPUS"); }

  client->text("wifi:" + String(evoWifiRealLevel())); // APMS: realny poziom RSSI WiFi

  } 
  else if (type == WS_EVT_DATA) 
  {
    AwsFrameInfo *info = (AwsFrameInfo*)arg;
    if (info->final && info->index == 0 && info->len == len) 
    {
      String msg = "";
      for (size_t i = 0; i < len; i++) 
      {
        msg += (char) data[i];
      }

      Serial.println("debug Web -> Odebrano WS: " + msg);

      if (msg.startsWith("volume:")) 
      {
        int newVolume = msg.substring(7).toInt();
        volumeValue = newVolume;
        volumeMute = false;
        audio.setVolume(volumeValue);  // zakres 0...21 lub 0...42
        volumeDisplay();   // wyswietle wartosci Volume na wyswietlaczu OLED
      }
      else if (msg.startsWith("station:")) 
      {
        int newStation = msg.substring(8).toInt();
        station_nr = newStation;
        bank_nr = previous_bank_nr;
        urlPlaying = false;

        ir_code = rcCmdOk; // Przypisujemy kod polecenia z pilota
        bit_count = 32; // ustawiamy informacje, ze mamy pelen kod NEC do analizy 
        calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC    
      }
      else if (msg.startsWith("bank:")) 
      {
        int newBank = msg.substring(5).toInt();
        bank_nr = newBank;
        
        //bankMenuEnable = true;        
        //displayStartTime = millis();
        //timeDisplay = false;
        
        bankMenuDisplay();
        fetchStationsFromServer();
        clearFlags();
        urlPlaying = false;

        station_nr = 1;
        
        //Zatwirdzenie zmiany stacji
        ir_code = rcCmdOk; // Przypisujemy kod polecenia z pilota
        bit_count = 32; // ustawiamy informacje, ze mamy pelen kod NEC do analizy 
        calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC    
        
      }
      else if (msg.startsWith("displayMode")) 
      {
        ir_code = rcCmdSrc; // Udajemy kod pilota SRC - zmiana trybu wyswietlacza 
        bit_count = 32;
        calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC
      }

    }
  }

}


// ========================================================================
// APMS FIX WEB/HTTP + METADATA
// Lokalny adapter ESPAsyncWebServer.h w tej paczce pracuje na zwyklym
// WebServer, dlatego prawdziwe WebSockety nie dzialaja. Ponizsze funkcje
// daja stronie WWW sterowanie i odswiezanie metadanych przez zwykle HTTP.
// ========================================================================
String evoWebCleanText(String s)
{
  s.replace("\r", " ");
  s.replace("\n", " ");
  while (s.indexOf("  ") >= 0) s.replace("  ", " ");
  s.trim();
  return s;
}

String evoWebJsonEscape(String s)
{
  s = evoWebCleanText(s);
  sanitizeUtf8(s);
  s.replace("\\", "\\\\");
  s.replace("\"", "\\\"");
  s.replace("/", "\\/");
  s.replace("\b", "");
  s.replace("\f", "");
  s.replace("\t", " ");
  return s;
}

String evoWebNowPlayingText()
{
  String s = evoNowPlayingText;
  if (tftIsEmptyNowPlayingText(s) || !evoNowPlayingValid) s = "Oczekiwanie na tytul utworu...";
  s = evoWebCleanText(s);
  return s;
}

String evoWebStationNameText()
{
  String s = stationName;
  int e = s.indexOf("  ");
  if (e > 0) s = s.substring(0, e);
  s = evoWebCleanText(s);
  if (s.length() == 0) s = evoWebCleanText(stationNameStream);
  if (s.length() == 0) s = "EVO RADIO";
  return s;
}

String evoWebCodecText()
{
  if (streamCodec.length()) return streamCodec;
  if (mp3) return "MP3";
  if (flac) return "FLAC";
  if (aac) return "AAC";
  if (vorbis) return "VORBIS";
  if (opus) return "OPUS";
  return "----";
}

String evoWebSampleRateText()
{
  if (sampleRateString.length() && sampleRateString != "--.-")
  {
    int sr = sampleRateString.toInt();
    if (sr > 1000) return String(sr / 1000) + "." + String((sr % 1000) / 100) + "kHz";
  }
  if (SampleRate > 0) return String(SampleRate) + "." + String(SampleRateRest) + "kHz";
  return "---.-kHz";
}

String evoWebBitrateText()
{
  if (bitrateString.length() && bitrateString != "-?-") return bitrateString + "kbps";
  int br = audio.getBitRate() / 1000;
  if (br > 0) return String(br) + "kbps";
  return "---kbps";
}

String evoWebBitsText()
{
  if (bitsPerSampleString.length() && bitsPerSampleString != "--") return bitsPerSampleString + "bit";
  return "---bit";
}

String evoWebStateJson()
{
  String json;
  json.reserve(720);
  json += "{\"ok\":true";
  json += ",\"station\":" + String(station_nr);
  json += ",\"bank\":" + String(bank_nr);
  json += ",\"volume\":" + String(volumeValue);
  json += ",\"mute\":" + String(volumeMute ? 1 : 0);
  json += ",\"mode\":" + String(displayMode);
  json += ",\"wifi\":" + String(evoWifiRealLevel());
  json += ",\"rssi\":" + String(WiFi.status() == WL_CONNECTED ? WiFi.RSSI() : -127);
  json += ",\"stationname\":\"" + evoWebJsonEscape(evoWebStationNameText()) + "\"";
  json += ",\"stationtext\":\"" + evoWebJsonEscape(evoWebNowPlayingText()) + "\"";
  json += ",\"artist\":\"" + evoWebJsonEscape(evoNowPlayingArtist) + "\"";
  json += ",\"title\":\"" + evoWebJsonEscape(evoNowPlayingTitle) + "\"";
  json += ",\"metaok\":" + String(evoNowPlayingValid ? 1 : 0);
  json += ",\"samplerate\":\"" + evoWebJsonEscape(evoWebSampleRateText()) + "\"";
  json += ",\"bitrate\":\"" + evoWebJsonEscape(evoWebBitrateText()) + "\"";
  json += ",\"bitpersample\":\"" + evoWebJsonEscape(evoWebBitsText()) + "\"";
  json += ",\"streamformat\":\"" + evoWebJsonEscape(evoWebCodecText()) + "\"";
  json += ",\"ip\":\"" + evoWebJsonEscape(WiFi.status() == WL_CONNECTED ? WiFi.localIP().toString() : currentIP) + "\"";
  json += ",\"stations\":" + String(stationsCount);
  json += ",\"maxvolume\":" + String(maxVolume);
  json += "}";
  return json;
}

void evoWebApplyCommand(const String &cmdRaw, const String &valueRaw)
{
  String cmd = cmdRaw;
  cmd.trim();
  String value = valueRaw;
  value.trim();

  if (cmd == "volume")
  {
    int newVolume = constrain(value.toInt(), 0, maxVolume);
    volumeValue = newVolume;
    volumeMute = false;
    audio.setVolume(volumeValue);
    volumeDisplay();
    wsVolumeChange();
  }
  else if (cmd == "mute")
  {
    volumeMute = !volumeMute;
    audio.setVolume(volumeMute ? 0 : volumeValue);
    volumeDisplay();
    wsVolumeChange();
  }
  else if (cmd == "stationDelta")
  {
    int newStation = station_nr + value.toInt();
    if (newStation < 1) newStation = 1;
    if (stationsCount > 0 && newStation > stationsCount) newStation = stationsCount;
    station_nr = newStation;
    bank_nr = previous_bank_nr;
    urlPlaying = false;
    ir_code = rcCmdOk;
    bit_count = 32;
    calcNec();
  }
  else if (cmd == "bankDelta")
  {
    int newBank = bank_nr + value.toInt();
    if (newBank < 1) newBank = 1;
    if (newBank > bank_nr_max) newBank = bank_nr_max;
    bank_nr = newBank;
    bankMenuDisplay();
    fetchStationsFromServer();
    clearFlags();
    urlPlaying = false;
    station_nr = 1;
    ir_code = rcCmdOk;
    bit_count = 32;
    calcNec();
  }
  else if (cmd == "station")
  {
    int newStation = value.toInt();
    if (newStation < 1) newStation = 1;
    if (stationsCount > 0 && newStation > stationsCount) newStation = stationsCount;
    station_nr = newStation;
    bank_nr = previous_bank_nr;
    urlPlaying = false;
    ir_code = rcCmdOk;
    bit_count = 32;
    calcNec();
  }
  else if (cmd == "bank")
  {
    int newBank = value.toInt();
    if (newBank < 1) newBank = 1;
    if (newBank > bank_nr_max) newBank = bank_nr_max;
    bank_nr = newBank;
    bankMenuDisplay();
    fetchStationsFromServer();
    clearFlags();
    urlPlaying = false;
    station_nr = 1;
    ir_code = rcCmdOk;
    bit_count = 32;
    calcNec();
  }
  else if (cmd == "displayMode")
  {
    displayMode++;
    if (displayMode > displayModeMax) displayMode = 0;
    displayActive = false;
    ActionNeedUpdateTime = true;
    displayRadio();
  }
  else if (cmd == "mode")
  {
    displayMode = constrain(value.toInt(), 0, displayModeMax);
    displayActive = false;
    ActionNeedUpdateTime = true;
    displayRadio();
  }
}

// ========================================================================
// APMS FIX WEB V2: czysta strona HTTP bez zaleznosci od WebSocket.
// Dziala z prawdziwym ESPAsyncWebServer i z lokalnym adapterem.
// ========================================================================
String evoWebHtmlEscape(String s)
{
  s = evoWebCleanText(s);
  s.replace("&", "&amp;");
  s.replace("<", "&lt;");
  s.replace(">", "&gt;");
  s.replace("\"", "&quot;");
  s.replace("'", "&#39;");
  return s;
}

String evoWebStationListName(uint16_t idx)
{
  char station[STATION_NAME_LENGTH + 1];
  memset(station, 0, sizeof(station));
  if (idx >= MAX_STATIONS || psramData == nullptr) return String("");
  int length = psramData[idx * (STATION_NAME_LENGTH + 1)];
  if (length < 0) length = 0;
  if (length > STATION_NAME_LENGTH) length = STATION_NAME_LENGTH;
  for (int j = 0; j < length; j++)
  {
    station[j] = psramData[idx * (STATION_NAME_LENGTH + 1) + 1 + j];
  }
  return evoWebHtmlEscape(String(station).substring(0, stationNameLenghtCut));
}

String evoWebBuildMainPage()
{
  // =====================================================================
  // APMS WEB PANEL BAZOWY + LISTA KANALOW
  // ---------------------------------------------------------------------
  // To jest przywrocony wyglad bazowej strony Web Radio podobny do V7:
  // szare tlo, centralny wyswietlacz, suwak glosnosci, banki pamieci
  // oraz lista stacji w czterech kolumnach jak na oryginalnym panelu.
  // Sterowanie jest jednak poprawione: zamiast zalezec od WebSocket,
  // kazda komenda idzie przez HTTP /webcmd, a stan przez /api/state.
  // Dzieki temu dziala rowniez z adapterem AsyncWebServer/WebServer.
  // =====================================================================
  String html;
  html.reserve(36000);

  html += F("<!DOCTYPE HTML><html><head><meta charset='UTF-8'>");
  html += F("<link rel='icon' href='/favicon.ico' type='image/x-icon'>");
  html += F("<meta name='viewport' content='width=device-width, initial-scale=1'>");
  html += F("<title>Evo Web Radio</title>");
  html += F("<style>");
  html += F("html{font-family:Arial,Helvetica,sans-serif;text-align:center}body{max-width:1380px;margin:0 auto;padding-bottom:25px;background:#d0d0d0;color:#000}h2{font-size:19px;margin:4px 0 14px}.display{display:inline-block;padding:8px 10px;border:2px solid #4caf50;border-radius:14px;background:#4a4a4a;color:#aaa;width:345px;min-height:136px;text-align:center;white-space:nowrap;box-shadow:0 0 20px #4caf50;cursor:pointer}.stationTitle{font-size:20px;font-weight:bold;overflow:hidden;text-overflow:ellipsis;text-shadow:0 1px #000}.stationText{font-size:13px;color:#aaa;margin:9px 0;height:60px;line-height:20px;white-space:normal;overflow:hidden}.displayFooter{border-top:1px solid #4caf50;padding-top:5px;display:flex;gap:9px;justify-content:center;align-items:center;font-size:12px}.codecLine{display:flex;gap:5px;align-items:center;font-size:7px}.mute{color:#4caf50;font-weight:bold}.slider{appearance:none;-webkit-appearance:none;margin:14px;width:330px;height:10px;background:#4caf50;outline:none;border-radius:5px}.slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:35px;height:25px;background:#4a4a4a;cursor:pointer;border-radius:5px}.slider::-moz-range-thumb{width:35px;height:25px;background:#4a4a4a;cursor:pointer;border-radius:5px}.button,.buttonBank,.buttonBankSelected{border:1px solid #222;color:white;border-radius:5px;cursor:pointer}.button{background:#4caf50;padding:6px 13px;margin:2px}.buttonBank{background:#4caf50;padding:8px;width:35px;height:35px;margin:0 1.5px}.buttonBankSelected{background:#505050;padding:8px;width:35px;height:35px;margin:0 1.5px}.button:hover,.buttonBank:hover{background:#4a4a4a}.column{padding:5px;display:flex;justify-content:space-between;gap:22px}.column table{border:1px solid gray;border-collapse:collapse;margin:0}.column td{font-size:14px;border:1px solid gray;border-collapse:collapse;padding:0 3px;height:17px;line-height:17px;background:#d0d0d0}.column td:hover{font-weight:bold;background:#c4e8c6}.stationNumberList{width:25px;text-align:center}.stationList{width:230px;text-align:left;cursor:pointer}.stationNumberListSelected,.stationListSelected{background:#4caf50!important;font-weight:bold}.wifi-wrapper{display:flex;align-items:flex-end;gap:1px;height:13px;margin:0 0 0 2px}.wifiBar{width:2px;background:#555;border-radius:2px}.bar1{height:2px}.bar2{height:4px}.bar3{height:6px}.bar4{height:8px}.bar5{height:10px}.bar6{height:12px}.controls{margin-top:10px}.foot{font-size:11px;margin-top:10px}a{color:#000;text-decoration:none}@media(max-width:900px){.column{display:block}.column table{margin:7px auto}.stationList{width:270px}.display{width:92vw;max-width:345px}.slider{width:80vw;max-width:330px}}");
  html += F("</style></head><body><h2>Evo Web Radio</h2>");

  html += F("<div id='display' class='display' onclick='displayMode()'>");
  html += F("<div class='stationTitle' id='textStationName'>EVO RADIO</div>");
  html += F("<div class='stationText'><span id='stationText'>... No audio stream ! ...</span><br><span class='mute' id='muteIndicator'></span></div>");
  html += F("<div class='displayFooter'><span id='bankValue'>Bank: --</span><span class='codecLine'><span id='samplerate'>---.-kHz</span><span id='bitrate'>---kbps</span><span id='bitpersample'>---bit</span><span id='streamformat'>----</span> WiFi:<span class='wifi-wrapper'>");
  for (uint8_t i = 1; i <= 6; i++) {
    html += "<span class='wifiBar bar" + String(i) + "' id='wifiBar" + String(i) + "'></span>";
  }
  html += F("</span></span><span id='stationNumber'>Station: --</span></div></div>");

  html += F("<div class='controls'><p>Volume: <span id='textSliderValue'>");
  html += String(volumeValue);
  html += F("</span></p><p><input type='range' onchange='updateSliderVolume(this)' oninput='document.getElementById(\"textSliderValue\").innerText=this.value' id='volumeSlider' min='0' max='");
  html += String(maxVolume);
  html += F("' value='");
  html += String(volumeValue);
  html += F("' step='1' class='slider'></p>");
  html += F("<p><button class='button' onclick='volStep(-1)'>VOL-</button><button class='button' onclick='volStep(1)'>VOL+</button><button class='button' onclick='sendCmd(\"mute\",\"\")'>MUTE</button><button class='button' onclick='sendCmd(\"mode\",18)'>Styl 18</button><button class='button' onclick='sendCmd(\"mode\",20)'>Styl 20</button><button class='button' onclick='sendCmd(\"mode\",21)'>Styl 21</button></p>");
  html += F("<p>Memory Bank Selection:</p><p>");
  for (int i = 1; i < bank_nr_max + 1; i++) {
    html += "<button class='";
    html += (i == bank_nr) ? "buttonBankSelected" : "buttonBank";
    html += "' onclick='changeBank(" + String(i) + ")'>" + String(i) + "</button>";
  }
  html += F("</p></div>");

  // Lista stacji: 4 kolumny po 25 pozycji, jak w bazowym panelu Web Radio.
  html += F("<div class='column'>");
  const uint16_t listMax = (MAX_STATIONS > 100) ? 100 : MAX_STATIONS;
  for (uint16_t col = 0; col < 4; col++) {
    html += F("<table>");
    for (uint16_t r = 0; r < 25; r++) {
      uint16_t idx = col * 25 + r;
      if (idx >= listMax) break;
      String name = (idx < stationsCount) ? evoWebStationListName(idx) : String("");
      bool sel = ((int)idx + 1 == station_nr);
      html += F("<tr data-station='"); html += String(idx + 1); html += F("' onclick='changeStation("); html += String(idx + 1); html += F(")'>");
      html += F("<td class='stationNumberList"); if (sel) html += F(" stationNumberListSelected"); html += F("'>"); html += String(idx + 1); html += F("</td>");
      html += F("<td class='stationList"); if (sel) html += F(" stationListSelected"); html += F("'>"); html += name; html += F("</td></tr>");
    }
    html += F("</table>");
  }
  html += F("</div>");
  html += F("<div class='foot'>Web Radio, desktop, Evo: ");
  html += String(softwareRev);
  html += F("<br>IP: <span id='ipText'>");
  html += currentIP;
  html += F("</span><br><a class='button' style='display:inline-block;padding:4px 14px;margin-top:8px;color:white' href='/menu'>Menu</a> <a class='button' style='display:inline-block;padding:4px 14px;margin-top:8px;color:white' href='/api/ping'>Ping</a> <a class='button' style='display:inline-block;padding:4px 14px;margin-top:8px;color:white' href='/api/state'>API</a></div>");

  html += F("<script>");
  html += F("function el(i){return document.getElementById(i)}function tx(i,v){var e=el(i);if(e)e.textContent=v}function setWifi(level){level=parseInt(level)||0;for(var i=1;i<=6;i++){var b=el('wifiBar'+i);if(!b)continue;b.style.backgroundColor=(i<=level)?(level<=2?'#d73333':(level<=4?'#d6a900':'#4CAF50')):'#555'}}function highlightStation(n){document.querySelectorAll('.stationNumberListSelected').forEach(e=>e.classList.remove('stationNumberListSelected'));document.querySelectorAll('.stationListSelected').forEach(e=>e.classList.remove('stationListSelected'));var row=document.querySelector('tr[data-station=\"'+n+'\"]');if(row){row.children[0].classList.add('stationNumberListSelected');row.children[1].classList.add('stationListSelected');}}function applyState(d){if(!d)return;tx('textStationName',d.stationname||'EVO RADIO');tx('stationText',d.stationtext||'... No audio stream ! ...');tx('muteIndicator',d.mute?'MUTED':'');tx('bankValue','Bank: '+((d.bank!==undefined?d.bank:'--')));tx('stationNumber','Station: '+((d.station!==undefined?d.station:'--')));tx('samplerate',d.samplerate||'---.-kHz');tx('bitrate',d.bitrate||'---kbps');tx('bitpersample',d.bitpersample||'---bit');tx('streamformat',d.streamformat||'----');tx('textSliderValue',(d.volume!==undefined?d.volume:'--'));tx('ipText',d.ip||'');var sl=el('volumeSlider');if(sl&&d.volume!==undefined)sl.value=d.volume;setWifi(d.wifi);if(d.station)highlightStation(d.station)}");
  html += F("function refresh(){fetch('/api/state?ts='+Date.now(),{cache:'no-store'}).then(r=>r.json()).then(applyState).catch(e=>{tx('stationText','Brak polaczenia ze strona API /api/state')})}function sendCmd(cmd,val){return fetch('/webcmd?cmd='+encodeURIComponent(cmd)+'&value='+encodeURIComponent(val||'')+'&ts='+Date.now(),{cache:'no-store'}).then(r=>r.json()).then(applyState).catch(e=>{tx('stationText','Blad komendy WWW')})}function updateSliderVolume(){var v=el('volumeSlider').value;tx('textSliderValue',v);sendCmd('volume',v)}function volStep(d){var s=el('volumeSlider');var v=Math.max(+s.min,Math.min(+s.max,(+s.value)+d));s.value=v;tx('textSliderValue',v);sendCmd('volume',v)}function changeStation(n){sendCmd('station',n)}function changeBank(n){sendCmd('bank',n)}function displayMode(){sendCmd('displayMode','')}document.addEventListener('DOMContentLoaded',function(){refresh();setInterval(refresh,2000);var s=el('volumeSlider');if(s){s.addEventListener('wheel',function(ev){ev.preventDefault();volStep(ev.deltaY<0?1:-1);});}});");
  html += F("</script></body></html>");
  return html;
}



void bufforAudioInfo()
{
  int bitRateBps = audio.getBitRate() / 1000;
  int bytesPerSecond = 0;

  if (bitRateBps > 0) { bytesPerSecond = bitRateBps / 8;}   // kB/s

  int inputBufferBytes = audio.inBufferFilled() / 1000;

  // zabezpieczenie przed dzieleniem przez zero i innymi błędami
  if (bytesPerSecond > 0 && inputBufferBytes > 8) 
  {
    audioBufferTime = inputBufferBytes / bytesPerSecond;
  } 
  else 
  {
    audioBufferTime = 0;
  }

  
  
  Serial.print("debug-- Audio Bufor wolne: ");
  Serial.print(audio.inBufferFree());
  Serial.print(" / ");
  Serial.print("zajęte: ");
  Serial.print(audio.inBufferFilled());
  
  Serial.print("  Muzyka w buforze na: " + String(audioBufferTime) + " sek. " );
  Serial.print("  bitrate: " );
  Serial.print(audio.getBitRate());
  Serial.print("  " );
  /*
  if (audioBufferTime >= 10) {Serial.println("##########");}
  if (audioBufferTime >= 9) {Serial.println("#########_");}
  if (audioBufferTime >= 8) {Serial.println("########__");}
  if (audioBufferTime >= 7) {Serial.println("#######___");}
  if (audioBufferTime >= 6) {Serial.println("######____");}
  if (audioBufferTime >= 5) {Serial.println("#####_____");}
  if (audioBufferTime == 4) {Serial.println("####______");}
  if (audioBufferTime == 3) {Serial.println("###_______");}
  if (audioBufferTime == 2) {Serial.println("##________");}
  if (audioBufferTime == 1) {Serial.println("#_________");}
  if (audioBufferTime == 0) {Serial.println("__________");}
  */
  
  if (audioBufferTime < 0)  audioBufferTime = 0;
  if (audioBufferTime > 10) audioBufferTime = 10;

  /*
  char bar[11];
  for (int i = 0; i < 10; i++) {bar[i] = (i < audioBufferTime) ? '#' : '_'; }
  bar[10] = '\0';
  Serial.println(bar);
  */
  
  Serial.print("[");
  for (int i = 0; i < 10; i++) {if (i < audioBufferTime) Serial.print('#'); else Serial.print('_'); }
  Serial.println("]");

  Serial.print("Free internal RAM: ");
  Serial.println(heap_caps_get_free_size(MALLOC_CAP_INTERNAL));

  Serial.print("Free PSRAM: ");
  Serial.println(heap_caps_get_free_size(MALLOC_CAP_SPIRAM));
  
  Serial.print("Free heap: ");
  Serial.println(ESP.getFreeHeap());

  Serial.print("Total heap: ");
  Serial.println(ESP.getHeapSize());

  Serial.print("Min free heap (od startu): ");
  Serial.println(ESP.getMinFreeHeap());

  Serial.print("Free stack (words): ");
  Serial.println(uxTaskGetStackHighWaterMark(NULL));

  Serial.print("Loop task free stack (bytes): ");
  Serial.println(uxTaskGetStackHighWaterMark(NULL) * 4);

}

// Funkcja obsługująca przerwanie (reakcja na zmianę stanu pinu)
void IRAM_ATTR pulseISR()
{
  if (digitalRead(recv_pin) == HIGH)
  {
    pulse_start_high = micros();  // Zapis początku impulsu
  }
  else
  {
    pulse_end_high = micros();    // Zapis końca impulsu
    pulse_ready = true;
  }

  if (digitalRead(recv_pin) == LOW)
  {
    pulse_start_low = micros();  // Zapis początku impulsu
  }
  else
  {
    pulse_end_low = micros();    // Zapis końca impulsu
    pulse_ready_low = true;
  }

   // ----------- ANALIZA PULSOW -----------------------------
  if (pulse_ready_low) // spradzamy czy jest stan niski przez 9ms - start ramki
  {
    pulse_duration_low = pulse_end_low - pulse_start_low;
  
    if (pulse_duration_low > (LEAD_HIGH - TOLERANCE) && pulse_duration_low < (LEAD_HIGH + TOLERANCE))
    {
      pulse_duration_9ms = pulse_duration_low; // przypisz czas trwania puslu Low do zmiennej puls 9ms
      pulse_ready9ms = true; // flaga poprawnego wykrycia pulsu 9ms w granicach tolerancji
    }

  }

  // Sprawdzenie, czy impuls jest gotowy do analizy
  if ((pulse_ready== true) && (pulse_ready9ms = true))
  {
    pulse_ready = false;
    pulse_ready9ms = false; // kasujemy flage wykrycia pulsu 9ms

    // Obliczenie czasu trwania impulsu
    pulse_duration = pulse_end_high - pulse_start_high;
    //Serial.println(pulse_duration); odczyt dlugosci pulsow z pilota - debug
    if (!data_start_detected)
    {
    
      // Oczekiwanie na sygnał 4,5 ms wysoki
      if (pulse_duration > (LEAD_LOW - TOLERANCE) && pulse_duration < (LEAD_LOW + TOLERANCE))
      {
        pulse_duration_4_5ms = pulse_duration;
        // Początek sygnału: 4,5 ms wysoki
        
        data_start_detected = true;  // Ustawienie flagi po wykryciu sygnału wstępnego
        bit_count = 0;               // Reset bit_count przed odebraniem danych
        ir_code = 0;                 // Reset kodu IR przed odebraniem danych
      }
    }
    else
    {
      // Sygnały dla bajtów (adresu ADDR, IADDR, komendy CMD, ICMD) zaczynają się po wstępnym sygnale
      if (pulse_duration > (HIGH_THRESHOLD - TOLERANCE) && pulse_duration < (HIGH_THRESHOLD + TOLERANCE))
      {
        ir_code = (ir_code << 1) | 1;  // Dodanie "1" do kodu IR
        //bit_count++;
        bit_count = bit_count + 1;
        pulse_duration_1690us = pulse_duration;
       

      }
      else if (pulse_duration > (LOW_THRESHOLD - TOLERANCE) && pulse_duration < (LOW_THRESHOLD + TOLERANCE))
      {
        ir_code = (ir_code << 1) | 0;  // Dodanie "0" do kodu IR
        //bit_count++;
        bit_count = bit_count + 1;
        pulse_duration_560us = pulse_duration;
       
      }

      // Sprawdzenie, czy otrzymano pełny 32-bitowy kod IR
      if (bit_count == 32)
      {
        // Symulacja aktywnosci LED IR
        //#ifdef IR_LED
          //digitalWrite(IR_LED, HIGH);
        //#endif
        
        // Rozbicie kodu na 4 bajty
        uint8_t ADDR = (ir_code >> 24) & 0xFF;  // Pierwszy bajt
        uint8_t IADDR = (ir_code >> 16) & 0xFF; // Drugi bajt (inwersja adresu)
        uint8_t CMD = (ir_code >> 8) & 0xFF;    // Trzeci bajt (komenda)
        uint8_t ICMD = ir_code & 0xFF;          // Czwarty bajt (inwersja komendy)

        // Sprawdzenie poprawności (inwersja) bajtów adresu i komendy
        if ((ADDR ^ IADDR) == 0xFF && (CMD ^ ICMD) == 0xFF)
        {
          data_start_detected = false;
          //bit_count = 0;
        }
        else
        {
          ir_code = 0; 
          data_start_detected = false;
          //bit_count = 0;        
        }

      }
		  
    }
  }
 //runTime2 = esp_timer_get_time();
}

void displayEqualizer() // Funkcja rysująca menu 3-punktowego equalizera
{

  displayStartTime = millis();  // Uaktulniamy czas dla funkcji auto-pwrotu z menu
  equalizerMenuEnable = true;   // Ustawiamy flage menu equalizera
  timeDisplay = false;          // Wyłaczamy zegar
  displayActive = true;         // Wyswietlacz aktywny
  
  Serial.println("--Equalizer--");
  Serial.print("Wartość tonów Niskich/Low:   ");
  Serial.println(toneLowValue);
  Serial.print("Wartość tonów Średnich/Mid:  ");
  Serial.println(toneMidValue);
  Serial.print("Wartość tonów Wysokich/High: ");
  Serial.println(toneHiValue);
  
  Serial.print("Wartość Baalansu: ");
  Serial.println(balanceValue);

  audio.setTone(toneLowValue, toneMidValue, toneHiValue); // Zakres regulacji -40 + 6dB jako int8_t ze znakiem
  audio.setBalance(balanceValue);
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeEqualizer();
  return;
#endif

  gfx.setDrawColor(1);
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf);
  gfx.drawStr(60, 14, "EQUALIZER");
  //gfx.drawStr(1, 14, "EQUALIZER");
  gfx.setFont(spleen6x12PL);
  //gfx.setCursor(138,12);
  //gfx.print("P1    P2    P3    P4");
  uint8_t xTone;
  uint8_t yTone;  
  
  // ---- Tony Wysokie ----
  xTone=0; 
  yTone=28;
  gfx.setCursor(xTone,yTone);
  if (toneHiValue >= 0) {gfx.print("High:  " + String(toneHiValue) + "dB");}  // Dla wartosci dodatnich piszemy normalnie
  if ((toneHiValue < 0) && (toneHiValue >= -9)) {gfx.print("High: " + String(toneHiValue) + "dB");}    // Dla wartosci ujemnych piszemy o 1 znak wczesniej
  if ((toneHiValue < 0) && (toneHiValue < -9)) {gfx.print("High:" + String(toneHiValue) + "dB");}    // Dla wartosci ujemnych ponizej -9 piszemy o 2 znak wczesniej
  
  xTone=20;
  if (toneSelect == 1) 
  { 
    gfx.drawRBox(xTone+56,yTone-9,154,9,1); // Rysujemy biały pasek pod regulacją danego tonu  
    gfx.setDrawColor(0); 
    gfx.drawLine(xTone+57,yTone-5,xTone+208,yTone-5);
    if (toneHiValue >= 0){ gfx.drawRBox((6 * toneHiValue) + xTone + 128,yTone-7,10,5,1);}
    if (toneHiValue < 0) { gfx.drawRBox((6 * toneHiValue) + xTone + 128,yTone-7,10,5,1);}
    gfx.setDrawColor(1);
  }
  else 
  {
    gfx.drawLine(xTone+57,yTone-5,xTone+208,yTone-5);
    if (toneHiValue >= 0){ gfx.drawRBox((6 * toneHiValue) + xTone + 128,yTone-7,10,5,1);}
    if (toneHiValue < 0) { gfx.drawRBox((6 * toneHiValue) + xTone + 128,yTone-7,10,5,1);}
  }

  // ---- Tony średnie ----
  xTone=0;
  yTone=40;
  gfx.setCursor(xTone,yTone);
  if (toneMidValue >= 0) {gfx.print("Mid:   " + String(toneMidValue) + "dB");}  // Dla wartosci dodatnich piszemy normalnie
  if ((toneMidValue < 0) && (toneMidValue >= -9)) {gfx.print("Mid:  " + String(toneMidValue) + "dB");}
  if ((toneMidValue < 0) && (toneMidValue < -9))  {gfx.print("Mid: " + String(toneMidValue) + "dB");} 
  
  xTone=20;
  if (toneSelect == 2) 
  { 
    gfx.drawRBox(xTone+56,yTone-9,154,9,1);
    gfx.setDrawColor(0);
    gfx.drawLine(xTone+57,yTone-5,xTone + 208,yTone-5);
    //gfx.drawLine(xTone+57,yTone-4,xTone + 208,yTone-4);
    if (toneMidValue >= 0) { gfx.drawRBox((6 * toneMidValue) + xTone + 128,yTone-7,10,5,1);}
    if (toneMidValue < 0)  { gfx.drawRBox((6 * toneMidValue) + xTone + 128,yTone-7,10,5,1);}
    gfx.setDrawColor(1);
  }
  else
  {
    gfx.drawLine(xTone+57,yTone-5,xTone + 208,yTone-5);
    //gfx.drawLine(xTone+57,yTone-4,xTone + 208,yTone-4);
    if (toneMidValue >= 0) { gfx.drawRBox((6 * toneMidValue) + xTone + 128,yTone-7,10,5,1);}
    if (toneMidValue < 0)  { gfx.drawRBox((6 * toneMidValue) + xTone + 128,yTone-7,10,5,1);}
    //gfx.drawRBox((3 * toneMidValue) + xTone + 138,yTone-7,10,6,1);
  }


  // Tony niskie
  xTone=0; 
  yTone=52;
  gfx.setCursor(xTone,yTone);
  if (toneLowValue >= 0) { gfx.print("Low:   " + String(toneLowValue) + "dB");}
  if ((toneLowValue < 0) && (toneLowValue >= -9)) { gfx.print("Low:  " + String(toneLowValue) + "dB");}
  if ((toneLowValue < 0) && (toneLowValue < -9)) { gfx.print("Low: " + String(toneLowValue) + "dB");}
  xTone=20;
  if (toneSelect == 3) 
  { 
    gfx.drawRBox(xTone+56,yTone-9,154,9,1);
    gfx.setDrawColor(0);
    gfx.drawLine(xTone + 57,yTone-5,xTone + 208,yTone-5);
    if ( toneLowValue >= 0 ) { gfx.drawRBox((6 * toneLowValue) + xTone + 128,yTone-7,10,5,1);}
    if ( toneLowValue < 0 )  { gfx.drawRBox((6 * toneLowValue) + xTone + 128,yTone-7,10,5,1);}
    gfx.setDrawColor(1);
  }
  else
  {
    gfx.drawLine(xTone + 57,yTone-5,xTone + 208,yTone-5);
    if ( toneLowValue >= 0 ) { gfx.drawRBox((6 * toneLowValue) + xTone + 128,yTone-7,10,5,1);}
    if ( toneLowValue < 0 )  { gfx.drawRBox((6 * toneLowValue) + xTone + 128,yTone-7,10,5,1);}
  }

// Balans
  xTone=0; 
  yTone=64;
  gfx.setCursor(xTone,yTone);
  if (balanceValue >= 0) { gfx.print("Bal:   " + String(balanceValue) + "dB");}
  if ((balanceValue < 0) && (balanceValue >= -9)) { gfx.print("Bal:  " + String(balanceValue) + "dB");}
  if ((balanceValue < 0) && (balanceValue < -9)) { gfx.print("Bal: " + String(balanceValue) + "dB");}
  xTone=20;
  if (toneSelect == 4) 
  { 
    gfx.drawRBox(xTone+56,yTone-9,154,9,1);
    gfx.setDrawColor(0);
    gfx.drawLine(xTone + 64,yTone-5,xTone + 201,yTone-5);
    gfx.setFont(u8g2_font_04b_03_tr);
    gfx.drawStr(xTone + 58, yTone-2, "L");
    gfx.drawStr(xTone + 204, yTone-2, "R");
    if ( balanceValue >= 0 ) { gfx.drawRBox((4 * balanceValue) + xTone + 128,yTone-7,10,5,1);}
    if ( balanceValue < 0 )  { gfx.drawRBox((4 * balanceValue) + xTone + 128,yTone-7,10,5,1);}
    gfx.setDrawColor(1);
  }
  else
  {
    gfx.drawLine(xTone + 64,yTone-5,xTone + 201,yTone-5);
    gfx.setFont(u8g2_font_04b_03_tr);
    gfx.drawStr(xTone + 58, yTone -2, "L");
    gfx.drawStr(xTone + 204, yTone-2, "R");
    if ( balanceValue >= 0 ) { gfx.drawRBox((4 * balanceValue) + xTone + 128,yTone-7,10,5,1);}
    if ( balanceValue < 0 )  { gfx.drawRBox((4 * balanceValue) + xTone + 128,yTone-7,10,5,1);}

  }

  gfx.sendBuffer(); 
}


void displayInfo()
{
  displayStartTime = millis();  // Uaktulniamy czas dla funkcji auto-powrotu z menu
  timeDisplay = false;          // Wyłaczamy zegar
  displayActive = true;         // Wyswietlacz aktywny
  
  uint64_t chipid = ESP.getEfuseMac();

  char buf[100];
  snprintf(buf, sizeof(buf),
          "ESP32 SN:%04X%08X,  FW Ver.: %s",
          (uint16_t)(chipid >> 32),
          (uint32_t)chipid,
          softwareRev);

String chipSN = buf;
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeInfo(chipSN);
  return;
#endif
  gfx.clearBuffer();
  gfx.setFont(spleen6x12PL);
  gfx.drawStr(0, 10, "Info:");
  //gfx.setCursor(0,25); gfx.print("ESP32 SN:" + String(ESP.getEfuseMac()) + ",  FW Ver.:" + String(softwareRev));
  gfx.setCursor(0,25); gfx.print(chipSN);
  gfx.setCursor(0,38); gfx.print("Hostname:" + String(hostname) + ",  WiFi Signal:" + String(WiFi.RSSI()) + "dBm");
  gfx.setCursor(0,51); gfx.print("WiFi SSID:" + String(wifiManager.getWiFiSSID()));
  gfx.setCursor(0,64); gfx.print("IP:" + currentIP + "  MAC:" + String(WiFi.macAddress()) );
  
  gfx.sendBuffer();
}
/*
void audioProcessing(void *p)
{
  while (true) {
  audio.loop();
  vTaskDelay(1 / portTICK_PERIOD_MS); // Opóźnienie 1 milisekundy
  }
}
*/


//  OTA update callback dla Wifi Managera i trybu Recovery Mode
void handlePreOtaUpdateCallback()
{
  Update.onProgress([](unsigned int progress, unsigned int total) 
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
    tftNativeOTA(progress, total);
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
    return;
#endif
    gfx.setCursor(1,56); gfx.printf("Update: %u%%\r", (progress / (total / 100)) );
    gfx.setCursor(80,56); gfx.print(String(progress) + "/" + String(total));
    gfx.sendBuffer();
    Serial.printf("Progress: %u%%\r", (progress / (total / 100)));
  });
}

void recoveryModeCheck()
{
  unsigned long lastTurnTime = 0;

  if (digitalRead(SW_PIN2) == 0)
  {
    int8_t recoveryMode = 0;
    gfx.clearBuffer();
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(1,14, "RECOVERY / RESET MODE - release encoder");
    gfx.sendBuffer();
    delay(2000);

    while (digitalRead(SW_PIN2) == 0) {delay(10);}  
    gfx.drawStr(1,14, "Please Wait...                         ");
    gfx.sendBuffer();
    delay(1000);
    gfx.clearBuffer();
     
    prev_CLK_state2 = digitalRead(CLK_PIN2);
    
    while (true)
    {
      if (millis() - lastTurnTime > 50)
      {  
        CLK_state2 = digitalRead(CLK_PIN2);
        //if (CLK_state2 != prev_CLK_state2 && CLK_state2 == HIGH)  // Sprawdzenie, czy stan CLK zmienił się na wysoki
        if (CLK_state2 != prev_CLK_state2 && CLK_state2 == LOW)  // Sprawdzenie, czy stan CLK zmienił się na wysoki
        //if (CLK_state2 != prev_CLK_state2)
        {
          //if (digitalRead(DT_PIN2) == HIGH)
          if (digitalRead(DT_PIN2) != CLK_state2)
          { recoveryMode++; }
          else
          { recoveryMode--; }

          if (recoveryMode > 1) {recoveryMode =1;}
          if (recoveryMode < 0) {recoveryMode =0;}
          lastTurnTime = millis();
        }
        prev_CLK_state2 = CLK_state2;
      }

      gfx.drawStr(1,14, "[ -- Rotate Enckoder -- ]            ");

      if (recoveryMode == 0)
      {
        gfx.drawStr(1,28, ">> RESET BANK=1, STATION=1 <<");
        gfx.drawStr(1,42, "   RESET WIFI SSID, PASSWD   ");  
      }
      else if (recoveryMode == 1)
      {
        gfx.drawStr(1,28, "   RESET BANK=1, STATION=1   ");
        gfx.drawStr(1,42, ">> RESET WIFI SSID, PASSWD <<");      
      }
      gfx.sendBuffer();
      
      if (digitalRead(SW_PIN2) == 0)
      {
        if (recoveryMode == 0)
        {
          bank_nr = 1;
          station_nr = 1;
          saveStationOnSD();
          gfx.clearBuffer(); 
          gfx.drawStr(1,14, "SET BANK=1, STATION=1         ");
          gfx.drawStr(1,28, "ESP will RESET in 3sec.       ");
          gfx.sendBuffer();
          delay(3000);
          ESP.restart();
        }  
        else if (recoveryMode == 1)
        {
          gfx.clearBuffer();
          gfx.drawStr(1,14, "WIFI SSID, PASSWD CLEARED   ");
          gfx.drawStr(1,28, "ESP will RESET in 3sec.     ");
          gfx.sendBuffer();
          wifiManager.resetSettings();
          delay(3000);
          ESP.restart();
        }
      }
      
      delay(20);
    }   
  } 
}


void displayDimmerTimer()
{
  displayDimmerTimeCounter++;
  
  if ((displayActive == true) ) //&& (displayDimmerActive == true) Jezeli wysweitlacz aktywny i jest przyciemniony
  { 
    displayDimmerTimeCounter = 0;
    //Serial.println("debug displayDimmerTimer -> displayDimmerTimeCounter = 0");
    if (displayDimmerActive == true) {displayDimmer(0);}
  }
  // Jesli upłynie czas po którym mamy przyciemnic wyswietlacz i funkcja przyciemniania włączona oraz nie jestemswy w funkcji aktulizacji OTA to
  if ((displayDimmerTimeCounter >= displayAutoDimmerTime) && (displayAutoDimmerOn == true) && (fwupd == false)) 
  {
    if (displayDimmerActive == false) // jesli wyswietlacz nie jest jeszcze przyciemniony
    {
      displayDimmer(1); // wywolujemy funkcje przyciemnienia z parametrem 1 (załacz)
      timer2.detach();
    }
    displayDimmerTimeCounter = 0;
  }

  displayPowerSaveTimeCounter++;
  
  if (displayPowerSaveTimeCounter >= displayPowerSaveTime && displayPowerSaveEnabled && !fwupd) 
  {
    displayPowerSaveTimeCounter = 0;
    displayPowerSave(1);
    timer2.detach();
  }
}

void displayDimmer(bool dimmerON)
{
  displayDimmerActive = dimmerON;
  Serial.print("debug displayDimmer -> displayDimmerActive: ");
  Serial.println(displayDimmerActive);
  
  if ((dimmerON == 1) && (displayActive == false) && (fwupd == false)) { gfx.setContrast(dimmerDisplayBrightness);}
  if (dimmerON == 0) 
  { 
    displayPowerSave(0);
    gfx.setContrast(displayBrightness); 
    displayDimmerTimeCounter = 0;
    displayPowerSaveTimeCounter = 0;
    timer2.attach(1, displayDimmerTimer);
  }
}

#ifdef twoEncoders
  void handleEncoder1()
  {
    CLK_state1 = digitalRead(CLK_PIN1);                       // Odczytanie aktualnego stanu pinu CLK enkodera 1
    if (CLK_state1 != prev_CLK_state1 && CLK_state1 == HIGH)  // Sprawdzenie, czy stan CLK zmienił się na wysoki
    {
      timeDisplay = false;
      displayActive = true;
      displayStartTime = millis();

      if (bankMenuEnable == false)  // Przewijanie listy stacji radiowych
      {
        station_nr = currentSelection + 1;
        if (digitalRead(DT_PIN1) == HIGH) 
        {
          station_nr--;
          //if (listedStations == 1) station_nr--;
          if (station_nr < 1) 
          {
            station_nr = stationsCount;//1;
          }
          Serial.print("debug ENC1 -> Numer stacji do tyłu: ");
          Serial.println(station_nr);
          scrollUp();
        } 
        else 
        {
          station_nr++;
          if (station_nr > stationsCount) 
          {
            station_nr = 1;//stationsCount;
          }
          Serial.print("debug ENC1 -> Numer stacji do przodu: ");
          Serial.println(station_nr);
          scrollDown();
        }
        displayStations();
      } 
      else // Przewijanie listy bankow
      {
        if (bankMenuEnable == true)  // Przewijanie listy banków stacji radiowych
        {
          if (digitalRead(DT_PIN1) == HIGH) 
          {
            bank_nr--;
            if (bank_nr < 1) 
            {
              bank_nr = bank_nr_max;
            }
          } 
          else 
          {
            bank_nr++;
            if (bank_nr > bank_nr_max) 
            {
              bank_nr = 1;
            }
          }
          bankMenuDisplay();
        }
      }
    }
    prev_CLK_state1 = CLK_state1;
    


    if ((button1.isReleased()) && (listedStations == false)) 
    {
      timeDisplay = false;
      volumeSet = false;
      displayActive = true;
      displayStartTime = millis();

      if (bankMenuEnable == true)
      {
        bankMenuEnable = false;
        fetchStationsFromServer();
        changeStation();
        displayRadio();
        clearFlags();
        return;
      }
      else if (bankMenuEnable == false)
      {
        bankMenuEnable = true;  
        bankMenuDisplay();// Po nacisnieciu enkodera1 wyswietlamy menu Banków
        return;
      }
    }
    
    
    /*
    if ((button1.isReleased()) && (listedStations == false) && (bankMenuEnable == true)) 
    {
      bankMenuEnable = false;
      displayStartTime = millis();
      timeDisplay = false;
      volumeSet = false;
      displayActive = true;
      previous_bank_nr = bank_nr;
      station_nr = 1;
      fetchStationsFromServer();
      changeStation();
      displayRadio();
      clearFlags();
      return;
    }
    */

    /*
    if (button1.isPressed() && listedStations == false && bankMenuEnable == false) 
    {
      
      bankMenuEnable = true;
      listedStations = false;
      volumeSet = false;
      timeDisplay = false;
      volumeSet = false;
      displayActive = true;
      
      displayStartTime = millis();
      bankMenuDisplay();// Po nacisnieciu enkodera1 wyswietlamy menu Banków
      return;
      
    }
    //*/
    

    if (button1.isReleased() && listedStations) 
    {
      listedStations = false;
      volumeSet = false;
      changeStation();
      displayRadio();
      //gfx.sendBuffer();
      clearFlags();
      return;
    }

    

    
  }
#endif


void handleEncoder2StationsVolumeClick()
{
  CLK_state2 = digitalRead(CLK_PIN2);                       // Odczytanie aktualnego stanu pinu CLK enkodera 2
  if (CLK_state2 != prev_CLK_state2 && CLK_state2 == HIGH)  // Sprawdzenie, czy stan CLK zmienił się na wysoki
  {
    timeDisplay = false;
    displayActive = true;
    displayStartTime = millis();

    if ((volumeSet == false) && (bankMenuEnable == false))  // Przewijanie listy stacji radiowych
    {
      currentSelection = station_nr - 1;

      if (digitalRead(DT_PIN2) == HIGH) 
      {  
        if (listedStations == true)
        {
          station_nr--;
          if (station_nr < 1) {station_nr = stationsCount;} //1;
          Serial.print("Numer stacji do tyłu: "); Serial.println(station_nr);
          
          scrollUp();
        }
        else
        {
          if (maxSelection() - currentSelection < maxVisibleLines) // 98 - 98 = 0 < 4 = YES
          {
            firstVisibleLine = maxSelection() - maxVisibleLines + 1; // 98 - 4- 1 -> 93, za daleko, musi byc 95
          } 
          else 
          {
            firstVisibleLine = currentSelection;
          }
          /*
          if (currentSelection > 0) // jezeli obecne zaznaczenie ma wartosc mniejsza niz pierwsza wyswietlana linia
          { 
            if (currentSelection < firstVisibleLine) {firstVisibleLine = currentSelection;}
          } 
          else // Jeśli osiągnięto wartość 0, przejdź do najwyższej wartości 
          {  
            if (currentSelection == maxSelection()) {firstVisibleLine = currentSelection - maxVisibleLines + 1;} // Ustaw pierwszą widoczną linię na najwyższą
            
          } 
          */  
        } 
      }  
      else 
      {
        if (listedStations == true)
        {
          station_nr++;
          //if (listedStations == 1) station_nr++;
          if (station_nr > stationsCount) {station_nr = 1;}//stationsCount;
          Serial.print("Numer stacji do przodu: "); Serial.println(station_nr);

          scrollDown();
        }
        else
        {    
                 
          //currentSelection = station_nr - 1; // Przywracamy zaznaczenie obecnie grajacej stacji
          
          if (maxSelection() - currentSelection < maxVisibleLines) {firstVisibleLine = maxSelection() - maxVisibleLines + 1;} else {firstVisibleLine = currentSelection;}
          /*
          if (currentSelection > 0)
          {
            if (currentSelection < firstVisibleLine) // jezeli obecne zaznaczenie ma wartosc mniejsza niz pierwsza wyswietlana linia
            {
              firstVisibleLine = currentSelection;
            }
          } 
          else 
          {  // Jeśli osiągnięto wartość 0, przejdź do najwyższej wartości
            if (currentSelection = maxSelection())
            {
              firstVisibleLine = currentSelection - maxVisibleLines + 1;  // Ustaw pierwszą widoczną linię na najwyższą
            }
          }
          */ 
        }
      }
      displayStations();
    } 
    else 
    {
      if (bankMenuEnable == false)
      {
        if (digitalRead(DT_PIN2) == HIGH) // pokrecenie enkoderem 2
        {volumeDown();} 
        else 
        {volumeUp();}
      }
    }

    if (bankMenuEnable == true)  // Przewijanie listy banków stacji radiowych
    {
      if (digitalRead(DT_PIN2) == HIGH) 
      {
        bank_nr--;
        if (bank_nr < 1) {bank_nr = bank_nr_max;}
      } 
      else 
      {
        bank_nr++;
        if (bank_nr > bank_nr_max) {bank_nr = 1;}
      }
      bankMenuDisplay();
    }
  }
  prev_CLK_state2 = CLK_state2;
      
  if ((button2.isReleased()) && (listedStations == true)) 
  {
    listedStations = false;
    volumeSet = false;
    changeStation();
    displayRadio();
    gfx.sendBuffer();
    clearFlags();
  }

  if ((button2.isPressed()) && (listedStations == false) && (bankMenuEnable == false)) 
  {
    displayStartTime = millis();
    timeDisplay = false;
    volumeSet = true;
    displayActive = true;
    volumeDisplay();  // Po nacisnieciu enkodera2 wyswietlamy menu głośnosci
  }

  if ((button2.isPressed()) && (bankMenuEnable == true)) 
  {
    station_nr = 1;
    fetchStationsFromServer();
    changeStation();
    gfx.clearBuffer();
    displayRadio();

    volumeSet = false;
    bankMenuEnable = false;
  }

}



void handleEncoder2VolumeStationsClick()
{
  CLK_state2 = digitalRead(CLK_PIN2);                       // Odczytanie aktualnego stanu pinu CLK enkodera 2
  if (CLK_state2 != prev_CLK_state2 && CLK_state2 == HIGH)  // Sprawdzenie, czy stan CLK zmienił się na wysoki
  {
    timeDisplay = false;
    displayActive = true;
    displayStartTime = millis();

    if ((listedStations == false) && (bankMenuEnable == false))  // Przewijanie listy stacji radiowych
    {
      if (digitalRead(DT_PIN2) == HIGH) 
      {
        volumeDown();
      } 
      else 
      {
        volumeUp();
      }
    } 
    else 
    {
      if ((bankMenuEnable == false) && (volumeSet == true)) 
      {
        if (digitalRead(DT_PIN2) == HIGH)  // pokrecenie enkoderem 2
        {
          volumeDown();
        } 
        else 
        {
          volumeUp();
        }
      
      }
    }
    #ifndef twoEncoders // Kompilujemy ten blok jesli nie ma zdefinionwanego "twoEncoders", dla 2 enkoderów jest niepotrzebny
      if ((listedStations == true) && (bankMenuEnable == false)) 
      {
        station_nr = currentSelection + 1;
        if (digitalRead(DT_PIN2) == HIGH) 
        {
          station_nr--;
          if (station_nr < 1) { station_nr = stationsCount; }
          scrollUp();
        } 
        else 
        {
          station_nr++;
          if (station_nr > stationsCount) { station_nr = 1; }  //stationsCount;
          scrollDown();
        }
        displayStations();
      }

      if (bankMenuEnable == true)  // Przewijanie listy banków stacji radiowych
      {
        if (digitalRead(DT_PIN2) == HIGH) 
        {
          bank_nr--;
          if (bank_nr < 1) 
          {
            bank_nr = bank_nr_max;
          }
        } 
        else 
        {
          bank_nr++;
          if (bank_nr > bank_nr_max) 
          {
            bank_nr = 1;
          }
        }
        bankMenuDisplay();
      }
    #endif    
  }
  prev_CLK_state2 = CLK_state2;


  if ((button2.isReleased()) && (encoderButton2 == true))  // jestesmy juz w menu listy stacji to zmieniamy stacje po nacisnieciu przycisku
  {
    encoderButton2 = false;
    //  Serial.println("debug--------------------------------> SET ENCODER button 2 FALSE");
  }

  #ifdef twoEncoders
    if ((button2.isPressed())) // zmieniamy stację
    {
      volumeMute = !volumeMute;
      if (volumeMute == true)
      {
        audio.setVolume(0);   
      }
      else if (volumeMute == false)
      {
        audio.setVolume(volumeValue);   
      }
      displayRadio();
      return;
    }
  #endif

  if ((button2.isPressed())) // zmieniamy stację
  {
    
    if ((encoderButton2 == false) && (listedStations == true) && (bankMenuEnable == false) && (volumeSet == false))  // jestesmy juz w menu listy stacji to zmieniamy stacje po nacisnieciu przycisku
    {
      encoderButton2 = true;
      gfx.clearBuffer();
      changeStation();
      displayRadio();
      clearFlags();       
    }
  
    else if ((encoderButton2 == false) && (listedStations == false) && (bankMenuEnable == false) && (volumeSet == false))  // wchodzimy do listy
    {
      displayStartTime = millis();
      timeDisplay = false;
      displayActive = true;
      listedStations = true;
      currentSelection = station_nr - 1; 

      if (maxSelection() - currentSelection < maxVisibleLines) 
      {
        firstVisibleLine = maxSelection() - maxVisibleLines + 1;
      } 
      else 
      {
        firstVisibleLine = currentSelection;
      }
      displayStations();
    } 
      
    else if ((bankMenuEnable == true) && (volumeSet == false)) 
    {
      displayStartTime = millis();
      timeDisplay = false;
      displayActive = true;
      
      //previous_bank_nr = bank_nr;
      station_nr = 1;

      listedStations = false;
      volumeSet = false;
      bankMenuEnable = false;
      bankNetworkUpdate = false;

      fetchStationsFromServer();
      changeStation();
      gfx.clearBuffer();
      displayRadio();
    }  
  }
}


void stationNameSwap()
{
  stationNameFromStream = !stationNameFromStream;
  if (stationNameFromStream) stationNameLenghtCut = 40; else stationNameLenghtCut = 24;
}

void saveConfig() 
{
  // Sprawdź, czy plik istnieje
  if (STORAGE.exists("/config.txt")) 
  {
    Serial.println("Plik config.txt już istnieje.");

    // Otwórz plik do zapisu i nadpisz aktualną wartość konfiguracji
    myFile = STORAGE.open("/config.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println("#### Evo Web Radio Config File ####");
      myFile.print("Display Brightness =");    myFile.print(displayBrightness); myFile.println(";");
      myFile.print("Dimmer Display Brightness =");    myFile.print(dimmerDisplayBrightness); myFile.println(";");
      myFile.print("Auto Dimmer Time ="); myFile.print(displayAutoDimmerTime); myFile.println(";");
      myFile.print("Auto Dimmer ="); myFile.print(displayAutoDimmerOn); myFile.println(";");
      myFile.println("Voice Info Every Hour =" + String(timeVoiceInfoEveryHour) + ";");
      myFile.println("VU Meter Mode =" + String(vuMeterMode) + ";");
      myFile.println("Encoder Function Order  =" + String(encoderFunctionOrder) + ";");
      myFile.println("Startup Display Mode  =" + String(displayMode) + ";");
      myFile.println("VU Meter On  =" + String(vuMeterOn) + ";");
	    myFile.println("VU Meter Refresh Time  =" + String(vuMeterRefreshTime) + ";");
      myFile.println("Scroller Refresh Time =" + String(scrollingRefresh) + ";");
      myFile.println("ADC Keyboard Enabled =" + String(adcKeyboardEnabled) + ";");
      myFile.println("Display Power Save Enabled =" + String(displayPowerSaveEnabled) + ";");  
      myFile.println("Display Power Save Time =" + String(displayPowerSaveTime) + ";");
      myFile.println("Max Volume Extended =" + String(maxVolumeExt) + ";");
      myFile.println("VU Meter Peak Hold On =" + String(vuPeakHoldOn) + ";");
      myFile.println("VU Meter Smooth On =" + String(vuSmooth) + ";");
      myFile.println("VU Meter Rise Speed =" + String(vuRiseSpeed) + ";");
      myFile.println("VU Meter Fall Speed =" + String(vuFallSpeed) + ";");
      myFile.println("Display Clock in Sleep =" + String(f_displayPowerOffClock) + ";");
      myFile.print("Dimmer Sleep Display Brightness =");    myFile.print(dimmerSleepDisplayBrightness); myFile.println(";");
      myFile.print("Radio switch to standby after Power Fail =");    myFile.print(f_sleepAfterPowerFail); myFile.println(";");
      myFile.println("Volume fade on station change and power off =" + String(f_volumeFadeOn) + ";");
      myFile.println("Save Always Station Bank Volume or only during power off =" + String(f_saveVolumeStationAlways) + ";");
      myFile.println("Power Off Animation =" + String(f_powerOffAnimation) + ";");
      myFile.println("Presets On =" + String(f_Presets) + ";");

      myFile.close();
      Serial.println("Aktualizacja config.txt na karcie SD");
    } 
	  else 
	  {
      Serial.println("Błąd podczas otwierania pliku config.txt.");
    }
  } 
  else 
  {
    Serial.println("Plik config.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualne wartości konfiguracji
    myFile = STORAGE.open("/config.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println("#### Evo Web Radio Config File ####");
      myFile.print("Display Brightness =");    myFile.print(displayBrightness); myFile.println(";");
      myFile.print("Dimmer Display Brightness =");    myFile.print(dimmerDisplayBrightness); myFile.println(";");
      myFile.print("Auto Dimmer Time ="); myFile.print(displayAutoDimmerTime); myFile.println(";");
      myFile.print("Auto Dimmer On ="); myFile.print(displayAutoDimmerOn); myFile.println(";");
		  myFile.println("Voice Info Every Hour =" + String(timeVoiceInfoEveryHour) + ";");
      myFile.println("VU Meter Mode =" + String(vuMeterMode) + ";");
      myFile.println("Encoder Function Order  =" + String(encoderFunctionOrder) + ";");
      myFile.println("Startup Display Mode  =" + String(displayMode) + ";");
      myFile.println("VU Meter On  =" + String(vuMeterOn) + ";");
      myFile.println("VU Meter Refresh Time  =" + String(vuMeterRefreshTime) + ";");
      myFile.println("Scroller Refresh Time =" + String(scrollingRefresh) + ";");
      myFile.println("ADC Keyboard Enabled =" + String(adcKeyboardEnabled) + ";");
      myFile.println("Display Power Save Enabled =" + String(displayPowerSaveEnabled) + ";");  
      myFile.println("Display Power Save Time =" + String(displayPowerSaveTime) + ";");
      myFile.println("Max Volume settings Extended =" + String(maxVolumeExt) + ";");
      myFile.println("VU Meter Peak Hold On =" + String(vuPeakHoldOn) + ";");
      myFile.println("VU Meter Smooth On =" + String(vuSmooth) + ";");
      myFile.println("VU Meter Rise Speed =" + String(vuRiseSpeed) + ";");
      myFile.println("VU Meter Fall Speed =" + String(vuFallSpeed) + ";");
      myFile.println("Display Clock in Sleep =" + String(f_displayPowerOffClock) + ";");
      myFile.print("Dimmer Sleep Display Brightness =");    myFile.print(dimmerSleepDisplayBrightness); myFile.println(";");
      myFile.print("Radio goes to sleep after Power Fail =");    myFile.print(f_sleepAfterPowerFail); myFile.println(";");
      myFile.println("Volume fade on station change and power off =" + String(f_volumeFadeOn) + ";");
      myFile.println("Save Always Station Bank Volume or only during power off =" + String(f_saveVolumeStationAlways) + ";");
      myFile.println("Power Off Animation =" + String(f_powerOffAnimation) + ";");
      myFile.println("Presets On =" + String(f_Presets) + ";");

      myFile.close();
      Serial.println("Utworzono i zapisano config.txt na karcie SD");
    } 
	  else 
	  {
      Serial.println("Błąd podczas tworzenia pliku config.txt.");
    }
  }


}

void saveAdcConfig() 
{

  // Sprawdź, czy plik istnieje
  if (STORAGE.exists("/adckbd.txt")) 
  {
    Serial.println("Plik adckbd.txt już istnieje.");

    // Otwórz plik do zapisu i nadpisz aktualną wartość konfiguracji klawiatury ADC
    myFile = STORAGE.open("/adckbd.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println("#### Evo Web Radio Config File - ADC Keyboard ####");
      myFile.println("keyboardButtonThreshold_0 =" + String(keyboardButtonThreshold_0) + ";");
      myFile.println("keyboardButtonThreshold_1 =" + String(keyboardButtonThreshold_1) + ";");
      myFile.println("keyboardButtonThreshold_2 =" + String(keyboardButtonThreshold_2) + ";");
      myFile.println("keyboardButtonThreshold_3 =" + String(keyboardButtonThreshold_3) + ";");
      myFile.println("keyboardButtonThreshold_4 =" + String(keyboardButtonThreshold_4) + ";");
      myFile.println("keyboardButtonThreshold_5 =" + String(keyboardButtonThreshold_5) + ";");
      myFile.println("keyboardButtonThreshold_6 =" + String(keyboardButtonThreshold_6) + ";");
      myFile.println("keyboardButtonThreshold_7 =" + String(keyboardButtonThreshold_7) + ";");
      myFile.println("keyboardButtonThreshold_8 =" + String(keyboardButtonThreshold_8) + ";");
      myFile.println("keyboardButtonThreshold_9 =" + String(keyboardButtonThreshold_9) + ";");
      myFile.println("keyboardButtonThreshold_Ok =" + String(keyboardButtonThreshold_Ok) + ";");
      myFile.println("keyboardButtonThreshold_BankMenu =" + String(keyboardButtonThreshold_BankMenu) + ";");
      myFile.println("keyboardButtonThreshold_Back =" + String(keyboardButtonThreshold_Back) + ";");
      myFile.println("keyboardButtonThreshold_DisplayMode =" + String(keyboardButtonThreshold_DisplayMode) + ";");
      myFile.println("keyboardButtonThreshold_Dimmer =" + String(keyboardButtonThreshold_Dimmer) + ";");
      myFile.println("keyboardButtonThreshold_Mute =" + String(keyboardButtonThreshold_Mute) + ";");
      myFile.println("keyboardButtonThresholdTolerance =" + String(keyboardButtonThresholdTolerance) + ";");
      myFile.println("keyboardButtonNeutral =" + String(keyboardButtonNeutral) + ";");
      myFile.println("keyboardSampleDelay =" + String(keyboardSampleDelay) + ";");
      
      myFile.println("keyboardButtonThreshold_ArrowLeft =" + String(keyboardButtonThreshold_ArrowLeft) + ";");
      myFile.println("keyboardButtonThreshold_ArrowRight =" + String(keyboardButtonThreshold_ArrowRight) + ";");
      myFile.println("keyboardButtonThreshold_ArrowUp =" + String(keyboardButtonThreshold_ArrowUp) + ";");
      myFile.println("keyboardButtonThreshold_ArrowDown =" + String(keyboardButtonThreshold_ArrowDown) + ";");
      
      myFile.println("keyboardButtonThreshold_PresetsOn =" + String(keyboardButtonThreshold_PresetsOn) + ";");
      

      myFile.close();
      Serial.println("Aktualizacja adckbd.txt na karcie SD / w pamieci Storage");
    } 
	  else 
	  {
      Serial.println("Błąd podczas otwierania pliku adckbd.txt.");
    }
  } 
  else 
  {
    Serial.println("Plik adckbd.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualne wartości konfiguracji
    myFile = STORAGE.open("/adckbd.txt", FILE_WRITE);
    if (myFile) 
	  {
      myFile.println("#### Evo Web Radio Config File - ADC Keyboard ####");
      myFile.println("keyboardButtonThreshold_0 =" + String(keyboardButtonThreshold_0) + ";");
      myFile.println("keyboardButtonThreshold_1 =" + String(keyboardButtonThreshold_1) + ";");
      myFile.println("keyboardButtonThreshold_2 =" + String(keyboardButtonThreshold_2) + ";");
      myFile.println("keyboardButtonThreshold_3 =" + String(keyboardButtonThreshold_3) + ";");
      myFile.println("keyboardButtonThreshold_4 =" + String(keyboardButtonThreshold_4) + ";");
      myFile.println("keyboardButtonThreshold_5 =" + String(keyboardButtonThreshold_5) + ";");
      myFile.println("keyboardButtonThreshold_6 =" + String(keyboardButtonThreshold_6) + ";");
      myFile.println("keyboardButtonThreshold_7 =" + String(keyboardButtonThreshold_7) + ";");
      myFile.println("keyboardButtonThreshold_8 =" + String(keyboardButtonThreshold_8) + ";");
      myFile.println("keyboardButtonThreshold_9 =" + String(keyboardButtonThreshold_9) + ";");
      myFile.println("keyboardButtonThreshold_Ok =" + String(keyboardButtonThreshold_Ok) + ";");
      myFile.println("keyboardButtonThreshold_BankMenu =" + String(keyboardButtonThreshold_BankMenu) + ";");
      myFile.println("keyboardButtonThreshold_Back =" + String(keyboardButtonThreshold_Back) + ";");
      myFile.println("keyboardButtonThreshold_DisplayMode =" + String(keyboardButtonThreshold_DisplayMode) + ";");
      myFile.println("keyboardButtonThreshold_Dimmer =" + String(keyboardButtonThreshold_Dimmer) + ";");
      myFile.println("keyboardButtonThreshold_Mute =" + String(keyboardButtonThreshold_Mute) + ";");
      myFile.println("keyboardButtonThresholdTolerance =" + String(keyboardButtonThresholdTolerance) + ";");
      myFile.println("keyboardButtonNeutral =" + String(keyboardButtonNeutral) + ";");
      myFile.println("keyboardSampleDelay =" + String(keyboardSampleDelay) + ";");

      myFile.println("keyboardButtonThreshold_ArrowLeft =" + String(keyboardButtonThreshold_ArrowLeft) + ";");
      myFile.println("keyboardButtonThreshold_ArrowRight =" + String(keyboardButtonThreshold_ArrowRight) + ";");
      myFile.println("keyboardButtonThreshold_ArrowUp =" + String(keyboardButtonThreshold_ArrowUp) + ";");
      myFile.println("keyboardButtonThreshold_ArrowDown =" + String(keyboardButtonThreshold_ArrowDown) + ";");
      
      myFile.println("keyboardButtonThreshold_PresetsOn =" + String(keyboardButtonThreshold_PresetsOn) + ";");

      myFile.close();
      Serial.println("Utworzono i zapisano adckbd.txt na karcie SD / w pamieci Storage");
    } 
	  else 
	  {
      Serial.println("Błąd podczas tworzenia pliku adckbd.txt.");
    }
  }


}


void readConfig() 
{

  Serial.println("Odczyt pliku config.txt z karty");
  String fileName = String("/config.txt"); // Tworzymy nazwę pliku

  if (!STORAGE.exists(fileName))               // Sprawdzamy, czy plik istnieje
  {
    Serial.println("Błąd: Plik nie istnieje.");
    configExist = false;
    return;
  }
 
  File configFile = STORAGE.open(fileName, FILE_READ);// Otwieramy plik w trybie do odczytu
  if (!configFile)  // jesli brak pliku to...
  {
    Serial.println("Błąd: Nie można otworzyć pliku konfiguracji");
    return;
  }
  // Przechodzimy do odpowiedniego wiersza pliku
  int currentLine = 0;
  String configValue = "";
  while (configFile.available() && currentLine < CONFIG_COUNT) 

  {
    String line = configFile.readStringUntil(';'); //('\n');
    
    int lineStart = line.indexOf("=") + 1;  // Szukamy miejsca, gdzie zaczyna wartość zmiennej
    if ((lineStart != -1)) //&& (currentLine != 0)) // Pomijamy pierwszą linijkę gdzie jest opis pliku
	  {
      configValue = line.substring(lineStart);  // Wyciągamy numer od miejsc a"="
      configValue.trim();                       // Usuwamy białe znaki na początku i końcu
      Serial.print("debug SD -> Odczytano zmienna konfiguracji numer:" + String(currentLine) + " wartosc:");
      Serial.println(configValue);
      configArray[currentLine] = configValue.toInt();
    }
    currentLine++;
  }
  Serial.print("Zamykamy plik config na wartosci currentLine:");
  Serial.println(currentLine);
  
  //Odczyt kontrolny
  //for (int i = 0; i < 16; i++) 
  //{
  //  Serial.print("wartosc: " + String(i) + " z tablicy konfiguracji:");
  //  Serial.println(configArray[i]);
  //}

  configFile.close();  // Zamykamy plik po odczycie kodow pilota

  displayBrightness = configArray[0];
  dimmerDisplayBrightness = configArray[1];
  displayAutoDimmerTime = configArray[2];
  displayAutoDimmerOn = configArray[3];
  timeVoiceInfoEveryHour = configArray[4];
  vuMeterMode = configArray[5];
  encoderFunctionOrder = configArray[6];
  displayMode = configArray[7];
  vuMeterOn = configArray[8];
  vuMeterRefreshTime = configArray[9];
  scrollingRefresh = configArray[10];
  adcKeyboardEnabled = configArray[11];
  displayPowerSaveEnabled = configArray[12];
  displayPowerSaveTime = configArray[13];
  maxVolumeExt = configArray[14];
  vuPeakHoldOn = configArray[15];
  vuSmooth = configArray[16];
  vuRiseSpeed = configArray[17];
  vuFallSpeed = configArray[18];
  f_displayPowerOffClock = configArray[19];
  dimmerSleepDisplayBrightness = configArray[20];
  f_sleepAfterPowerFail = configArray[21];
  f_volumeFadeOn = configArray[22];
  f_saveVolumeStationAlways = configArray[23];
  f_powerOffAnimation = configArray[24];
  f_Presets = configArray[25];

  if (maxVolumeExt == 1)
  { 
    maxVolume = 42;
  }
  else
  {
    maxVolume = 21;
  }
  evoAudioApplyVolumeProfile();
  //stationNameSwap();
}


void readAdcConfig() 
{

  Serial.println("Odczyt pliku konfiguracji klawiatury ADC adckbd.txt z karty");
  String fileName = String("/adckbd.txt"); // Tworzymy nazwę pliku

  if (!STORAGE.exists(fileName))               // Sprawdzamy, czy plik istnieje
  {
    Serial.println("Błąd: Plik nie istnieje.");
    return;
  }
 
  File configFile = STORAGE.open(fileName, FILE_READ);// Otwieramy plik w trybie do odczytu
  if (!configFile)  // jesli brak pliku to...
  {
    Serial.println("Błąd: Nie można otworzyć pliku konfiguracji klawiatury ADC");
    return;
  }
  // Przechodzimy do odpowiedniego wiersza pliku
  int currentLine = 0;
  String configValue = "";
  while (configFile.available()) 
  {
    String line = configFile.readStringUntil(';'); //('\n');
    
    int lineStart = line.indexOf("=") + 1;  // Szukamy miejsca, gdzie zaczyna wartość zmiennej
    if ((lineStart != -1)) //&& (currentLine != 0)) // Pomijamy pierwszą linijkę gdzie jest opis pliku
	  {
      configValue = line.substring(lineStart);  // Wyciągamy URL od "http"
      configValue.trim();                      // Usuwamy białe znaki na początku i końcu
      Serial.print(" Odczytano ustawienie ADC nr.:" + String(currentLine) + " wartosc:");
      Serial.println(configValue);
      configAdcArray[currentLine] = configValue.toInt();
    }
    currentLine++;
  }
  Serial.print("Zamykamy plik config na wartosci currentLine:");
  Serial.println(currentLine);
  
  //Odczyt kontrolny
  //for (int i = 0; i < 16; i++) 
  //{
  //  Serial.print("wartosc poziomu ADC: " + String(i) + " z tablicy:");
  //  Serial.println(configAdcArray[i]);
 // }

  configFile.close();  // Zamykamy plik po odczycie kodow pilota

 // ---- Progi przełaczania ADC dla klawiatury matrycowej 5x3 w tunrze Sony ST-120 ---- //
        // Pozycja neutralna
  keyboardButtonThreshold_0 = configAdcArray[0];          // Przycisk 0
  keyboardButtonThreshold_1 = configAdcArray[1];          // Przycisk 1
  keyboardButtonThreshold_2 = configAdcArray[2];          // Przycisk 2
  keyboardButtonThreshold_3 = configAdcArray[3];          // Przycisk 3
  keyboardButtonThreshold_4 = configAdcArray[4];          // Przycisk 4
  keyboardButtonThreshold_5 = configAdcArray[5];          // Przycisk 5
  keyboardButtonThreshold_6 = configAdcArray[6];        // Przycisk 6
  keyboardButtonThreshold_7 = configAdcArray[7];        // Przycisk 7
  keyboardButtonThreshold_8 = configAdcArray[8];        // Przycisk 8
  keyboardButtonThreshold_9 = configAdcArray[9];        // Przycisk 9
  keyboardButtonThreshold_Ok = configAdcArray[10];   // Shift - funkcja Enter/OK
  keyboardButtonThreshold_BankMenu = configAdcArray[11];  // Memory - funkcja Bank menu
  keyboardButtonThreshold_Back = configAdcArray[12];    // Przycisk Band - funkcja Back
  keyboardButtonThreshold_DisplayMode = configAdcArray[13];    // Przycisk Auto - przelacza Radio/Zegar
  keyboardButtonThreshold_Dimmer = configAdcArray[14];    // Przycisk Scan - funkcja Dimmer ekranu OLED
  keyboardButtonThreshold_Mute = configAdcArray[15];      // Przycisk Mute - funkcja MUTE
  keyboardButtonThresholdTolerance = configAdcArray[16];  // Tolerancja dla pomiaru ADC
  keyboardButtonNeutral = configAdcArray[17];             // Pozycja neutralna 
  keyboardSampleDelay = configAdcArray[18];               // Czas co ile ms odczytywac klawiature
  
  keyboardButtonThreshold_ArrowLeft = configAdcArray[19];
  keyboardButtonThreshold_ArrowRight = configAdcArray[20];
  keyboardButtonThreshold_ArrowUp = configAdcArray[21];
  keyboardButtonThreshold_ArrowDown = configAdcArray[22];
  keyboardButtonThreshold_PresetsOn = configAdcArray[23];
}



void readPSRAMstations()  // Funkcja testowa-debug, do odczytu PSRAMu, nie uzywana przez inne funkcje
{
  Serial.println("-------- POCZATEK LISTY STACJI ---------- ");
  for (int i = 0; i < stationsCount; i++) 
  {
    // Odczyt stacji pod daną komórka pamieci PSRAM:
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych
    int length = psramData[(i) * (STATION_NAME_LENGTH + 1)];   // Odczytaj długość nazwy stacji z PSRAM dla bieżącego indeksu stacji
      
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
    { // Odczytaj nazwę stacji z PSRAM jako ciąg bajtów, maksymalnie do STATION_NAME_LENGTH
        station[j] = psramData[(i) * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }
    String stationNameText = String(station);
    
    Serial.print(i+1);
    Serial.print(" ");
    Serial.println(stationNameText);
  }	
  
  Serial.println("-------- KONIEC LISTY STACJI ---------- ");

  String stationUrl = "";

  // Odczyt stacji pod daną komórka pamieci PSRAM:
  char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
  memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych
  int length = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1)];   // Odczytaj długość nazwy stacji z PSRAM dla bieżącego indeksu stacji
      
  for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
  { // Odczytaj nazwę stacji z PSRAM jako ciąg bajtów, maksymalnie do STATION_NAME_LENGTH
    station[j] = psramData[(station_nr - 1) * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
  }
  
  //String stationNameText = String(station);
  
  Serial.println("-------- OBECNIE GRAMY  ---------- ");
  Serial.print(station_nr - 1);
  Serial.print(" ");
  Serial.println(String(station));

}

void webUrlStationPlay() 
{
  audio.stopSong();

  // Usunięcie wszystkich znaków z obiektów 
  evoAudioClearNowPlaying();
  stationNameStream.remove(0);
  stationLogoUrl.remove(0);

  bitrateString.remove(0);
  sampleRateString.remove(0);
  bitsPerSampleString.remove(0); 
  SampleRate = 0;
  SampleRateRest = 0;

  sampleRateString = "--.-";
  bitsPerSampleString = "--";
  bitrateString = "-?-";
    
  gfx.clearBuffer();
  gfx.setFont(u8g2_font_fub14_tf); // cziocnka 14x11
  gfx.drawStr(34, 33, "Loading stream..."); // 8 znakow  x 11 szer
  gfx.sendBuffer();

  mp3 = flac = aac = vorbis = opus = false;
  streamCodec = "";
    
  Serial.println("debug-- Read station from WEB URL");
    
  if (url2play != "") 
  {
    url2play.trim(); // Usuwamy białe znaki na początku i końcu
  }
  else
  {
	  return;
  }
  
  if (url2play.isEmpty()) // jezeli link URL jest pusty
  {
    Serial.println("Błąd: Nie znaleziono stacji dla podanego numeru.");
    return;
  }
    
  // Weryfikacja, czy w linku znajduje się "http" lub "https"
  if (url2play.startsWith("http://") || url2play.startsWith("https://")) 
  {
    // Wydrukuj nazwę stacji i link na serialu
    Serial.print("Link do stacji: ");
    Serial.println(url2play);
    
    gfx.setFont(spleen6x12PL);  // wypisujemy jaki stream jakie stacji jest ładowany
    gfx.drawStr(34, 55, String(url2play).c_str());
    gfx.sendBuffer();
    
    // Połącz z daną stacją
    audio.connecttohost(url2play.c_str());
    urlPlaying = true;
    station_nr = 0;
    bank_nr = 0;
    //stationName = stationNameStream;
    stationName = "WEB URL";
    //wsStationChange(station_nr); // Od teraz Event Audio odpowiada za info o stacji
    //f_audioInfoRefreshDisplayRadio = true;
    wsStationChange(0,0);
    wsAudioRefresh = true;
  } 
  else 
  {
    Serial.println("Błąd: link stacji nie zawiera 'http' lub 'https'");
    Serial.println("Odczytany URL: " + url2play);
  }

  //url2play = "";
}

String stationBankListHtmlMobile()
{
  String html1;
  
  html1 += "<p>Volume: <span id='textSliderValue'>--</span></p>" + String("\n");
  html1 += "<p><input type='range' onchange='updateSliderVolume(this)' id='volumeSlider' min='1' max='" + String(maxVolume) + "' value='1' step='1' class='slider'></p>" + String("\n");
  html1 += "<p>Memory Bank Selection:</p>" + String("\n");

  html1 += "<center>";  
  html1 += "<p>";
  //for (int i = 1; i < 17; i++) // Przyciski Banków
  for (int i = 1; i < bank_nr_max + 1; i++) // Przyciski Banków
  {
    
    if (i == bank_nr)
    {
      html1 += "<button class='buttonBankSelected' onClick=\"changeBank('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }
    else
    {
      html1 += "<button class=\"buttonBank\" onClick=\"changeBank('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }
    //if (i == 8) {html1 += "</p><p>";}
    if (i % 8 == 0) {html1 += "</p><p>";}
  }
  html1 += "</p>";
  html1 += "</center>";
  html1 += "<center>"; 
 
  html1 += "<table>";


  for (int i = 0; i < stationsCount; i++) // lista stacji
  {
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych
    int length = psramData[i * (STATION_NAME_LENGTH + 1)];
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
    {
      station[j] = psramData[i * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }
    
    html1 += "<tr>";
    html1 += "<td><p class='stationNumberList'>" + String(i + 1) + "</p></td>";
    html1 += "<td><p class='stationList' onClick=\"changeStation('" + String(i + 1) +  "');\">" + String(station).substring(0, stationNameLenghtCut) + "</p></td>";
    html1 += "</tr>" + String("\n");
          
  }
 
  html1 += "</table>" + String("\n");
  html1 += "</div>" + String("\n");

  html1 += "<p style=\"font-size: 0.8rem;\">Web Radio, mobile, Evo: " + String(softwareRev) + "</p>" + String("\n");
  html1 += "<p style='font-size: 0.8rem;'>IP: "+ currentIP + "</p>" + String("\n");
  
  html1 += "<a href='/menu' class='button' style='padding: 0.2rem; font-size: 0.7rem; height: auto; line-height: 1;color: white; width: 65px; border: 1px solid black; display: inline-block; border-radius: 5px; text-decoration: none;'>Menu</a>";
  html1 += "</center></body></html>";
  
  return html1;
}

String stationBankListHtmlPC()
{
  String html2;
  

  html2 += "<p>Volume: <span id='textSliderValue'>--</span></p>" + String("\n");
  html2 += "<p><input type='range' onchange='updateSliderVolume(this)' id='volumeSlider' min='1' max='" + String(maxVolume) + "' value='1' step='1' class='slider'></p>" + String("\n");
  html2 += "<p>Memory Bank Selection:</p>" + String("\n");
  
  
  html2 += "<p>";
  //for (int i = 1; i < 17; i++)
  for (int i = 1; i < bank_nr_max + 1; i++) // Przyciski Banków
  {
    
    if (i == bank_nr)
    {
      html2 += "<button class=\"buttonBankSelected\" onClick=\"changeBank('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }
    else
    {
      html2 += "<button class=\"buttonBank\" onClick=\"changeBank('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }
  }
  
  html2 += "</p>";
  html2 += "<center>" + String("\n");
  html2 += "<div class=\"column\">" + String("\n");
  for (int i = 0; i < MAX_STATIONS; i++) 
  //for (int i = 0; i < stationsCount; i++) 
  {
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych

    int length = psramData[i * (STATION_NAME_LENGTH + 1)];
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
    {
      station[j] = psramData[i * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }     

    
    if ((i == 0) || (i == 25) || (i == 50) || (i == 75))
    { 
      html2 += "<table>" + String("\n");
    } 
    
    // 0-98   >98
    if (i >= stationsCount) { station[0] ='\0'; } // Jesli mamy mniej niz 99 stacji to wypełniamy pozostałe komórki pustymi wartościami
                 
    html2 += "<tr>";
    html2 += "<td><p class='stationNumberList'>" + String(i + 1) + "</p></td>";
    html2 += "<td><p class='stationList' onClick=\"changeStation('" + String(i + 1) +  "');\">" + String(station).substring(0, stationNameLenghtCut) + "</p></td>";
    html2 += "</tr>" + String("\n");

    if ((i == 24) || (i == 49) || (i == 74)) //||(i == 98))
    { 
      html2 += "</table>" + String("\n");
    }
           
  }

  html2 += "</table>" + String("\n");
  html2 += "</div>" + String("\n");
  html2 += "<p style=\"font-size: 0.8rem;\">Web Radio, desktop, Evo: " + String(softwareRev) + "</p>" + String("\n");
  html2 += "<p style='font-size: 0.8rem;'>IP: " + currentIP + "</p>" + String("\n");
  html2 += "<a href='/menu' class='button' style='padding: 0.2rem; font-size: 0.7rem; height: auto; line-height: 1;color: white; width: 65px; border: 1px solid black; display: inline-block; border-radius: 5px; text-decoration: none;'>Menu</a>";
  html2 += "</center></body></html>"; 

  return html2;
}

/*
String stationBankListHtml(bool mobilePage)
{
  String html3;

  html3 += "<p>Volume: <span id='textSliderValue'>%%SLIDERVALUE%%</span></p>";
  html3 += "<p><input type='range' onchange='updateSliderVolume(this)' id='volumeSlider' min='1' max='" + String(maxVolume) + "' value='%%SLIDERVALUE%%' step='1' class='slider'></p>";
  html3 += "<br>";
  html3 += "<p>Bank selection:</p>";


  html3 += "<p>";
  for (int i = 1; i < 17; i++)
  {
    
    if (i == bank_nr)
    {
      html3 += "<button class=\"buttonBankSelected\" onClick=\"bankLoad('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }
    else
    {
      html3 += "<button class=\"buttonBank\" onClick=\"bankLoad('" + String(i) + "');\" id=\"Bank\">" + String(i) + "</button>" + String("\n");
    }

    if ((mobilePage == 1) && (i == 8)) {html3 += "</p><p>";}
  }
  
  html3 += "</p>";
  html3 += "<center>" + String("\n");


  if (mobilePage == 1)
  {
   html3 += "<table>";
  }
  else if (mobilePage == 0)
  { 
    html3 += "<div class=\"column\">" + String("\n");
  }
  
  int limit = (mobilePage == 1) ? stationsCount : MAX_STATIONS;

  for (int i = 0; i < limit; i++)
  {
    char station[STATION_NAME_LENGTH + 1];  // Tablica na nazwę stacji o maksymalnej długości zdefiniowanej przez STATION_NAME_LENGTH
    memset(station, 0, sizeof(station));    // Wyczyszczenie tablicy zerami przed zapisaniem danych

    int length = psramData[i * (STATION_NAME_LENGTH + 1)];
    for (int j = 0; j < min(length, STATION_NAME_LENGTH); j++) 
    {
      station[j] = psramData[i * (STATION_NAME_LENGTH + 1) + 1 + j];  // Odczytaj znak po znaku nazwę stacji
    }     

    
    if ((mobilePage == 0) && ((i == 0) || (i == 25) || (i == 50) || (i == 75)))
    { 
      html3 += "<table>" + String("\n");
    } 
 
    // 0-98   >98
    if (mobilePage == 0) 
    {
      if (i >= stationsCount) { station[0] ='\0'; } // Jesli mamy mniej niz 99 stacji to wypełniamy pozostałe komórki pustymi wartościami
    }

    html3 += "<tr>";
    html3 += "<td><p class='stationNumberList'>" + String(i + 1) + "</p></td>";
    html3 += "<td><p class='stationList' onClick=\"changeStation('" + String(i + 1) +  "');\">" + String(station).substring(0, stationNameLenghtCut) + "</p></td>";
    html3 += "</tr>" + String("\n");
   
    if ((mobilePage == 0) && ((i == 24) || (i == 49) || (i == 74))) //||(i == 98))
    { 
      html3 += "</table>" + String("\n");
    }
           
  }

  html3 += "</table>" + String("\n");
  html3 += "</div>" + String("\n");
  if (mobilePage == 0) { html3 += "<p style=\"font-size: 0.8rem;\">Web Radio, desktop, Evo: " + String(softwareRev) + "</p>" + String("\n"); }
  if (mobilePage == 1) { html3 += "<p style=\"font-size: 0.8rem;\">Web Radio, mobile, Evo: " + String(softwareRev) + "</p>" + String("\n"); }
  html3 += "<p style='font-size: 0.8rem;'>IP: " + currentIP + "</p>" + String("\n");
  html3 += "<p style='font-size: 0.8rem;'><a href='/menu'>MENU</a></p>" + String("\n");

  html3 += "</center></body></html>"; 

  return html3;
}
*/

void voiceTime()
{
  resumePlay = true;
  voiceTimeMillis = millis();
  char chbuf[30];      //Bufor komunikatu tekstowego zegara odczytywanego głosowo
  String time_s;
  struct tm timeinfo;
  char timeString[9];  // Bufor przechowujący czas w formie tekstowej
  if (!getLocalTime(&timeinfo, 1000))
  {
    Serial.println("debug voice time PL -> Nie udało się uzyskać czasu funkcji voice time");
    return;  // Zakończ funkcję, gdy nie udało się uzyskać czasu
  }

  snprintf(timeString, sizeof(timeString), "%02d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
  time_s = String(timeString);
  int h = time_s.substring(0,2).toInt();
  snprintf(chbuf, sizeof (chbuf), "Jest godzina %i:%02i:00", h, time_s.substring(3,5).toInt());
  Serial.print("debug voice time PL -> ");
  Serial.println(chbuf);
  
  audio.connecttospeech(chbuf, "pl");
}

void voiceTimeEn()
{
  resumePlay = true;
  char chbuf[30];      //Bufor komunikatu tekstowego zegara odczytywanego głosowo
  String time_s;
  char am_pm[5] = "am.";
  struct tm timeinfo;
  char timeString[9];  // Bufor przechowujący czas w formie tekstowej

  if (!getLocalTime(&timeinfo, 1000)) 
  {
    Serial.println("debug voice time EN -> Nie udało się uzyskać czasu funkcji voice time");
    return;  // Zakończ funkcję, gdy nie udało się uzyskać czasu
  }

  snprintf(timeString, sizeof(timeString), "%02d:%02d:%02d", timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
  time_s = String(timeString);
  int h = time_s.substring(0,2).toInt();
  if(h > 12){h -= 12; strcpy(am_pm,"pm.");}
  //snprintf(chbuf, sizeof (chbuf), "Jest godzina %i:%02i", h, time_s.substring(3,5).toInt());
  sprintf(chbuf, "It is now %i%s and %i minutes", h, am_pm, time_s.substring(3,5).toInt());
  Serial.print("debug voice time EN -> ");
  Serial.println(chbuf);
  audio.connecttospeech(chbuf, "en");
}

/*
void saveRemoteControlConfig()
{
  Serial.println("RC - Config, zapis pliku konfiguracji pilota IR remote.txt");
  //String fileName = String("/remote.txt");

  const char* filename = "/remote.txt";

  File myFile = STORAGE.open(filename, FILE_WRITE);
  if (!myFile)
  {
    Serial.println("Blad otwarcia remote.txt");
    return;
  }

  myFile.println("#### Evo Web Radio Config File - IR Remote ####");

  for (uint8_t i = 0; i < CONFIGREMOTE_COUNT; i++)
  {
    myFile.printf("%s = 0x%04X;\n", remoteMap[i].name, configRemoteArray[i]);
  }
  myFile.close();
  Serial.println("Zapisano remote.txt");
}
*/

void saveRemoteControlConfig()
{
  Serial.println("RC - Config, zapis pliku konfiguracji pilota IR remote.txt");

    // Sprawdź, czy plik istnieje
  if (STORAGE.exists("/remote.txt")) 
  {
	  Serial.println("RC - Config, plik remote.txt już istnieje.");
	  
    // Otwórz plik do zapisu i nadpisz aktualną wartość konfiguracji
    myFile = STORAGE.open("/remote.txt", FILE_WRITE);
	  if (myFile)
	  {
      myFile.println("#### Evo Web Radio Config File - IR Remote ####");
      myFile.printf("%s = 0x%04X;\n", "cmdVolumeUp", configRemoteArray[0]);
      myFile.printf("%s = 0x%04X;\n", "cmdVolumeDown", configRemoteArray[1]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowRight", configRemoteArray[2]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowLeft", configRemoteArray[3]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowUp", configRemoteArray[4]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowDown", configRemoteArray[5]);
      myFile.printf("%s = 0x%04X;\n", "cmdBack", configRemoteArray[6]);
      myFile.printf("%s = 0x%04X;\n", "cmdOk", configRemoteArray[7]);
      myFile.printf("%s = 0x%04X;\n", "cmdSrc", configRemoteArray[8]);
      myFile.printf("%s = 0x%04X;\n", "cmdMute", configRemoteArray[9]);
      myFile.printf("%s = 0x%04X;\n", "cmdAud", configRemoteArray[10]);
      myFile.printf("%s = 0x%04X;\n", "cmdDirect", configRemoteArray[11]);
      myFile.printf("%s = 0x%04X;\n", "cmdBankMinus", configRemoteArray[12]);
      myFile.printf("%s = 0x%04X;\n", "cmdBankPlus", configRemoteArray[13]);
      myFile.printf("%s = 0x%04X;\n", "cmdRed", configRemoteArray[14]);
      myFile.printf("%s = 0x%04X;\n", "cmdGreen", configRemoteArray[15]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey0", configRemoteArray[16]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey1", configRemoteArray[17]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey2", configRemoteArray[18]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey3", configRemoteArray[19]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey4", configRemoteArray[20]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey5", configRemoteArray[21]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey6", configRemoteArray[22]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey7", configRemoteArray[23]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey8", configRemoteArray[24]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey9", configRemoteArray[25]);
      myFile.close();
      Serial.println("RC - Config, aktualizacja remote.txt udana");
	  }
	  else
	  {
		  Serial.println("RC - Config, blad podczas otwierania pliku remote.txt");
	  }
  }
  else
  {
    Serial.println("RC - Config, plik remote.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualne wartości konfiguracji
    myFile = STORAGE.open("/remote.txt", FILE_WRITE);
    if (myFile)
    {
      myFile.println("#### Evo Web Radio Config File - IR Remote ####");
      myFile.printf("%s = 0x%04X;\n", "cmdVolumeUp", configRemoteArray[0]);
      myFile.printf("%s = 0x%04X;\n", "cmdVolumeDown", configRemoteArray[1]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowRight", configRemoteArray[2]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowLeft", configRemoteArray[3]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowUp", configRemoteArray[4]);
      myFile.printf("%s = 0x%04X;\n", "cmdArrowDown", configRemoteArray[5]);
      myFile.printf("%s = 0x%04X;\n", "cmdBack", configRemoteArray[6]);
      myFile.printf("%s = 0x%04X;\n", "cmdOk", configRemoteArray[7]);
      myFile.printf("%s = 0x%04X;\n", "cmdSrc", configRemoteArray[8]);
      myFile.printf("%s = 0x%04X;\n", "cmdMute", configRemoteArray[9]);
      myFile.printf("%s = 0x%04X;\n", "cmdAud", configRemoteArray[10]);
      myFile.printf("%s = 0x%04X;\n", "cmdDirect", configRemoteArray[11]);
      myFile.printf("%s = 0x%04X;\n", "cmdBankMinus", configRemoteArray[12]);
      myFile.printf("%s = 0x%04X;\n", "cmdBankPlus", configRemoteArray[13]);
      myFile.printf("%s = 0x%04X;\n", "cmdRed", configRemoteArray[14]);
      myFile.printf("%s = 0x%04X;\n", "cmdGreen", configRemoteArray[15]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey0", configRemoteArray[16]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey1", configRemoteArray[17]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey2", configRemoteArray[18]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey3", configRemoteArray[19]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey4", configRemoteArray[20]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey5", configRemoteArray[21]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey6", configRemoteArray[22]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey7", configRemoteArray[23]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey8", configRemoteArray[24]);
      myFile.printf("%s = 0x%04X;\n", "cmdKey9", configRemoteArray[25]);
      myFile.close();
      Serial.println("RC - Config, utworzono remote.txt");
    }
    else
	  {
		  Serial.println("RC - Config, blad podczas tworzenia pliku remote.txt");
	  }
  }
}




void readRemoteControlConfig() 
{

  Serial.println("RC - Config, odczyt pliku konfiguracji pilota IR remote.txt");
  
    // Tworzymy nazwę pliku
  String fileName = String("/remote.txt");

  // Sprawdzamy, czy plik istnieje
  if (!STORAGE.exists(fileName)) 
  {
    Serial.println("RC - Config, błąd, Plik konfiguracji pilota IR remote.txt nie istnieje.");
    configIrExist = false;
    return;
  }

  // Otwieramy plik w trybie do odczytu
  File configRemoteFile = STORAGE.open(fileName, FILE_READ);
  if (!configRemoteFile)  // jesli brak pliku to...
  {
    Serial.println("RC - Config, błąd, nie można otworzyć pliku konfiguracji pilota IR");
    configIrExist = false;
    return;
  }
  // Przechodzimy do odpowiedniego wiersza pliku
  configIrExist = true;
  int currentLine = 0;
  String configValue = "";
  while (configRemoteFile.available())
  {
    String line = configRemoteFile.readStringUntil(';'); //('\n');
    int lineStart = line.indexOf("0x") + 2;  // Szukamy miejsca, gdzie zaczyna wartość zmiennej
    if ((lineStart != -1)) //&& (currentLine != 0)) // Pomijamy pierwszą linijkę gdzie jest opis pliku
	  {
      configValue = line.substring(lineStart, lineStart + 5);  // Wyciągamy adres i komende
      configValue.trim();                      // Usuwamy białe znaki na początku i końcu
      Serial.print(" Odczytano kod: " + String(currentLine) + " wartosc:");
      Serial.print(configValue + " wartosc ConfigArray: ");
      configRemoteArray[currentLine] = strtol(configValue.c_str(), NULL, 16);
      Serial.println(configRemoteArray[currentLine], HEX);
    }
    currentLine++;
  }
  //Serial.print("Zamykamy plik config na wartosci currentLine:");
  //Serial.println(currentLine);
  configRemoteFile.close();  // Zamykamy plik po odczycie kodow pilota
}

void assignRemoteCodes()
{
  Serial.println("RC - Config, # assignRemoteCodes #");
  Serial.print("RC - Config, plik konfiguracji pilota istnieje, configIrExist: ");
  Serial.println(configIrExist);

  //if ((noSDcard == false) && (configIrExist == true))
  if (configIrExist == true)  
  {
  Serial.println("RC - Config, plik istnieje, przypisuje wartosci z pliku Remote.txt");
  rcCmdVolumeUp = configRemoteArray[0];    // Głosnosc +
  rcCmdVolumeDown = configRemoteArray[1];  // Głośnosc -
  rcCmdArrowRight = configRemoteArray[2];  // strzałka w prawo - nastepna stacja
  rcCmdArrowLeft = configRemoteArray[3];   // strzałka w lewo - poprzednia stacja  
  rcCmdArrowUp = configRemoteArray[4];     // strzałka w góre - lista stacji krok do gory
  rcCmdArrowDown = configRemoteArray[5];   // strzałka w dół - lista stacj krok na dół
  rcCmdBack = configRemoteArray[6]; 	     // Przycisk powrotu
  rcCmdOk = configRemoteArray[7];          // Przycisk Ent - zatwierdzenie stacji
  rcCmdSrc = configRemoteArray[8];         // Przełączanie źródła radio, odtwarzacz
  rcCmdMute = configRemoteArray[9];        // Wyciszenie dzwieku
  rcCmdAud = configRemoteArray[10];        // Equalizer dzwieku
  rcCmdDirect = configRemoteArray[11];     // Janość ekranu, dwa tryby 1/16 lub pełna janość     
  rcCmdBankMinus = configRemoteArray[12];  // Wysweitla wybór banku
  rcCmdBankPlus = configRemoteArray[13];   // Wysweitla wybór banku
  rcCmdRed = configRemoteArray[14];        // Przełacza ładowanie banku kartaSD - serwer GitHub w menu bank
  rcCmdPower = configRemoteArray[14];      // PRZYCISK POWER Z KODEM Czerwonej Słuchawki
  rcCmdGreen = configRemoteArray[15];      // VU wyłaczony, VU tryb 1, VU tryb 2, zegar
  rcCmdKey0 = configRemoteArray[16];       // Przycisk "0"
  rcCmdKey1 = configRemoteArray[17];       // Przycisk "1"
  rcCmdKey2 = configRemoteArray[18];       // Przycisk "2"
  rcCmdKey3 = configRemoteArray[19];       // Przycisk "3"
  rcCmdKey4 = configRemoteArray[20];       // Przycisk "4"
  rcCmdKey5 = configRemoteArray[21];       // Przycisk "5"
  rcCmdKey6 = configRemoteArray[22];       // Przycisk "6"
  rcCmdKey7 = configRemoteArray[23];       // Przycisk "7"
  rcCmdKey8 = configRemoteArray[24];       // Przycisk "8"
  rcCmdKey9 = configRemoteArray[25];       // Przycisk "9"
  }
  
  //else if ((noSDcard == true) || (configIrExist == false)) // Jesli nie ma karty SD przypisujemy standardowe wartosci dla pilota Kenwood RC-406
  else if (configIrExist == false) // Jesli nie ma karty SD przypisujemy standardowe wartosci dla pilota Kenwood RC-406
  {
    Serial.println("IR Config - BRAK konfiguracji pilota, przypisuje wartosci domyslne");
    rcCmdVolumeUp = 0xB914;   // Głosnosc +
    rcCmdVolumeDown = 0xB915; // Głośnosc -
    rcCmdArrowRight = 0xB90B; // strzałka w prawo - nastepna stacja
    rcCmdArrowLeft = 0xB90A;  // strzałka w lewo - poprzednia stacja  
    rcCmdArrowUp = 0xB987;    // strzałka w góre - lista stacji krok do gory
    rcCmdArrowDown = 0xB986;  // strzałka w dół - lista stacj krok na dół
    rcCmdBack = 0xB985;	   	  // Przycisk powrotu
    rcCmdOk = 0xB90E;         // Przycisk Ent - zatwierdzenie stacji
    rcCmdSrc = 0xB913;        // Przełączanie źródła radio, odtwarzacz
    rcCmdMute = 0xB916;       // Wyciszenie dzwieku
    rcCmdAud = 0xB917;        // Equalizer dzwieku
    rcCmdDirect = 0xB90F;     // Janość ekranu, dwa tryby 1/16 lub pełna janość     
    rcCmdBankMinus = 0xB90C;  // Wysweitla wybór banku
    rcCmdBankPlus = 0xB90D;   // Wysweitla wybór banku
    rcCmdRed = 0xB988;        // Przycisk czerwonej sluchawki - obecnie power
    rcCmdPower = 0xB988;      // Przycisk power - brak obecnie na pilocie
    rcCmdGreen = 0xB992;      // Przycisk zielonej sluchawki - obecnie sleep
    rcCmdKey0 = 0xB900;       // Przycisk "0"
    rcCmdKey1 = 0xB901;       // Przycisk "1"
    rcCmdKey2 = 0xB902;       // Przycisk "2"
    rcCmdKey3 = 0xB903;       // Przycisk "3"
    rcCmdKey4 = 0xB904;       // Przycisk "4"
    rcCmdKey5 = 0xB905;       // Przycisk "5"
    rcCmdKey6 = 0xB906;       // Przycisk "6"
    rcCmdKey7 = 0xB907;       // Przycisk "7"
    rcCmdKey8 = 0xB908;       // Przycisk "8"
    rcCmdKey9 = 0xB909;       // Przycisk "9"

    configRemoteArray[0]  = rcCmdVolumeUp;
    configRemoteArray[1]  = rcCmdVolumeDown;
    configRemoteArray[2]  = rcCmdArrowRight;
    configRemoteArray[3]  = rcCmdArrowLeft;
    configRemoteArray[4]  = rcCmdArrowUp;
    configRemoteArray[5]  = rcCmdArrowDown;
    configRemoteArray[6]  = rcCmdBack;
    configRemoteArray[7]  = rcCmdOk;
    configRemoteArray[8]  = rcCmdSrc;
    configRemoteArray[9]  = rcCmdMute;
    configRemoteArray[10] = rcCmdAud;
    configRemoteArray[11] = rcCmdDirect;
    configRemoteArray[12] = rcCmdBankMinus;
    configRemoteArray[13] = rcCmdBankPlus;
    configRemoteArray[14] = rcCmdRed;
    configRemoteArray[15] = rcCmdGreen;
    configRemoteArray[16] = rcCmdKey0;
    configRemoteArray[17] = rcCmdKey1;
    configRemoteArray[18] = rcCmdKey2;
    configRemoteArray[19] = rcCmdKey3;
    configRemoteArray[20] = rcCmdKey4;
    configRemoteArray[21] = rcCmdKey5;
    configRemoteArray[22] = rcCmdKey6;
    configRemoteArray[23] = rcCmdKey7;
    configRemoteArray[24] = rcCmdKey8;
    configRemoteArray[25] = rcCmdKey9;
    
  }
  /*
  Serial.println("IR Config - Przypisane wartosci:");
  for (uint8_t i = 0; i < CONFIGREMOTE_COUNT; i++)
  {
    Serial.print(i);
    Serial.print(". ");
    Serial.println(configRemoteArray[i], HEX);
  }
  */
}

void listFiles(String path, String &html) 
{
    File root = STORAGE.open(path);
    if (!root) {
        Serial.println("Nie można otworzyć karty SD!");
        return;
    }

    // Przeglądanie plików w katalogu
    File file = root.openNextFile();
    while (file) {
        if (!file.isDirectory()) {
            html += "<tr>";

            html += "<td>" + String(file.name()) + "</td>";
            html += "<td>" + String(file.size()) + "</td>";
            html += "<td>" + String("\n");
            
            // Kasowanie pliku
            html += "<form action=\"/delete\" method=\"POST\" style=\"display:inline; margin-right: 35px;\">";
            html += "<input type=\"hidden\" name=\"filename\" value=\"" + String(file.name()) + "\">";
            html += "<input type=\"submit\" value=\"Delete\">";
            html += "</form>" + String("\n");

            // Podglad pliku
            html += "<form action=\"/view\" method=\"GET\" style=\"display:inline;\">";
            html += "<input type=\"hidden\" name=\"filename\" value=\"" + String(file.name()) + "\">";
            html += "<input type=\"submit\" value=\"View\">";
            html += "</form>" + String("\n");
            
            // Edycja pliku
            html += "<form action=\"/edit\" method=\"GET\" style=\"display:inline;\">";
            html += "<input type=\"hidden\" name=\"filename\" value=\"" + String(file.name()) + "\">";
            html += "<input type=\"submit\" value=\"Edit\">";
            html += "</form>" + String("\n");            
            
            // Pobieranie pliku
            html += "<form action=\"/download\" method=\"GET\" style=\"display:inline;\">";
            html += "<input type=\"hidden\" name=\"filename\" value=\"" + String(file.name()) + "\">";
            html += "<input type=\"submit\" value=\"Download\">";
            html += "</form>" + String("\n");

            html += "</td>";
            html += "</tr>" + String("\n");
        }
        file = root.openNextFile();
    }
    root.close();
}



void saveTimezone(String timezone) 
{
  if (STORAGE.exists("/timezone.txt")) 
  {
    Serial.println("debug SD -> Plik timezone.txt już istnieje.");

    // Otwórz plik do zapisu i nadpisz aktualną wartość flitrów equalizera
    myFile = STORAGE.open("/timezone.txt", FILE_WRITE);
    if (myFile) 
    {
      myFile.println(timezone);
      myFile.close();
      Serial.println("debug SD -> Aktualizacja timezone.txt na karcie SD");
    } 
    else 
    {
      Serial.println("debug SD -> Błąd podczas otwierania pliku timezone.txt");
    }
  } 
  else 
  {
    Serial.println("debug SD -> Plik timezone.txt nie istnieje. Tworzenie...");

    // Utwórz plik i zapisz w nim aktualną wartość głośności
    myFile = STORAGE.open("/timezone.txt", FILE_WRITE);
    if (myFile) 
    {
      myFile.println(timezone);
      myFile.close();
      Serial.println("debug SD -> Utworzono i zapisano timezone.txt na karcie SD");
    } 
    else 
    {
      Serial.println("debug SD -> Błąd podczas tworzenia pliku timezone.txt");
    }
  }
}

void readTimezone() 
{
  // Sprawdzamy czy plik  istnieje
  if (STORAGE.exists("/timezone.txt")) 
  {
    File myFile = STORAGE.open("/timezone.txt", FILE_READ);

    // Plik istnieje, ale nie udało się go otworzyć
    if (!myFile) 
    {
      timezone = "CET-1CEST,M3.5.0/2,M10.5.0/3";
      Serial.println("debug SD -> Blad pliku timezone.txt, ustawiam strefe:" + timezone);
      return;
    }

    // Plik udało się otworzyć
    timezone = myFile.readString();
    timezone.trim();
    myFile.close();
    Serial.println("debug SD -> Odczytano timezone.txt, strefa:" + timezone);
  } 
  else 
  {
    // Plik nie istnieje ustawiamy wartosc domyslna
    timezone = "CET-1CEST,M3.5.0/2,M10.5.0/3";
    saveTimezone(timezone);
    Serial.println("debug SD -> Pliku timezone.txt, nie istnieje");
  }
}


//####################################################################################### OBSŁUGA POWER OFF / SLEEP ####################################################################################### //

// ---- FUNKCJA WYSWIETLA NAPIS NA SRODKU OLEDa duzą czcionka -----
void displayCenterBigText(String stringText, int stringText_Y)
{
  displayStartTime = millis(); 
  displayActive = true;
  volumeSet = false;
  bankMenuEnable = false;
  timeDisplay = false;
  
  gfx.setContrast(displayBrightness); // Ustawiamy maksymalną jasnosc
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeCenterMessage(stringText);
  return;
#endif
  //gfx.setFont(u8g2_font_fub14_tr);
  gfx.setFont(u8g2_font_helvB14_tr);
  int stringTextWidth = gfx.getStrWidth(stringText.c_str()); // Liczy pozycje aby wyswietlic TEXT na środku
  int stringText_X = (SCREEN_WIDTH - stringTextWidth) / 2;
  gfx.clearBuffer();
  gfx.drawStr(stringText_X, stringText_Y, stringText.c_str());     
  gfx.sendBuffer();
  //Serial.print("debug sleep -> Chart Max Height: ");       
  //Serial.println(gfx.getMaxCharHeight(stringText.substring(0,1).c_str()));
  Serial.println(gfx.getMaxCharHeight());
}

void sleepTimer()
{
  if (f_debug_on) {Serial.println("debug sleep -> Sleep timer check");}
  Serial.println("debug sleep -> Sleep timer check");       
  if (f_sleepTimerOn)
  {
    sleepTimerValueCounter--;
    //if (f_debug_on) 
    //{
      Serial.print("debug sleep -> Sleep timer value counter: ");       
      Serial.println(sleepTimerValueCounter);
    //}
    
    if (sleepTimerValueCounter == 0) 
    {   
      f_sleepTimerOn = false;
      displayActive = true;
      displayStartTime = millis();
      timeDisplay = false;
             
      displayCenterBigText("SLEEP",36);
      //Fadeout volume
      
      ir_code = rcCmdPower; // Power off - udejmy kod pilota
      bit_count = 32;
      calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC

    }
  }
}

void powerOffAnimation() 
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativePowerOffAnimation();
  return;
#endif
  int width  = gfx.getDisplayWidth();
  int height = gfx.getDisplayHeight();

  // Animacja "zamykania" ekranu od góry i dołu
  for (int i = 0; i < height / 2; i += 2) 
  {
    gfx.clearBuffer();

    // Rysujemy prostokąt w środku ekranu, który się kurczy
    int boxHeight = height - 2 * i;
    gfx.drawBox(0, i, width, boxHeight);

    gfx.sendBuffer();
    delay(20); // czas między krokami animacji
  }

  // Po zamknięciu — "zanikanie" linii środkowej
  for (int t = 0; t < 3; t++) 
  {
    gfx.clearBuffer();
    gfx.drawHLine(0, height / 2, width);
    gfx.sendBuffer();
    delay(50);
  }

  // Całkowite wygaszenie
  gfx.clearBuffer();
  gfx.sendBuffer();
}

void displaySleepTimer()
{
  f_displaySleepTime = true;
  displayActive = true;
  displayStartTime = millis();
  timeDisplay = false;
  //gfx.clearBuffer();
  //gfx.setFont(u8g2_font_fub14_tf);
  String stringText ="";
  if (sleepTimerValueCounter != 0) {stringText = SLEEP_STRING + String(sleepTimerValueCounter) + SLEEP_STRING_VAL;}
  else {stringText = String(SLEEP_STRING) + SLEEP_STRING_OFF;}
  displayCenterBigText(stringText,36);  // Text, Y cordinate value
  //gfx.sendBuffer();
}

void sleepTimerSet()
{
  /* // DEBUG
  Serial.print("debug sleep -> f_displaySleepTime: ");       
  Serial.println(f_displaySleepTime);  

  Serial.print("debug sleep -> f_displaySleepTimeSet: ");       
  Serial.println(f_displaySleepTimeSet); 

  Serial.print("debug sleep -> f_sleepTimerOn: ");       
  Serial.println(f_sleepTimerOn); 

  Serial.print("debug sleep -> sleepTimerValueSet: ");       
  Serial.println(sleepTimerValueSet);

  Serial.print("debug sleep -> sleepTimerValueCounter: ");       
  Serial.println(sleepTimerValueCounter);   
  */
  
  if (f_displaySleepTime)
  {  
    if (f_displaySleepTimeSet)
    {
      sleepTimerValueSet = 0;
      sleepTimerValueCounter = 0;
      f_displaySleepTimeSet = false;
      f_sleepTimerOn = false;
      f_displaySleepTime = false;
    }
    else
    {
      // Odliczamy od MAX w doł w z krokiem STEP
      if (sleepTimerValueSet == 0) {sleepTimerValueSet = sleepTimerValueMax;}
      else {sleepTimerValueSet = sleepTimerValueSet - sleepTimerValueStep;}

      // Odliczamy od 0 w góre z krokiem step
      //sleepTimerValueSet = sleepTimerValueSet + sleepTimerValueStep;
      if (sleepTimerValueSet > sleepTimerValueMax) {sleepTimerValueSet = 0;}
      sleepTimerValueCounter = sleepTimerValueSet;
        
    }

    if (sleepTimerValueSet !=0)
    {
      f_sleepTimerOn = true;
      timer3.attach(60, sleepTimer);      // Ustawiamy flage działania funkcji sleep i załaczamy Timer 3
    }  
    else 
    {
      f_sleepTimerOn = false; 
      f_displaySleepTimeSet = false;
      timer3.detach();
    }                                      // Zerujemy flage działania funkcji sleep i odpinamy Timer 3 aby w sleepie nie działał
  }
  else 
  {
    if (f_displaySleepTimeSet == 0) // Jezeli nie mamy wyswietlonego menu Sleep Timer i sam Timer jest OFF to pierwsze nacisniejcie ustawia go na ValueMAX zamiast wyswietlac stan obecny czyli OFF
    {
      // Odliczamy od MAX w doł w z krokiem STEP
        if (sleepTimerValueSet == 0) {sleepTimerValueSet = sleepTimerValueMax;}
        else {sleepTimerValueSet = sleepTimerValueSet - sleepTimerValueStep;}

        // Odliczamy od 0 w góre z krokiem step
        //sleepTimerValueSet = sleepTimerValueSet + sleepTimerValueStep;
        if (sleepTimerValueSet > sleepTimerValueMax) {sleepTimerValueSet = 0;}
        sleepTimerValueCounter = sleepTimerValueSet;

        if (sleepTimerValueSet !=0)
      {
        f_sleepTimerOn = true;
        timer3.attach(60, sleepTimer);      // Ustawiamy flage działania funkcji sleep i załaczamy Timer 3
      }
      else 
      {
        f_sleepTimerOn = false; 
        f_displaySleepTimeSet = false;
        timer3.detach();
      }
    }    
  }

  displaySleepTimer();                   // Obsługa komunikatu na OLED 
}


bool evoPowerOffClockEnabled()
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS && EVO_STANDBY_CLOCK_ALWAYS_AFTER_POWER_OFF
  // Na TFT po wylaczeniu z pilota ma byc zawsze: animacja -> zegar standby.
  // Nie uzalezniamy tego od starej opcji OLED "Display Clock in Sleep".
  return true;
#else
  return f_displayPowerOffClock;
#endif
}

void powerOffClock()
{
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI && EVO_TFT_NATIVE_ALL_SCREENS
  tftNativeStandbyClock();
  seconds2nextMinute = 1;
  // Standby clock:
  // - podczas przewijania cyfr budzimy ekran czesto, aby animacja byla plynna,
  // - po zakonczeniu animacji usypiamy dokladnie do nastepnej pelnej sekundy,
  //   zeby sekundy zmienialy sie co 1 s, a nie przypadkowo co 180 ms.
  if (evoStandbyClockAnimating)
  {
    micros2nextMinute = (uint64_t)EVO_TFT_STANDBY_CLOCK_FRAME_MS * 1000ULL;
  }
  else
  {
    uint64_t nowUs = (uint64_t)esp_timer_get_time();
    uint64_t remUs = 1000000ULL - (nowUs % 1000000ULL);
    if (remUs < 25000ULL) remUs += 1000000ULL;
    micros2nextMinute = remUs;
  }
  return;
#endif

  //gfx.clearBuffer();
  gfx.setPowerSave(0);
  gfx.setContrast(dimmerSleepDisplayBrightness);
  gfx.setDrawColor(1);  // Ustaw kolor na biały

  // Struktura przechowująca informacje o czasie
  struct tm timeinfo;

  if (!getLocalTime(&timeinfo, 500)) 
  {
    // Wyświetl komunikat o niepowodzeniu w pobieraniu czasu
	  Serial.println("debug time powerOffClock -> Nie udało się uzyskać czasu");
    gfx.clearBuffer();
    gfx.setFont(u8g2_font_7Segments_26x42_mn);
    gfx.drawStr(40, 52, "--:--");
    gfx.sendBuffer();
    return;  // Zakończ funkcję, gdy nie udało się uzyskać czasu
  }
      
  
  seconds2nextMinute = 60 - timeinfo.tm_sec;
  micros2nextMinute = seconds2nextMinute * 1000000ULL - (esp_timer_get_time() % 1000000ULL);
  
  // ---------- ZABEZPIECZENIE ----------
  if (micros2nextMinute < 1000) micros2nextMinute = 1000;
  // -----------------------------------



  //showDots = (timeinfo.tm_sec % 2 == 0); // Parzysta sekunda = pokazuj dwukropek

  // Konwertuj godzinę, minutę i sekundę na stringi w formacie "HH:MM:SS"
  char timeString[9];  // Bufor przechowujący czas w formie tekstowej
  gfx.setFont(u8g2_font_7Segments_26x42_mn);
  snprintf(timeString, sizeof(timeString), "%2d:%02d", timeinfo.tm_hour, timeinfo.tm_min);
  gfx.clearBuffer();
  gfx.drawStr(53, 52, timeString);
  gfx.sendBuffer();

}

void powerOff()
{
  bool standbyClockActive = evoPowerOffClockEnabled();

  // Wyłaczamy LED IR - wspolna z LED Standby
  //delay(30); 
  //digitalWrite(IR_LED, LOW);
  
  
  // ---- WYSWIETLAMY NAPIS POWER OFF na srodku ----
  displayCenterBigText("POWER OFF",36); // Tekst, pozycja Y
    
  // ---- ZAMYKAMY CALY OBIEKT AUDIO ----
  ws.closeAll();
  if (!volumeMute && f_volumeFadeOn) {volumeFadeOut(volumeSleepFadeOutTime);}
  audio.setVolume(0);
  delay(500);
  audio.stopSong();
  delay(500);
  
  // ---- ZAPIS OSTATNIEGO NR.STACJI, NR.BANKU, POZIOMU VOLUME jesli funkcja saveAlwasy wylaczona ----
  if (!f_saveVolumeStationAlways) {saveVolumeOnSD(); saveStationOnSD();}
  
  
  // ---- ANIMACJA POWER OFF, jesli wlaczona ----
  if (f_powerOffAnimation || standbyClockActive) {Serial.println("debug Power -> Animacja PowerOff / Standby Clock"); powerOffAnimation(); gfx.clearBuffer();}

  // ---- ZEGAR W TRYBIE POWER OFF pierwsze wywloane celem synch. ntp----
  if (standbyClockActive)
  {
    gfx.setPowerSave(0);  // Jesli zegar wlaczony to nie przelaczamy OLEDa w tryb power save
    Serial.println("debug Power -> Zegar ON");
    powerOffClock();
  } 
  // Wyłącz ekran jesli zegar ma byc wyłaczony
  else 
  {
    gfx.setPowerSave(1);
  } 
  
  delay(25);
  
  // ----- ZERUJEMY SLEEP TIMER -----
  sleepTimerValueSet = 0;
  sleepTimerValueCounter = 0;
  f_displaySleepTimeSet = false;
  f_sleepTimerOn = false;
  f_displaySleepTime = false;
  timer3.detach();
  timer4.detach();

  f_powerOff = true; 
  Serial.println("debug Power -> Usypiam ESP, power off");

  // -------------- WYŁACZAMY PERYFERIA ------------------
  WiFi.mode(WIFI_OFF);
  btStop();
  // -------------- WYŁACZAMY LED na module ESP32 ------------------
  pinMode(TX, OUTPUT);
  pinMode(RX, OUTPUT);
  digitalWrite(TX, HIGH);
  digitalWrite(RX, HIGH);
  
  Serial.end();
    
  // ---- USTAWIAMY PRZYCISKI NA ENKODERACH do POWER ON -----
  
  pinMode(SW_PIN2, INPUT_PULLUP); // Enkoder 2 SW pin
  
  #ifdef SW_POWER
    pinMode(SW_POWER, INPUT_PULLUP);
  #endif
  
  #ifdef twoEncoders
    pinMode(SW_PIN1, INPUT_PULLUP);
  #endif

  // --------LED STANDBY config ----------------
  //pinMode(STANDBY_LED, OUTPUT);  
  
  // ---------------- USTAWIAMY WAKEUP ----------------    
  #ifdef twoEncoders
  gpio_wakeup_enable((gpio_num_t)SW_PIN1, GPIO_INTR_LOW_LEVEL);
  #endif
    
  #ifdef SW_POWER
  gpio_wakeup_enable((gpio_num_t)SW_POWER, GPIO_INTR_LOW_LEVEL);
  #endif
  
  gpio_wakeup_enable((gpio_num_t)SW_PIN2, GPIO_INTR_LOW_LEVEL);

  //gpio_wakeup_enable((gpio_num_t)recv_pin, GPIO_INTR_LOW_LEVEL);
  
  esp_sleep_enable_gpio_wakeup();
  
  while (f_powerOff)
  {
    // ---------------- RESET STANÓW IR ----------------
    bit_count = 0;
    ir_code = 0;
    detachInterrupt(digitalPinToInterrupt(recv_pin)); // WYLACZAMY PRZERWANIE
    delay(10);

    // ---------------- DEZAKTYWACJA PERYFERIOW i AKTYWACJA ZEGARA (jesli właczony) ----------------
    if (standbyClockActive) 
    {
      powerOffClock();
      esp_sleep_enable_timer_wakeup(micros2nextMinute); 
    }
    else 
    {
      gfx.setPowerSave(1);
    }
      
    // ---------------- USTAWIAMY WAKEUP ----------------    
    gpio_wakeup_enable((gpio_num_t)recv_pin, GPIO_INTR_LOW_LEVEL);

    // ---------------- USTAWIAMY LED Standby ----------------
    #ifdef TAS5805
      digitalWrite(STANDBY_LED, LOW); // Dla TAS jest to pin #PWDN sterowany stanem niskim
    #else
    digitalWrite(STANDBY_LED, HIGH); // Dla LED wyłączonego w trybie Power ON a właczonego w trybie Standby
    //digitalWrite(STANDBY_LED, LOW); // Dla LED właczonego w trybie Power ON
    #endif

    
    // ---------------- SLEEP ----------------
    delay(10);
    esp_light_sleep_start();

    // ------------- TU SIĘ OBUDZIMY ----------------

    // Jesli obudził nas timer to robimy aktulizacje zegera i wracamy na początek petli while
    esp_sleep_wakeup_cause_t cause = esp_sleep_get_wakeup_cause();
    if (cause == ESP_SLEEP_WAKEUP_TIMER)
    {
      // APMS FIX: nie rysujemy zegara drugi raz tutaj.
      // Po continue petla while od razu wywola powerOffClock() przed kolejnym sleep.
      // Wczesniej byly dwa rysowania prawie pod rzad, co powodowalo opoznienia i szarpanie sekund.
      delay(2);
      continue;   // wraca do while – ESP idzie znowu spać
    }

    // Konfiguracja przerwania IR
    attachInterrupt(digitalPinToInterrupt(recv_pin), pulseISR, CHANGE);
    delay(100); // stabilizacja
                
    // Analiza IR
    ir_code = reverse_bits(ir_code, 32);
    uint8_t CMD  = (ir_code >> 16) & 0xFF;
    uint8_t ADDR = ir_code & 0xFF;
    ir_code = (ADDR << 8) | CMD;
  
  
    // Warunek POWER UP
    #ifdef twoEncoders
    bool POWER_UP =
        (bit_count == 32 && ir_code == rcCmdPower && f_powerOff) ||
        #ifdef SW_POWER 
          (digitalRead(SW_POWER) == LOW) ||
        #endif
        (digitalRead(SW_PIN1) == LOW) ||
        (digitalRead(SW_PIN2) == LOW);
    #else
    bool POWER_UP =
        (bit_count == 32 && ir_code == rcCmdPower && f_powerOff) ||
        #ifdef SW_POWER 
          (digitalRead(SW_POWER) == LOW) ||
        #endif
        (digitalRead(SW_PIN2) == LOW);
    #endif    

    // ------------------ WSTAEMY po poprawny rozpoznaiu kodu (lub nie, else) -----------------
    if (POWER_UP)
    {
      detachInterrupt(digitalPinToInterrupt(recv_pin));
      esp_sleep_disable_wakeup_source(ESP_SLEEP_WAKEUP_ALL);
    
      f_powerOff = false;
      displayActive = true;

      gfx.setPowerSave(0);
      displayCenterBigText("POWER ON", 36);
      
      // ------------ LED STANDBY -----------
      //pinMode(STANDBY_LED, OUTPUT);
      //digitalWrite(STANDBY_LED, HIGH); // Dla LED właczonego w trybie Power ON
      digitalWrite(STANDBY_LED, LOW); // Dla LED wyłączonego w trybie PowerON a właczonego w trybie Standby
      
      delay(800);

      // Twardy restart
      REG_WRITE(RTC_CNTL_OPTIONS0_REG, RTC_CNTL_SW_SYS_RST);
      break;
    }

    // Nie to nie POWER_UP -> rozpinamy przerwanie IR
    detachInterrupt(digitalPinToInterrupt(recv_pin));
  }
}

// ---- ŁADOWANIE LOGO STARTOWEGO jesli plik istnieje ----
bool loadXBM(const char* filename) 
{
    File logo = STORAGE.open(filename, FILE_READ);
    if (!logo) return false;
  
    if (logo.size() == 0) {
        logo.close();
        return false;
    }

    int index = 0;

    while (logo.available() && index < LOGO_SIZE) 
    {
        char c = logo.read();

        if (c == '0' && logo.peek() == 'x') 
        {
            logo.read(); // skip 'x'
            
            char hex1 = logo.read();
            char hex2 = logo.read();

            char hexStr[3] = {hex1, hex2, 0};
            logo_bits[index++] = strtol(hexStr, NULL, 16);
        }
    }

    logo.close();
  
    if (index < LOGO_SIZE) return false;

    return true;
}

void startOta()
{
  timeDisplay = false;
  displayActive = true;
  fwupd = true;
  
  ws.closeAll();
  audio.stopSong();
  delay(250);
  if (!f_saveVolumeStationAlways){saveStationOnSD(); saveVolumeOnSD();}
  
  for (int i = 0; i < 3; i++) 
  {
    gfx.clearBuffer();
    delay(25);
  }        
  unsigned long now = millis();
  gfx.clearBuffer();
  gfx.setDrawColor(1);
  gfx.setFont(spleen6x12PL);     
  gfx.setCursor(5, 12); gfx.print("Evo Radio, OTA Firwmare Update");
  gfx.sendBuffer();
}

void setPreset(uint8_t preset)
{
  displayStartTime = millis();
  
  displayActive = true;
  volumeSet = false;
  bankMenuEnable = false;
  timeDisplay = false;

   
  Serial.print("debug Presets -> Szybkie wybieranie - stacja:");
  Serial.println(preset);
  
  if (preset == 0) {station_nr = 10;} else {station_nr = preset;}

  #ifdef IR_LED
    irLedBlink(); 
  #endif

  changeStation();
  clearFlags();  // Czyscimy wszystkie flagi przebywania w różnych menu
  displayRadio();
  gfx.sendBuffer();
}

//Miganie LED w momencie odebraknia poprawnego kodu IR
void irLedBlink()
{
  digitalWrite(IR_LED, IR_LED_ON);
  delay(30); 
  digitalWrite(IR_LED, IR_LED_OFF);
} 

/*---------------------  FUNKCJA PILOT IR  / Obsluga pilota IR w kodzie NEC ---------------------*/ 
void evoAudioEqButton();
void evoAudioEqRestoreReturnMode();
void handleRemote()
{
  if (bit_count == 32) // sprawdzamy czy odczytalismy w przerwaniu pełne 32 bity kodu IR NEC
  {
    if (ir_code != 0) // sprawdzamy czy zmienna ir_code nie jest równa 0
    {
      
      detachInterrupt(recv_pin);            // Rozpinamy przerwanie
      
      // ---- Symulacja aktywnosci LED IR ----
      #ifdef IR_LED
        irLedBlink(); 
      #endif
      
      Serial.print("debug IR -> Kod NEC OK:");
      Serial.print(ir_code, HEX);
      ir_code = reverse_bits(ir_code,32);   // Rotacja bitów - zmiana porządku z LSB-MSB na MSB-LSB
      Serial.print("  MSB-LSB: ");
      Serial.print(ir_code, HEX);
    
      uint8_t CMD = (ir_code >> 16) & 0xFF; // Drugi bajt (inwersja adresu)
      uint8_t ADDR = ir_code & 0xFF;        // Czwarty bajt (inwersja komendy)
      
      Serial.print("  ADR:");
      Serial.print(ADDR, HEX);
      Serial.print(" CMD:");
      Serial.println(CMD, HEX);
      ir_code = ADDR << 8 | CMD;      // Łączymy ADDR i CMD w jedną zmienną 0x ADR CMD

      // Info o przebiegach czasowytch kodu pilota IR
      Serial.print("debug IR -> puls 9ms:"); 
      Serial.print(pulse_duration_9ms);
      Serial.print("  4.5ms:");
      Serial.print(pulse_duration_4_5ms);
      Serial.print("  1690us:");
      Serial.print(pulse_duration_1690us);
      Serial.print("  560us:");
      Serial.println(pulse_duration_560us);


      fwupd = false;        // Kasujemy flagę aktulizacji OTA gdyby była ustawiona
      //displayActive = true; // jesli odbierzemy kod z pilota to uatywnij wyswietlacz i wyłacz przyciemnienie OLEDa
      //displayDimmer(0); // jesli odbierzemy kod z pilota to wyłaczamy przyciemnienie wyswietlacza OLED
      displayPowerSave(0);
      
      // Nauka pilota - wywolanie WebSocket
      if (remoteConfig) 
      {
        wsIrCode(ir_code, ADDR, CMD);
        ir_code = 0;
        bit_count = 0;
      }

      if (ir_code == rcCmdVolumeUp)  { volumeUp(); }         // Przycisk głośniej
      else if (ir_code == rcCmdVolumeDown) { volumeDown(); } // Przycisk ciszej
      else if (ir_code == rcCmdArrowRight) // strzałka w prawo - nastepna stacja, bank lub nastawy equalizera
      {  
        if (bankMenuEnable == true)
        {
          bank_nr++;
          if (bank_nr > bank_nr_max) 
          {
            bank_nr = 1;
          }
        bankMenuDisplay();
        }
        else if (equalizerMenuEnable == true)
        {
          if (displayMode == 13 || eq16MenuActive)
          {
            evo43Eq16SelectBand(+1);   // EQ16: strzalka w prawo wybiera nastepna czestotliwosc
          }
          else
          {
            if (toneSelect == 1) {toneHiValue++;}
            if (toneSelect == 2) {toneMidValue++;}
            if (toneSelect == 3) {toneLowValue++;}
            if (toneSelect == 4) {balanceValue++;}
            
            if (toneHiValue > 12) {toneHiValue = 12;}
            if (toneMidValue > 12) {toneMidValue = 12;}
            if (toneLowValue > 12) {toneLowValue = 12;}
            if (balanceValue > 16) {balanceValue = 16;}
            displayEqualizer();
          }
        }     
        else if (listedStations == true) // Szybkie przewijanie o 5 stacji
        {
          timeDisplay = false;
          displayActive = true;
          displayStartTime = millis();    
          station_nr = currentSelection + 1;

          station_nr = station_nr + 5;
          for (int i = 0; i < 5; i++) {scrollDown();}
    
          if (station_nr > stationsCount) {station_nr = station_nr - stationsCount; } //Zbaezpiecznie aby przewijac sie tylko po stacjach w liczbie jaka jest w stationCount
          
          displayStations();
        }
        else
        {
          station_nr++;
          //if (station_nr > stationsCount) { station_nr = stationsCount; }
          if (station_nr > stationsCount) { station_nr = 1; } // Przwijanie listy stacji w pętli po osiągnieciu ostatniej stacji banku przewijamy do pierwszej.
          changeStation();
          displayRadio();
          gfx.sendBuffer();
        }
      }
      else if (ir_code == rcCmdArrowLeft) // strzałka w lewo - poprzednia stacja, bank lub nastawy equalizera
      {  
        if (bankMenuEnable == true)
        {
          bank_nr--;
          if (bank_nr < 1) 
          {
            bank_nr = bank_nr_max;
          }
        bankMenuDisplay();  
        }
        else if (equalizerMenuEnable == true)
        {
          if (displayMode == 13 || eq16MenuActive)
          {
            evo43Eq16SelectBand(-1);   // EQ16: strzalka w lewo wybiera poprzednia czestotliwosc
          }
          else
          {
            if (toneSelect == 1) {toneHiValue--;}
            if (toneSelect == 2) {toneMidValue--;}
            if (toneSelect == 3) {toneLowValue--;}
            if (toneSelect == 4) {balanceValue--;}
            
            if (toneHiValue < -12)  {toneHiValue = -12;}
            if (toneMidValue < -12) {toneMidValue = -12;}
            if (toneLowValue < -12) {toneLowValue = -12;}
            if (balanceValue < -16) {balanceValue = -16;}
           
            displayEqualizer();
          }
        }     
        else if (listedStations == true)
        {
          timeDisplay = false;
          displayActive = true;
          displayStartTime = millis();    
          station_nr = currentSelection + 1;

          station_nr = station_nr - 5;
          
          for (int i = 0; i < 5; i++) {scrollUp();}
      
          //Zbaezpiecznie aby przewijac sie tylko po stacjach w liczbie jaka jest w stationCount
          if (station_nr > stationsCount) { station_nr = (stationsCount - (255 - station_nr)) - 1 ;} 
          
          // Jesli jestesmy na stacji nr 5 to aby uniknąc station_nr = 0 przewijamy do ostatniej
          if (station_nr == 0) {station_nr = stationsCount;} 

          displayStations();
        }      
        else
        {        
          station_nr--;
          //if (station_nr < 1) { station_nr = 1; }
          if (station_nr < 1) { station_nr = stationsCount; } // Przwijanie listy stacji w pętli po osiągnieciu ostatniej stacji banku przewijamy do pierwszej.
          changeStation();
          displayRadio();
          gfx.sendBuffer();
        }
      }
      else if ((ir_code == rcCmdArrowUp) && (volumeSet == false) && (equalizerMenuEnable == true))
      {
        if (displayMode == 13 || eq16MenuActive)
        {
          evo43Eq16AdjustGain(+1);     // EQ16: po OK strzalka gora zwieksza wzmocnienie
        }
        else
        {
          toneSelect--;
          if (toneSelect < 1){toneSelect = 1;}
          displayEqualizer();
        }
      }
      else if ((ir_code == rcCmdArrowUp) && (equalizerMenuEnable == false))// Przycisk w góre
      {  
        if ((volumeSet == true) && (volumeBufferValue != volumeValue))
        {
          if (f_saveVolumeStationAlways) {saveVolumeOnSD();}
          volumeSet = false;
        }
        
        timeDisplay = false;
        displayActive = true;
        displayStartTime = millis();    
        station_nr = currentSelection + 1;

        if (listedStations == true) {station_nr--; scrollUp();} //station_nr-- tylko jesli już wyswietlany liste stacji;
        else
        {        
          currentSelection = station_nr - 1; // Przywracamy zaznaczenie obecnie grajacej stacji
          
          if (currentSelection >= 0)
          {
            if (currentSelection < firstVisibleLine) // jezeli obecne zaznaczenie ma wartosc mniejsza niz pierwsza wyswietlana linia
            {
              firstVisibleLine = currentSelection;
            }
          } 
          else 
          {  // Jeśli osiągnięto wartość 0, przejdź do najwyższej wartości
            if (currentSelection = maxSelection())
            {
            firstVisibleLine = currentSelection - maxVisibleLines + 1;  // Ustaw pierwszą widoczną linię na najwyższą
            }
          }   
        }
        
        if (station_nr < 1) { station_nr = stationsCount; } // jesli dojdziemy do początku listy stacji to przewijamy na koniec
        
        
       
       
      displayStations();
      }
      else if ((ir_code == rcCmdArrowDown) && (volumeSet == false) && (equalizerMenuEnable == true))
      {
        if (displayMode == 13 || eq16MenuActive)
        {
          evo43Eq16AdjustGain(-1);     // EQ16: po OK strzalka dol zmniejsza wzmocnienie
        }
        else
        {
          toneSelect++;
          if (toneSelect > 4){toneSelect = 4;}
          displayEqualizer();
        }
      }
      else if ((ir_code == rcCmdArrowDown) && (equalizerMenuEnable == false)) // Przycisk w dół
      {  
        if ((volumeSet == true) && (volumeBufferValue != volumeValue))
        {
          if (f_saveVolumeStationAlways) {saveVolumeOnSD();}
          volumeSet = false;
        }
        
        timeDisplay = false;
        displayActive = true;
        displayStartTime = millis();     
        station_nr = currentSelection + 1;
        
        //station_nr++;
        if (listedStations == true) {station_nr++; scrollDown(); } //station_nr++ tylko jesli już wyswietlany liste stacji;
        else
        {        
          currentSelection = station_nr - 1; // Przywracamy zaznaczenie obecnie grajacej stacji

          if (currentSelection >= 0)
          {
            if (currentSelection < firstVisibleLine) // jezeli obecne zaznaczenie ma wartosc mniejsza niz pierwsza wyswietlana linia
            {
              firstVisibleLine = currentSelection;
            }
          } 
          else 
          {  // Jeśli osiągnięto wartość 0, przejdź do najwyższej wartości
            if (currentSelection = maxSelection())
            {
            firstVisibleLine = currentSelection - maxVisibleLines + 1;  // Ustaw pierwszą widoczną linię na najwyższą
            }
          }
             
        }
        
        if (station_nr > stationsCount) 
	      {
          station_nr = 1;//stationsCount;
        }
        
        //Serial.println(station_nr);

         
        displayStations();
      }    
      else if (ir_code == rcCmdOk)
      {
        if ((equalizerMenuEnable == true) && (displayMode == 13 || eq16MenuActive))
        {
          // EQ16: OK wlacza/konczy regulacje wybranego pasma. Nie wychodzimy od razu z menu.
          evo43Eq16ToggleEdit();
          volumeSet = false;
        }
        else
        {
          if (bankMenuEnable == true)
          {
            station_nr = 1;
            fetchStationsFromServer(); // Ładujemy stacje z karty lub serwera 
            bankMenuEnable = false;
          }  
          if (equalizerMenuEnable == true) { saveEqualizerOnSD();}    // zapis ustawien equalizera
          //if (volumeSet == true) { saveVolumeOnSD();}                 // zapis ustawien głośnosci po nacisnięciu OK, wyłaczony aby można było przełączyć stacje na www bez czekania
          //if ((equalizerMenuEnable == false) && (volumeSet == false)) // jesli nie zapisywaliśmy equlizer i glonosci to wywolujemy ponizsze funkcje
          if ((equalizerMenuEnable == false)) // jesli nie zapisywaliśmy equlizer 
          {
            if ((!urlPlaying) || (listedStations)) {changeStation();}
            if (rcInputDigitsMenuEnable) {changeStation();}
            else if (urlPlaying) {webUrlStationPlay();}

            clearFlags();                                             // Czyscimy wszystkie flagi przebywania w różnych menu
            displayRadio();
            gfx.sendBuffer();
          }
          equalizerMenuEnable = false; // Kasujemy flage ustawiania equalizera
          volumeSet = false; // Kasujemy flage ustawiania głośnosci
        }
      } 
      else if (ir_code == rcCmdKey0) {if (f_Presets && !bankMenuEnable) {setPreset(0);} else {rcInputKey(0);}}
      else if (ir_code == rcCmdKey1) {if (f_Presets && !bankMenuEnable) {setPreset(1) ;} else {rcInputKey(1);}}     
      else if (ir_code == rcCmdKey2) {if (f_Presets && !bankMenuEnable) {setPreset(2) ;} else {rcInputKey(2);}}     
      else if (ir_code == rcCmdKey3) {if (f_Presets && !bankMenuEnable) {setPreset(3) ;} else {rcInputKey(3);}}
      else if (ir_code == rcCmdKey4) {if (f_Presets && !bankMenuEnable) {setPreset(4) ;} else {rcInputKey(4);}}
      else if (ir_code == rcCmdKey5) {if (f_Presets && !bankMenuEnable) {setPreset(5) ;} else {rcInputKey(5);}}
      else if (ir_code == rcCmdKey6) {if (f_Presets && !bankMenuEnable) {setPreset(6) ;} else {rcInputKey(6);}}  
      else if (ir_code == rcCmdKey7) {if (f_Presets && !bankMenuEnable) {setPreset(7) ;} else {rcInputKey(7);}}
      else if (ir_code == rcCmdKey8) {if (f_Presets && !bankMenuEnable) {setPreset(8) ;} else {rcInputKey(8);}}
      else if (ir_code == rcCmdKey9) {if (f_Presets && !bankMenuEnable) {setPreset(9) ;} else {rcInputKey(9);}}
      else if (ir_code == rcCmdBack) 
      {   
        //f_simpleMode3 = !f_simpleMode3;
        if ((equalizerMenuEnable == true) && (displayMode == 13 || eq16MenuActive))
        {
          evo43Eq16Save();
          evoAudioEqRestoreReturnMode();
        }
        displayDimmer(0);
        clearFlags();   // Zerujemy wszystkie flagi
        displayRadio(); // Ładujemy erkran radia
        gfx.sendBuffer(); // Wysyłamy bufor na wyswietlacz
        currentSelection = station_nr - 1; // Przywracamy zaznaczenie obecnie grajacej stacji
      }
      else if (ir_code == rcCmdMute) 
      {
        volumeMute = !volumeMute;
        if (volumeMute == true)
        {
          audio.setVolume(0);   
        }
        else if (volumeMute == false)
        {
          audio.setVolume(volumeValue);   
        }
        displayRadio();
        //wsVolumeChange(volumeValue);
        wsVolumeChange();
      }
      else if (ir_code == rcCmdDirect) // Przycisk Direct -> Menu Bank - udpate GitHub, Menu Equalizer - reset wartosci, Radio Display - fnkcja przyciemniania ekranu
      {
        if ((bankMenuEnable == true) && (equalizerMenuEnable == false))// flage można zmienic tylko bedąc w menu wyboru banku
        { 
          bankNetworkUpdate = !bankNetworkUpdate; // zmiana flagi czy aktualizujemy bank z sieci czy karty SD
          bankMenuDisplay(); 
        }
        if ((bankMenuEnable == false) && (equalizerMenuEnable == true))
        {
          if (displayMode == 13 || eq16MenuActive)
          {
            evo43Eq16Reset();
            evo43Eq16Save();
            evo43Eq16EditGain = false;
            evo43Eq16OpenPanel();
          }
          else
          {
            toneHiValue = 0;
            toneMidValue = 0;
            toneLowValue = 0;
            balanceValue = 0;    
            displayEqualizer();
          }
        }
        if ((bankMenuEnable == false) && (equalizerMenuEnable == false) && (volumeSet == false))
        { 
          if (displayMode == 4) // Jesli jestesmy w display Mode 4 czyli duzy VU wsazowkowy to mozna właczyc buffor audio print.
          {
            debugAudioBuffor=!debugAudioBuffor;
          }
          else
          {
            displayDimmer(!displayDimmerActive); // Dimmer OLED
            Serial.println("Właczono display Dimmer rcCmdDirect");
          }
        }
      }      
      else if (ir_code == rcCmdSrc) 
      {
        displayMode++;
        if (displayMode > displayModeMax) {displayMode = 0;}

        // Opcja zamiany kolorow w mode4 bez dodawania nowego trybu               
        //if ((displayMode > displayModeMax) & (reversColorMode4)) {displayMode = displayModeMax; reversColorMode4=!reversColorMode4;}
        //else if ((displayMode > displayModeMax) & (!reversColorMode4)) {displayMode = 0; reversColorMode4=!reversColorMode4;}
        
        displayRadio();
        clearFlags();
        ActionNeedUpdateTime = true;
      }
      else if (ir_code == rcCmdRed)   {powerOff();}
      else if (ir_code == rcCmdPower) {powerOff();}
      else if (ir_code == rcCmdGreen) if (listedStations) {voiceTime();} else {sleepTimerSet();}   
      else if (ir_code == rcCmdBankMinus) 
      {
        /*
        if (bankMenuEnable == true) 
        { 
          bank_nr--; 
          if (bank_nr < 1) {bank_nr = bank_nr_max;}
        }
        */       
        bankMenuDisplay();
      }
      else if (ir_code == rcCmdBankPlus) 
      {
        f_Presets = !f_Presets;
        if (f_Presets) displayCenterBigText("PRESETS ON",36); else displayCenterBigText("PRESETS OFF",36);
        /*
        if (bankMenuEnable == true)
        {
          bank_nr++;
          if (bank_nr > bank_nr_max) {bank_nr = 1;}
        }       
        bankMenuDisplay();
        */       
      }     
      else if (ir_code == rcCmdAud) {evoAudioEqButton();}
      else { Serial.println("Inny przycisk"); }
    }
    else
    {
      Serial.println("Błąd - kod pilota NEC jest niepoprawny!");
      Serial.print("debug IR -> puls 9ms:");
      Serial.print(pulse_duration_9ms);
      Serial.print("  4.5ms:");
      Serial.print(pulse_duration_4_5ms);
      Serial.print("  1690us:");
      Serial.print(pulse_duration_1690us);
      Serial.print("  560us:");
      Serial.println(pulse_duration_560us);    
    }
    
    // ---- Symulacja aktywnosci LED IR ----
    //#ifdef IR_LED
    //  irLedBlink();  
      //delay(30); digitalWrite(IR_LED, LOW);  // Wyjatek aby nie załaczac diody LED Standby w momencie odbioru komendy PowerOFF
    //#endif
        
    ir_code = 0;
    bit_count = 0;
    attachInterrupt(digitalPinToInterrupt(recv_pin), pulseISR, CHANGE);    

  }

}

#ifdef TAS5805
  void tasWrite(uint8_t reg, uint8_t val) 
  {
    Serial.print("TAS Write: ");
    Serial.print(reg,HEX);
    Serial.print(" ");
    Serial.println(val,HEX);

    Wire.beginTransmission(TAS5805_ADDR);
    Wire.write(reg);
    Wire.write(val);
    Wire.endTransmission();
  }
   
 void tasRead(uint8_t reg)
 {
  Wire.beginTransmission(TAS5805_ADDR);
  Wire.write(reg);
  Wire.endTransmission(false);   // repeated start

  Wire.requestFrom(TAS5805_ADDR, (uint8_t)1);

  Serial.print("TAS Read: ");
  Serial.print(reg, HEX);
  Serial.print(" = ");

  if (Wire.available()) 
    Serial.println(Wire.read(), HEX);
  else
    Serial.println("ERR");
}

  
  
  
  /*

  void tas5805init()
  {
      tasWrite(0x01, 0x01);      // Software reset
      delay(1);

      tasWrite(0x00, 0x00);      // Book 0
      tasWrite(0x7F, 0x00);      // Page 0

      //tasWrite(0x46, 0x00);      // Disable Digital Auto-Mute
      tasWrite(0x03, 0x03);      // I2S, 24-bit, standard
      //tasWrite(0x28, 0x30);      // Master volume = -48 dB
      tasWrite(0x4c, 0x30);      // Master volume = -48 dB
      
      tasWrite(0x30, 0x01);      // Exit Hi-Z
      delay(10);

      tasWrite(0x02, 0x00);      // PLAY
  }
  */
    void tas5805init()
  {
      tasWrite(0x01, 0x01);      // Software reset
      delay(1);

      tasWrite(0x00, 0x00);      // Book 0
      tasWrite(0x7F, 0x00);      // Page 0
      tasWrite(0x03, 0x02);     // switch to High-Z (powienien byc po resecie równiez)

      tasWrite(0x30, 0x01);      // SDOUT - pre-proccessing, DSP input
      delay(10);
      
      tasWrite(0x02, 0x00);      // RES 000 - 768k 0 0-BTL 00-BD Mode

      tasWrite(0x28, 0x50);      // 1001 BCK Ratio 256FS/ 00 autodedect  0000 FS_mode Autio

      tasWrite(0x33, 0x02);

      tasWrite(0x4c, 0x30);      // Master volume = -48 dB

      tasWrite(0x03, 0x03);      // PLAY
      delay(5);

      //tasWrite(0x28, 0x30);      // Master volume = -48 dB
  }

  void tas5805vol(uint8_t volume)
  {
    tasWrite(0x4c, volume);
  }
#endif

//####################################################################################### SETUP ####################################################################################### //



// =================================================================================================
// V47 / FULL ADOPTED - adapter funkcji z EVO3 MOD OST do bazy V7/V46
// -------------------------------------------------------------------------------------------------
// Cel: zachowujemy rdzen V7 i kolorowa warstwe LovyanGFX, ale udostepniamy brakujace wejscia/funkcje
// z oryginalnego EVO3 MOD OST. Funkcje sa podlaczone do nowych mechanizmow evo43/evo46, zeby nie
// dublowac starego bufora U8G2 i nie rozbijac ekranu ILI9488.
// =================================================================================================

#ifndef EVO47_FULL_ADOPTED_ADAPTERS
#define EVO47_FULL_ADOPTED_ADAPTERS 1

// Nazwy kompatybilne ze starym MOD OST / modułami.
bool sdPlayerActive = false;
bool sdPlayerPlayingMusic = false;
bool sdPlayerOLEDActive = false;
bool listedTracks = false;
// eq16MenuActive przeniesione wyzej, obok zmiennych EQ16.
bool sdPlayerScanRequested = false;
uint8_t sdPlayerReturnBank = 0;
uint8_t sdPlayerReturnStation = 0;
String currentMP3Artist = "";
String currentMP3Title = "";
String currentMP3Album = "";
String dlnaHost = "";
String dlnaIDX = "0";
String dlnaDescUrl = "";
String g_dlnaControlUrl = "";
SemaphoreHandle_t g_dlnaHttpMux = NULL;

// Style SDPlayer z oryginalnego MOD OST - w V7/V46 sa mapowane na tablice evo46SdPlayerStyleEnabled[].
bool sdPlayerStyle1Enabled  = true;
bool sdPlayerStyle2Enabled  = true;
bool sdPlayerStyle3Enabled  = true;
bool sdPlayerStyle4Enabled  = true;
bool sdPlayerStyle5Enabled  = true;
bool sdPlayerStyle6Enabled  = true;
bool sdPlayerStyle7Enabled  = true;
bool sdPlayerStyle9Enabled  = true;
bool sdPlayerStyle10Enabled = true;
bool sdPlayerStyle11Enabled = true;
bool sdPlayerStyle12Enabled = true;
bool sdPlayerStyle13Enabled = true;
bool sdPlayerStyle14Enabled = true;

fs::FS& getStorage()
{
#ifdef AUTOSTORAGE
  if (_storage) return *_storage;
  return LittleFS;
#elif defined(USE_SD)
  return SD;
#else
  return LittleFS;
#endif
}

bool isValidUtf8(const String& str)
{
  const unsigned char* bytes = (const unsigned char*)str.c_str();
  while (*bytes) {
    if (*bytes <= 0x7F) { bytes++; }
    else if ((*bytes & 0xE0) == 0xC0) { if ((bytes[1] & 0xC0) != 0x80) return false; bytes += 2; }
    else if ((*bytes & 0xF0) == 0xE0) { if ((bytes[1] & 0xC0) != 0x80 || (bytes[2] & 0xC0) != 0x80) return false; bytes += 3; }
    else if ((*bytes & 0xF8) == 0xF0) { if ((bytes[1] & 0xC0) != 0x80 || (bytes[2] & 0xC0) != 0x80 || (bytes[3] & 0xC0) != 0x80) return false; bytes += 4; }
    else return false;
  }
  return true;
}

void win1250ToUtf8(String& input)
{
  String output = "";
  const uint8_t* bytes = (const uint8_t*)input.c_str();
  while (*bytes) {
    uint8_t c = *bytes++;
    switch (c) {
      case 0xA5: output += "Ą"; break; case 0xB9: output += "ą"; break;
      case 0xC6: output += "Ć"; break; case 0xE6: output += "ć"; break;
      case 0xCA: output += "Ę"; break; case 0xEA: output += "ę"; break;
      case 0xA3: output += "Ł"; break; case 0xB3: output += "ł"; break;
      case 0xD1: output += "Ń"; break; case 0xF1: output += "ń"; break;
      case 0xD3: output += "Ó"; break; case 0xF3: output += "ó"; break;
      case 0x8C: output += "Ś"; break; case 0x9C: output += "ś"; break;
      case 0x8F: output += "Ź"; break; case 0x9F: output += "ź"; break;
      case 0xAF: output += "Ż"; break; case 0xBF: output += "ż"; break;
      default: output += (char)c; break;
    }
  }
  input = output;
}

bool isAudioFile(const String& fileName)
{
  return evo43IsAudioFile(fileName);
}

void scanDirectory(const String& path, int& fileCount)
{
  String oldDir = evo43CurrentDir;
  evo43CurrentDir = evo43NormalizePath(path);
  evo43MarkFilesDirty();
  evo43ScanCurrentDir();
  fileCount = evo43TrackCount;
  evo43CurrentDir = oldDir;
  evo43MarkFilesDirty();
}

void loadTracksFromSD()
{
  evo43CurrentDir = "/";
  evo43MarkFilesDirty();
  evo43ScanCurrentDir();
  sdPlayerScanRequested = false;
  evo43LastAction = String("SD TRACKS ") + String(evo43TrackCount);
}

void saveSDPlayerSessionState()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  File f = STORAGE.open("/sdplayer_session.txt", FILE_WRITE);
  if (!f) return;
  f.println(evo43CurrentDir);
  f.println(evo43SelectedTrack);
  f.println(evo43CurrentTrack);
  f.close();
#endif
}

void loadSDPlayerSessionState()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  if (!STORAGE.exists("/sdplayer_session.txt")) return;
  File f = STORAGE.open("/sdplayer_session.txt", FILE_READ);
  if (!f) return;
  String dir = f.readStringUntil('\n'); dir.trim();
  String idx = f.readStringUntil('\n'); idx.trim();
  String trk = f.readStringUntil('\n'); trk.trim();
  if (dir.length()) evo43CurrentDir = evo43NormalizePath(dir);
  evo43SelectedTrack = constrain(idx.toInt(), 0, EVO43_MAX_TRACKS - 1);
  evo43CurrentTrack = trk;
  f.close();
  evo43MarkFilesDirty();
#endif
}

void clearSDPlayerSessionCompleted()
{
#if defined(USE_SD) || defined(AUTOSTORAGE)
  if (STORAGE.exists("/sdplayer_session.txt")) STORAGE.remove("/sdplayer_session.txt");
#endif
}

void SDPlayerOLED_init()
{
  sdPlayerActive = true;
  sdPlayerOLEDActive = true;
  loadSDPlayerSessionState();
  evo43ScanCurrentDir();
  evo43LastAction = "SD PLAYER INIT";
}

void SDPlayerOLED_loop()
{
  if (sdPlayerScanRequested) {
    evo43MarkFilesDirty();
    evo43ScanCurrentDir();
    sdPlayerScanRequested = false;
  }
  sdPlayerPlayingMusic = evo43SdPlaying;
}

void SDPlayerWebUI_registerHandlers(AsyncWebServer& srv)
{
  (void)srv;
  // W V7/V46 trasy SDPlayer rejestruje evo43RegisterFullModHandlers().
}

void SDRecorder_displayCallback(const String& status, const String& time, const String& size)
{
  evo43LastAction = status + " " + time + " " + size;
  Serial.printf("[SDRecorder Display] %s | %s | %s\n", status.c_str(), time.c_str(), size.c_str());
}

void SDRecorder_init()
{
  evo43LastAction = "SD RECORDER INIT";
}

void SDRecorder_loop()
{
  evo43RecorderLoop();
}

void BTWebUI_init()
{
  evo43BtEnsureUart();
  evo43BtLastCmd = "BT INIT";
}

void BTWebUI_loop()
{
  if (evo43BtUartEnabled && Serial2.available()) {
    while (Serial2.available()) {
      char c = (char)Serial2.read();
      evo43BtLog += c;
      if (evo43BtLog.length() > 800) evo43BtLog.remove(0, evo43BtLog.length() - 800);
    }
  }
}

void BTWebUI_registerHandlers(AsyncWebServer& srv)
{
  (void)srv;
  // Trasy /bt sa rejestrowane przez evo43RegisterFullModHandlers().
}

void saveDLNAConfig()
{
  evo43DlnaHost = dlnaHost.length() ? dlnaHost : evo43DlnaHost;
  evo43DlnaIdx = dlnaIDX.length() ? dlnaIDX : evo43DlnaIdx;
  evo43DlnaDescUrl = dlnaDescUrl.length() ? dlnaDescUrl : evo43DlnaDescUrl;
  evo43DlnaSave();
}

void readDLNAConfig()
{
  evo43DlnaLoad();
  dlnaHost = evo43DlnaHost;
  dlnaIDX = evo43DlnaIdx;
  dlnaDescUrl = evo43DlnaDescUrl;
}

void activateDLNAMode()
{
  readDLNAConfig();
  displayMode = 11;
  displayActive = true;
  timeDisplay = false;
  displayStartTime = millis();
  evo43LastAction = "DLNA MODE";
}

void DLNAWebUI_init()
{
  if (g_dlnaHttpMux == NULL) g_dlnaHttpMux = xSemaphoreCreateMutex();
  readDLNAConfig();
  evo43LastAction = "DLNA INIT";
}

void DLNAWebUI_registerHandlers(AsyncWebServer& srv)
{
  (void)srv;
  // Trasy /dlna sa rejestrowane przez evo43RegisterFullModHandlers().
}

void DLNAWebUI_loop()
{
  // Lekki adapter. Rozbudowana logika sieci DLNA z oryginalu zostaje w katalogu legacy_mod_ost_source.
}

void loadWifiNetworks()
{
  evo46WifiLoad();
}

void saveWifiNetworks()
{
  evo46WifiSave();
}

bool connectMultiWifi()
{
  evo46WifiLoad();
  if (evo46WifiCount == 0) return false;
  WiFi.mode(WIFI_STA);
  WiFi.setAutoReconnect(false);
  WiFi.disconnect(false);
  delay(200);
  int scanCount = WiFi.scanNetworks(false, true);
  for (uint8_t i = 0; i < evo46WifiCount; i++) {
    bool visible = (scanCount <= 0);
    for (int s = 0; s < scanCount; s++) {
      if (WiFi.SSID(s) == evo46WifiNetworks[i].ssid) { visible = true; break; }
    }
    if (!visible) continue;
    Serial.println(String("[MultiWiFi] Proba: ") + evo46WifiNetworks[i].ssid);
    WiFi.begin(evo46WifiNetworks[i].ssid.c_str(), evo46WifiNetworks[i].pass.c_str());
    uint32_t start = millis();
    while (WiFi.status() != WL_CONNECTED && millis() - start < 12000) {
      delay(250);
      audio.loop();
    }
    if (WiFi.status() == WL_CONNECTED) {
      Serial.println(String("[MultiWiFi] Polaczono: ") + evo46WifiNetworks[i].ssid + " IP=" + WiFi.localIP().toString());
      return true;
    }
  }
  return false;
}

void performSeekAction(int deltaSeconds)
{
  if (deltaSeconds == 0) return;
  // Adapter zachowuje wejscie z MOD OST.
  // W tej bazie V7 bez klasy SDPlayerWebUI nie wymuszamy seek, bo rozne wersje ESP32-audioI2S maja inne API.
  evo43LastAction = String("SEEK REQUEST ") + String(deltaSeconds) + "s";
}

void updateSpeakersPin()
{
#ifdef SPEAKERS_PIN
  digitalWrite(SPEAKERS_PIN, volumeMute ? LOW : HIGH);
#endif
}

void displayBasicInfo()
{
  displayStartTime = millis();
  timeDisplay = false;
  displayActive = true;
  tftNativeCenterMessage("SYSTEM", String("FW ") + softwareRev);
}

void displayEqualizerFullAdopted()
{
  if (displayMode != 13)
  {
    evoAudioEqReturnDisplayMode = displayMode;
    evoAudioEqReturnModeValid = true;
  }
  displayMode = 13;
  eq16MenuActive = true;
  equalizerMenuEnable = true;
  displayActive = true;
  timeDisplay = false;
  displayStartTime = millis();
  evo43Eq16EditGain = false;
  evo43Eq16OpenPanel();
}

void evoAudioEqRestoreReturnMode()
{
  if (displayMode == 13)
  {
    if (evoAudioEqReturnModeValid && evoAudioEqReturnDisplayMode != 13)
    {
      displayMode = evoAudioEqReturnDisplayMode;
    }
    else
    {
      displayMode = 0;
    }
  }
  eq16MenuActive = false;
  evo43Eq16EditGain = false;
}

void evoAudioEqShowEq3()
{
  evoAudioEqRestoreReturnMode();
  eq16MenuActive = false;
  evo43Eq16EditGain = false;
  displayEqualizer();
}

void evoAudioEqButton()
{
  // AUDIO dziala w petli: pierwsze nacisniecie EQ3, drugie EQ16, kolejne znow EQ3.
  if (equalizerMenuEnable == true)
  {
    if (displayMode == 13 || eq16MenuActive)
    {
      evoAudioEqShowEq3();
    }
    else
    {
      if (!evoAudioEqReturnModeValid)
      {
        evoAudioEqReturnDisplayMode = displayMode;
        evoAudioEqReturnModeValid = true;
      }
      displayEqualizerFullAdopted();
    }
  }
  else
  {
    evoAudioEqReturnDisplayMode = (displayMode == 13) ? 0 : displayMode;
    evoAudioEqReturnModeValid = true;
    evoAudioEqShowEq3();
  }
}

void displayTracks()
{
  displayMode = 19;
  listedTracks = true;
  displayActive = true;
  timeDisplay = false;
  displayStartTime = millis();
  evo43MarkFilesDirty();
  evo43ScanCurrentDir();
}

void vuMeterMode0new()
{
  uint16_t raw = audio.getVUlevel();
  int L = (raw >> 8) & 0xFF;
  int R = raw & 0xFF;
  displayVuL = constrain(L, 0, 255);
  displayVuR = constrain(R, 0, 255);
  peakL = (uint8_t)max((int)peakL, (int)displayVuL);
  peakR = (uint8_t)max((int)peakR, (int)displayVuR);
}

#endif // EVO47_FULL_ADOPTED_ADAPTERS

void setup() 
{
  // --------LED STANDBY dla stanu HIGH w trybie Power ON ----------------
  pinMode(STANDBY_LED, OUTPUT);
  timer4.attach(0.5, updateStandbyLED);  // Ustaw timer4, aby wywoływał miganie LED informujaca o starcie, inicjalizacji radia

  // Inicjalizuj komunikację szeregową (Serial)
  Serial.begin(115200);
  delay(600);
#if defined(ESP32)
  setCpuFrequencyMhz(240);   // AUDIO SAFE: pelna predkosc CPU dla dekodowania 44.1kHz / 256kbps
#endif
  
  uint64_t chipid = ESP.getEfuseMac();
  Serial.println("");
  Serial.println("------------------ START of Evo Web Radio --------------------");
  Serial.println("-                                                            -");
  Serial.printf("--------- ESP32 SN: %04X%08X,  FW Ver.: %s ---------\n",(uint16_t)(chipid >> 32), (uint32_t)chipid, softwareRev);
  Serial.println("-         FW Config  use SD:" + String(useSD) + ",  Use Two Encoders:" + String(use2encoders) + "           -");
  Serial.println("-                                                            -");
  Serial.println("- Code source: https://github.com/dzikakuna/ESP32_radio_evo3 -");
  Serial.println("--------------------------------------------------------------");
  Serial.println("AUDIO SAFE: TFT delta render ON, reduced blocking for 44.1kHz/256kbps streams");
  
  // Ograniczenie pasma ESP32 WiFi do 20MHz
  //esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT40);
  
  #ifdef USE_SD
  // Inicjalizacja SPI z nowymi pinami dla czytnika kart SD
    customSPI.begin(SD_SCLK, SD_MISO, SD_MOSI, SD_CS);  // SCLK = 45, MISO = 21, MOSI = 48, CS = 47
  #endif
  
  //pinMode(SD_SCLK, OUTPUT);
  //digitalWrite(SD_SCLK, LOW);

  psramData = (unsigned char *)ps_malloc(PSRAM_lenght * sizeof(unsigned char));

  if (psramInit()) {
    Serial.println("Pamiec PSRAM zainicjowana poprawnie.");
    Serial.print("Dostepna pamiec PSRAM: ");
    Serial.println(ESP.getPsramSize());
    Serial.print("Wolna pamiec PSRAM: ");
    Serial.println(ESP.getFreePsram());


  } else {
    Serial.println("debug-- BLAD Pamieci PSRAM");
  }

  wifiManager.setHostname(hostname);

  //WiFi.mode(WIFI_STA);
  WiFi.setSleep(false);
  //WiFi.setBandwith(WIFI_BW_HT20);
  //esp_wifi_set_bandwidth(WIFI_IF_STA, WIFI_BW_HT20);




  EEPROM.begin(128);

  // ----------------- Inicjalizacja TAS5805 -----------------
  #ifdef TAS5805
    Wire.begin(I2C_DATA, I2C_CLK);   // inicjalizacja I2C
    Wire.setClock(400000);           // I2C 400kHz
    delay(200);
    tas5805init();
    delay(100);
  #endif

  // ----------------- ENKODER 2 podstaowwy -----------------
  pinMode(CLK_PIN2, INPUT_PULLUP);           // Konfiguruj piny enkodera 2 jako wejścia
  pinMode(DT_PIN2, INPUT_PULLUP); 
  pinMode(SW_PIN2, INPUT_PULLUP);            // Inicjalizacja przycisków enkoderów jako wejścia
  prev_CLK_state2 = digitalRead(CLK_PIN2);   // Odczytaj początkowy stan pinu CLK enkodera
  

  // ----------------- ENKODER 1 dodatkowy (jesli włączony) -----------------
  #ifdef twoEncoders
    pinMode(CLK_PIN1, INPUT_PULLUP);           // Konfiguruj piny enkodera 1 jako wejścia
    pinMode(DT_PIN1, INPUT_PULLUP);
    pinMode(SW_PIN1, INPUT_PULLUP);           // Inicjalizacja przycisków enkoderów jako wejścia
    prev_CLK_state1 = digitalRead(CLK_PIN1);  // Odczytaj początkowy stan pinu CLK enkodera
  #endif  

  // ----------------- SW_POWER dodatkowy (jesli włączony) -----------------
  #ifdef SW_POWER
    pinMode(SW_POWER, INPUT_PULLUP);
  #endif


  // ----------------- LED CS karty SD - klon (jesli włączony) -----------------
  #ifdef SD_LED
    pinMode(SD_LED, OUTPUT);
    //PIN, CLONE PIN, INVERTED, EN_INV -Klonowanie sygnału CS kontrolera VirtualSPI (VSPI) na LED aby miec informacje o aktywnosci karty z czytnika z tyłu PCB
    gpio_matrix_out(SD_LED, SPI3_CS0_OUT_IDX, false, false);
  #endif


  // ----------------- IR ODBIORNIK - Konfiguracja pinu -----------------
  pinMode(recv_pin, INPUT);
  attachInterrupt(digitalPinToInterrupt(recv_pin), pulseISR, CHANGE);


  // ----------------- PRZETWORNIK ADC KLAWIATURA - Konfiguracja -----------------
  analogReadResolution(12);                 // Ustawienie rozdzielczości na 11 bits (zakres 0-4095)
  analogSetAttenuation(ADC_11db);           // Wzmocnienie ADC (0dB dla zakresu 0-3.3V)

  #ifdef I2S_MCLK
    audio.setPinout(I2S_BCLK, I2S_LRC, I2S_DOUT, I2S_MCLK);  // Konfiguruj pinout dla interfejsu I2S audio
  #else
    audio.setPinout(I2S_BCLK, I2S_LRC, I2S_DOUT);  // Konfiguruj pinout dla interfejsu I2S audio
  #endif
  // ESP32-audioI2S z GitHuba: nowe callbacki Audio::msg_t przekierowujemy do istniejącej logiki EVO.
  Audio::audio_info_callback = evoAudioInfoCallback;
  audio.setConnectionTimeout(700, 3000);
  audio.setVolume(0);
  

  // Interfejs SPI wyświetlacza inicjalizuje teraz LovyanGFX.
  // Ta linia zostaje jako zgodność z dotychczasową konfiguracją pinów Arduino SPI.
  SPI.begin(SPI_SCK_OLED, EVO_TFT_MISO, SPI_MOSI_OLED);
  #ifdef LOWNOISESPI // Kontrola driverow wyjsciowych GPIO w celu onizenia EMI
    gpio_set_drive_capability((gpio_num_t)SPI_MOSI_OLED, GPIO_DRIVE_CAP_2);
    gpio_set_drive_capability((gpio_num_t)SPI_SCK_OLED, GPIO_DRIVE_CAP_2);
    gpio_set_drive_capability((gpio_num_t)CS_OLED, GPIO_DRIVE_CAP_1);
    gpio_set_drive_capability((gpio_num_t)DC_OLED, GPIO_DRIVE_CAP_1);
  #endif
  // SPI.setFrequency(2000000);  // Niepotrzebne: częstotliwość ustawia EVO_TFT_SPI_FREQ w LovyanGFX.


  // Inicjalizuj wyświetlacz i odczekaj 250 milisekund na włączenie
  gfx.begin();
  delay(250);

  // ----------------- KARTA SD / PAMIEC SPIFFS/LittleFS - Inicjalizacja -----------------
  // Inicjalizacja STORAGE
  #ifdef AUTOSTORAGE
    if (!initStorage()) 
    {
      while (1);
    }
  #else
    // ----------------- KARTA SD / PAMIEC SPIFFS - Inicjalizacja -----------------
    if (!STORAGE_BEGIN())
    {
      Serial.println("Błąd inicjalizacji pamieci STORAGE!"); // Informacja o problemach lub braku karty SD
      noSDcard = true;                                // Flaga braku karty SD
    }
    else
    {
      Serial.println("Pamiec STORAGE zainicjalizowana pomyślnie.");
      noSDcard = false;
    }
  #endif
  delay(50);
  
  // Odczyt konfiguracji
  readConfig();          
  if (configExist == false) { saveConfig(); readConfig();} // Jesli nie ma pliku config.txt to go tworzymy
  

  if ((esp_reset_reason() != ESP_RST_POWERON) || (!f_sleepAfterPowerFail))
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
    bool evoTftLogoLoaded = loadXBM("/logo.xbm");
    if (!evoTftLogoLoaded) {
      Serial.println("No logo in storage memory, loading notes...");
    } else {
      f_logo = 1;
    }
    tftNativeStartupSplash(evoTftLogoLoaded, softwareRev);
#else
    gfx.clearBuffer();
    if (f_logoSlowBrightness) {gfx.setContrast(0);}

    if (!loadXBM("/logo.xbm")) 
    {
      Serial.println("No logo in storage memory, loading notes...");
      gfx.drawXBMP(0, 5, notes_width, notes_height, notes);  // obrazek - nutki
      gfx.setFont(u8g2_font_fub14_tf);
      gfx.drawStr(38, 17, "Evo Internet Radio");
      gfx.sendBuffer();
    }
    else
    {
      
      gfx.drawXBMP(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT, logo_bits); // obrazek - logo z pamieci
      gfx.sendBuffer();     
      f_logo = 1;
    }   

    // ---- POWOLNE ROZJASNIANIE LOGO NUTKI / WGRANE LOGO ----
    if (f_logoSlowBrightness)
    {
      for (int i = 0; i <= displayBrightness; i++)
        {
          gfx.setContrast(i);
          delay(10); 
        }
      gfx.setContrast(displayBrightness);
    }
     
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(208, 62, softwareRev);
    gfx.sendBuffer();
#endif
  }
  
  #ifndef AUTOSTORAGE
  // Informacja na wyswietlaczu o problemach lub braku karty SD
  if (noSDcard) // flaga noSDcard ustawia sie jesli nie wykryto karty
  {
#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
    tftNativeNoStorageScreen();
#else
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(5, 62, "Error - Please check SD card");
    gfx.setDrawColor(0);
    gfx.drawBox(212, 0, 44, 45);
    gfx.setDrawColor(1);
    gfx.drawXBMP(220, 3, 30, 40, sdcard);  // ikona SD karty
    gfx.sendBuffer();
#endif
  }
  #endif

#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  if ((esp_reset_reason() == ESP_RST_POWERON) && (f_sleepAfterPowerFail)) {
    tftNativeConnectingMessage("Wakeup after power loss, syncing NTP");
  } else if (f_logo) {
    tftNativeConnectingMessage("Evo Web Radio, connecting...");
  } else {
    tftNativeConnectingMessage("Connecting to network...");
  }
#else
  gfx.setFont(spleen6x12PL);
  if ((esp_reset_reason() == ESP_RST_POWERON) && (f_sleepAfterPowerFail)) {gfx.drawStr(5, 50, "Wakeup after power loss, syncing NTP");}
  if (f_logo) {gfx.drawStr(5, 62, "Evo Web Radio, connecting...");} else {gfx.drawStr(5, 62, "Connecting to network...    ");}
  gfx.sendBuffer();
#endif
  //delay(1000); // Popatrzmy dłuzej na nutki lub logo :)
  
  #ifdef twoEncoders
    button1.setDebounceTime(50);  // Ustawienie czasu debouncingu dla przycisku enkodera 2
  #endif

  button2.setDebounceTime(50);  // Ustawienie czasu debouncingu dla przycisku enkodera 2
  

    
  // Inicjalizacja WiFiManagera
  wifiManager.setConfigPortalBlocking(false);

  // ---- ODCZYTY RÓZNYCH USTAWIEN Z KARTY SD / PAMIECI SPIFFS ----
  readStationFromSD();       // Odczytujemy zapisaną ostanią stację i bank z karty SD /EEPROMu
  readEqualizerFromSD();     // Odczytujemy ustawienia filtrów equalizera z karty SD 
  readVolumeFromSD();        // Odczytujemy nastawę ostatniego poziomu głośnosci z karty SD /EEPROMu
  readAdcConfig();           // Odczyt konfiguracji klawitury ADC
  readRemoteControlConfig(); // Odczyt konfiguracji pilota IR
  assignRemoteCodes();       // Przypisanie kodów pilota IR
  readTimezone();
  evoWeatherReadConfig();       // APMS: miejscowosc pogody z /weather_city.txt

  evoAudioApplyVolumeProfile();
  //audio.setVolume(0);                  // Ustaw głośność na podstawie wartości zmiennej volumeValue w zakresie 0...21
  
  // ----------------- EKRAN - JASNOŚĆ -----------------
  gfx.setContrast(displayBrightness); 

  // -------------------- RECOVERY MODE --------------------
  recoveryModeCheck();
  
  previous_bank_nr = bank_nr;  // wyrównanie wartości przy stacie radia aby nie podmienic bank_nr na wartość 0 po pierwszym upływie czasu menu
  Serial.print("debug1...wartość bank_nr:");
  Serial.println(bank_nr);
  Serial.print("debug1...wartość previous_bank_nr:");
  Serial.println(previous_bank_nr);
  Serial.print("debug1...wartość station_nr:");
  Serial.println(station_nr);

  // Rozpoczęcie konfiguracji Wi-Fi i połączenie z siecią, jeśli konieczne
  if (wifiManager.autoConnect("EVO-Radio")) 
  {
    Serial.println("Połączono z siecią WiFi");
    currentIP = WiFi.localIP().toString();  //konwersja IP na string
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(5, 62, "                               ");  // czyszczenie lini spacjami
    gfx.sendBuffer();
    gfx.drawStr(5, 62, "Connected, IP:");  //wyswietlenie IP
    gfx.drawStr(90, 62, currentIP.c_str());   //wyswietlenie IP
    gfx.sendBuffer();
    delay(1000);  // odczekaj 1 sek przed wymazaniem numeru IP
    
    if (MDNS.begin(hostname)) { Serial.println("mDNS wystartowal, adres: " + String(hostname) + ".local w przeglądarce"); MDNS.addService("http", "tcp", 80);}
        
    //configTzTime("CET-1CEST,M3.5.0/2,M10.5.0/3", ntpServer1, ntpServer2);
    configTzTime(timezone.c_str(), ntpServer1, ntpServer2);
    struct tm timeinfo;
    int retry = 0;
    Serial.println("debug RTC -> synchronizacja NTP pierwszy raz od startu");
    while (!getLocalTime(&timeinfo) && retry < 10) 
    {
      Serial.println("debug RTC -> Czekam na synchronizację czasu NTP...");
      delay(1000);
      retry++;
    }


    timer1.attach(0.5, updateTimerFlag);  // Ustaw timer, aby wywoływał funkcję updateTimer
    //timer1.attach(0.7, updateTimerFlag);  // Ustaw timer, aby wywoływał funkcję updateTimer
    timer2.attach(1, displayDimmerTimer);
    //timer3.attach(60, sleepTimer);   // Ustaw timer3,

    if ((esp_reset_reason() == ESP_RST_POWERON) && (f_sleepAfterPowerFail)) // sprawdzamy czy radio wlaczylo sie po braku zasilania jesli tak to idziemy do spania gdy zasilanie powroci
    {
      Serial.println("debug PWR -> power OFF po powrocie zasilania");
      Serial.print("debug PWR -> Funkcja zegara f_displayPowerOffClock: ");
      Serial.println(f_displayPowerOffClock);
      //prePowerOff();
      powerOff();
    }


    uint8_t temp_station_nr = station_nr; // Chowamy na chwile odczytaną stacje z karty SD aby podczas ładowania banku nie zmienic ostatniej odtwarzanej stacji
    fetchStationsFromServer();            // Ładujemy liste stacji z karty SD  lub serwera GitHub
    station_nr = temp_station_nr ;        // Przywracamy numer po odczycie stacji
    changeStation();                      // Ustawiamy stację
    
    // ########################################### WEB Server ######################################################
    DefaultHeaders::Instance().addHeader("Access-Control-Allow-Origin", "*");
    
    server.on("/", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      // APMS WEB STABLE FIX: zwykly send(), bez streamu i bez WebSocket.
      // Ta metoda dziala stabilniej z roznych wersjami ESPAsyncWebServer.
      request->send(200, "text/html; charset=utf-8", evoWebBuildMainPage());
    });

    server.on("/radio", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      request->send(200, "text/html; charset=utf-8", evoWebBuildMainPage());
    });

    server.on("/apms", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      request->send(200, "text/html; charset=utf-8", evoWebBuildMainPage());
    });

    server.on("/favicon.ico", HTTP_GET, [](AsyncWebServerRequest *request){
          request->send(STORAGE, "/favicon.ico", "image/x-icon");       
    });
    
    server.on("/icon.png", HTTP_GET, [](AsyncWebServerRequest *request){
        request->send(STORAGE, "/icon.png", "image/png");       
    });

        server.on("/favicon.ico", HTTP_GET, [](AsyncWebServerRequest *request){
          request->send(STORAGE, "favicon.ico", "image/x-icon");       
    });
    
    server.on("/icon.png", HTTP_GET, [](AsyncWebServerRequest *request){
        request->send(STORAGE, "icon.png", "image/png");       
    });

    server.on("/menu", HTTP_GET, [](AsyncWebServerRequest *request){   
      String html = String(menu_html);
      request->send(200, "text/html", html);
    });
    
    server.on("/firmwareota", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      request->send(200, "text/plain", "Update done");
    },
    [](AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final) 
    {

      static size_t total = 0;
      static size_t contentLength = 0;
      static unsigned long lastPrint = 0;

      if (index == 0) 
      {
        // Tylko przy pierwszym pakiecie
        Serial.printf("OTA Start: %s\n", filename.c_str());
        total = 0;
        contentLength = request->contentLength();  // pełna długość pliku
        lastPrint = millis();

        size_t sketchSpace = (ESP.getFreeSketchSpace() - 0x1000) & 0xFFFFF000;

        if (contentLength > sketchSpace) 
        {
          Serial.printf("Error: firmware too big (%u > %u bytes)\n", contentLength, sketchSpace);
          return;
        }

        if (!Update.begin(sketchSpace)) 
        {
          Update.printError(Serial);
          return;
        }
      }

      if (Update.write(data, len) != len) 
      {
        Update.printError(Serial);
      } 
      else 
      {
        total += len;
          
        // Wyświetlaj pasek postępu co 300 ms
        unsigned long now = millis();
        if (now - lastPrint >= 200 || final) 
        {     
          int percent = (total * 100) / contentLength;
          Serial.printf("Progress: %d%% (%u/%u bytes)\n", percent, total, contentLength);
          gfx.setCursor(5, 24); gfx.print("File: " + String(filename));
          gfx.setCursor(5, 36); gfx.print("Flashing... " + String(total / 1024) + " KB");
          gfx.sendBuffer();
          lastPrint = now;
        }
      }
      if (final) 
      {
        if (Update.end(true)) 
        {
          request->send(200, "text/plain", "Update done - reset in 3sec");
          Serial.println("Update complete");
          gfx.setCursor(5, 48); gfx.print("Completed - reset in 3sec");
          gfx.sendBuffer();
              
          AsyncWebServerRequest *reqCopy = request;
          reqCopy->onDisconnect([]() 
          {
            delay(3000);
            //ESP.restart();
            REG_WRITE(RTC_CNTL_OPTIONS0_REG, RTC_CNTL_SW_SYS_RST);
          });
        } 
        else 
        {
          Update.printError(Serial);
          request->send(500, "text/plain", "Update failed");
        }
      }
    });

    server.on("/editor", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      request->send(STORAGE, "/editor.html", "text/html"); //"application/octet-stream");
    });

     server.on("/browser", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      request->send(STORAGE, "/browser.html", "text/html"); //"application/octet-stream");
    });

    server.on("/ota", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      
      timeDisplay = false;
      displayActive = true;
      fwupd = true;
           
      ws.closeAll();
      ws.cleanupClients();
      audio.stopSong();

      delay(250);
      if (!f_saveVolumeStationAlways){saveStationOnSD(); saveVolumeOnSD();}
      
      for (int i = 0; i < 3; i++) 
      {
        gfx.clearBuffer();
        delay(25);
      }        
      unsigned long now = millis();
      gfx.clearBuffer();
      gfx.setDrawColor(1);
      gfx.setFont(spleen6x12PL);     
      gfx.setCursor(5, 12); gfx.print("Evo Radio, OTA Firwmare Update");
      gfx.sendBuffer();

      request->send(200, "text/html", String(ota_html));
      //request->send(SD, "/ota.html", "text/html"); //"application/octet-stream");
    });

    server.on("/page1", HTTP_GET, [](AsyncWebServerRequest *request)
    { // Strona do celow testowych ladowana ze STORAGE (karty Sd lub pamieci FS)
      request->send(STORAGE, "/page1.html", "text/html"); //"application/octet-stream");
    });

    server.on("/playurl", HTTP_GET, [](AsyncWebServerRequest *request)
    { 
      //String html =""; 
      //String finalhtml = String(urlplay_html);  // Składamy cześć stałą html z częscią generowaną dynamicznie
      //request->send(200, "text/html", finalhtml);
      request->send(200, "text/html", String(urlplay_html));
      //request->send(STORAGE, "/playurl.html", "text/html");
    });

    server.on("/edit", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      if (!request->hasParam("filename")) 
      {
          request->send(400, "text/plain", "Brak parametru filename");
          return;
      }

      String filename = request->getParam("filename")->value();
      if (!filename.startsWith("/")) { filename = "/" + filename;}
      File file = STORAGE.open(filename, FILE_READ);
      if (!file) {
          request->send(404, "text/plain", "Nie można otworzyć pliku");
          return;
      }

      String html = "<html><head><title>Edit File</title></head><body>";
      html += "<h2 style='font-size: 1.3rem;'>Editing: " + filename + "</h2>";
      html += "<form method='POST' action='/save'>";
      html += "<input type='hidden' name='filename' value='" + filename + "'>";
      html += "<textarea name='content' rows='100' cols='130'>";

      while (file.available()) 
      {
          html += (char)file.read();
      }

      file.close();

      html += "</textarea><br>";
      html += "<input type='submit' value='Save'>";
      html += "</form>";
      html += "<p><a href='/list'>Back to list</a></p>";
      html += "</body></html>";

      request->send(200, "text/html", html);
    });

    server.on("/save", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      if (!request->hasParam("filename", true) || !request->hasParam("content", true)) 
      {
        request->send(400, "text/plain", "Brakuje danych");
        return;
      }

      String filename = request->getParam("filename", true)->value();
      String content = request->getParam("content", true)->value();

      File file = STORAGE.open(filename, FILE_WRITE);
      if (!file) 
      {
        request->send(500, "text/plain", "Nie można zapisać pliku");
        return;
      }

      file.print(content);
      file.close();

      request->send(200, "text/html", "<p>File Saved!</p><p><a href='/list'>Back to list</a></p>");
    });

    server.on("/list", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      String html = String(list_html) + String("\n");
      
      //html += "<body><h2 style='font-size: 1.3rem;'>Evo Web Radio - SD / SPIFFS:</h2>" + String("\n");
      html += "<body><h2 style='font-size: 1.3rem;'>Evo Web Radio - ";
      html += storageTextName;
      html += "</h2>" + String("\n");
      
      //if (useSD) html += "<body><h2 style='font-size: 1.3rem;'>Evo Web Radio - SD card:</h2>" + String("\n");
      //else html += "<body><h2 style='font-size: 1.3rem;'>Evo Web Radio - SPIFFS memory:</h2>" + String("\n");

      html += "<form action=\"/upload\" method=\"POST\" enctype=\"multipart/form-data\">";
      html += "<input type=\"file\" name=\"file\">";
      html += "<input type=\"submit\" value=\"Upload\">";
      html += "</form>";
      html += "<div class=\"columnlist\">" + String("\n");
      html += "<table><tr><th>File</th><th>Size (Bytes)</th><th>Action</th></tr>";

      listFiles("/", html);
      html += "</table></div>";
      html += "<p style='font-size: 0.8rem;'><a href='/menu'>Go Back</a></p>" + String("\n"); 
      html += "</body></html>";     
      request->send(200, "text/html", html);
    });

    server.on("/delete", HTTP_POST, [](AsyncWebServerRequest *request) {
    String filename = "/"; // Dodajemy sciezke do głownego folderu
      if (request->hasParam("filename", true)) {
        filename += request->getParam("filename", true)->value();
        if (STORAGE.remove(filename.c_str())) {
            Serial.println("Plik usunięty: " + filename);
        } else {
            Serial.println("Nie można usunąć pliku: " + filename);
        }
      }
      request->redirect("/list"); // Przekierowujemy na stronę listy
    });

      server.on("/config", HTTP_GET, [](AsyncWebServerRequest *request) {
        //String html = String(config_html);
        String html = FPSTR(config_html);  // czyta z PROGMEM

        // liczby
        html.replace(F("%D10"), String(vuRiseSpeed));
        html.replace(F("%D11"), String(vuFallSpeed));
        html.replace(F("%D12"), String(dimmerSleepDisplayBrightness));
        html.replace(F("%D46VU"), String(evo46VuDrive));
        html.replace(F("%D46AST"), String(evo46AnalyzerStyles));
        html.replace(F("%D46APR"), String(evo46AnalyzerPreset));
        html.replace(F("%D46BTV"), String(evo46BtVolume));
        
        html.replace(F("%D1"), String(displayBrightness));
        html.replace(F("%D2"), String(dimmerDisplayBrightness));
        html.replace(F("%D3"), String(displayAutoDimmerTime));
        html.replace(F("%D4"), String(vuMeterMode));
        html.replace(F("%D5"), String(encoderFunctionOrder));
        html.replace(F("%D6"), String(displayMode));
        html.replace(F("%D7"), String(vuMeterRefreshTime));
        html.replace(F("%D8"), String(scrollingRefresh));
        html.replace(F("%D9"), String(displayPowerSaveTime));
        html.replace(F("%WEATHER_CITY"), evoWeatherCityDisplayName(evoWeatherCity));

        //Opcje CheckBox
        html.replace(F("%S11_checked"), maxVolumeExt ? " checked" : "");
        html.replace(F("%S13_checked"), vuPeakHoldOn ? " checked" : "");
        html.replace(F("%S15_checked"), vuSmooth ? " checked" : "");
        html.replace(F("%S17_checked"), stationNameFromStream ? " checked" : "");
        html.replace(F("%S19_checked"), f_displayPowerOffClock ? " checked" : "");
        html.replace(F("%S21_checked"), f_sleepAfterPowerFail ? " checked" : "");
        html.replace(F("%S22_checked"), f_volumeFadeOn ? " checked" : "");
        html.replace(F("%S23_checked"), f_saveVolumeStationAlways ? " checked" : "");
        html.replace(F("%S24_checked"), f_powerOffAnimation ? " checked" : "");
        html.replace(F("%S25_checked"), f_Presets ? " checked" : "");        

        html.replace(F("%S1_checked"), displayAutoDimmerOn ? " checked" : "");
        html.replace(F("%S3_checked"), timeVoiceInfoEveryHour ? " checked" : "");
        html.replace(F("%S5_checked"), vuMeterOn ? " checked" : "");
        html.replace(F("%S7_checked"), adcKeyboardEnabled ? " checked" : "");
        html.replace(F("%S9_checked"), displayPowerSaveEnabled ? " checked" : "");
        html.replace(F("%S46AON_checked"), evo46AnalyzerEnabled ? " checked" : "");
        html.replace(F("%S46BT_checked"), evo43BtUartEnabled ? " checked" : "");
        for (int i = 1; i <= 14; i++) {
          String token = String("%S46SD") + String(i) + String("_checked");
          html.replace(token, evo46SdPlayerStyleEnabled[i] ? " checked" : "");
        }
              

        request->send(200, "text/html", html);
      });

    server.on("/adc", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      String html = String(adc_html);
      html.replace("%D10", String(keyboardButtonThreshold_Ok).c_str());
      html.replace("%D11", String(keyboardButtonThreshold_BankMenu).c_str()); 
      html.replace("%D12", String(keyboardButtonThreshold_Back).c_str()); 
      html.replace("%D13", String(keyboardButtonThreshold_DisplayMode).c_str()); 
      html.replace("%D14", String(keyboardButtonThreshold_Dimmer).c_str()); 
      html.replace("%D15", String(keyboardButtonThreshold_Mute).c_str()); 
      html.replace("%D16", String(keyboardButtonThresholdTolerance).c_str()); 
      html.replace("%D17", String(keyboardButtonNeutral).c_str());
      html.replace("%D18", String(keyboardSampleDelay).c_str()); 

      html.replace("%D19", String(keyboardButtonThreshold_ArrowLeft).c_str()); 
      html.replace("%D20", String(keyboardButtonThreshold_ArrowRight).c_str()); 
      html.replace("%D21", String(keyboardButtonThreshold_ArrowUp).c_str()); 
      html.replace("%D22", String(keyboardButtonThreshold_ArrowDown).c_str()); 

      html.replace("%D23", String(keyboardButtonThreshold_PresetsOn).c_str()); 
      

      html.replace("%D0", String(keyboardButtonThreshold_0).c_str()); 
      html.replace("%D1", String(keyboardButtonThreshold_1).c_str()); 
      html.replace("%D2", String(keyboardButtonThreshold_2).c_str()); 
      html.replace("%D3", String(keyboardButtonThreshold_3).c_str()); 
      html.replace("%D4", String(keyboardButtonThreshold_4).c_str()); 
      html.replace("%D5", String(keyboardButtonThreshold_5).c_str()); 
      html.replace("%D6", String(keyboardButtonThreshold_6).c_str()); 
      html.replace("%D7", String(keyboardButtonThreshold_7).c_str()); 
      html.replace("%D8", String(keyboardButtonThreshold_8).c_str()); 
      html.replace("%D9", String(keyboardButtonThreshold_9).c_str()); 
      
      request->send(200, "text/html", html);
    });


    //server.on("/remoteconfigupdate", HTTP_POST, handleRemoteConfigUpdate);
    server.on("/remoteconfigupdate", HTTP_POST, [](AsyncWebServerRequest *request)
    {
      if (request->hasParam("cmdVolumeUp", true))   {configRemoteArray[0] = strtol(request->getParam("cmdVolumeUp", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdVolumeDown", true)) {configRemoteArray[1] = strtol(request->getParam("cmdVolumeDown", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdArrowRight", true)) {configRemoteArray[2] = strtol(request->getParam("cmdArrowRight", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdArrowLeft", true))  {configRemoteArray[3] = strtol(request->getParam("cmdArrowLeft", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdArrowUp", true))    {configRemoteArray[4] = strtol(request->getParam("cmdArrowUp", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdArrowDown", true))  {configRemoteArray[5] = strtol(request->getParam("cmdArrowDown", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdBack", true)) {configRemoteArray[6] = strtol(request->getParam("cmdBack", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdOk", true)) {configRemoteArray[7] = strtol(request->getParam("cmdOk", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdSrc", true)) {configRemoteArray[8] = strtol(request->getParam("cmdSrc", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdMute", true)) {configRemoteArray[9] = strtol(request->getParam("cmdMute", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdAud", true)) {configRemoteArray[10] = strtol(request->getParam("cmdAud", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdDirect", true)) {configRemoteArray[11] = strtol(request->getParam("cmdDirect", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdBankMinus", true)) {configRemoteArray[12] = strtol(request->getParam("cmdBankMinus", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdBankPlus", true)) {configRemoteArray[13] = strtol(request->getParam("cmdBankPlus", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdRed", true)) {configRemoteArray[14] = strtol(request->getParam("cmdRed", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdGreen", true)) {configRemoteArray[15] = strtol(request->getParam("cmdGreen", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey0", true)) {configRemoteArray[16] = strtol(request->getParam("cmdKey0", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey1", true)) {configRemoteArray[17] = strtol(request->getParam("cmdKey1", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey2", true)) {configRemoteArray[18] = strtol(request->getParam("cmdKey2", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey3", true)) {configRemoteArray[19] = strtol(request->getParam("cmdKey3", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey4", true)) {configRemoteArray[20] = strtol(request->getParam("cmdKey4", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey5", true)) {configRemoteArray[21] = strtol(request->getParam("cmdKey5", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey6", true)) {configRemoteArray[22] = strtol(request->getParam("cmdKey6", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey7", true)) {configRemoteArray[23] = strtol(request->getParam("cmdKey7", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey8", true)) {configRemoteArray[24] = strtol(request->getParam("cmdKey8", true)->value().c_str(), NULL, 16);}
      if (request->hasParam("cmdKey9", true)) {configRemoteArray[25] = strtol(request->getParam("cmdKey9", true)->value().c_str(), NULL, 16);}

      /*
      for (uint8_t i = 0; i < CONFIGREMOTE_COUNT; i++)
      {
        if (!request->hasArg(remoteMap[i].name)) continue;

        String val = request->arg(remoteMap[i].name);
        val.trim();

        // walidacja HEX 0xFFFF
        if (!val.startsWith("0x")) continue;
        configRemoteArray[i] = strtol(val.c_str(), NULL, 16);
        Serial.printf("%s = 0x%04X\n", remoteMap[i].name, configRemoteArray[i]);
      }
      */
      remoteConfig = false;
      saveRemoteControlConfig();
      readRemoteControlConfig();
      assignRemoteCodes();
      //request->send(200, "text/html", "<h1>Remote Control Config Codes Updated!</h1><a href='/'>Go to Main</a>");
      request->send(200, "text/html", "<!DOCTYPE html><html><head><meta http-equiv='refresh' content='2;url=/'></head><body><h1>Remote Control Config Codes Updated!</h1></body></html>");
      
    });


    server.on("/remoteconfig", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      String html = String(remoteconfig_html);
      
     // for (int i = 25; i >= 0; i--)
     // {
     //   html.replace("%D" + String(i), String(configRemoteArray[i]).c_str());
     // }
      
      for (int i = 25; i >= 0; i--)
      {
        char buf[7];                    // "0xFFFF" + \0
        sprintf(buf, "0x%04X", configRemoteArray[i]);
        html.replace("%D" + String(i), buf);
      }
      
      wsIrCodeClear();
      request->send(200, "text/html", html);
      //request->send(STORAGE, "/remoteconfig.html", "text/html"); //"application/octet-stream");
    });


    server.on("/configadc", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      if (request->hasParam("keyboardButtonThreshold_Ok", true)) {
        keyboardButtonThreshold_Ok = request->getParam("keyboardButtonThreshold_Ok", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThreshold_BankMenu", true)) {
        keyboardButtonThreshold_BankMenu = request->getParam("keyboardButtonThreshold_BankMenu", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThreshold_Back", true)) {
        keyboardButtonThreshold_Back = request->getParam("keyboardButtonThreshold_Back", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThreshold_DisplayMode", true)) {
        keyboardButtonThreshold_DisplayMode = request->getParam("keyboardButtonThreshold_DisplayMode", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThreshold_Dimmer", true)) {
        keyboardButtonThreshold_Dimmer = request->getParam("keyboardButtonThreshold_Dimmer", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThreshold_Mute", true)) {
        keyboardButtonThreshold_Mute = request->getParam("keyboardButtonThreshold_Mute", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonThresholdTolerance", true)) {
        keyboardButtonThresholdTolerance = request->getParam("keyboardButtonThresholdTolerance", true)->value().toInt();
      }
      if (request->hasParam("keyboardButtonNeutral", true)) {
        keyboardButtonNeutral = request->getParam("keyboardButtonNeutral", true)->value().toInt();
      }
      if (request->hasParam("keyboardSampleDelay", true)) {
        keyboardSampleDelay = request->getParam("keyboardSampleDelay", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_0", true)) {
        keyboardButtonThreshold_0 = request->getParam("keyboardButtonThreshold_0", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_1", true)) {
        keyboardButtonThreshold_1 = request->getParam("keyboardButtonThreshold_1", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_2", true)) {
        keyboardButtonThreshold_2 = request->getParam("keyboardButtonThreshold_2", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_3", true)) {
        keyboardButtonThreshold_3 = request->getParam("keyboardButtonThreshold_3", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_4", true)) {
        keyboardButtonThreshold_4 = request->getParam("keyboardButtonThreshold_4", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_5", true)) {
        keyboardButtonThreshold_5 = request->getParam("keyboardButtonThreshold_5", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_6", true)) {
        keyboardButtonThreshold_6 = request->getParam("keyboardButtonThreshold_6", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_7", true)) {
        keyboardButtonThreshold_7 = request->getParam("keyboardButtonThreshold_7", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_8", true)) {
        keyboardButtonThreshold_8 = request->getParam("keyboardButtonThreshold_8", true)->value().toInt();
      } 
      if (request->hasParam("keyboardButtonThreshold_9", true)) {
        keyboardButtonThreshold_9 = request->getParam("keyboardButtonThreshold_9", true)->value().toInt();
      }
      // --- Arrow Left ---
      if (request->hasParam("keyboardButtonThreshold_ArrowLeft", true)) {
        keyboardButtonThreshold_ArrowLeft = request->getParam("keyboardButtonThreshold_ArrowLeft", true)->value().toInt();
      }
      // --- Arrow Right ---
      if (request->hasParam("keyboardButtonThreshold_ArrowRight", true)) {
        keyboardButtonThreshold_ArrowRight = request->getParam("keyboardButtonThreshold_ArrowRight", true)->value().toInt();
      }
      // --- Arrow Up ---
      if (request->hasParam("keyboardButtonThreshold_ArrowUp", true)) {
        keyboardButtonThreshold_ArrowUp = request->getParam("keyboardButtonThreshold_ArrowUp", true)->value().toInt();
      }
      // --- Arrow Down ---
      if (request->hasParam("keyboardButtonThreshold_ArrowDown", true)) {
         keyboardButtonThreshold_ArrowDown = request->getParam("keyboardButtonThreshold_ArrowDown", true)->value().toInt();
      }
      // Preset ON / OFF
      if (request->hasParam("keyboardButtonThreshold_PresetsOn", true)) {
         keyboardButtonThreshold_PresetsOn = request->getParam("keyboardButtonThreshold_PresetsOn", true)->value().toInt();
      }

      

      request->send(200, "text/html", "<h1>ADC Keyboard Thresholds Updated!</h1><a href='/menu'>Go Back</a>");
      
      saveAdcConfig(); 
       
      //ODswiezenie ekranu OLED po zmianach konfiguracji
      ir_code = rcCmdBack; // Udajemy kod pilota Back
      bit_count = 32;
      calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC
    });



    server.on("/weather-refresh", HTTP_GET, [](AsyncWebServerRequest *request)
    {
      evoWeatherMaybeUpdate(true);
      request->send(200, "text/plain; charset=utf-8", evoWeatherLine());
    });

    server.on("/configupdate", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      if (request->hasParam("displayBrightness", true)) { displayBrightness = request->getParam("displayBrightness", true)->value().toInt(); }
      if (request->hasParam("dimmerDisplayBrightness", true)) {dimmerDisplayBrightness = request->getParam("dimmerDisplayBrightness", true)->value().toInt();}
      if (request->hasParam("dimmerSleepDisplayBrightness", true)) {dimmerSleepDisplayBrightness = request->getParam("dimmerSleepDisplayBrightness", true)->value().toInt();}
      if (request->hasParam("displayAutoDimmerTime", true)) {displayAutoDimmerTime = request->getParam("displayAutoDimmerTime", true)->value().toInt();}

      //  CHECKBOXY – ZAWSZE 0 lub 1
      //displayAutoDimmerOn = request->hasParam("displayAutoDimmerOn", true) ? true : false;
      displayAutoDimmerOn        = request->hasParam("displayAutoDimmerOn", true);
      timeVoiceInfoEveryHour     = request->hasParam("timeVoiceInfoEveryHour", true);
      vuMeterOn                  = request->hasParam("vuMeterOn", true);
      adcKeyboardEnabled         = request->hasParam("adcKeyboardEnabled", true);
      displayPowerSaveEnabled    = request->hasParam("displayPowerSaveEnabled", true);
      maxVolumeExt               = request->hasParam("maxVolumeExt", true);
      vuPeakHoldOn               = request->hasParam("vuPeakHoldOn", true);
      vuSmooth                   = request->hasParam("vuSmooth", true);
      f_displayPowerOffClock     = request->hasParam("f_displayPowerOffClock", true);
      f_sleepAfterPowerFail      = request->hasParam("f_sleepAfterPowerFail", true);
      f_volumeFadeOn             = request->hasParam("f_volumeFadeOn", true);
      f_saveVolumeStationAlways  = request->hasParam("f_saveVolumeStationAlways", true);
      f_powerOffAnimation        = request->hasParam("f_powerOffAnimation", true);
      f_Presets                  = request->hasParam("f_Presets", true);

      // Jeśli parametr istnieje checkbox był zaznaczony to TRUE
      // Jeśli go nie ma checkbox nie był zaznaczony to FALSE

      if (request->hasParam("vuMeterMode", true)) {vuMeterMode = request->getParam("vuMeterMode", true)->value().toInt();}
      if (request->hasParam("encoderFunctionOrder", true)) {encoderFunctionOrder = request->getParam("encoderFunctionOrder", true)->value().toInt();}
      if (request->hasParam("displayMode", true)) {displayMode = request->getParam("displayMode", true)->value().toInt();}
      if (request->hasParam("vuMeterRefreshTime", true)) {vuMeterRefreshTime = request->getParam("vuMeterRefreshTime", true)->value().toInt();}
      if (request->hasParam("scrollingRefresh", true)) {scrollingRefresh = request->getParam("scrollingRefresh", true)->value().toInt();}
      if (request->hasParam("displayPowerSaveTime", true)) {displayPowerSaveTime = request->getParam("displayPowerSaveTime", true)->value().toInt();}
      if (request->hasParam("evoWeatherCity", true)) {
        evoWeatherCity = evoWeatherCityDisplayName(request->getParam("evoWeatherCity", true)->value());
        if (evoWeatherCity.length() == 0) evoWeatherCity = "Golotczyzna";
        evoWeatherSaveConfig();
        evoWeatherLastFetchMs = 0;
        evoWeatherText = "czekam na dane pogody";
      }
      if (request->hasParam("vuRiseSpeed", true)) {vuRiseSpeed = request->getParam("vuRiseSpeed", true)->value().toInt();}
      if (request->hasParam("vuFallSpeed", true)) {vuFallSpeed = request->getParam("vuFallSpeed", true)->value().toInt();}
      if (request->hasParam("evo46VuDrive", true)) {evo46VuDrive = evo46ClampU8(request->getParam("evo46VuDrive", true)->value().toInt(), 10, 200);}
      evo46AnalyzerEnabled = request->hasParam("fftAnalyzerOn", true);
      if (request->hasParam("analyzerStyles", true)) {evo46AnalyzerStyles = evo46ClampU8(request->getParam("analyzerStyles", true)->value().toInt(), 0, 2);}
      if (request->hasParam("analyzerPreset", true)) {
        uint8_t oldPreset46 = evo46AnalyzerPreset;
        evo46AnalyzerPreset = evo46ClampU8(request->getParam("analyzerPreset", true)->value().toInt(), 0, 4);
        if (evo46AnalyzerPreset != oldPreset46) { evo46AnalyzerApplyPreset(evo46AnalyzerPreset); evo46AnalyzerStyleSave(); }
      }
      evo43BtUartEnabled = request->hasParam("btUartEnabled", true);
      if (request->hasParam("btVolume", true)) {evo46BtVolume = evo46ClampU8(request->getParam("btVolume", true)->value().toInt(), 0, 42); evo43BtSend(String("VOL ") + String(evo46BtVolume));}
      for (int i = 1; i <= 14; i++) { String k = String("sdPlayerStyle") + String(i); evo46SdPlayerStyleEnabled[i] = request->hasParam(k, true); }
      evo46SystemSave();

      saveConfig();
      readConfig();
      //clearFlags();
      
      //Refresh
      ir_code = rcCmdBack; // Udajemy kod pilota Back
      bit_count = 32;
      calcNec();          // Przeliczamy kod pilota na pełny oryginalny kod NEC

      //request->send(200, "text/html","<h1>Config Updated!</h1><a href='/menu'>Go Back</a>");
      request->send(200, "text/html","<!DOCTYPE html><html><head><meta http-equiv='refresh' content='2;url=/'></head><body><h1>Config Updated!</h1></body></html>");
    });
    
    server.on("/toggleAdcDebug", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      // Przełączanie wartości
      gfx.clearBuffer();
      displayActive = true;
      displayStartTime = millis();
      debugKeyboard = !debugKeyboard;
      //adcKeyboardEnabled = !adcKeyboardEnabled;
      Serial.print("Pomiar wartości ADC ON/OFF:");
      Serial.println(debugKeyboard);
      request->send(200, "text/plain", debugKeyboard ? "1" : "0"); // Wysyłanie aktualnej wartości
      //debugKeyboard = !debugKeyboard;
      
      if (debugKeyboard == 0)
      {
        ir_code = rcCmdBack; // Przypisujemy kod polecenia z pilota
        bit_count = 32; // ustawiamy informacje, ze mamy pelen kod NEC do analizy 
        calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC  
      }
        
    });

    server.on("/toggleRemoteConfig", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      displayActive = true;
      displayStartTime = millis();
      remoteConfig = !remoteConfig;
      if (remoteConfig) {displayCenterBigText("RC Learning Mode ON",46);} else {displayCenterBigText("RC Learning Mode OFF",46);}
      
      Serial.print("Nauka pilota RC - ON/OFF:");
      Serial.println(remoteConfig);
      //if (remoteConfig) wsIrCode(0x0000,0,0); else 
      wsIrCodeClear();
      request->send(200, "text/plain", remoteConfig ? "1" : "0"); // Wysyłanie aktualnej wartości       
    });
    
    server.on("/mute", HTTP_POST, [](AsyncWebServerRequest *request) 
    {
      ir_code = rcCmdMute; // Przypisujemy kod polecenia z pilota
      bit_count = 32; // ustawiamy informacje, ze mamy pelen kod NEC do analizy 
      calcNec();  // przeliczamy kod pilota na kod oryginalny pełen kod NEC 
      request->send(204);       // brak odpowiedzi (204)    
    });
    

    server.on("/view", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      String filename = "/";
      if (request->hasParam("filename")) 
      {
        filename += request->getParam("filename")->value();
        //String fullPath = "/" + filename;

        File file = STORAGE.open(filename);
        if (file) 
        {
            String content = "<html><body><h1>File content: " + filename + "</h1><pre>";
            while (file.available()) {
                content += (char)file.read();
            }
            content += "</pre><a href=\"/list\">Back to list</a></body></html>";
            request->send(200, "text/html", content);
            file.close();
          } 
          else 
          {
            request->send(404, "text/plain", "File not found");
          }
        } 
        else 
        {
        request->send(400, "text/plain", "No file name");
      }
    });
    // Format viewweb ver2 na potrzeby zewnetrznego Edytora Bankow HTML
    server.on("/viewweb2", HTTP_GET, [](AsyncWebServerRequest *request)  
    {
      String filename = "/";
      if (request->hasParam("filename")) 
      {
        filename += request->getParam("filename")->value();
        //String fullPath = "/" + filename;

        File file = STORAGE.open(filename);
        if (file) 
        {
            String content; //= "<html><body>";
            while (file.available()) {
                //line = file.readStringUntil('\n');
                content += file.readStringUntil('\n') + String("\n");
            }
            //content +="</body></html>";
            request->send(200, "text/html", content);
            file.close();
          } 
          else 
          {
            request->send(404, "text/plain", "File not found");
          }
        } 
        else 
        {
        request->send(400, "text/plain", "No file name");
      }
    });
  
    /*
    server.on("/editordata", HTTP_GET, [](AsyncWebServerRequest *request) 
    {
      if (!request->hasParam("filename")) {
          request->send(400, "text/plain", "No file name");
          return;
      }

      String filename = request->getParam("filename")->value();
      File file = STORAGE.open(filename);
      if (!file) {
          request->send(404, "text/plain", "File not found");
          return;
      }

      // Tworzymy odpowiedź strumieniową tekstową
      AsyncWebServerResponse *response = request->beginResponseStream("text/plain");
      AsyncWebServerResponseStream *stream = static_cast<AsyncWebServerResponseStream*>(response);

      while (file.available()) {
          String line = file.readStringUntil('\n');
          stream->print(line + "\n");  // tu działa print
      }

      file.close();
      request->send(response);
    });
    */
    server.on("/editordata", HTTP_GET, [](AsyncWebServerRequest *request) {
    if (!request->hasParam("filename")) {
        request->send(400, "text/plain", "No file name");
        return;
    }

    String filename = "/" + request->getParam("filename")->value();

    File file = STORAGE.open(filename);
    if (!file) {
        request->send(404, "text/plain", "File not found");
        return;
    }

    // Tworzymy strumień odpowiedzi typu text/plain
    AsyncResponseStream *response = request->beginResponseStream("text/plain");

    while (file.available()) {
        String line = file.readStringUntil('\n');
        response->print(line + "\n");  // działa tylko z AsyncResponseStream
    }

    file.close();
    request->send(response);
});



    server.on("/download", HTTP_ANY, [](AsyncWebServerRequest *request) {
      if (request->hasParam("filename")) {
        String filename = request->getParam("filename")->value();
        String fullPath = "/" + filename;
        //String fullPath = filename;

        Serial.println("Pobieranie pliku: " + fullPath);

        File file = STORAGE.open(fullPath);
        //Serial.println("SD: " + SD + "/" + filename);

        if (file) 
        {
            if (file.size() > 0) 
            {         
              request->send(STORAGE, fullPath, "application/octet-stream", true); //"application/octet-stream");"text/plain"
              file.close();
              Serial.println("Plik wysłany: " + filename);
            } 
            else 
            {
              request->send(404, "text/plain", "Plik jest pusty");
            }
        } 
        else 
        {
          Serial.println("Nie znaleziono pliku: " + fullPath);
          request->send(404, "text/plain", "Plik nie znaleziony");
        }
      } 
      else 
      {
        Serial.println("Brak parametru filename");
        request->send(400, "text/plain", "Brak nazwy pliku");
      }
    });
 
    server.on("/upload", HTTP_POST, [](AsyncWebServerRequest *request) {
        request->send(200, "text/plain", "File Uploaded!");
      },
      //nullptr,
      [](AsyncWebServerRequest *request, String filename, size_t index, uint8_t *data, size_t len, bool final) {
      if (!filename.startsWith("/")) {
        filename = "/" + filename;
      }

      Serial.print("Upload File Name: ");
      Serial.println(filename);

      // Otwórz plik na karcie SD
      static File file; // Użyj statycznej zmiennej do otwierania pliku tylko raz
      if (index == 0) {
          file = STORAGE.open(filename, FILE_WRITE);
          if (!file) {
              Serial.println("Failed to open file for writing");
              request->send(500, "text/plain", "Failed to open file for writing");
              return;
          }
      }

      // Zapisz dane do pliku
      size_t written = file.write(data, len);
      if (written != len) {
          Serial.println("Error writing data to file");
          file.close();
          request->send(500, "text/plain", "Error writing data to file");
          return;
      }

      // Jeśli to ostatni fragment, zamknij plik i wyślij odpowiedź do klienta
      if (final) {
          file.close();
          Serial.println("File upload completed successfully.");
          request->send(200, "text/plain", "File upload successful");
      } else {
          Serial.println("Received chunk of size: " + String(len));
      }
    });

    server.on("/update", HTTP_GET, [] (AsyncWebServerRequest *request) {
      if (request->hasParam("url")) 
      {
        String inputMessage = request->getParam("url")->value();
        url2play = inputMessage.c_str();
        urlToPlay = true;
        Serial.println("Odebrany URL: " + inputMessage);
        request->send(200, "text/plain", "URL received");
      } 
      else 
      {
        request->send(400, "text/plain", "Missing URL parameter");
      }  
    });

    server.on("/info", HTTP_GET, [](AsyncWebServerRequest *request) {
      String html = String(info_html);
      String signal = "";
      uint64_t chipid = ESP.getEfuseMac();
      char chipStr[20];
      sprintf(chipStr, "%04X%08X", (uint16_t)(chipid >> 32), (uint32_t)chipid);
      
      html.replace("%D1", String(softwareRev).c_str()); 
      html.replace("%D2", String(hostname).c_str());                
      html.replace("%D3", String(WiFi.RSSI()).c_str()); 
      html.replace("%D4", String(wifiManager.getWiFiSSID()).c_str()); 
      html.replace("%D5", currentIP.c_str()); 
      html.replace("%D6", WiFi.macAddress().c_str()); 
      html.replace("%D7", String(storageTextName).c_str()); 
      //if (useSD) html.replace("%D7", String("SD").c_str()); 
      //else html.replace("%D7", String("SPIFFS").c_str()); 
      html.replace("%D0", chipStr); 
      //f_callInfo = true;
      
      request->send(200, "text/html", html);

    });

    server.on("/timezone", HTTP_GET, [](AsyncWebServerRequest *request){
      //request->send(STORAGE, "/timezone.html", "text/html");
      request->send(200, "text/html", String(timezone_html));
    });

    server.on("/getTZ", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(200, "text/plain", timezone);
    });

    server.on("/setTZ", HTTP_GET, [](AsyncWebServerRequest *request){
      if (!request->hasParam("value")) 
      {
        request->send(400, "text/plain", "Missing timezone value");
        return;
      }

      String newTZ = request->getParam("value")->value();
      newTZ.trim();
      timezone = newTZ;

      saveTimezone(newTZ);

      //configTzTime(timezone.c_str(), "pool.ntp.org", "time.nist.gov");
      configTzTime(timezone.c_str(), ntpServer1, ntpServer2);
      
      request->send(200, "text/plain", "OK");
    });

    // APMS FIX: HTTP API dla strony WWW, gdy WebSocket nie jest dostepny w lokalnym adapterze.
    server.on("/api/state", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(200, "application/json", evoWebStateJson());
    });

    server.on("/api/ping", HTTP_GET, [](AsyncWebServerRequest *request){
      request->send(200, "text/plain", "OK");
    });

    server.on("/webcmd", HTTP_GET, [](AsyncWebServerRequest *request){
      String cmd = request->hasParam("cmd") ? request->getParam("cmd")->value() : String("");
      String val = request->hasParam("value") ? request->getParam("value")->value() : String("");
      evoWebApplyCommand(cmd, val);
      request->send(200, "application/json", evoWebStateJson());
    });

    evo43RegisterFullModHandlers();
    // V47 FULL ADOPTED: inicjalizacja adapterow zgodnosci z EVO3 MOD OST
    SDPlayerOLED_init();
    SDRecorder_init();
    BTWebUI_init();
    DLNAWebUI_init();

    ws.onEvent(onWsEvent);
    server.addHandler(&ws);
    // APMS: onNotFound usuniete - lokalny adapter AsyncWebServer go nie obsluguje.

    server.begin();
    Serial.println("APMS WEB: server HTTP started on port 80");
    Serial.println(String("APMS WEB: open http://") + WiFi.localIP().toString() + "/");
    currentSelection = station_nr - 1; // ustawiamy stacje na liscie na obecnie odtwarzaczną przy starcie radia
    firstVisibleLine = currentSelection + 1; // pierwsza widoczna lina to grająca stacja przy starcie
    if (currentSelection + 1 >= stationsCount - 1) 
    {
      firstVisibleLine = currentSelection - 3;
    }  
    displayRadio();
    ActionNeedUpdateTime = true;
    
    timer4.detach();
    switchOffstartupLED();
    //fadeInVolume
    // Ograniczenie mocy WiFI, wyłaczenie sleep
    //WiFi.setTxPower(WIFI_POWER_8_5dBm);
    //esp_wifi_set_bandwidth(WIFI_IF_AP, WIFI_BW_HT20);
    //WiFi.bandwidth(WIFI_BW_HT20);
  } 
  else 
  {
    timer4.attach(0.2, updateStandbyLED);
    Serial.println("Brak połączenia z siecią WiFi");  // W przypadku braku polaczenia wifi - wyslij komunikat na serial
    gfx.clearBuffer();
    gfx.setFont(spleen6x12PL);
    gfx.drawStr(5, 13, "No network connection");  // W przypadku braku polaczenia wifi - wyswietl komunikat na wyswietlaczu OLED
    gfx.drawStr(5, 26, "Connect to WiFi: ESP Internet Radio");
    gfx.drawStr(5, 39, "Open web page http://192.168.4.1");
    gfx.sendBuffer();
    while(true)
    { 
      wifiManager.process(); 
    

      /*---------------------  FUNKCJA PILOT IR w trybie BRAK WiFI ---------------------*/ 
      if (bit_count == 32) // sprawdzamy czy odczytalismy w przerwaniu pełne 32 bity kodu IR NEC
      {
        if (ir_code != 0) // sprawdzamy czy zmienna ir_code nie jest równa 0
        {
          
          detachInterrupt(recv_pin);            // Rozpinamy przerwanie
          Serial.print("debug IR -> Kod NEC OK:");
          Serial.print(ir_code, HEX);
          ir_code = reverse_bits(ir_code,32);   // Rotacja bitów - zmiana porządku z LSB-MSB na MSB-LSB
          Serial.print("  MSB-LSB: ");
          Serial.print(ir_code, HEX);
        
          uint8_t CMD = (ir_code >> 16) & 0xFF; // Drugi bajt (inwersja adresu)
          uint8_t ADDR = ir_code & 0xFF;        // Czwarty bajt (inwersja komendy)
          
          Serial.print("  ADR:");
          Serial.print(ADDR, HEX);
          Serial.print(" CMD:");
          Serial.println(CMD, HEX);
          ir_code = ADDR << 8 | CMD;      // Łączymy ADDR i CMD w jedną zmienną 0x ADR CMD

          // Info o przebiegach czasowytch kodu pilota IR
          Serial.print("debug IR -> puls 9ms:"); 
          Serial.print(pulse_duration_9ms);
          Serial.print("  4.5ms:");
          Serial.print(pulse_duration_4_5ms);
          Serial.print("  1690us:");
          Serial.print(pulse_duration_1690us);
          Serial.print("  560us:");
          Serial.println(pulse_duration_560us);

          fwupd = false;        // Kasujemy flagę aktulizacji OTA gdyby była ustawiona
          displayPowerSave(0);
          
          if (ir_code == rcCmdPower) 
          {     
            //prePowerOff();
            powerOff();
          }
          else if (ir_code == rcCmdBack)
          {
            displayCenterBigText("RESTART",36);
            delay(2000);
            REG_WRITE(RTC_CNTL_OPTIONS0_REG, RTC_CNTL_SW_SYS_RST); // Restart pełen sprzętowy jak z przycisku reset
          }
                    
          else { Serial.println("Inny przycisk"); }
        }
        else
        {
          Serial.println("Błąd - kod pilota NEC jest niepoprawny!");
          Serial.print("debug-- puls 9ms:");
          Serial.print(pulse_duration_9ms);
          Serial.print("  4.5ms:");
          Serial.print(pulse_duration_4_5ms);
          Serial.print("  1690us:");
          Serial.print(pulse_duration_1690us);
          Serial.print("  560us:");
          Serial.println(pulse_duration_560us);    
        }
        ir_code = 0;
        bit_count = 0;
        attachInterrupt(digitalPinToInterrupt(recv_pin), pulseISR, CHANGE);  
      } 

      /*---------------------  FUNKCJA INFORMACJA O PODLACZENI i RESET ---------------------*/ 
      if (WiFi.status() == WL_CONNECTED)
      {
        timer4.attach(0.5, updateStandbyLED);
        
        displayCenterBigText("CONNECTED",34);
        currentIP = WiFi.localIP().toString();
        showIP(1,51);
        gfx.drawStr(1, 62, "Wait, reseting...");
        gfx.sendBuffer();
        delay(2000);
        REG_WRITE(RTC_CNTL_OPTIONS0_REG, RTC_CNTL_SW_SYS_RST); // Restart pełen sprzętowy jak z przycisku reset
      }
    
    } // Nieskonczona petla z procesowaniem Wifi aby nie przejsc do ekranu radia gdy nie ma Wifi
  }
}
// #######################################################################################  LOOP  ####################################################################################### //
void loop() 
{
  runTime1 = esp_timer_get_time();
  audio.loop();           // Wykonuje główną pętlę dla obiektu audio
#if defined(APMS_LOCAL_ASYNC_WEBSERVER_ADAPTER)
  // Lokalny adapter ESPAsyncWebServer.h pracuje na zwyklym WebServer,
  // wiec musi byc obslugiwany w loop(). Przy prawdziwym ESPAsyncWebServer
  // ten blok sie nie kompiluje i nie powoduje bledu handleClient().
  server.handleClient();
#endif
  evo43FullModLoop();       // EVO3 MOD KOLOR: recorder/web modules
  SDPlayerOLED_loop();      // V47 FULL ADOPTED adapter
  SDRecorder_loop();        // V47 FULL ADOPTED adapter
  BTWebUI_loop();           // V47 FULL ADOPTED adapter
  DLNAWebUI_loop();         // V47 FULL ADOPTED adapter
  button2.loop();         // Wykonuje pętlę dla obiektu button2 (sprawdza stan przycisku z enkodera 2)
  handleButtons();        // Wywołuje dodatkowe funkcję obsługującą przyciski enkoderow
  handleFadeIn();         // Obsługa sciszania stacji przy przełaczaniu

#if (defined(EVO_PANEL_ILI9341) || defined(EVO_PANEL_ILI9488)) && EVO_TFT_NATIVE_UI
  // V39: nowe panele 7-14 sa rysowane natywnie przez displayRadioTFT().
  // Nie uruchamiamy dla nich starego scroller/VU OLED, bo to powodowaloby migotanie i nadpisywanie bufora.
  if ((displayMode >= 7) && (displayActive == false) && (fwupd == false))
  {
    displayRadio();
  }
#endif
  
  #ifdef SERIALCOM
    handleSerialRX();
  #endif
  
#if EVO_AUDIO_PRIORITY_MODE
  static uint8_t audioYieldCounter = 0;
  if (++audioYieldCounter >= EVO_AUDIO_LOOP_YIELD_EVERY)
  {
    audioYieldCounter = 0;
    vTaskDelay(1);        // AUDIO SAFE: oddajemy czas rzadko, nie blokujemy audio.loop() co kazda petle
  }
#else
  vTaskDelay(2);          // Krótkie opóźnienie, oddaje czas procesora innym zadaniom
#endif
  
  /*---------------------  FUNKCJA PILOT IR  / Obsluga pilota IR w kodzie NEC ---------------------*/ 
  handleRemote();         

  /*-- FUNKCJA KLAWIATURA / Odczyt stanu klawiatura ADC pod GPIO 9 ---------------------*/
  if ((millis() - keyboardLastSampleTime >= keyboardSampleDelay) && (adcKeyboardEnabled)) // Sprawdzenie ADC - klawiatury 
  {
    keyboardLastSampleTime = millis();
    handleKeyboard();
  }
    
  /*-- ENKODER 1 - obsluga opcjonlanego enkodera 1 ---------------------*/
  #ifdef twoEncoders
    button1.loop();
    handleEncoder1();
  #endif

  /*-- ENKODER 2 - Podstaowy, obsluga enkodera 2 ---------------------*/
  if (encoderFunctionOrder) { handleEncoder2StationsVolumeClick();} else {handleEncoder2VolumeStationsClick();}


  //if (encoderFunctionOrder == 0) { handleEncoder2VolumeStationsClick(); } 
  //else if (encoderFunctionOrder == 1) { handleEncoder2StationsVolumeClick(); }
  
  // Obsługa przycisku Power ON/OFF
  #ifdef SW_POWER
    if (digitalRead(SW_POWER) == LOW) {powerOff();}
  #endif

  /*---------------------  FUNKCJA DIMMER ---------------------*/
  if ((displayActive == true) && (displayDimmerActive == true) && (fwupd == false)) {displayDimmer(0);}  

  /*---------------------  FUNKCJA BACK / POWROTU ze wszystkich opcji Menu, Ustawien, itd ---------------------*/
  if ((fwupd == false) && (displayActive) && (millis() - displayStartTime >= displayTimeout))  // Przywracanie poprzedniej zawartości ekranu po 6 sekundach
  {
    if (volumeBufferValue != volumeValue && f_saveVolumeStationAlways) { saveVolumeOnSD(); }    
    if ((rcInputDigitsMenuEnable == true) && (station_nr != stationFromBuffer)) { changeStation(); }  // Jezeli nastapiła zmiana numeru stacji to wczytujemy nową stacje
    
    displayDimmer(0); 
    clearFlags();
    displayRadio();
    gfx.sendBuffer();
    
    // Przywracamy zaznaczenie obecnie grajacej stacji
    currentSelection = station_nr - 1; 
    //if (maxSelection() - currentSelection < maxVisibleLines) {firstVisibleLine = maxSelection() - 3;} else {firstVisibleLine = currentSelection;}
  }


  /*---------------------  FUNKCJA PETLI MILLIS SCROLLER / Odswiezanie VU Meter, Time, Scroller, OLED, WiFi ver. 1 ---------------------*/ 
  if ((millis() - scrollingStationStringTime > scrollingRefresh) && (displayActive == false) && (displayMode <= 6)) 
  {
    scrollingStationStringTime = millis();
    
    if (ActionNeedUpdateTime == true) // Aktualizacja zegara, zegar głosowy, debug Audio, sygnał wifi 
    {
      ActionNeedUpdateTime = false;
      updateTime();
  
      if (f_requestVoiceTimePlay == true) // Zegar głosowy, sprawdzamy czy została ustawiona flaga zegara przy pełnej godzinie
      {
        f_requestVoiceTimePlay = false;
        voiceTime();
      }

      if (debugAudioBuffor == true) {bufforAudioInfo();}
      
      if ((displayMode == 0) || (displayMode == 2))  {drawSignalPower(210,63,0,1);}
      if ((displayMode == 1) && (volumeMute == false)) {drawSignalPower(244,47,0,1);}
      if (displayMode == 3) {drawSignalPower(209,10,0,1);}


      if (wifiSignalLevel != wifiSignalLevelLast) {wifiSignalLevelLast = wifiSignalLevel; wsSignalLevel();}


      if ((f_audioInfoRefreshStationString == true) && (displayActive == false)) // Zmiana streamtitle - wymaga odswiezenia na wyswietlaczu
      { 
        f_audioInfoRefreshStationString = false; //NewAudioInfoSSF
        stationStringFormatting(); // Formatujemy StationString do wyswietlenia przez Scroller
      } 

      if ((f_audioInfoRefreshDisplayRadio == true) && (displayActive == false)) //&& (f_requestVoiceTimePlay == false) Zmiana bitrate - wymaga odswiezenia na wyswietlaczu
      { 
        f_audioInfoRefreshDisplayRadio = false;
        ActionNeedUpdateTime = true;
        displayRadio();
      } 
      
      if (wsAudioRefresh == true) // Web Socket StremInfo wymaga odswiezenia
      {
        wsAudioRefresh = false;
        wsStreamInfoRefresh();
      }
      
    }

    if (volumeMute == false) // Jezeli mute OFF to rysujemy VU
    {
      if (vuMeterOn)
      { 
        if (displayMode == 0) {vuMeterMode0();}
        if (displayMode == 3) {vuMeterMode3();}
        if (displayMode == 4) 
        {
          vuMeterMode4(); 
          if (debugAudioBuffor) // Wskaznik bufora audio w trybie wskaznikow analogowych
          {
            for (int i = 0; i < 10; i++) 
            {
              int y = 1 + (9 - i) * 6; 
              if (audioBufferTime > i) { gfx.drawBox(126, y, 8, 5);} else {gfx.drawFrame(126, y, 8, 5);}
            }
          }
        }
        if (displayMode == 5) {vuMeterMode5();}
        if (displayMode == 7) {vuMeterMode7();}
      }
      else if (displayMode == 0) {showIP(1,47);} //y = vuRy
    }
    else // Jesli MUTE to zamiast VU wprowadzamy napis MUTE na ekran
    {
      gfx.setDrawColor(0);
      if (displayMode == 0) {gfx.drawStr(0,48, "> MUTED <");}
      if (displayMode == 1) {gfx.drawStr(200,47, "> MUTED <");}
      if (displayMode == 2) {gfx.drawStr(0,48, "> MUTED <");}
      if (displayMode == 3) {gfx.drawStr(101,63, "> MUTED <");}
      if (displayMode == 4) {gfx.setDrawColor(1); vuMeterMode4(); gfx.setDrawColor(1); gfx.setFont(spleen6x12PL); gfx.setDrawColor(0); gfx.drawStr(103,57, "> MUTED <");}
      gfx.setDrawColor(1);
    }  

       
    if (urlToPlay == true) // Jesli web serwer ustawił flagę "odtwarzaj URL" to uruchamiamy funkcje odtwarzania z adresu URL wysłanego przez strone WWW
    {
      urlToPlay = false;
      webUrlStationPlay();
      displayRadio();
    }
    
    displayRadioScroller();  // wykonujemy przewijanie tekstu station stringi przygotowujemy bufor ekranu
    gfx.sendBuffer();  // rysujemy całą zawartosc ekranu.
    
    //if (f_callInfo) {f_callInfo = false; displayInfo();}  
    
  }
  //runTime2 = esp_timer_get_time();
  //runTime = runTime2 - runTime1;
}
